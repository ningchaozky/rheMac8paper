#!/usr/bin/perl -w 
#
####################################################
#This script help you get the sort of you taxonomy #
####################################################

if(@ARGV!=2){
print "Usage:\t\nplus.pl xls number\nNumber:\tHow many you want wo left to your imagine\n\n";
}
elsif(@ARGV==2){
my %hash;
open XLS,"$ARGV[0]";
# get taxonomy hash
open TAX,"/home/ningch/data/geneInformation/names.txt";
my %taxonomy;
while (<TAX>){
		if(/scientific\ name$/){
		chomp;
		s/scientific\ name//;
		my @sps = split /\t/,$_,2;
		my $name = $sps[0];
		$taxonomy{$name} = $sps[1];
		}
}
#
while(<XLS>){
s/\t//g;
chomp;
$tax = (split /\|/,$_)[0];
	$hash{$tax}++;
}

@sortKeys = sort {$hash{$b} <=> $hash{$a}} keys %hash;
$nu = $ARGV[1] -1;
chomp $nu;

$sum = 0;
for(values %hash){
	$sum += $_;
}


for(my $i=0;$each= shift @sortKeys,$i<=$nu;$i++){
		chomp $each;
		print "$each\t$hash{$each}\t";
		$num += $hash{$each};
		printf "%.2f",$hash{$each}/$sum;
		print "\t$taxonomy{$each}\n";
}
$others = $sum - $num;
print "others\t";
print "$others\t";
printf "%.2f",$others/$sum;
print "\n";
}

