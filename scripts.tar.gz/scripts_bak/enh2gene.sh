#!/usr/bin/env sh
if [ $# -lt 1 ]; then
	echo $0 peirod''
	exit
fi

echo "ac.distal.dnase_sp.py ac.distal.dnase /dataB/ftp/pub/rheMac3/prefrontal/H3K27ac/entropy/$1 | xargs -0 bash -c"
echo 'bed_peaks_mapping_nearestGene.py -peak ac.distal.dnase.sp -bed /home/ningch/data/genome/rheMac8/exon/ref_ensemble_xeonRefGene.bed > ac.distal.dnase.sp.nearestGene'
echo 'run_kobas_ningch.py -i ac.distal.dnase.sp.nearestGene 4 | xargs -0 bash -c '
echo goBar.py -i ac.distal.dnase.sp.nearestGene.go -k neu  reg -n 200
