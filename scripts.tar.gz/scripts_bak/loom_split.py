#!/usr/bin/env python3
import os
import sys
import numpy as np
import argparse
import loompy
import random
from collections import defaultdict
from ningchao.nSys import trick, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'loom', nargs = '?', help = '')
parser.add_argument( '-cn', nargs = '?', help = 'all cells set 0 default all cells', type = int, required = True )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


ds = loompy.connect(args.loom)
gene_id = ds.ra['Accession']
gene_name = ds.ra['Gene']
CellID = ds.ca['CellID']
if 'ClusterName' not in ds.ca.keys():
    ClusterName = ['' for i in CellID]
else :
    ClusterName = ds.ca['ClusterName']
r,c = ds.shape
if not args.cn:
    outtext = fix.fix( args.loom ).append( ''.join( random.sample( [ chr(i) for i in range(65,91) ], k = 4 ) ), 'all.text')
    if os.path.exists( outtext ):
        print( 'Already exists: {}'.format( outtext ) )
        exit()
    ofh = open( outtext, 'w')
    print ( 'gene_id', *[ '-'.join(i).strip('-') for i in zip(CellID,ClusterName)], sep = '\t', file = ofh )
    for ir in range( r ):
        print ( '-'.join( [ gene_id[ir], gene_name[ir] ] ), *ds[ir, :], sep = '\t', file = ofh )
else :
    cell_combs = list( range( 0, c, args.cn ) )
    cell_combs.append( c -1 )
    for s,e in zip( cell_combs[:-1], cell_combs[1:]):
        num_file = [ s//10000, e//10000 ]
        num_file = '-'.join(map( str, num_file)) +'W'
        outtext = fix.fix( args.loom ).append( num_file,'text')
        if os.path.exists( outtext ):
            exit('Exists: {}'.format(outtext))
        else :
            print ( 'Output:', outtext, 'slice:', s, e )
        ofh = open( outtext, 'w')
        print ( 'gene_id', *[ '-'.join(i).strip('-') for i in zip(CellID[s:e],ClusterName[s:e])], sep = '\t', file = ofh )
        for ir in range(r):
            print ( '-'.join( [ gene_id[ir], gene_name[ir] ] ), *ds[ir, s:e], sep = '\t', file = ofh)

#np.savetxt(outtext, ds[:,:], delimiter = '\t', header = '\t'.join(CellID))
#for ic in range(c):
#    print ( CellID[ic], ClusterName[ic], len(ds[:, ic]))























