#!/usr/bin/env python3
import os
import sys
import math
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import pandas as pd
import matplotlib.pyplot as plt
plt.tight_layout()
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
from collections import defaultdict
import argparse
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'p', nargs='?', help = 'period for the after period compare')
parser.add_argument( 'm', nargs='?', help = 'marker')
parser.add_argument( '-annot', nargs='?', help = 'annot', default = '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.bed')
#parser.add_argument( '-rna', nargs='?', help = 'annot', default = '/dataB/ftp/pub/rheMac3/analysis/RNA/fpkm/fpkm.uniq.mini.d80.dnoExp')
parser.add_argument( '-rna', nargs= 2, help = 'rna cut', default = ['/dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.addsameGene.d80', 1] )
with open("/home/soft/soft/packages/ningchao/scripts/periods.py") as f :
    for line in f:
        if '-a' in line and 'near' in line :
            eval(line)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def get_specific_symbols():
    infor = defaultdict( list )
    periods = 'periods.py {} -a {}'.format( args.p, ' '.join(args.a) )
    cmd = 'project_beds_bws_bams_andSoOn_pos.py bed {} {} 2>/dev/null'
    compare_periods = list(system.run( periods, shell = True ) )
    kwargs.update({ 'compare_periods': compare_periods})
    pbed_raw = list(system.run( cmd.format( args.m, args.p), shell = True ) )[0]
    for p in compare_periods:
        fh = open( fix.fix( args.p ).append('specific.{}'.format(p)), 'w')
        pbed = list(system.run( cmd.format( args.m, p), shell = True ) )[0]
        for line in system.run( 'bedtools intersect -a {} -b {} -v'.format( pbed_raw, pbed ), shell = True):
            line_arr = line.rstrip().split('\t')
            print ( *line_arr[:3], sep = '\t', file = fh )
        fh.close()
        pick_gene = 'bedtools intersect -a {} -b {} -wo'.format( fh.name, args.annot )
        for line in system.run( pick_gene, shell = True):
            line_arr = line.rstrip().split('\t')
            infor[ 'vs'.join([ args.p, p ]) ].append( line_arr[-4].split('.')[0].upper() )
    return infor

def rna_exp():
    infor = defaultdict( list )
    with open( args.rna[0] ) as f :
        header = next(f).rstrip().split('\t')
        header_map = [ system.dir.str_map_period(i) for i in header[1:] ]
        for line in f:
            line_arr = line.rstrip().split('\t')
            symbol = line_arr[0].split('.')[0]
            infor[symbol].append( line )
    for symbol in infor.keys():
        dit = dict( zip( header_map, trick.lst( infor[symbol] ).pick( pt = 'sum' )[1:] ))
        infor[symbol] = dit
    return infor
def pre_data( specific_symbols, exp ):
    lst = []
    for each in specific_symbols:
        symbols = specific_symbols[each]
        for symbol in symbols:
            if symbol in exp:
                val = exp[symbol][args.p]
                if val < args.rna[1] :
                        continue
                lst.append( [ symbol, math.log(1+val), args.p ])
            for p in kwargs.get('compare_periods'):
                if symbol in exp :
                    val = exp[symbol][ p ]
                    if val < args.rna[1] :
                        continue
                    lst.append([ symbol, math.log(1+val), p])
    df = pd.DataFrame( lst, columns = ['symbol', 'val', 'period'] )
    return df

def plot( df ):
    fig = plt.figure( figsize=( 18, 24) )
    ax = sns.violinplot( x='period', y='val', data = df)
    ax.set_ylim([0, 10])
    plt.savefig( 'test.pdf', dpi=250, transparent = True )


if __name__ == '__main__':
    kwargs = vars( args )
    specific_symbols = get_specific_symbols()
    exp = rna_exp()
    df = pre_data( specific_symbols, exp)
    plot( df )













