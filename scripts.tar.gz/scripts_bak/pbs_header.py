#!/usr/bin/env python
import os
import sys
import re
import ningch as nc

def split_to_pbs(bs):
	out,cmd = '',''
	shell = open(bs)
	p = re.compile(r'\n\n',re.M)
	for line in shell:
		cmd += line
	cmd_arr = p.split(cmd)
	p = re.compile(r'\n+',re.M)
	cmd = []
	for each in cmd_arr:
		each = each.rstrip()
		if each == '':
			continue 
		cmd.append(each)
	i = 0
	pbs_name = []
	for each in cmd:
		i += 1
		name = bs.replace('.sh','')+str(i)
		out_file = open('%s_split.pbs' % name,'w')
		pbs_name.append('%s_split.pbs' % name)
		header = '\
\n#PBS -N %s\
\n#PBS -q core24\
\n#PBS -l nodes=1:ppn=%s,mem=%sgb,walltime=1000:00:00\
\n#PBS -j oe\
\n#HSCHED -s hschedd\n' % (name,sys.argv[2],sys.argv[3])
		out_file.write(header)
		out_file.write(each)
		out_file.close()
	return pbs_name



if __name__ == '__main__':
	nc.usage('file:*sh, int:cpu, mem:intGb')
	dsub = open('dsub_%s.sh' % sys.argv[1].replace('.sh',''),'w')
	for each in split_to_pbs(sys.argv[1]):
		print('dsub %s' % each, file=dsub)
	dsub.close()
