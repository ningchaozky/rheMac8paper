#!/usr/bin/env python3
import os
import re
import sys
import argparse
from scipy import stats
from collections import defaultdict
from ningchao.nSys import trick
#from scipy.stats import chi2_contingency
from scipy.stats.distributions import chi2
desc = '''raw data pvalue calculate'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help = 'mat for pvalue calculate')
parser.add_argument('-c', nargs = 2, help = 'c for compare', default = [ 2, 3 ] )
parser.add_argument('-m', choices = ['ttest','chi2'], help = 'c for compare', default = 'ttest' )
parser.add_argument('-fc', nargs='?', help = 'fold change', default = 1.5, type = float )
parser.add_argument('-mincut', nargs = 2, help = 'min signal cut off. header should be same with the mat for extract data as dit' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

#stats.chisqprob = lambda chisq, df: stats.chi2.sf(chisq, df)
def get_pos( args ):
    pos = []
    try :
        pos = [ int(i) - 1 for i in args.c ]
        print ( 'raw int pos: ', pos )
    except :
        with open( args.mat ) as f:
            header = next(f).rstrip().split('\t')
            for peirod in args.c:
                p = re.compile(r'{}'.format(peirod),re.I)
                pos.extend([i for i,v in enumerate(header) if p.search(v)])
        print ( 'match pos: ', pos, file = sys.stderr )
    with open( args.mat ) as f :
        header = next(f).rstrip().split('\t')
        header = [ v for i,v in enumerate( header ) if i in pos ]
    return pos, header


def cal_p( lst, **kwargs):
    mx, mi = max( lst ), min( lst )
    rep1 = [ mi, mi * 1.15, mi * 0.85 ]
    rep2 = [ mx, mx * 1.15, mx * 0.85 ]
    if kwargs.get('m') == 'ttest':
        results = stats.ttest_ind( rep1, rep2 )
        return results.pvalue
    else :
        return 1 - chi2.cdf( *lst )

def get_maxsignal( pos, args ) :
    infor = defaultdict( lambda : defaultdict( list ) )
    if args.mincut :
        with open( args.mincut[0] ) as f:
            header = next(f).rstrip().split('\t')
            for line in f :
                line_arr = line.rstrip().split('\t')
                symbol = line_arr[0]
                line_arr[1:] = [ float(i) for i in line_arr[1:] ]
                dit = dict(zip(header[1:], line_arr[1:]))
                for i in pos:
                    infor[ symbol ][header[i]] = line_arr[i]
    return infor

if __name__ == '__main__':
    pos, header = get_pos( args )
    print ( 'symbol','fc', 'pvalue', *header, 'UporDown', sep = '\t' )
    fh = open( args.mat )
    maxsignal = get_maxsignal( pos, args )
    header = next(fh).rstrip().split('\t')
    for line in fh :
        line_arr = line.rstrip().split('\t')
        vals = [ float(line_arr[i]) for i in pos  ]
        #pvalue = chi2.sf( *vals )
        #print ( vals, chi2_contingency([ vals, vals], False) )
        if vals[1] == 0:
            vals[1] = 1
        fc = vals[0]/vals[1]
        lst = [line_arr[0], fc, cal_p( vals, **vars(args) ), *vals, 'up' ]
        if fc <= 1/args.fc :
            if lst[1] :
                lst[1] = 1/lst[1]
            else :
                lst[1] = 1000000
            lst[-1] = 'down'
        if args.mincut :
            symbol_max = [ maxsignal.get(line_arr[0]).get(header[pos[0]]), maxsignal.get(line_arr[0]).get(header[pos[1]]) ]
            if lst[1] > args.fc and min(symbol_max) > float( args.mincut[1] ):
                print ( *lst, sep = '\t' )
        else :
            if lst[1] > args.fc :
                print ( *lst, sep = '\t' )



























