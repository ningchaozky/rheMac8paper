#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome
example = '''val file in'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('infile', nargs='?', help = 'input file for calculate the values')
parser.add_argument('-sp', choices = ['rh8','mm10'], help = 'chrom for delete not in use', default = 'rh8')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def line_deal( line ):
    line_arr = line.strip().split('\t')
    name = trick.lst(line_arr).get([ 'exon' ], regular = True )
    name = '.'.join( name.split('.')[0 : -1] )
    if 'None' in line_arr[-1]:
        value = 0
    else :
        value = float( line_arr[-1] )
    bases = int( line_arr[2] ) - int( line_arr[1] )
    alias = name.split('.')[0]
    return name, alias.upper(), bases, value * bases


def main():
    dit = {}
    chroms = chromosome.chr(args.sp).chr
    fh = open( args.infile )
    fname, falias, fbases, fval = line_deal( next(fh) )
    trick.dinit(dit, falias, 0)
    for line in fh:
        chrom = line.strip().split('\t')[0]
        if chrom not in chroms:
            continue
        name, alias, bases, val = line_deal( line )
        trick.dinit(dit, alias, 0)
        if name != fname :
            dit[falias] += 1
            print('\t'.join([ str(i) for i in ('.'.join([fname, 'copy' + str(dit[falias])]), fval/fbases) ] ))
            fval, fname, falias, fbases = 0, name, alias, bases
        else :
            fval += val
            fbases += bases
    print('\t'.join([ str(i) for i in ('.'.join([fname, str(dit[falias])]), fval/fbases) ] ))
if __name__ == '__main__':
    main()




























