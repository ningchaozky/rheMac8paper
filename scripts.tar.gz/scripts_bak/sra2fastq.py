#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'root', nargs = '?', help = 'dir root to search sra file')
parser.add_argument( '-d', nargs = '+', help = 'depth for search sra$', default = [10])
parser.add_argument( '-outputdir', nargs = '?', help = 'outputdir', required = True)
parser.add_argument( '-nr', action = 'store_true', help = 'rename output prefix to dirname')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

fls = system.dir( args.root ).fls('\.sra$', depth = args.d, abspath = True)
fastq = [ os.path.basename(i).replace('_1.fastq','').replace('_2.fastq','').replace('.fastq','') for i in system.dir( args.root ).fls('.*fastq$', depth = args.d) ]
cwd = os.getcwd()
for fl in fls:
    fl_dir, flname = os.path.split(fl)
    srr = os.path.basename(fl).replace('.sra','')
    if srr in fastq:
        continue
    if re.search(r'^SRR\d+\.sra$', flname) and not args.nr :
        outdir =  system.dir(''.join( [ args.outputdir, fl_dir.replace( cwd, '' ) ])).check()
        cmd = 'cd {}\nfastq-dump --split-3 {} --outdir {}'.format( fl_dir, flname, outdir )
        print ( cmd )





























