#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
import pandas as pd
import numpy as np
from pandas import read_csv
import seaborn as sns
import matplotlib.cm as cm
from collections import OrderedDict
from ningchao.nSys import trick, fix, dataframe
from ningchao.nSys import color as COLOR
from sklearn.decomposition import PCA
from mpl_toolkits.mplot3d import Axes3D
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('df', nargs='?', help = 'data frame for plot')
parser.add_argument('-t', nargs='?', help = 'signal type for plot', default = 'active signal')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def parse( args ) :
    df = args.df
    return df

def main( df ):
    # Get the iris dataset
    out = fix.fix(df).append('pca.pdf')
    sns.set_style("white")
    #df = sns.load_dataset( args.df )
    #df = read_csv( df, sep = '\t', header = 0, index_col = 0)
    df = read_csv( df, sep = '\t', header = 0, index_col = None )
    df = df.T
    df = df.dropna( axis = 1, how='any' )
    df = dataframe.df(df).clean_dataset( )
    #df.fillna( df.mean() )
    #row_mask = df.isnull().any( axis = 1 )
    #df = df.loc[ row_mask, ]
    #print df[df.eq(np.inf).any( axis=1 )]
    #exit()
    #df = df.transpose()
    my_dpi=96*2
    #plt.figure(figsize=(480/my_dpi, 480/my_dpi), dpi=my_dpi)
    plt.figure( figsize=(18, 16) )


# Keep the 'specie' column appart + make it numeric for coloring
#df['species']=pd.Categorical(df['species'])
#my_color=df['species'].cat.codes
#df = df.drop('species', 1)
    label = [ i.split('.')[1] + '.' + i.split('.')[4]  for i in list( df.index )]
    print ( label )
    df['color'] = pd.Categorical( label )
    my_color=df['color'].cat.codes
    df = df.drop('color', 1)

# Run The PCA
    pca = PCA(n_components=3)
    pca.fit( df )

# Store results of PCA in a data frame
    result=pd.DataFrame(pca.transform(df), columns=['PCA%i' % i for i in range(3)], index=df.index)

# Plot initialisation
    fig = plt.figure()
    #ax = fig.add_subplot(111, projection='3d')
    ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)
    #fig.add_axes([0.1, 0.1, 0.6, 0.75])
    my_color = COLOR.plt().lstGetLst( [ i for i in my_color] )
    #my_color = ['darkorange', 'darkorange', 'deeppink', 'deeppink', 'darkorchid', 'darkorchid', 'green', 'green', 'darkmagenta', 'darkmagenta', 'fuchsia', 'fuchsia', 'thistle', 'thistle']
    my_color = ['darkorange', 'darkorange', 'deeppink', 'deeppink', 'darkorchid', 'darkorchid', 'turquoise', 'turquoise', 'chartreuse', 'chartreuse', 'palevioletred', 'palevioletred', 'lightseagreen', 'lightseagreen']
    #ax.scatter(result['PCA0'], result['PCA1'], result['PCA2'], c=my_color, cmap="Set2_r", s=60, label = label )
    for x,y,z,c,l in zip(result['PCA0'], result['PCA1'], result['PCA2'], my_color, label ):
        ax.scatter( x, y, z, c=c, cmap="Set2_r", s=60, label = l )

# make simple, bare axis lines through space:
    if 0 :
        xAxisLine = ((min(result['PCA0']), max(result['PCA0'])), (0, 0), (0,0))
        ax.plot(xAxisLine[0], xAxisLine[1], xAxisLine[2], 'r')
        yAxisLine = ((0, 0), (min(result['PCA1']), max(result['PCA1'])), (0,0))
        ax.plot(yAxisLine[0], yAxisLine[1], yAxisLine[2], 'r')
        zAxisLine = ((0, 0), (0,0), (min(result['PCA2']), max(result['PCA2'])))
        ax.plot(zAxisLine[0], zAxisLine[1], zAxisLine[2], 'r')

# label the axes
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_zlabel("PC3")
    ax.set_title("PCA on the %s signal" % args.t)
    ax.zaxis.set_tick_params(labelsize=0)
    ax.xaxis.set_tick_params(labelsize=0)
    ax.yaxis.set_tick_params(labelsize=0)
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = OrderedDict(list(zip(labels, handles)))
    plt.legend(list(by_label.values()), list(by_label.keys()), loc = 'upper left', bbox_to_anchor=(0.005, 0.45), fancybox=True, shadow=True, ncol=1 )
    #plt.legend(loc = 'right', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=1 )
    #ax.add_artist(legend1)
    fig.set_size_inches(8, 6)
    plt.savefig( out, format='pdf' )

if __name__ == '__main__':
    df = parse( args )
    main( df )



























