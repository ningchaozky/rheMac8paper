ssh awg02 useradd -u 1032 -g 506 wangqiumei
ssh awg02 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg02 passwd -e wangqiumei
ssh awg03 useradd -u 1032 -g 506 wangqiumei
ssh awg03 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg03 passwd -e wangqiumei
ssh awg04 useradd -u 1032 -g 506 wangqiumei
ssh awg04 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg04 passwd -e wangqiumei
ssh awg05 useradd -u 1032 -g 506 wangqiumei
ssh awg05 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg05 passwd -e wangqiumei
ssh awg06 useradd -u 1032 -g 506 wangqiumei
ssh awg06 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg06 passwd -e wangqiumei
ssh awg07 useradd -u 1032 -g 506 wangqiumei
ssh awg07 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg07 passwd -e wangqiumei
ssh awg08 useradd -u 1032 -g 506 wangqiumei
ssh awg08 echo "wangqiumei:wangqiumei1234" | chpasswd
ssh awg08 passwd -e wangqiumei
