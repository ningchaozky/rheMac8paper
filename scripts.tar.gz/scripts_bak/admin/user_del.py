#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
	print 'fix fm to'
	exit()


fix = sys.argv[1]
fm = sys.argv[2]
To = sys.argv[3]

for i in range(int(fm),int(To)+1,1):
	print 'userdel %s%d' % (fix,i)
