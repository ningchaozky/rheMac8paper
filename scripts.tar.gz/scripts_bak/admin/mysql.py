#!/usr/bin/env python
import os
import sys
if len(sys.argv) <= 1:
        print sys.argv[0],'awg01 ...'
        exit()

cmd = []
for each in sys.argv[1:]:
        cmd.append('ssh %s mkdir -p /var/run/mysqld/ ' % each)
        cmd.append('ssh %s chown mysql.mysql /var/run/mysqld/ ' % each)
        cmd.append('ssh %s setenforce 0 ' % each)
        cmd.append('ssh %s systemctl start mysqld' % each)

for each in cmd:
        if 'awg01' in sys.argv[1:]:
                print each.replace('ssh awg01 ','')
        else :
		print each
