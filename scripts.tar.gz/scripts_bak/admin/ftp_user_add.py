#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
	print sys.argv[0],'passwd','group','hostNum'
	exit()

fhu = open(sys.argv[1])
fhg = open(sys.argv[2])
for line in fhg:
	line_arr = line.strip().split(':')
	if 900 > int(line_arr[2]) > 500:
		for i in range(1,int(sys.argv[3])+1):
			if i < 10:
				print 'ssh awg0%s groupadd -g %s %s' % (str(i),line_arr[2],line_arr[0])
			else:	
				print 'ssh awg%s groupadd -g %s %s' % (str(i),line_arr[2],line_arr[0])

for line in fhu:
	line_arr = line.strip().split(':')
	if 'polkitd' in line_arr[0]:
		continue
	if 'nfsnobody' in line_arr[0]:
		continue
	if int(line_arr[2]) > 500 and 'systemd' not in line_arr[0]:
		for i in range(1,int(sys.argv[3])+1):
			if i < 10:
				print 'ssh awg0%s useradd -u %s -g %s %s' % (str(i),line_arr[2],line_arr[3],line_arr[0])
				print 'ssh awg0%s echo \"%s:%s1234\" | chpasswd' % (str(i),line_arr[0],line_arr[0])
				print 'ssh awg0%s passwd -e %s' % (str(i),line_arr[0])
			else:
				print 'ssh awg%s useradd -u %s -g %s %s' % (str(i),line_arr[2],line_arr[3],line_arr[0])
				print 'ssh awg%s echo \"%s:%s1234" | chpasswd' % (str(i),line_arr[0],line_arr[0])
				print 'ssh awg%s passwd -e %s' % (str(i),line_arr[0])
