#!/usr/bin/env python
import os
import sys
import datetime
import time
if len(sys.argv) <= 1:
    print sys.argv[0],'dirs:/allwegene3 /allwegene4 /allwegene5'

uids = {}
fh = open('/etc/passwd')
for each in fh:
    each = each.strip().split(':')
    uids[each[2]] = each[0]
dirs = sys.argv[1:]
now = time.time()
now = datetime.datetime.fromtimestamp(now)
name = []
for each in sys.argv[1:]:
    name.append(os.path.basename(os.path.abspath(each)))
name = '.'.join(name)
print name
fh = open(name +'.'+str(now).split(' ')[0],'w')
size,size30,size60,last60 = {},{},{},{}
for key in uids:
    size[uids[key]] = 0
    size30[uids[key]] = 0
    size60[uids[key]] = 0
    last60[uids[key]] = 0
fh.write('user\tsize\tabs_path\tcreate_days\tlast_call_days\n')

for each in dirs:
    for root,dirs,files in os.walk(each):
            for fl in files:
                abs_path = os.path.join(root,fl)
                if os.path.islink(abs_path):
                    continue
                if os.path.exists(abs_path):
                    status = os.stat(abs_path)  
                    create = status.st_ctime
#                   modifiy = status.st_mtime
                    last_call = status.st_atime
                    last_call_days = (now - datetime.datetime.fromtimestamp(last_call)).days
#                   modifiy_days = now - datetime.datetime.fromtimestamp(modifiy)
                    create_days = (now - datetime.datetime.fromtimestamp(create)).days
                    key = str(status.st_uid)
                    if key in uids:
                        key = str(key)
                    else : 
                        sys.stderr.write('no body %s: %s\n' % (str(key), abs_path))
                        uids[key] = 'nobody%s' % str(key)
                        if uids[key] not in size:
                                size.update({uids[key]:0})
                                size30.update({uids[key]:0})
                                size60.update({uids[key]:0})
                                last60.update({uids[key]:0})
                    info = [uids[key], str(status.st_size), abs_path, str(create_days), str(last_call_days)]
                    size[uids[key]] += status.st_size
                    if create_days > 30:
                        size30[uids[key]] += status.st_size
                    if create_days > 60:
                        size60[uids[key]] += status.st_size
                    if last_call_days > 60:
                        last60[uids[key]] += status.st_size
#                   info = [str(i) for i in info]       
                    fh.write('\t'.join(info))
                    fh.write('\n')

fh.close()
fh = open('%s.size.' % name +str(now).split(' ')[0],'w')
fh.write('all size'+'\n')
allsize = 0
for each in size:
    allsize += size[each]/1024/1024/1024
    gb = str(size[each]/1024/1024/1024)+'gb'
    fh.write('\t'.join([each,gb])+'\n')
fh.write('allsize: ' + str(allsize) + '\n')
fh.write('\n\n')
fh.write('create more than 30 days size'+'\n')
for each in size30:
    gb = str(size30[each]/1024/1024/1024)+'gb'
    fh.write('\t'.join([each,gb])+'\n')
fh.write('\n\n')
fh.write('create more than 60 days size'+'\n')
for each in size60:
    gb = str(size60[each]/1024/1024/1024)+'gb'
    fh.write('\t'.join([each,gb])+'\n')
fh.write('\n\n')

fh.write('call more than 60 days'+'\n')
for each in last60:
    gb = str(size60[each]/1024/1024/1024)+'gb'
    fh.write('\t'.join([each,gb])+'\n')
fh.write('\n\n')

fh.close()
