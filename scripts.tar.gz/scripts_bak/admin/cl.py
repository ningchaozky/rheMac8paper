#!/usr/bin/env python
import os
import sys


awgs = ['awg02','awg03','awg04','awg05','awg06','awg07','awg08']


for each in awgs:
	print 'ssh %s \'echo 1 > /proc/sys/vm/drop_caches\'' % each


