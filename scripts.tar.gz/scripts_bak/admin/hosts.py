#!/usr/bin/env python
import os
import sys

if len(sys.argv) == 1:
	exit('%s nodesNum' % sys.argv[0])


def ad(string):
	if len(string) < 2:
		return '0' + string
	else :
		return string



nodes = [ad(str(i)) for i in range(1,int(sys.argv[1])) ]
nodes.append('web')
nodes = [ 'awg'+i for i in nodes ]


ips = [ '10.1.1.%s' % str(i) for i in range(1,int(sys.argv[1])) ]
ips.append('10.1.1.125')
alias = [i + '.local'  for i in nodes ]
infor = zip(ips, alias, nodes)
network = '''NETWORKING=yes
HOSTNAME=awg01'''

hosts = '''127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
'''

scp = []

for i in nodes:
	hfh = open('hosts.%s' % i,'w')
	hfh.write(hosts)
	nfh = open('network.%s' % i,'w')
	nfh.write(network.replace('awg01', i) +'\n')
	nfh.close()
	for each in infor:
		hfh.write('\t'.join(each) + '\n')
		
	hfh.close()


	scp.append('scp hosts.%s root@%s:/etc/hosts' % (i,i)) 
	scp.append('scp network.%s root@%s:/etc/sysconfig/network' % (i,i)) 


for each in scp:
	print each

































