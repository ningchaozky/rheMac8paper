#!/usr/bin/env python
import sys
import os

if len(sys.argv) <= 1:
        print sys.argv[0],'rpmlist'
        exit()


for i in range(1,2):
        for each in sys.argv[1:]:
                print ''' ssh awg%s  \'rpm -Uvh http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm\' ''' % each
                print ''' ssh awg%s  \'yum -y install mysql-community-server\' ''' % each
                print ''' ssh awg%s  \'yum -y install mysql-community-client\' ''' % each

