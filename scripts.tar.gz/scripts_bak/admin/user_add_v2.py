#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 2:
	print sys.argv[0],'hostNum','username','group,..'
    print 'group cmd: RNA,soft|borrow,BIOINFO,MICRO,HUMAN,ftp,soft'
	exit()

gid = {'RNA':'502','borrow':'1076','ftp':'506','BIOINFO':'506','MICRO':'505','HUMAN':'504','soft':'1077'}
fhu = open('/etc/passwd')
fhg = open('/etc/group')

user = sys.argv[2]
cmd = []
for line in fhg:
	line_arr = line.strip().split(':')
	if 900 > int(line_arr[2]) > 500:
		for i in range(1,int(sys.argv[1])+1):
			if i < 20:
				cmd.append( 'ssh awg0%s groupadd -g %s %s' % (str(i),line_arr[2],line_arr[0]))
			else:	
				cmd.append( 'ssh awg%s groupadd -g %s %s' % (str(i),line_arr[2],line_arr[0]))

index = 0
for line in fhu:
	line_arr = line.strip().split(':')
	if 'polkitd' in line_arr[0]:
		continue
	if 'nfsnobody' in line_arr[0]:
		continue
	if int(line_arr[2]) > 500 and 'systemd' not in line_arr[0]:
		if user == line_arr[0]:
			index += 1
		for i in range(2,int(sys.argv[1])+1):
			if i < 10:
				cmd.append( 'ssh awg0%s useradd -u %s -g %s %s' % (str(i),line_arr[2],line_arr[3],line_arr[0]) )
				cmd.append( 'ssh awg0%s \'echo \"%s:1234\" | chpasswd\'' % (str(i),line_arr[0]) )
				cmd.append( 'ssh awg0%s passwd -e %s' % (str(i),line_arr[0]) )
				cmd.append( 'ssh awg0%s usermod -a -G soft %s' % (str(i),line_arr[0]) )
			else:
				cmd.append( 'ssh awg%s useradd -u %s -g %s %s' % (str(i),line_arr[2],line_arr[3],line_arr[0]) ) 
				cmd.append( 'ssh awg%s \'echo \"%s:1234" | chpasswd\'' % (str(i),line_arr[0]) )
				cmd.append( 'ssh awg%s passwd -e %s' % (str(i),line_arr[0]) ) 
				cmd.append( 'ssh awg0%s usermod -a -G soft %s' % (str(i),line_arr[0]) )
if not index :
	print 'useradd -g 506 %s' % user
	print 'usermod -a -G soft %s' % user
	print 'echo \"%s:1234" | chpasswd' %  user
	exit('##pleas run and rerun this scritp once for all nodes')

for each in cmd :
	if sys.argv[2] in each:
		print each
