#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
	print sys.argv[0],'num','prefix','expire'
	exit()

for i in range(int(sys.argv[1])):
	name = sys.argv[2]+str(i+1)
	print 'useradd -g 1002 %s' % name
	print 'echo \"%s:1234\" | chpasswd' % name
	if len(sys.argv) > 3:
		print 'passwd -e %s' % name
