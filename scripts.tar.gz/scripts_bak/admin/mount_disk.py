#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
    print sys.argv[0],'awg01 ...'
    exit()


opt = ',usrquota,grpquota '

def umount(each):
    cmd = []
    cmd.append('ssh %s umount  -l /allwegene3/ ' % each)
    cmd.append('ssh %s umount  -l /allwegene4/ ' % each)
    cmd.append('ssh %s umount  -l /allwegene5/ ' % each)
    cmd.append('ssh %s umount  -l /allwegene6/ ' % each)
    cmd.append('ssh %s umount  -l /allwegene7/ ' % each)
    cmd.append('ssh %s umount  -l /allwegene8/ ' % each)
    if each == 'awg01':
        for i,v in enumerate(cmd):
            cmd[i] = v.replace('ssh %s' % each,'').strip()
    return cmd
def restart(each):
    cmd = []
    if each == 'awg01':
        cmd.append('service rpcbind restart')
        cmd.append('service nfs restart')
    else :
        cmd.append('ssh %s service rpcbind restart' % each)
        cmd.append('ssh %s service nfs restart' % each)
    return cmd

def mount(each):
    cmds = []
    if each == 'awg02':
        cmds.append('ssh awg02 mount -o defaults /dev/mapper/mpatha  /allwegene3/')
        cmds.append('ssh awg02 mount -o defaults /dev/mapper/mpathb /allwegene4/')
        cmds.append('ssh awg02 mount -o defaults /dev/mapper/mpathc /allwegene5/')
        cmds.append('ssh awg02 mount -o defaults /dev/mapper/mpathd /allwegene6/')
        cmds.append('ssh awg02 mount -o defaults  awg04:/allwegene8/ /allwegene8/')
        cmds.append('ssh awg02 mount -o defaults  awg03:/allwegene7/ /allwegene7/')
    elif each == 'awg03':
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene3/ /allwegene3/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene4/ /allwegene4/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene5/ /allwegene5/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene6/ /allwegene6/' % each)
        cmds.append('ssh awg03 mount -o defaults  awg04:/allwegene8/ /allwegene8/')
        cmds.append('ssh awg03 mount -o defaults  /dev/mapper/mpatha /allwegene7/')
    elif each == 'awg04':
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene3/ /allwegene3/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene4/ /allwegene4/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene5/ /allwegene5/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene6/ /allwegene6/' % each)
        cmds.append('ssh awg04 mount -o defaults  /dev/mapper/mpatha /allwegene8/')
        cmds.append('ssh awg04 mount -o defaults  awg03:/allwegene7/ /allwegene7/')
    elif each == 'awg01':
        cmds.append('mount -o defaults  awg02:/allwegene3/ /allwegene3/')
        cmds.append('mount -o defaults  awg02:/allwegene4/ /allwegene4/')
        cmds.append('mount -o defaults  awg02:/allwegene5/ /allwegene5/')
        cmds.append('mount -o defaults  awg02:/allwegene6/ /allwegene6/')
        cmds.append('mount -o defaults  awg04:/allwegene8/ /allwegene8/')
        cmds.append('mount -o defaults  awg03:/allwegene7/ /allwegene7/')
    else :
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene3/ /allwegene3/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene4/ /allwegene4/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene5/ /allwegene5/' % each)
        cmds.append('ssh %s mount -o defaults  awg02:/allwegene6/ /allwegene6/' % each)
        cmds.append('ssh %s mount -o defaults  awg04:/allwegene8/ /allwegene8/' % each)
        cmds.append('ssh %s mount -o defaults  awg03:/allwegene7/ /allwegene7/' % each)
    return cmds            



cmds = []
for each in sys.argv[1:]:
    cmds.extend(umount(each))
    cmds.extend(restart(each))
    cmds.extend(mount(each))

for each in cmds:
    print each





#NOTE: firewall-cmd --permanent --add-service=mountd
#    firewall-cmd --permanent --add-service=nfs
#    firewall-cmd --permanent --add-service=rpc-bind
#    firewall-cmd --reload
