#!/usr/bin/env python
import os
import re
import sys

if len(sys.argv) <= 2:
    print sys.argv[0],'username','group,..'
    print 'group Example: RNA,soft|borrow,BIOINFO,MICRO,HUMAN,ftp,soft'
    exit()

gid = {'RNA':'502','borrow':'1076','ftp':'506','BIOINFO':'506','MICRO':'505','HUMAN':'504','soft':'1077'}
hfh = open('/etc/hosts')
user = sys.argv[1]
p = re.compile(r'\s+')

def check_user(user):
    pfh = open('/etc/passwd')
    for each in pfh:
        if each.startswith(user):
            return True
    return False 

def uid_get():
    dit = {}
    pfh = open('/etc/passwd')
    for line in pfh:
        line_arr = line.split(':')
        dit.update({line_arr[0]:line_arr[2]})
    pfh.close()
    return dit
uid = uid_get()
if sys.argv[1] not in uid:
    print 'Please check the user name\n'

hosts = []
for line in hfh:
    if 'awg' in line:
        host = p.split(line.strip())[-1]
        if host not in hosts:
            hosts.append(host)
hfh.close()


groups = sys.argv[2].split(',')
soild_group = groups.pop(0)
if soild_group not in gid:
    exit('wrong the base gid\n')
else :
    soild_gid = gid[soild_group]

cmds = []
if soild_gid:
    cmds.append('useradd -g %s -u %s %s' % (soild_gid,uid[user],user))
    cmds.append('echo \"%s:1234\" | chpasswd' %  user)
if groups:
    for each in groups :
        cmds.append('usermod -a -G %s %s' % (each, user))



def add_ssh(hosts,lst):
    out = []
    for host in hosts:
        for each in lst:
            if host != 'awg01':
                out.append('ssh %s \'%s\'' % (host,each))
            else :
                out.append(each)
    return out
    
for each in add_ssh(hosts,cmds):
    print each


