ssh awg02 yum install -y ntpdate
ssh awg03 yum install -y ntpdate
ssh awg04 yum install -y ntpdate
ssh awg05 yum install -y ntpdate
ssh awg06 yum install -y ntpdate
ssh awg07 yum install -y ntpdate
ssh awg08 yum install -y ntpdate
