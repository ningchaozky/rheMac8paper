#!/usr/bin/env python
import os
import sys
passwd = '/etc/passwd'
group = '/etc/group'


pfh = open(passwd)
for line in pfh:
    print line





















