#!/usr/bin/env python
import os
import sys
from random import Random

if len(sys.argv) <= 1:
	print sys.argv[0],'length|username group'
	exit()


def random_str(randomlength=6):
    str = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    return str

try :
	name = random_str(int(sys.argv[1]))
except :
	name = sys.argv[1]

passwd = name




user_dir = os.path.join('/allwegene5/borrow',name)
print 'mkdir -p %s' % user_dir
print ('useradd -d %s %s' % (user_dir,name))
print ('chmod 755 %s' % user_dir)
print ('chown %s.%s %s' % (name,name,user_dir))
print ('usermod -a -G soft %s' % name)
print ('usermod -a -G borrow %s' % name)
print 'echo \"%s:%s\" | chpasswd' % (name,passwd)
if len(sys.argv) >= 3 :
	for group in sys.argv[2:]:
		print ('usermod -a -G %s %s' % (group,name))
