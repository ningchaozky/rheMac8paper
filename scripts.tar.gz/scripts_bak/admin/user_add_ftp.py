#!/usr/bin/env python
import os
import sys
from random import Random

if len(sys.argv) <= 1:
	print sys.argv[0],'dir'
	exit()




def random_str(randomlength=6):
    str = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    return str

name = dirname = passwd = random_str()+'ftp'
user_dir = sys.argv[1].strip()

cmds = []
ofh = open('/root/ftp/%s.sh' % name, 'w')


cmds.append('mkdir /allwegene3/ftp/bind/%s' % dirname)
cmds.append('mount --bind %s /allwegene3/ftp/bind/%s' % (user_dir,dirname))
cmds.append('useradd -g 1035 -s /sbin/nologin -d /allwegene3/ftp/bind/%s %s' % (dirname,name))
cmds.append('chmod 755 /allwegene3/ftp/bind/%s' % dirname)
#print ('chown %s.BIOINFO /allwegene3/ftp/bind/%s' % (name,name))
cmds.append('echo \"%s:%s\" | chpasswd' % (name,passwd))
cmds.append('usermod -a -G BIOINFO %s' % name)
cmds.append('echo ftp://%s:%s@111.200.58.93' % (name,passwd))

for each in cmds:
	ofh.write(each +'\n')
ofh.close()

cmd = 'sh /root/ftp/%s.sh' % name
print cmd



