vi /etc/pptpd.conf
vi /etc/ppp/chap-secrets
vi /etc/ppp/options.pptpd
