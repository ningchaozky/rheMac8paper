#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
	print sys.argv[0],'awg01 ...'
	exit()

cmd = []
for each in sys.argv[1:]:
	cmd.append('ssh %s umount -l /allwegene3/ ' % each)
	cmd.append('ssh %s umount -l /allwegene4/ ' % each)
	cmd.append('ssh %s umount -l /allwegene5/ ' % each)
	cmd.append('ssh %s umount -l /allwegene6/ ' % each)
	cmd.append('ssh %s umount -l /allwegene7/ ' % each)
	cmd.append('ssh %s umount -l /allwegene8/ ' % each)
	cmd.append('ssh %s init 6 ' % each)

for each in cmd:
	if 'awg01' in sys.argv[1:]:
		print each.replace('ssh awg01 ','')
	else :
		print each

