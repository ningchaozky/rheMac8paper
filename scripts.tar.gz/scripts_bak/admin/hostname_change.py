#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
    print sys.argv[0],'awg01 ...'
    exit()

for each in sys.argv[1:]:
    print 'hostnamectl set-hostname %s' % each
