#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
	print sys.argv[0],'awg01 ...'
	exit()


index = 0
if 'start' == sys.argv[-1]:
	index = 1
for each in sys.argv[1:]:
	if 'awg' in each:
		cmd = 'ssh %s /etc/rc3.d/S96sgeexecd.blade softstop' % each
		print cmd		
		if index:
			os.system(cmd)
		cmd = 'ssh %s /etc/rc3.d/S96sgeexecd.blade start' % each
		print cmd		
		if index:
			os.system(cmd)
		
