#!/usr/bin/env python
import sys
for i in range(40):
    user = 'training%d' % i
    if len(sys.argv) >= 2:
        print 'userdel %s' % user
    else :
        print 'user_add_awg01.py %s soft,borrow'  % user
