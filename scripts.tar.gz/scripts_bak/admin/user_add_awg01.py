#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1:
    print 'RNA,soft|borrow,BIOINFO,MICRO,HUMAN,ftp'
    print sys.argv[0],'user','group,...'
    exit()

gids = {'RNA':'502','borrow':'1076','ftp':'506','BIOINFO':'506','MICRO':'505','HUMAN':'504','soft':'1077'}
def get_gid(group, name = False):
    gfh = open('/etc/group')
    for line in gfh:
        if line.startswith(group):
            line_arr = line.strip().split(':')
            gid = line_arr[-2]
            gfh.close()
            if not name:
                return gid
            else :
                return line_arr[0]

groups = iter(sys.argv[2].split(','))
soild_groud = groups.next()
gid = get_gid(soild_groud)

if gid == None :
    exit('check the group name is vaild\n')
else :
    print 'useradd -g %s %s' % (gid,sys.argv[1])
for group in groups:
    if group.strip() != '':
        if group.strip() not in gids:
            exit('check the group name is vaild\n')
        print 'usermod -a -G %s %s' % (group,sys.argv[1])
print 'echo \"%s:1234\" | chpasswd' % sys.argv[1]
print 'passwd -e %s' % sys.argv[1]
