#!/usr/bin/env python
import sys
import os

if len(sys.argv) <= 1:
	print sys.argv[0],'rpmlist'
	exit()


for i in range(2,9):
	for each in sys.argv[1:]:
		print 'ssh awg0%s yum install -y %s' % (str(i),each)



