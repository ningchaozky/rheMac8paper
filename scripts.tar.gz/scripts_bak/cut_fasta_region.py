#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import fasta

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'fasta', nargs='?', help = 'fasta file' )
parser.add_argument( '-region','-r', nargs='?', help = 'region', required = True )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

dit = {}

p = re.compile(r'\s+')
region = args.region
dit = fasta.fa2dict( args.fasta )
rfh = open(region)
for line in rfh:
    name,start,end = p.split(line.strip())
    if name in dit:
        print(dit[name][ int(start) - 1 : int(end) ].seq)
    else :
        sys.stderr.write( '%s not in the fasta\n' % name )


























