#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import bed

example = '''bed get the cover gene'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bed', nargs='?', help ='chipseq bed file' )
parser.add_argument( '-gene', nargs='?', help ='gene file', default = '/home/ningch/data/genome/rheMac8/exon/merge_exons/gene' )
parser.add_argument( '-span', nargs='?', help ='span for the gene', default = 2000, type = int )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def parse( args ):
    ibed, gene, span = args.bed, args.gene, args.span
    pbed = bed.bed( gene ).span(span = span, sp = 'rh8', typ = 'promoter' )
    return pbed, ibed

def intersect( a, b ):
    for line in bed.bed(a).intersect(b):
        line_arr = line.strip().split('\t')
        if int( line_arr[-1] ) > 200 :
            print('\t'.join(line_arr[0:6]))



if __name__ == '__main__':
    pbed, ibed = parse( args )
    intersect( pbed, ibed )

























