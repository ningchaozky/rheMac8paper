#!/usr/bin/env python
import os
import sys
import datetime
import time
if len(sys.argv) <= 1:
	print(sys.argv[0],'dirs:/allwegene3 /allwegene4 /allwegene5')

uids = {}
fh = open('/etc/passwd')
for each in fh:
	each = each.strip().split(':')
	uids[each[2]] = each[0]
dirs = sys.argv[1:]
now = time.time()
now = datetime.datetime.fromtimestamp(now)
fh = open('disk_usage.'+str(now).split(' ')[0],'w')
size,size30,size60,last60 = {},{},{},{}
for each in dirs:
	for root,dirs,files in os.walk(each):
		if not dirs:
			for fl in files:
				abs_path = os.path.join(root,fl)
				if os.path.exists(abs_path):
					status = os.stat(abs_path)	
					create = status.st_ctime
					modifiy = status.st_mtime
					last_call = status.st_atime
					last_call_days = now - datetime.datetime.fromtimestamp(last_call)
					modifiy_days = now - datetime.datetime.fromtimestamp(modifiy)
					create_days = now - datetime.datetime.fromtimestamp(create)
					info = [uids[str(status.st_uid)],str(status.st_size), create_days,modifiy_days,last_call_days,abs_path]
					if uids[str(status.st_uid)] not in size:
						size[uids[str(status.st_uid)]] = 0
						size30[uids[str(status.st_uid)]] = 0
						size60[uids[str(status.st_uid)]] = 0
						last60[uids[str(status.st_uid)]] = 0
					size[uids[str(status.st_uid)]] += status.st_size
					if create_days.days > 30:
						size30[uids[str(status.st_uid)]] += status.st_size
					if create_days.days > 60:
						size60[uids[str(status.st_uid)]] += status.st_size
					if last_call_days.days > 60:
						last60[uids[str(status.st_uid)]] += status.st_size
					info = [str(i) for i in info]		
					fh.write('\t'.join(info))
					fh.write('\n')

fh.close()
fh = open('disk_usage.size.'+str(now).split(' ')[0],'w')
for each in size:
	fh.write('all size'+'\n')
	fh.write('\t'.join([each,str(size[each])])+'\n')
fh.write('\n\n')
fh.write('create more than 30 days size'+'\n')
for each in size30:
	fh.write('\t'.join([each,str(size[each])])+'\n')
fh.write('\n\n')
fh.write('create more than 60 days size'+'\n')
for each in size60:
	fh.write('\t'.join([each,str(size[each])])+'\n')
fh.write('\n\n')

fh.write('call more than 60 days'+'\n')
for each in last60:
	fh.write('\t'.join([each,str(size[each])])+'\n')
fh.write('\n\n')

fh.close()
