#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-exon', nargs='?', help ='reference', default = '/home/ningch/data/genome/rheMac8/exon/ref_ensemble_xeonRefGene.exons.bed')
parser.add_argument('-s', action='store_true', help = 'start script' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
efh = open(args.exon)
fline = next(efh)
def raw(string):
    arr = string.strip().split('\t')
    name_arr = arr[3].split('.')
    name_arr.pop(-1)
    chrom = arr[0]
    chain = arr[-1]
    return '.'.join(name_arr),chrom,chain

def flat(lst):
    exon_num = len(lst) - 3
    name = lst.pop(0)
    chrom = lst.pop(0)
    chain = lst.pop(0)
    starts = []
    ends = []
    for each in lst:
        line_arr = each.strip().split('\t')
        starts.append(line_arr[1])
        ends.append(line_arr[2])
    start = ','.join(starts)
    end = ','.join(ends)
    exonFrames = ','.join(['0' for i in lst ])
    return name,chrom,chain,starts[0],ends[-1],starts[0],ends[-1],exon_num,start,end,'0',name,start,end, exonFrames


fname,fchrom,fchain = raw(fline)
exon = [fname,fchrom,fchain,fline]

i = 0
for line in efh:
    name,chrom,chain = raw(line)
    if name != fname:
        rt = list(flat(exon))
        rt.insert(0, i)
        i += 1
        out_line = '\t'.join([ str(j) for j in rt ] )
        print(out_line)
        exon = [name,chrom,chain]    
        fname = name
    exon.append(line)
i += 1
print('\t'.join([ str(i) for i in flat(exon) ] ))

























