#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help = 'matrix for regression')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

#%maplotlib inline
from IPython import display
from mxnet import autograd, nd
import random



num_inputs = 2
num_examples = 1000
true_w = [ 2, -3.4 ]
true_b = 4.2
features = nd.random.normal(scale=1, shape = (num_examples, num_inputs ))
labels = true_w[0] * features[:,0] + true_w[1] * featrues[:,1] + true_b 



























