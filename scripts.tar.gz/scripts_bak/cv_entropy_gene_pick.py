#!/usr/bin/env python
import os
import sys
import argparse
from ningchao.nSys import trick
example = '''pick up gene from cv or entropy'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help ='matrix_trans output cv or entropy results')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



fh = open( args.tab )
genes = []
for line in fh:
    line_arr = line.strip().split('\t')
    if 'gene' == line_arr[0]:
        continue
    try :
        gene, signal = line_arr[0:2]
        gene_arr = gene.split('.')
        copy_pos = trick.lst( gene_arr ).index('copy', regular = True )
        gene = '.'.join( gene_arr[0: copy_pos] )
        if gene not in genes:
            genes.append( gene )
        if float( signal ) >= 3 :
            print ( line_arr[0] )
    except :
        sys.stderr.write ( line +'\n' )



























