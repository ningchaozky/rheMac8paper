#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system
example = ''' dir '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help ='dir')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fh, out, tout = open('index.html'), [], []
html_string = '\n'.join( [ i.strip() for i in fh.readlines() ])
fls, lst = system.dir( args.dir ).fls('mp4'), []
for fl in fls:
    fl = os.path.basename( fl )
    name = fl.replace('.mp4','')
    fh = open( name +'.html', 'w')
    fh.write('<video src="%s" controls="controls"> </video> <br />\n' % fl)
    fh.close()
    lst.append( ( name, fh.name ) )
out.extend( html_string.split('\n') )
for name, html in lst:
    string = '''<a href="%s">%s</a> <br/>''' % ( name, name )
    out.append( string )
outs = trick.lst(out).uniq()
print ( outs )

fh = open('index.html', 'w')
outs = sorted(outs)
for each in outs:
    fh.write( each + '\n')
fh.close()
























