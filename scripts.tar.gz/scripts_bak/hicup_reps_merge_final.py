#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
import argparse
from ningchao.nSys import trick,fix,status
from ningchao.nBio import chromosome,sam
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bams', nargs='*', help = 'bams for merge' )
parser.add_argument( '-prefix','-p', nargs='?', help = 'prefix for output file', required = True )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

cmds = []
bams = args.bams
bam = ' '.join(bams)
prefix = args.prefix
pre = fix.fix(prefix)
pwd = os.getcwd()
chr_obj = chromosome.chr('rh8')
ref = chr_obj.abspth.replace('.genome','.fa')
cmd, merge_out = sam.merge_sams(bams)
#cmd = 'samtools merge %s %s' % (name, bam)
cmd,oflg = status.cmd_accessory( pwd, '.'.join(bams), cmd)
cmds.append(cmd)

hicup_tmp = pre.append('hicup.temp.bam')
cmd = 'samtools view %s | samtools view -bS -T %s - > %s' % ( merge_out, ref, hicup_tmp)
cmd,oflg = status.cmd_accessory( pwd, hicup_tmp+'.genomeAlign', cmd)
cmds.append(cmd)

hicup_sort = pre.append('hicup.temp.sort.bam')
cmd = 'samtools sort %s -o %s' % (hicup_tmp, hicup_sort)
cmd,oflg = status.cmd_accessory( pwd, hicup_tmp+'.sort', cmd)
cmds.append(cmd)

cmd, redup = sam.remove_dup(pwd, hicup_sort, flag =hicup_sort + '.redup')
cmds.append(cmd)

pre = fix.fix(redup)
redup_sort = pre.insert('sortn')
cmd = 'samtools sort -n %s -o %s' % (redup, redup_sort)
cmd,oflg = status.cmd_accessory( pwd, redup+'.sortn', cmd)
cmds.append(cmd)

cmd = 'samtools view %s | samtools view -bS -T %s - > %s.hicup.final.bam' % (redup_sort, ref, prefix)
cmd,oflg = status.cmd_accessory( pwd, hicup_tmp+'.hicup.final', cmd)
cmds.append(cmd)
print('\n'.join(cmds))























