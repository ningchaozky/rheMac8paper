#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'compartment', nargs='?', help = 'compartment mean mini file, chrom, start, end with substract with symbolname')
parser.add_argument( '-geneBody', nargs='?', help = 'gene Body file', default = '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.bodyUpDown5K.bed')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

#tss /home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.bed
#gb /home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.bodyUpDown3K.bed






def get_header():
    with open( args.compartment ) as f :
        header = next(f).rstrip().split('\t')
        kwargs.update({'header': header})
    print ( 'symbol', *header[3:], sep = '\t')


def get_interset():
    header = kwargs.get('header')
    cmd = 'bedtools intersect -a {} -b {} -wo'.format( args.compartment, args.geneBody )
    output = system.run( cmd, shell = True )
    for line in output :
        line_arr = line.rstrip().split('\t')
        compart_key = '-'.join( [ ':'.join(line_arr[0:2]), line_arr[2] ])
        name = [ i for i in line_arr if 'copy' in i ][0]
        values = [ float(line_arr[i]) for i in range(3, len(header)) ]
        typ = get_type( values )
        new_key = '|'.join([name,compart_key,typ])
        print ( new_key, *values, sep = '\t')


def get_type( values ):
    header = kwargs.get('header')[3:]
    if min( values ) <= 0 and max( values ) <= 0:
        return 'cB'
    elif max( values ) >= 0 and min( values ) >= 0:
        return 'cA'
    else :
        typs = []
        tdit = dict( zip( header, values) )
        first_period = header[0]
        first_val = tdit[ first_period ]
        for period in header[1:] :
            if first_val >= 0 and tdit[period] >= 0 :
                first_period = period
                first_val = tdit[period]
                continue
            if first_val <= 0 and tdit[period] <= 0 :
                first_period = period
                first_val = tdit[period]
                continue
            if first_val >= 0 and tdit[period] <= 0 :
                near_type = ''.join( [ first_period, period, 'AtoB' ])
                typs.append( near_type )
            elif first_val <= 0 and tdit[period] >= 0 :
                near_type = ''.join( [ first_period, period, 'BtoA' ])
                typs.append( near_type )
            first_period = period
            first_val = tdit[period]
        return ','.join( [ 'c'+i for i in typs ] )

if __name__ == '__main__':
    kwargs = vars( args )
    get_header()
    get_interset()






















