#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, system, status
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('renamexls', nargs='?', help = 'xls for data analysi')
parser.add_argument('-d', nargs='?', help = 'dir for find gz file', default = ['/home/washU/pub/jingli_home/data/rnseq', '/dataC/lijing/a'])
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def name_reads_finder( args ):
    #df = pd.read_excel( args.renamexls, engine = 'openpyxl', sheet_name = args.n)
    infor = pd.read_excel( args.renamexls, engine = 'openpyxl', index_col = 0).to_dict()
    reads = defaultdict( set )
    for each in infor:
        infor_dit = infor[each]
        for old_name in infor_dit :
            new_name = infor_dit[old_name]
            for fdir in args.d:
                fls = list(system.dir( fdir ).fls('{}.*gz$'.format(new_name), depth = 100) )
                fls.extend( list( system.dir( fdir  ).fls('{}.*gz$'.format(old_name), depth = 100) ) )
                for gz in fls :
                    if reads.get( new_name ) and len(reads.get( new_name )) >= 2:
                        continue
                    reads[ new_name ].add( gz )
    return reads

def old_mapping( directory ):
    tab = '_resultReadsPerGene.out.tab'
    fls = system.dir( directory ).fls( '{}$'.format(tab), depth = 10 )
    fls = [ i for i in fls if os.path.getsize(i) > 100 ]
    return [ os.path.basename(i).replace(tab,'') for i in fls ]
def print_cmds( reads ):
    new_name_already = old_mapping( '.' )
    for new_name in reads:
        if new_name in new_name_already:
            continue
        read_1, read_2 = sorted( list( reads[new_name] ) )
        print ( 'echo {}'.format( new_name ) )
        cmd = 'STAR --twopassMode Basic --quantMode TranscriptomeSAM GeneCounts --runThreadN 6 --genomeDir /home/soft/data/genome/dmel --alignIntronMin 20 --alignIntronMax 500000 --outSAMtype BAM SortedByCoordinate --sjdbOverhang 149 --outSAMattrRGline ID:{} SM:{} PL:ILLUMINA --outFilterMismatchNmax 2 --outSAMmultNmax 2 --outSAMmapqUnique 60  --outFileNamePrefix {}_result --alignMatesGapMax 1000000 --outSJfilterReads Unique --readFilesCommand zcat --readFilesIn {} {}'.format( new_name, new_name, new_name, read_1, read_2 )
        cmd = status.cmd_accessory(cmd, wd = new_name, flag = 'mapping')
        print ( cmd )


if __name__ == '__main__':
    reads = name_reads_finder( args )
    print_cmds( reads )

















