#!/usr/bin/perl -w
#
#
#
#gene_id "XLOC_000005"; transcript_id "TCONS_00000010"; exon_number "22"; gene_name "Px000009"; oId "Px000009.11"; nearest_ref "Px000009.11"; class_code "="; tss_id "TSS9"; p_id "P5";
unless(@ARGV){
	print "\nUsage:\t$0 merged.gtf\n\n";
}
else{
open $merged, "$ARGV[0]";
#$tmp_gene_id = "\n";
print "gene_id\ttranscript\tgenome_gene_id\n";
while (<$merged>){
	chomp;
	@tmp =(split /;/,(split /\t/,$_)[8]);
	$tmp[0] =~ s/.*\ "//;
	$tmp[0] =~ s/"//;
	$tmp[1] =~ s/.*\ "//;
	$tmp[1] =~ s/"//;
	$tmp[3] =~ s/.*\ "//;
	$tmp[3] =~ s/"//;
	$tmp[0] = quotemeta $tmp[0];
#		if($tmp_gene_id !~  /$tmp[0]/){
		print "$tmp[0]\t$tmp[1]\t$tmp[3]\n";
#		$tmp[0] =~ s/\\//g;
#		$tmp_gene_id .= "$tmp[0]\n"
#		}
}
close $merged;

}
