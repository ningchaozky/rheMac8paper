#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,lineKit
from ningchao.nBio import neuron

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-bed', nargs='+', help ='bed and its colum extract Gene')
parser.add_argument('-split', action='store_true', help ='split the gene pos')
parser.add_argument('-neu', nargs='?', help ='neuron gene output file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

nGenes = neuron.neu().genes()
bed = args.bed[0]
pos = int(args.bed[1]) - 1
bfh = open(bed)
split = args.split
nfh = sys.stderr
if args.neu:
    nfh = open(args.neu, 'w')
print(next(bfh), end=' ')
lst = []
for line in bfh:
    if 'no match' in line:
        continue
    line_arr = line.strip().split('\t')
    if split :
        gene = lineKit.linspace_choose(line_arr[pos])
        gene = gene[0].split('.')[0].upper()
    else :
        gene = line_arr[pos].split('.')[0].upper()
    if gene in nGenes:
        if gene not in lst:
            nfh.write(gene + '\n')
            lst.append(gene)
        print(line, end=' ')






















