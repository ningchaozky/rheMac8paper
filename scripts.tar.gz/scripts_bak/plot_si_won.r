#!/usr/bin/env Rscript
#first
alen <- commandArgs()
library(argparser)
p <- arg_parser('this script discription')
p <- add_argument( p, "--bed", short = '-b', nargs = '?', help="bed for the fire score calling" )
p <- add_argument( p, "--genome", short = '-g', nargs = '?', help="genome length file", default="/home/soft/data/genome/rheMac8/rheMac8.genome")
#p <- add_argument( p, "--ICE_dir", short = '-ice', nargs = '+', help="ice normal matrixs directory", default = '/dataE/rawdata/rheMac/hic/E80R1/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/E80R2/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/E120R1/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/E120R2/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/4monthR1/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/4monthR2/prefrontal_corte/Norm_matrix/ICE/')
p <- add_argument( p, "--ICE_dir", short = '-ice', nargs = '+', help="ice normal matrixs directory", default = '/dataE/rawdata/rheMac/hic/E80R1/prefrontal_corte/Norm_matrix/ICE/,/dataE/rawdata/rheMac/hic/E80R2/prefrontal_corte/Norm_matrix/ICE/')
#p <- add_argument( p, "--name", short = '-n', nargs = '+', help="names for the matrixs", default = 'E80.R1,E80.R2,E120.R1,E120.R2,4M.R1,4M.R2')
p <- add_argument( p, "--name", short = '-n', nargs = '+', help="names for the matrixs", default = 'E80.R1,E80.R2')
p <- add_argument( p, "--prefix", short = '-p', nargs = '?', default = 'prefrontal_corte.clean.chr12.40k',help="prefrontal_corte.clean.chr12.40k")
p <- add_argument( p, "--res", short = '-res', nargs = '?', help="resolution", type = "integer", default = 40000)

if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))

prefix <- args$prefix
prefixs <- unlist(strsplit(prefix, '.', fixed = TRUE))
chrPos <- grep('chr',prefixs)
ices <- unlist(strsplit(args$ICE_dir, ','))
name <- unlist(strsplit(args$name, ','))
bed <- args$bed
genome <- args$genome
#### fitDistPlus ####
genelst<- read.table(bed,header = F)
res <- args$res
len <- read.table(genome,header = F)
len$V3 <- floor(len$V2/res)+1

library(fitdistrplus)
library(matrixStats)
library(fdrtool)
library(iterators)
for(idx in 1:nrow(genelst)){
    chr=genelst[idx,1]
    if(chr=="chrX"){next;}
    s=ifelse(genelst[idx,6]=="+",floor(genelst[idx,2]/res)+1,floor(genelst[idx,3]/res)+1)
    genename=genelst[idx,4]
    Plist<-list()
    Padjlist<-list()
    ct=1
    for (ice_dir in ices){
        prefixs[chrPos] <- as.character(chr)
        pattern <- paste(prefixs,collapse=".")
        cat(pattern)
        ice <- file.path(ice_dir,list.files(path = ice_dir, pattern = pattern))
        cat(ice)
        cat('\n')
        print (genename)
	    a<- read.table(ice,header = F)
        m=as.matrix(a)
        FW=list()
        for(i in 1:50){
            l=m[row(m)-col(m)==i]
            lf=l[l<quantile(l,probs = 0.95) & l!=0]
            #descdist(lf,boot = 1000)
            fitg <- fitdist(lf, "gamma")
            fitLN<- fitdist(lf,"lnorm")
            fitW <- fitdist(lf, "weibull")
            fitn<- fitdist(lf,"norm")
            plot.legend=c("weibull","lognorm","gamma","norm")
            #cdfcomp(list(fitW,fitLN,fitg,fitn),legendtext = plot.legend )
            #denscomp(list(fitW,fitLN,fitg,fitn),legendtext = plot.legend )
            #ppcomp(list(fitW,fitLN,fitg,fitn),legendtext = plot.legend )
            #qqcomp(list(fitW,fitLN,fitg,fitn),legendtext = plot.legend )
            gofstat(list(fitW,fitLN,fitg,fitn),fitnames = plot.legend )
            FW[i]=fitW
        }
        
        P=c()
        n=50
        sink('signal.txt')
        for(i in c(-n:-1,1:n)){
            if(s+i<=0 || s+i >subset(len, len$V1 == as.character(chr))$V3){
                next;
            }else{
                print(s)
                print(s+i)
                if (! is.null(a[s,s+i])) {
                    tmp=pweibull(a[s,s+i], shape = FW[abs(i)][[1]][1],scale = FW[abs(i)][[1]][2],lower.tail = F)
                    P[i+n+1]=tmp
                    print(tmp)
                    print(FW[abs(i)][[1]][1])
                    print(FW[abs(i)][[1]][2])
                }else {
                    P[i+n+1] = 1
                }
		    }
        }
        Plist[[ct]]= P
        Padj=fdrtool(P[!is.na(P)],statistic = 'pvalue',plot = F)
        Poutadj<-c()
        Poutadj[which(!is.na(P))]=Padj$qval
        Padjlist[[ct]]= Poutadj
        ct=ct+1
    }
    names(Plist)<- name
    names(Padjlist)<- name
    #par(mfrow=c(2,1),mar=c(2,2,2,2))
    #par(bty="n",xaxt="n")
    #3wh=m[s,(s-n):(s+n)]
    #image(as.matrix(wh),xaxt = "n",yaxt = "n",zlim=c(quantile(wh,probs = 0.05),quantile(wh,probs = 0.95)))
    
    pdf(paste(as.character(genename),'pdf',sep='.'))
    outp=c()
    cols <- c()
    for(i in 1:length(name)){
        outp=c(outp,max(-log10(Plist[[i]][!is.na(Plist[[i]])])))
    }
    if(max(outp)=="Inf"){outp[which.max(outp)]=300}
    P <- Plist[[1]]
    col <- sample(colors(), 1, replace = FALSE, prob = NULL)
    cols <- append(cols,col)
    plot(-log10(P),type="o",col=col,pch=19,xlim = c(1,length(P)),ylim = c(0,ifelse(max(outp)>15,max(outp),15)),bty="n",xlab ="",main=as.character(genename))
    for (i in seq(2,length(Plist))){
        P = Plist[[i]]
        col <- sample(colors(), 1, replace = FALSE, prob = NULL)
        cols <- append(cols,col)
        points(-log10(P),type="o",col = col, pch=19, xlim = c(1,length(P)),ylim = c(0,ifelse(max(outp)>8,max(outp),8)))
    }
#    legend("topright",col = c("black","gray","green","#F6921E","#ED9438","#D16F0F","#D10F5E","#E83D83","#BA0F55","blue"),cex = 0.7,title = "PFC Stage",legend = c("H1","HIMR90","H11WPL","H13WPL","H14WPL","H18WPL","H23WPL","H24WPL","H26WPL","H24WHipp"),lty = 1,pch = 19)
    legend("topright",col = cols, cex = 0.7, title = "PFC Stage",legend = name,lty = 1,pch = 19)
    #points(pch="*",which(P<1e-4),-log10(P[which(P<1e-4)]))
    #points(pch="+",which(Padj<1e-2),-log10(P[which(Padj<1e-2)])-0.2)
    abline(h=3,lty=2)
    abline(v=n+1,lty=2)
    dev.off()

## export bedgrpah
    start=(((s-50):(s+50))[c(1:50,52:101)]-1)*res
    end=(((s-50):(s+50))[c(1:50,52:101)])*res
    out=as.data.frame(Plist)[c(1:50,52:101),]
    out=-log(out,10)
    out <- data.frame(end = end, out)
    out <- data.frame(start = start, out)
    out <- data.frame(chr = chr, out)
    options(scipen = 999)
    write.table(out,file = paste(as.character(genename),'tab',sep="."),row.names = F,col.names = T,quote = F,sep = "\t")

}

if (0) {
#
#    cd ~/Hi-C/result/humanBrain/Epi/humanBrainHiC/hicexplorer/ini/loop/geneWonSI/
#    for i in `find ./ -name "*HMGA*"|sort`;do  bedGraphToBigWig $i ~/Reference/human/hg19/hg19.bwTransfer.genome $(echo $i|sed 's/\.bedGraph/\.bw/g');done
    ####  R   #####
    a<- data.frame(x=1:100,y1=rnorm(100,0,1),y2=rnorm(100,1,1))
    par(mar=c(10,2,10,2))
    par(bty="n")
    plot(a$x,a$y2,type="o",lty=1,pch=19,col="green",xaxt="n",xlab="",ylim=c(-5,5))
    points(a$x,a$y1,type="o",lty=1,pch=19,col="red")
    abline(h=1,lty=2,col="grey",lwd=2)
}
