#!/usr/bin/env python
import sys
import os
import subprocess
import threading

if len(sys.argv) <=1:
	print('\n\tUsage: ',sys.argv[0],'tissues_dir','share_name\n')
	exit()

def extract_mapped(file,mappedFile):
	cmd = "samtools view -h -F 4 "+file+" > "+mappedFile
	check = "wc -l  "+ mappedFile
	subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True).communicate()[0]
	data = subprocess.Popen(check, stdout=subprocess.PIPE, shell=True)
	print('The lines of header is \n'+data.stdout.read())


dirs = os.listdir(sys.argv[1])
homedir = os.path.abspath(sys.argv[1])
threads = []

for dir in dirs:
#	if os.path.isdir(dir):
#		files = os.listdir(dir)
#		for file in files:
			if dir.endswith(sys.argv[2]):
				file = os.path.join(homedir,dir)
				cwd = homedir
				os.chdir(cwd)
				t = threading.Thread(target=extract_mapped ,args=(file, dir+'.mapped.sam'))
#				t.daemon=(True) #if you want continue with the main die
				t.start()
				threads.append(t)
				os.chdir(homedir)

for t in threads:
	t.join()


