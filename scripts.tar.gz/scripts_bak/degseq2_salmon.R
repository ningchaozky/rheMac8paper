#!/usr/bin/env Rscript
#first
alen <- commandArgs()
library(argparser)
library("tximport")
p <- arg_parser('diff gene expression')
p <- add_argument(p, "--sf", help="files output from salmon")
p <- add_argument(p, "--workDir", help="work_dir", default = ".")
p <- add_argument(p, "--tx2gene", help="", default = 'all')
p <- add_argument(p, "--out", help="output file for diff")

if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
argv <- parse_args(p)


library(DESeq2)
files <- strsplit(argv$sf,',')[[1]]
names(files) <- gsub('.sf','',files)
tx2gene <- read.csv(argv$tx2gene)
txi <- tximport(files, type="salmon", tx2gene=tx2gene)
samples = gsub('.R1.','.',names(files))
samples = gsub('.R2.','.',samples)
condition <- factor(as.vector(samples))
colData <- data.frame(condition)
rownames(colData) <- names(files)
ddsTxi <- DESeqDataSetFromTximport(txi, colData = colData, design = ~ condition)
dds <- DESeq(ddsTxi)
res <- results(dds)
table(res$padj<0.05)
resOrdered <- res[order(res$pvalue),]
diff_gene_deseq2 <- subset(resOrdered, padj < 0.05 & (log2FoldChange > 1 | log2FoldChange < -1))
#diff_gene_deseq2 <- row.names(diff_gene_deseq2)
#resdata <-  merge(as.data.frame(res),as.data.frame(counts(dds2,normalize=TRUE)),by="row.names",sort=FALSE)
write.table(as.data.frame(diff_gene_deseq2),file=argv$out,sep="\t",quote = F)
