#!/usr/bin/perl -w

#cycle   A       T       G       C       N       mask
#1       7135298 3708020 5697987 4851659 0       0
unless(@ARGV){
	print "\nUsage:\t$0 cycle_composition_1.tab cycle_composition_2.tab > quantity.txt\n\t\tcycle_composition_1.tab from htseq output\n\n";
}
else{
my $nu = 0;
print "cycle\tpercent\ttype\n";
while(<>){
	chomp;
	@tmp_arry = split /\t/,$_;
	unless($tmp_arry[1] !~ /\d+/){
		$nu++;
		$sum = $tmp_arry[1]+$tmp_arry[2]+$tmp_arry[3]+$tmp_arry[4]+$tmp_arry[5];
		$percent_A = $tmp_arry[1]/$sum*100;
		$percent_T = $tmp_arry[2]/$sum*100;
		$percent_G = $tmp_arry[3]/$sum*100;
		$percent_C = $tmp_arry[4]/$sum*100;
		$percent_N = $tmp_arry[5]/$sum*100;
		print "$nu\t$percent_A\tA\n";
		print "$nu\t$percent_T\tT\n";
		print "$nu\t$percent_G\tG\n";
		print "$nu\t$percent_C\tC\n";
		print "$nu\t$percent_N\tN\n";
	}
}
}
