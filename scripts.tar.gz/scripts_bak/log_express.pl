#!/usr/bin/perl
use strict;
use warnings;
use Math::Complex;

my ($file,$log);

unless(@ARGV){
	die "Usage: $0 file [2]\n\tdo log transform\n";
}

open $file,"$ARGV[0]";
if(@ARGV == 2){
	$log = pop @ARGV;
}else{
	$log = 2;
}

while(<$file>){
	chomp;
	my @tmp = split /\t/,$_;
	my $out;
	for(@tmp){
		if(/^\d+.?\d+$/){
			$_ += 1 ;
			$out .= sprintf ("%.3f",logn($_,$log))."\t";
		} else {
			$out .= "$_\t";
		}
	}
	$out =~ s/\t$//;
	print "$out\n";
}
