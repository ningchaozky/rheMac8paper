#!/usr/bin/perl
use strict;

unless(@ARGV){
	print "\n\tUsage: $0 genes.fpkm_tracking gff3\n\n";
}else{
	my $gtf;
	my %name;
	open $gtf,"$ARGV[1]";
	while(<$gtf>){
		my @tmp = split /\t/,$_;
		if(@tmp >7){
			my @des = split /[:;=]/,$tmp[8];
			$name{$des[4]} = $des[2];
		}
	}

	my $cuf;
	open $cuf,"$ARGV[0]";
	my $title = <$cuf>;
	chomp $title;
	my @tmp = split /\t/,$title;
	my $i = -1;
	my @pos;
	print "ID\tgene name\t";
	for(@tmp){
		$i++;
		if(/FPKM/){
			print "$_\t";
			push @pos,$i;
		}
	}
	print "\n";
	
	while(<$cuf>){
		my @tmp = split /\t/,$_;
		my @gene = split /,/,$tmp[4];
		for my $gene(@gene){
			unless($gene =~ /^-$/){
				if($name{$gene}){
					print "$name{$gene}\t$tmp[0]\t";
				}
				else{
					print "$gene\t$tmp[0]\t";
				}
			}
			else{
				print "$tmp[0]\t$tmp[0]\t";
			}
			for(@pos){
					print "$tmp[$_]\t";
			}
			print "\n";
		}
	}
}
