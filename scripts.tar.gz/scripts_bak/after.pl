#!/usr/bin/perl -w

unless($ARGV[0]){
print "\ngive me a sequence name, i will give\nyou after the name's sequence\n\n\tafter.pl name fastq\n\n";
}
else{
open SEQ, "$ARGV[1]";
$i = 0;
while (<SEQ>) {
$name = quotemeta $ARGV[0];
chomp $name;
	if(/^>$name$/){
	print;
	$i=1;
	}
	elsif($i==1){
	print;
	}
}
close SEQ;
}

