#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick, system

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('p', nargs='?', help = 'pattern')
parser.add_argument('-dir', nargs='?', help = 'readme for manual', default = '.')
parser.add_argument('-depth', nargs='?', help = 'depth for find readme.status.txt')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

fls = system.dir( args.dir ).fls('readme.status.txt$', depth = 10)
for fl in fls:
    fh = open( fl )
    tmp = open ( fl +'tmp','w' )
    string = re.split(r'\n{2,}', ''.join( fh.readlines() ) )
    for cmd in string:
        stat = cmd.split('\t')
        if not stat[0].startswith('#') and re.search( r'{}'.format( args.p ), stat[0]):
            sys.stderr.write( cmd +'\n')
            cmd = '#' + cmd
        tmp.write( cmd +'\n\n\n\n')
    tmp.close()
    os.system('mv {} {}'.format(tmp.name, fl))



























