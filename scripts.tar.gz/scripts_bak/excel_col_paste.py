#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( '-xls', nargs='*', help ='xls for paste' )
parser.add_argument( '-index', nargs='*', help ='reference', type = int, default = [1,2,3,4,5])
parser.add_argument( '-each_excel_fix_pos', nargs='?', help ='reference', default = 6)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

excels = args.xls
lst = []
index = [ i - 1 for i in args.index ]
fxls = excels[0]
ffh = open(fxls)
for line in ffh:
    line_arr = line.strip().split('\t')
    lst.append( trick.getList(line_arr, index) )
ffh.close()

for xls in excels:
    fh = open(xls)
    for i,line in enumerate(fh):
        line_arr = line.strip().split('\t')
        lst[i].append( trick.getList( line_arr, args.each_excel_fix_pos - 1) )

for each in lst:
    print('\t'.join(each))



























