#!/usr/bin/perl 

if( (! exists $ARGV[0])){
	print "Usage: \nexcelN.pl title xls\n\thash used\t title can be title|m.*\n\txls like express\n"
}
else{
open TITLE,"< $ARGV[0]";
open XLS, "< $ARGV[1]";

#get a %hash
while(<XLS>){
s///g;
chomp;
	if(/^\S+/){	
	my ($name,$seq) = split /\t/,$_,2;
	$hash{$name} = $seq;
	}
}


# get the value

while(<TITLE>){
chomp;
$af = $_;
s/\s+.*//;
s/\|m\..*//;
print "$_\t$hash{$_}\t$af\n";
}


close TITLE;
close XLS;
}
