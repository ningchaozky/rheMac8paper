#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('fl', nargs = '?', help = 'file deal with')
parser.add_argument('stat', nargs = '*', help = 'file deal with')
parser.add_argument('-r', action = 'store_true', help = 'reverse. for eg, del E12 -r for include E6')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_repress_stat( fl, repress_stat, rev ):
    fh, infor, out = open( fl ), {}, {}
    for line in fh:
        if 'period' in line:
            continue
        peiord, pos, stat, num = line.strip().split('\t')
        trick.dinit( infor, pos, stat, [] )
        infor[ pos ][ stat ].append( peiord )
    fh.close()
    for pos in infor:
        if 'pos' in pos:
            continue
        chrom, bins = pos.split('.')
        #print ( infor[pos].keys(), infor[pos].values() )
        stats = set(infor[pos])
        if rev :
            if set( repress_stat ) & stats :
                continue
            trick.dinit( out, chrom, pos, 1 )
        if not args.r:
            if len( stats ) == 1 and set( repress_stat ) in stats:
                trick.dinit( out, chrom, pos, 1 )
    return out




if __name__ == '__main__':
    fl, rstat, rev = args.fl, args.stat, args.r
    infor = get_repress_stat( fl, rstat, rev)
    fh = open( fl )
    print ( next( fh ).strip() )
    for line in fh:
        if not line.strip():
            continue
        peiord, pos, stat, num = line.strip().split('\t')
        chrom, bins = pos.split('.')
        if chrom in infor and pos in infor[chrom]:
            continue
        print ( line.strip()  )


























