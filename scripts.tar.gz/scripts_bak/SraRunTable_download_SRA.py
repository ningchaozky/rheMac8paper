#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'csv', nargs = '?', help = 'download SraRunTable from paper GEO link' )
parser.add_argument( '-v', nargs = '?', help = 'version for sratoolkit', default = '2.11.3', choices = ['2.9.6','2.11.3'] )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def pick():
    selector = []
    #xiewei nature 2016  The landscape of accessible chromatin in mammalian preimplantation embryos PRJNA317459
    #ChIP-Seq 2-cell H3K27ac: GSM2108724, ChIP-Seq 2-cell H3K27me3: GSM2108725, GSE79935_RAW.tar accessible chromatin, 
    #/farangism/ningch/earyly_embryo/xiewei.2016.nature.accessible/cmds.sh
    p1 = ['anti-H3K27ac', 'anti-H3K27me3']
    #xiewei Resetting epigenetic memory by reprogramming of histone modifications, PRJNA309055
    p2 = ['Inner cell mass', 'Inner cell mass', 'Preimplantation embryo', 'primordial germ cell', 'MII oocyte', 'GV oocyte', 'Growing oocyte', 'Mature sperm']

    selector.extend(p1)
    selector.extend(p2)
    return selector
df = pd.read_csv( args.csv, header = 0 )
SRRs = df['Run'].to_list()

name = '{}.run.txt'.format(args.csv)
df['Run'].to_csv( name, index = False, header = False)



for each in SRRs:
    #cmd = 'sra_download.py {}'.format( each )
    if args.v == '2.9.6':
        print ('''/home/soft/soft/sratoolkit/v2.9.6/bin/prefetch -t ascp -a "/home/soft/.aspera/connect/bin/ascp|/home/soft/.aspera/connect/etc/asperaweb_id_dsa.openssh" --output-directory . {}'''.format( each) )
    elif args.v == '2.11.3':
        print ('''prefetch {} --max-size 100G  --output-directory . '''.format( each ) )




























