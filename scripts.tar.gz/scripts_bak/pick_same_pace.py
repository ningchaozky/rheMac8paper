#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = '''same pace for gene express and active signal'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'm1', nargs='?', help = 'active signal' )
parser.add_argument( 'm2', nargs='?', help = 'RNA express' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( matrix ):
    fh, dit = open( matrix ), {}
    for line in fh:
        if 'gene' in line:
            continue
        line_arr = line.strip().split('\t')
        gene, rh8, mouse = line_arr
        trick.dinit( dit, gene, [] )
        dit[gene].append( [ rh8, mouse, float( rh8 ) - float( mouse ) ,0 < float( rh8 ) - float( mouse ) or 0 < float( rh8 ) + 0.5 - float( mouse )] )
    return dit
m1 = parse( args.m1 )
m2 = parse( args.m2 )

def check( *args ):
    lst, i1, i2 = [], 0, 0 
    for i in args :
        for each in i :
            lst.append( each[-1] )
    for each in lst:
        if each == True :
            i1 += 1
        if each == False :
            i2 += 1
    return i1 >= 2 or i2 >= 2

for gene in m1:
    if gene in m2:
        if check( m1[gene], m2[gene] ):
            print(gene, trick.lst( m1[gene][0] ).join(), trick.lst( m2[gene][0] ).join())
































