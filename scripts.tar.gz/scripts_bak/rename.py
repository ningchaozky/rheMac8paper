#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'pattern', nargs = '?', help = 'pattern for rename')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



fls = system.dir( '.' ).fls(args.pattern, fdir = True )
for fl in fls:
    fl = fl.strip('./')
    if '.' in fl.strip('./') :
        oname = fl.split('.')[0]
        print ('mv {} {}'.format( fl, oname ) )




























