#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('segment', nargs='?', help ='segment file')
parser.add_argument('-len', '-l', nargs = '?', type = int, help ='key words for include in file name', default = 400)
parser.add_argument('-stat', '-s', nargs = '*', help ='stat you want to extract', required = True )
parser.add_argument('-o', nargs='?', help ='reference')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

ofh = sys.stdout
if args.o:
    ofh = open(ofh,'w')
segment = open(args.segment)
stat = args.stat
span = args.len
for line in segment:
    line_arr = line.split('\t')
    if line_arr[-1].strip() in stat or line_arr[-1].strip().replace('E','') in stat:
        length = int(line_arr[2]) - int(line_arr[1])
        if length > span:
            ofh.write(line)



ofh.close()
segment.close()












