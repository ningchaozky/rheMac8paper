#!/usr/bin/env python3
import os
import re
import sys
import argparse
import random
from ningchao.nSys import trick
from collections import defaultdict
desc = ''''''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 't', nargs='?', help = 'raw intput uniq  random int uniq|float')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def uniq():
    if 'uniq' in args.t:
        while True :
            print ('Please input strings: ...')
            data, infor = sys.stdin.readlines(), defaultdict( list )
            print ( 'Start: ...', sep = '\n')
            i = 0
            for each in data:
                each =  each.rstrip()
                if not each :
                    continue
                i += 1
                infor[each.upper() ].append( each )
            print ( infor, sep = '\n')
            for each in infor :
                print ( infor[each][0] )
            print ('Input {}, output {}, Next...'.format( i, len(infor.keys())))

def random_float():
    if 'float' in args.t :
        while True :
            length,start,end,times,columns = 0,0,0,0,1
            header = ['length','start','end','times','columns']
            while True :
                print ('Pleas intput start end times...')
                para = re.split(r'\s+', sys.stdin.readline().strip())
                if len( para ) == 3 :
                    break
                if len( para ) == 4 :
                    columns = int( para.pop( -1 ) )
                    break
            start, end, times = para
            print ( *header, *para, columns, sep = '\t' )
            for i in range( int(times) ):
                num = random.uniform(int(start), int(end))
                print ( *[ random.uniform(int(start), int(end)) for i in range(columns)], sep = '\t')

if __name__ == '__main__':
    uniq()
    random_float()




















