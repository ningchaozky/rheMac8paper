#!/usr/bin/env python3
def jaccard_sim(a, b):
    unions = len(set(a).union(set(b)))
    intersections = len(set(a).intersection(set(b)))
    return intersections / unions
 
a = ['1', '0', '1','0','0','1','0']
b = ['1', '1', '1','0','0','0','1','1','1']
print(jaccard_sim(a, b))



