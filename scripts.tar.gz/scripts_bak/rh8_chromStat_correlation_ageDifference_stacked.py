#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#subplot define, also polar plot
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import pyBigWig
import itertools
import numpy as np
import random
import pandas as pd
from scipy import stats as STATS
from collections import defaultdict
from ningchao.nSys import trick, parse, fix

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'segment', nargs = '?', help = 'segments.bed from chromHMM output')
parser.add_argument( '-bwsIni', nargs = '?', help = 'ini for bw files', default = '/dataB/ftp/pub/rheMac3/bws.ini')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def chrom_stats( segment ):
    infor = defaultdict( list )
    with open( segment ) as fh :
        for line in fh:
            chrom,start,end,stat = line.strip().split('\t')
            infor[stat].append([chrom, int( start ), int( end )])
    for stat in infor:
            print ( stat, len(infor[stat]), file = sys.stderr)
    return infor

def values( bwinfor, stats_regions ):
    fhs, ovalues = defaultdict( lambda : defaultdict( str ) ), defaultdict( lambda : defaultdict( lambda : defaultdict(list) ) )
    for pfc in bwinfor:
        for marker in bwinfor[pfc]:
            for peirod in bwinfor[pfc][marker]:
                bw = pyBigWig.open( bwinfor[pfc][marker][peirod] )
                fhs[peirod][marker] = bw
                print ('{} chroms is {}'.format( bwinfor[pfc][marker][peirod], bw.chroms()))
    for peirod in fhs:
        for marker in fhs[peirod]:
            bwfh = fhs[peirod][marker]
            for stat in stats_regions:
                regions = stats_regions[stat]
                ofh = open( '{}.{}.{}.valeus.xls'.format(peirod,marker,stat), 'w')
                for chrom, start, end in regions:
                    try :
                        val =  bwfh.stats(chrom, int(start), int(end))[0] * ( end - start )
                        ovalues[peirod][marker][stat].append( val )
                        print ( chrom, start, end, val, sep = '\t', file = ofh )
                    except :
                        print ( chrom, start, end, bwfh, bwfh.chroms(), file = sys.stderr)
                ofh.close()
    return ovalues

def sample_same_length( lst1, lst2 ):
    if len( lst1 ) > len( lst2 ):
        lst1_random = random.sample( lst1, len( lst2 ))
        return lst1_random, lst2
    else :
        lst2_random = random.sample( lst2, len( lst1  ) )
        return lst1, lst2_random

def delta(p1,p2):
    ds = {'E50':150,'E80':240,'E90':270,'E120':360,'0M':165,'4M':285,'45Y':1785,'20Y':7365 }
    return abs( 1/ds[p1] - 1/ds[p2] )

def correlation( ovalues ):
    lst, dflst = [], []
    peirods = list( ovalues.keys() )
    markers = list( ovalues[peirods[0]].keys() )
    stats = list( ovalues[peirods[0]][markers[0]].keys()  )
    for peirod in peirods:
        for marker in markers:
            for stat in stats:
                lst.append([peirod,marker,stat])
    comb = list(itertools.combinations( lst,2))
    for k1,k2 in comb :
        p1,m1,s1 = k1
        p2,m2,s2 = k2
        vals1 = ovalues[p1][m1][s1]
        vals2 = ovalues[p2][m2][s2]
        print ('#Calculate {} vs {}... '.format(k1,k2))
        pvalue, p = STATS.pearsonr( *sample_same_length(vals1, vals2))
        dflst.append ( [ p1, p2, m1, m2, s1, s2, delta(p1,p2), pvalue, p ] )
    return pd.DataFrame( dflst, columns = [ 'p1', 'p2', 'm1', 'm2', 's1', 's2', 'delta','pvalue', 'cor'] )
if __name__ == '__main__':
    xls,figname = fix.fix(args.segment).append('correlation.xls'), fix.fix(args.segment).append('correlation.pdf')
    if not os.path.exists( xls ):
        bwinfor = parse.ini( args.bwsIni ).to_dict()
        stats_regions = chrom_stats( args.segment )
        ovalues = values( bwinfor, stats_regions  )
        df = correlation( ovalues  )
        df.to_csv(fix.fix(args.segment).append('correlation.xls'), sep = '\t', index_label = 'id')
    df = pd.read_csv(xls, header = 0, sep = '\t')
    df = df[ (df.s1 == 'E3') & (df.s2 == 'E3') & (df.delta != 0)]
    df = df[ (df.m1 != 'RNA') & (df.m2 != 'RNA')]
    df = df[ (df.m1 != 'CTCF') & (df.m2 != 'CTCF')]
    df = df[ (df.m1 != 'dnase') & (df.m2 != 'dnase')]
    df = df[ df.m1 == df.m2 ]
    df = df.groupby(['p1','p2', 'm1', 'm2', 's1', 's2', 'delta'])['cor'].agg('mean').reset_index()
    print (df)
    fig,ax = plt.subplots( 2, figsize=(10,30), subplot_kw=dict( projection = None ))
    sns.scatterplot( x = 'delta', y = 'cor',hue = 'm1',data = df, ax = ax[0])
    sns.boxplot( x = 'delta', y = 'cor',data = df, ax = ax[1])
    plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
















