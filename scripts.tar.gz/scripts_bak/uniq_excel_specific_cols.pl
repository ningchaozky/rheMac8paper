#!/usr/bin/env perl
use strict;
use warnings;

@ARGV || die "$0 excl,col,col\n";

my %hash;
my @arg = split /,/,$ARGV[0];
open XLS, shift @arg;

while(<XLS>){
	chomp ;
	my @tmp_arr = split /\t/,$_;
	my @key;
	for my $col(@arg){
		if (@tmp_arr > $col-1){
			push @key,"$tmp_arr[$col-1]";
		} else {
			print STDERR "$_\n";
		}
	}
	my $key =  join("\t",@key);
	if (not defined $hash{$key}){
		print "$_\n";
	}
	$hash{$key} = $_;
}



