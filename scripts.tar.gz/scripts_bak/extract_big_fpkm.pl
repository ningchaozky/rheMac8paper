#!/usr/bin/perl
use strict;

unless(@ARGV){
	die "Usage: $0 fpkm xls\n";
}

my ($fpkm,$xls);
open $xls,"$ARGV[1]";
$fpkm = $ARGV[0];
<$xls>;
while(<$xls>){
	my @tmp = split /\t/,$_;
	my $name = shift @tmp;
	my $i;
	for(@tmp){
			$i  += $_;
	}
	if($i >= 1){
		print "$name\n";
	}
}
