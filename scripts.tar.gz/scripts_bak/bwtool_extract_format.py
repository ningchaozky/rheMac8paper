#!/usr/bin/env python
import sys
import argparse

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('-bs', nargs='*', help ='beds for deal')
parser.add_argument('-bin', nargs='?', help ='bin the bed region or not default not. you can put peak. default = whole peak mean', default = 'all')
parser.add_argument('-o', nargs='?', help ='output file for the data', default = 'extract.default.bed')
parser.add_argument('-n', nargs='*', help ='name for output title default is the input bs name')
parser.add_argument('-f', nargs='*', default = ['ppois','bed','sp'],help ='fiter bs key word not in title ')
parser.add_argument('-m', nargs='?', default = 'median',help ='method you want get from the region. mean|min|max|median|mode|cv|var|ptp|std ')


if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
header_lst =  ['chr','start','end']
belen = len(header_lst)
method = args.m


def name_fit(string,lst):
        str_arr = string.split('.')
        return '.'.join([i for i in str_arr if i not in lst])

def binLst( lst, span = 50 , fun = 'median', default = 0):
        ''' mean|min|max|median|mode|cv|var|ptp|std'''
        from numpy import median,mean,std,var
        from scipy.stats import mode
        val_out = []
        lst = [ float(i) for i in lst ]
        bin_lst = list(range(0,len(lst),span))
        bin_lst.append(len(lst))
        bin_lst = iter(bin_lst)
        start_index = next(bin_lst)
        def cv(lst):
                return mean(lst) / std(lst)
        for end in bin_lst:
                val = eval(fun)(lst[start_index:end])
                val_out.append((start_index,end,val))
                start_index = end
        return val_out

def set1dict(dict1,a,val):
        if dict1.get(a) == None :
                dict1.update({a:val})



if args.n:
	header_lst.extend(args.n)
else :
	tmp_name = [ name_fit(i,args.f) for i in args.bs ]
	header_lst.extend(tmp_name)




if not args.bin == 'all':
	bed_bin = int(args.bin)
beds = args.bs
infor = {}
for j,bed in enumerate(beds):
	bedfh = open(bed)
	i = 0
	for line in bedfh:
		i += 1
		name = header_lst[j + belen]
		line_arr = line.strip().split('\t')
		value_arr = line_arr[-1].split(',')
		value_arr = [ k for k in value_arr if k != 'NA' ]
		if args.bin == 'all':
			bed_bin = len(value_arr)
		extract_infor = []
		try :
			extract_infor = binLst ( value_arr, span = bed_bin, default = 0, fun = method )
		except :
			print(value_arr,bed_bin)
		for start,end,val in extract_infor:
			if  args.bin == 'all':
				end = line_arr[2]
			else :
				end = str(int(line_arr[1])+end)
			key = '\t'.join([line_arr[0],str(int(line_arr[1])+start),end])
			set1dict(infor,key,[])
			infor[key].append(val)
	bedfh.close()

out = open(args.o,'w')
out.write('\t'.join(header_lst) + '\n')
for each in infor:
	out.write(each +'\t')
	out.write('\t'.join([str(i) for i in infor[each]]) +'\n')
out.close()




















