#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from pybedtools import BedTool
from ningchao.nSys import trick,system
from ningchao.nBio import bw,chromosome
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='use the point intersect the peaks and pick peaks sum vlaues', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bw', nargs='?', help ='bw file for extract' )
parser.add_argument( 'points', nargs='?', help ='region like tss' )
parser.add_argument( 'peaks', nargs='?', help ='macs2 callpeaks results' )
parser.add_argument( '-n', nargs='?', help = 'name for the column' )
parser.add_argument( '-o', nargs='?', help = 'ouput file' )
parser.add_argument( '-s', nargs='?', type = int, default = 1000, help = 'max span for the peaks. Note this is bigger than points smaller than peaks. default up and down 1000. more than tss 1000' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def intersect(points, peaks):
    infor = {}
    cmd = 'bedtools intersect -a %s -b %s -wo' % (points, peaks)
    stdout, stderr, returncode = system.run(cmd)
    fline = next(stdout)
    posA, posB, line_arr = check(fline)
    key = trick.lst( trick.lst(line_arr).get(posA) ).toStr(sep = '\t')
    value = trick.lst(trick.lst(line_arr).get(posB)).toStr(sep = '\t')
    trick.dit(infor).set(key, [ value ])
    for line in stdout:
        line = line.strip()
        if not line :
            continue
        line_arr = line.split('\t')
        key = trick.lst(trick.lst(line_arr).get(posA)).toStr(sep = '\t')
        value = trick.lst(trick.lst(line_arr).get(posB)).toStr(sep = '\t')
        trick.dit(infor).set(key, [  ])
        if value not in infor[key]:
            infor[key].append( value )
    return infor

def check(line):
    line_arr = line.strip().split('\t')
    index = [ i for i,v in enumerate(line_arr) if v.startswith('chr') ]
    posA, posB = [ (i,i+1,i+2) for i in index ]
    return posA, posB, line_arr

def values( line_arr, intersect_arr, mspan, chroms):
    val,line_arr = 0,[ int(i) for i in line_arr[1:3] ]
    for each in intersect_arr:
        nums = line_arr[ : ]
        chrom,start,end = each.strip().split('\t')
        nums.extend([ start,end ] )
        nums = [ int(i) for i in nums ]
        dstart,start,end,dend = sorted(nums)
        if [ start, end ] == line_arr:
            new_start = line_arr[0] - mspan > 0 and line_arr[0] - mspan or 0
            new_end = line_arr[1] + mspan < chroms[chrom] and line_arr[1] + mspan or chroms[chrom]
            new_arr = [ new_start, new_end, dstart, dend ]
            new_arr = sorted(new_arr)
            return bw.sum( chrom, new_arr[1], new_arr[2] )
        val += bw.sum( chrom, start, end )
    return val

if __name__ == '__main__':
    points, peaks, name, mspan = args.points, args.peaks, args.bw, args.s
    bw, chroms = bw.bw(args.bw), chromosome.chr('rh8', sexY = True ).chr
    infor = intersect(points, peaks)
    pfh = open(points)
    if args.n:
        name = args.n
    ofh = args.o and open(args.o, 'w') or sys.stdout
    ofh.write('chr\tstart\tend\t%s\n' % name)
    for line in pfh:
        if 'track' in line :
            continue
        line_arr = line.strip().split('\t')
        chrom, start, end = line_arr[0:3]
        start = int(start); end = int(end)
        key = trick.lst(line_arr[0:3]).toStr('\t')
        if key in infor:
            value = values( line_arr, infor[key], mspan, chroms)
        else :
            #sys.stderr.write('\t'.join([ chrom, str(start), str(end) ]) + '\n' )
            value = 0 and bw.sum( chrom, start, end ) or 0.1 
        line_arr = line_arr[0:3]
        line_arr.append(str(value))
        ofh.write('\t'.join(line_arr) + '\n')



















