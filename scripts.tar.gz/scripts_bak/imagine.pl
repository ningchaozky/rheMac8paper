#!/usr/bin/perl 
use strict;
unless(@ARGV){
	print "Usage: $0 kobas_output out_file_name\n";
}
else{
	my $xls;
	system("mkdir -p $ARGV[1]") unless (-d $ARGV[1]);
	open $xls,"$ARGV[0]";
	while(<$xls>){
		chomp;
		my @tmp = split /\t/,$_;
		if($tmp[8] =~ /^h/){
			system("imagine_download.sh $tmp[8] -d xxx");
		}
	}
}
