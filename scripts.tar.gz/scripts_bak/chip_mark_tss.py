#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import pybedtools
from ningchao.nSys import trick
from ningchao.nBio import order as orderLst

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bed', nargs='?', help =' bed file ' )
parser.add_argument( '-marker', '-m', choices = ['K4', 'AC', 'K27', 'pol2', 'CTCF','dnase'],  nargs='?', help ='', required = True )
parser.add_argument( '-peirod', '-p', choices = ['E50','E80','E90','E120','0M','4M','45Y','20Y'], nargs='?', help = '', required = True )
parser.add_argument( '-out','-o', nargs='?', help ='output file', required = True )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def table(out,tss,header):
    out_tmp = out + '.tmp'
    ofh = open(out_tmp,'w')
    ofh.write( '\t'.join(header) + '\n' )
    tfh = open(tss)
    mlen = len(header)
    for line in tfh:
        out_line_arr = [ '' for i in range(mlen) ]
        line_arr = line.strip().split('\t')
        for i,v in enumerate(line_arr):
            out_line_arr[i] = line_arr[i]
        ofh.write( '\t'.join(out_line_arr) + '\n' )
    ofh.close()
    if not os.path.exists(os.path.join(os.getcwd(), out)) :
        os.system('cp %s %s' % (out_tmp,out))
out = args.out
tss = '/home/ningch/data/genome/rheMac8/exon/ref_ensemble_xeonRefGene.Tss3K.bed'
order = ['K4', 'AC', 'K27', 'pol2', 'CTCF','dnase']
header = ['chr','start','end','gene','placeHolder','chain']
header.extend(order)
table(out,tss,header)
old_fh = open(out)
next(old_fh)
bed = pybedtools.BedTool(args.bed)
tss = pybedtools.BedTool(tss)
bedIntersectTss = tss.intersect(bed, u = True )
lst = [ str(i).strip() for i in list(bedIntersectTss) ]
marker, peirod = args.marker, args.peirod
index = header.index(marker)
tmp = out + '.tmp'
tfh = open(tmp, 'w')
tfh.write('\t'.join(header) + '\n' )
for line in old_fh:
    line_arr = line.strip('\n').split('\t')
    try :
        peirod_extend = line_arr[index].split(',')
    except :
        print(args.bed)
        exit()
    gene = '\t'.join(line_arr[0:6])
    if gene in lst:
        peirod_extend.append(peirod)
    peirod_extend.insert(0, marker)
    ps = trick.uList(peirod_extend, deEmpty = 'yes')
    ps = orderLst.orderLst(ps)
    line_arr[index] = ','.join(ps)
    tfh.write( '\t'.join(line_arr) + '\n' )
tfh.close()
os.system('mv %s %s' % (tmp,out))




















