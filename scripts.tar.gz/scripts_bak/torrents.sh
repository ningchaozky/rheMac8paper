#!/usr/bin/env sh
if [ $# -lt 1 ]; then
    echo $0 ''
    exit
fi

torr_link="${1}"

#perl parses the link and keeps as torrent title whatever comes after the variable "title" in the link
torr_title=$( echo "${torr_link}" | perl -ne 's/(.*)title=(.*)/\2/g; print;' )
echo "downloading ${torr_title}"

wget -O "${torr_title}".torrent.gz "${1}"

gunzip "${torr_title}".torrent.gz





























