#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
#plt.style.use('ggplot')
import argparse
import gzip
import json
import pandas as pd
from Bio import SeqIO
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'gz', nargs = '?', help = 'computMarixoutput gz file')
parser.add_argument( '-num', nargs = '?', help = 'num want to show', default = 5, type = int)
#parser.add_argument( '-g', nargs = '?', help = 'genome fasta file', required = True)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def show(lst, num):
    infor = [ ( k, len(lst), v) for k,v in enumerate( list(lst) ) ]
    out = sorted ( infor, key = lambda x: x[2], reverse = True )[0:num]
    return out


values = []
with gzip.open( args.gz ) as f:
    js = json.loads( next( f ).strip().decode().replace('@','') )
    up,body,down,binsize =  ( js['upstream'], js['body'], js['downstream'], js['bin size'] )
    for line in f:
        line_arr = line.decode().strip().split('\t')
        arr = line_arr[6:]
        values.append( [ float(i) for i in arr ] )

df = pd.DataFrame( values )
df.loc['mean'] = df.mean()
show_num = show(df.mean(), args.num)
df.to_csv('test.xls', sep = '\t')
print ( 'output num is is {}'.format( str(show_num) ), file = sys.stderr)

with gzip.open( args.gz ) as f:
    js = json.loads( next( f ).strip().decode().replace('@','') )
    up,body,down,binsize =  ( js['upstream'], js['body'], js['downstream'], js['bin size'] )
    for spd_num, line in enumerate(f):
        line_arr = line.decode().strip().split('\t')
        arr = line_arr[6:]
        length = int( line_arr[2] ) - int( line_arr[1] )
        print ( *line_arr[0:6], sep = '\t', file = sys.stderr)
        for pos, whole_length, value in show_num:
            region = 'chr'+line_arr[0], int( line_arr[1]) + int( (pos-2)/len(arr) * length), int( line_arr[1]) + int( (pos+2)/len(arr) * length)
            print ( 'spd{}'.format(spd_num+1), *region, '.', sep = '\t')
            print ( *region, pos, whole_length, 'max/body', pos/whole_length, len( arr ), 'body/whole', whole_length/len( arr ), 'value', value, file = sys.stderr)
            print ('\n', file = sys.stderr)

























