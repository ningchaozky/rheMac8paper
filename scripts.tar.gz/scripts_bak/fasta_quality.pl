#!/usr/bin/perl -w

unless(@ARGV){
	print "\nUsage:\t$0 file\n\tgive N10 N20 N30 N40 N50 mean length and length\n\n";
}
else{
#length hash and while bases
open $fa,"$ARGV[0]";
my %len;
my $bases;
my $name;
while(<$fa>){
	chomp;
	if(/>/){
		$name = $_;
	}
	else{
		$bases += length $_;
		$len{$name} += length $_;
	}
}

close $fa;
$N50 = int $bases/2;
$N20 = int $bases/5;
$N30 = int $bases/3;
$N10 = int $bases/10;
$N40 = int $bases/2.5;
$len = int $bases/1000**2;

#get bases N10,N20,N30,N50
for(sort{$len{$b}<=>$len{$a}}keys %len){
	push @arry,"$_\t$len{$_}";
}
# prepare for longest and shortest
$arry_len = @arry;
@Longest = split /\t/,$arry[0];
@Shortest = split /\t/,$arry[$arry_len - 1];

# find the excetly sequence

@arry2 = @arry;
@second = split /\t/,shift @arry2;
$tmp2_len = $second[1];
my $i = 0;
while($first = shift @arry){
	$i++;
	@first = split /\t/,$first;
	$tmp1_len += $first[1];
	if($second = shift @arry2){
		@second = split /\t/, $second;
		$tmp2_len += $second[1];
		if($tmp1_len <= $N10 && $tmp2_len >= $N10){
			print "N10\t$first[1]\t$first[0]\n";
		}
		elsif($tmp1_len <= $N20 && $tmp2_len >= $N20){
			print "N20\t$first[1]\t$first[0]\n";
		}
		elsif($tmp1_len <= $N30 && $tmp2_len >= $N30){
			print "N30\t$first[1]\t$first[0]\n";
		}
		elsif($tmp1_len <= $N40 && $tmp2_len >= $N40){
			print "N40\t$first[1]\t$first[0]\n";
		}
		elsif($tmp1_len <= $N50 && $tmp2_len >= $N50){
			print "N50\t$first[1]\t$first[0]\n";
		}
	}
}
$mean = int $bases/$i;
print "Longest\t";
print join "\t",@Longest;
print "\n";
print "Shortest\t";
print join "\t",@Shortest;
print "\n";
print "Bases\t$len MB\nMean\t$mean\n";
}
