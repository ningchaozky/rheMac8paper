#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import argparse
import ssl
import chardet
import argparse
import urllib2 as url
import urllib.request, urllib.parse, urllib.error
import base64
import requests
from bs4 import BeautifulSoup as bs
from ningchao.nSys import trick, env, html
import importlib

example = '''max page you want to check the auction'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'max', nargs='?', help ='max pages for tha auction' )
parser.add_argument( '-p', nargs='?', help ='pattern u want to download', required = True )
parser.add_argument( '-s', action = 'store_true', help ='exe' )

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()
importlib.reload(sys)  
sys.setdefaultencoding('utf8')   
ssl._create_default_https_context = ssl._create_unverified_context



def parse( args ):
    pattern = args.p
    p = re.compile(r'%s' % pattern, re.IGNORECASE )
    html_obj = html.html( dynamic = True )
    return html_obj, p

def pgs( pMax ):
    url = 'https://paipai.jd.com/auction-list/%7B%22pageNo%22%3A1%2C%22pageSize%22%3A50%2C%22category1%22%3A%22%22%2C%22status%22%3A%22%22%2C%22orderDirection%22%3A1%2C%22orderType%22%3A1%2C%22groupId%22%3A1000005%7D?entryid='.replace('%','~')
    return [ url.replace('No~22~3A1~2C~22', 'No~22~3A%s~2C~22' % str(i+1)).replace('~','%') for i in range(int(args.max)) ]
    


if __name__ == '__main__':
    html_obj, p = parse( args )
    pages = pgs( args.max )
    for url_id in pages:
        content = html_obj.open( url_id )
        for each in content.find_all('a'):
            href = each['href']
            if '/auction-detail/' in href and p.search( str(each.text) ):
                href = 'https://paipai.jd.com/' + str( href ).strip('/')
                print(each.text, href)
    html_obj.quit()




