#!/usr/bin/env python
import os
import sys
import gzip 
import ningch as nc 

nc.usage('fastq|fastq.gz')


if sys.argv[1].endswith('.gz'):
	fh = gzip.open(sys.argv[1])
else:
	fh = open(sys.argv[1])

num = 0
for each in fh:
	num += 1
print(num)
