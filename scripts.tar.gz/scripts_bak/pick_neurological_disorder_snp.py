#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ./neuron/nervous_system_disease_fromOBOFaltFile.txt gwas_catalog_v1.0.2-associations_e93_r2018-09-15.tsv' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-t', nargs='?', help ='Traits', default = '/home/ningch/data/genome/Homo_sapiens/neuron/nervous_system_disease_fromOBOFaltFile.txt')
parser.add_argument('-a', nargs='?', help ='associations', default = 'gwas_catalog_v1.0.2-associations_e93_r2018-09-15.tsv')
parser.add_argument('-s', action='store_true', help ='start')
parser.add_argument('-b', action='store_true', help ='brief information')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

tfh = open(args.t)
disease = []
for line in tfh:
    line_arr = line.strip().split('\t')
    disease.append(line_arr[0].strip().replace(':','_'))

disease = set(disease)
afh = open(args.a)
dit = {}

def brief(line, dit, ind):
    lst = line.strip().split('\t')
    key = lst[34]
    if ind == [] :
        dit[key].append(line.strip())
    else :
        nlst = trick.getList(lst, ind)
        value = '\t'.join(nlst)
        dit[key].append(value)

def check_in(lst, string = ':'):
    pos = []
    for each in lst :
        if each.startswith('chr') and ':' in each:
            chrom,start = each.split(':')
            end = str(int(start) - 1)
            pos.append('\t'.join([ chrom, start, end] ))
    if len(pos) >= 1:
        if len(pos) >= 2:
            exit()
        return pos
    return False
if args.b :
    header = afh.next().strip().split('\t')
#    ind = [ 5, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 27, 31, 33, 34, 35, 37 ]
    ind = [ 11, 12, 13, 14, 15, 16, 17, 21, 24, 27, 34, 35 ]
    print('\t'.join(trick.getList(header, ind)))
else :
    ind = []
for line in afh:
#    if trick.lstInStr( ['LINC00461, MEF2C', '', '', '', '', 'chr5_87992715', '', '8E-11', 'unipolar depression', 'http://www.ebi.ac.uk/efo/EFO_0003761'] , line):
    line_arr = line.strip().split('\t')
    lst = set([ i.strip().split('/')[-1] for i in line_arr[-3].split(',') ])
    if len(disease & lst) >= 1:
        key = line.strip().split('\t')[34]
        trick.set1dict(dit, key, [])
        brief(line, dit, ind)

i = 0
j = 0
for key in dit:
    for each in dit[key]:
        lst = each.strip().split('\t')
#multi rs
        if ';' in lst[0]:
            chroms = lst[0].split(';')
            pos = lst[1].split(';')
            name = lst[7].split(';')
            info = list(zip(chroms,pos,name))
            for each in info:                
                pass
                #print 'chr'+each[0] + '\t' + each[1] + '\t' + str(int(each[1]) + 1 ) + '\t' + each[2]
            continue
        if check_in(lst, string = ':'):
            print(check_in(lst, string = ':'))
            continue
        if 'rs' in lst[5] :
            sys.stderr.write(lst[5] +'\n')
            sys.stderr.write('#' + '\t'.join(lst) +'\n')
            continue
        try :
            out = [ 'chr'+lst[0], lst[1], str(int(lst[1]) + 1), lst[7] ]
            print('\t'.join(out))
            j += 1
        except :
            sys.stderr.write('\t'.join(lst) + '\n')
            i += 1

sys.stderr.write(str(i) +'\n')
sys.stderr.write(str(j) +'\n')























