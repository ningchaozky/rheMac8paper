#!/usr/bin/perl -w
use strict;
use warnings;

unless(@ARGV){
	die "#Usage: $0 keyword [keyword2] fasta.fa\n";
}

my ($in,$fa,@key,@line);
$in = pop @ARGV;
open $fa,"$in";
$/ = '>';
<$fa>;
while(<$fa>){
	chomp;
	my $i = 0;
	@line = split /\n/,$_,2;
	for my $key (@ARGV){
		$key = quotemeta $key;
		if($line[0] =~ /$key/i){
			$i++;
		}
	}
	if($i == @ARGV){
		print ">$_";
	}
}
close $fa;
