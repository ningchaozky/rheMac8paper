#!/usr/bin/env python3
import os
import sys
import gzip
import argparse
from biomart import BiomartServer
from ningchao.nSys import trick, excel
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='+', help = 'matrix and col')
parser.add_argument('-gene2accession', nargs='?', help ='reference', default = '/home/soft/data/gene/gene2accession.gz')
parser.add_argument('-ensembl', nargs='?', help ='reference', default = '/home/soft/data/gene/ensemblToGeneName.txt')
parser.add_argument('-T2G', nargs='?', help ='reference', default = '/home/soft/data/gene/ensGene.txt')
parser.add_argument('-nh', action = 'store_true', help = ' header ?')

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def infor( gz ):
    fh, out = gzip.open( gz ), {}
    need = ['RNA_nucleotide_accession.version','protein_accession.version', 'genomic_nucleotide_accession.version', 'Symbol']
    header = next(fh).decode().replace('#','').strip().split('\t')
    index = ( trick.lst(header).index(need) )
    need = [ i.split('.')[0] for i in  need ]
    for line in fh:
        line_arr = line.decode().strip().split('\t')
        if line_arr[ index[0] ].startswith('NM') or line_arr[ index[0] ].startswith('NR'):
            val =  [ i.split('.')[0] for i in trick.lst( line_arr ).get( index ) ]
            dit = dict( zip( need,  val ))
            trick.dinit( out, dit['RNA_nucleotide_accession'], [])
            out[dit['RNA_nucleotide_accession']].append( dit['Symbol'] )
    return out

def ens( ensembl ):
    fh, out = open( ensembl ), {}
    for line in fh:
        line_arr = line.strip().split('\t')
        ens_id = line_arr[0].split('.')[0]
        gene = line_arr[1]
        trick.dinit( out, ens_id, [])
        out[ ens_id ].append( gene )
    return out

def trans2gene( fl ):
    fh, out = open( fl ), {}
    for line in fh:
        line_arr = line.strip().split('\t')
        transcript, gene =  [ i.split('.')[0] for i in  trick.lst( line_arr ).get( [1, 12 ] ) ]
        trick.dinit( out, transcript, gene )
    return out

if __name__ == '__main__':
    xls, col, header = excel.args_deal( args.mat )
    t2g = trans2gene( args.T2G )
    #print (t2g['ENSMMUT00000047240'])
    info, einfo = infor(args.gene2accession), ens( args.ensembl )
    mfh = open( xls )
    header = next( mfh ).strip().split('\t')
    header.append('Symbol')
    trick.write( header )
    for line in mfh:
        line_arr = line.strip().split('\t')
        acc = trick.lst( line_arr ).get( col )
        assert len(acc) == 1
        acc = acc[0].split('.')[0]
        if acc.startswith('NR_') or acc.startswith('NM_'):
            if acc in info:
                line_arr.append( info[acc] )
                trick.write( line_arr )
            else :
                sys.stderr.write( acc + '\n')
        if acc.startswith('ENSMMUT'):
            if acc in einfo:
                line_arr.append( einfo[acc] )
                trick.write( line_arr )
            else :
                sys.stderr.write( acc + '\n')
                line_arr.append( acc )
                trick.write( line_arr )

























