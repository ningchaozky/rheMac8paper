#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.system as sysKit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-f', nargs='*', help ='file|files|dir')
parser.add_argument('-rd', nargs= '*', help ='remote dirs for possibel postion')
parser.add_argument('-md', nargs= '?',type = int, help ='max depth', default = 3)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

rdirs = ['/uDisk/rawdata/part2/rawdata/','/uDisk/rawdata/part1/rawdata/','/uDiskB/rawdata/part2/rawdata/','/uDiskB/rawdata/part1/rawdata/']

def fl_check(fl):
		fl = os.path.realpath(fl)
		fl_arr = iter(fl.split('/'))
		short_dir = []
		for each in fl_arr:
			if each == 'rawdata':
				for i in range(args.md):
					short_dir.append(next(fl_arr))
		short_dir = '/'.join(short_dir)
		rpath,rsize = '',''
		for each in rdirs:
			each = each.rstrip('/')
			pos = '/'.join([each,short_dir]) + '/' +os.path.basename(fl)
			stdout,stderr,returncode = sysKit.run('ssh ningch@192.168.76.34 file_stat.py %s' % pos)
			for each in stdout:
				each = each.strip()
				if each == '':
					continue
				rpath,rsize = each.split('\t')
			lsize = os.path.getsize(fl)
		if rsize == '':
			print('#! not exists %s' % fl, file=sys.stderr)
		elif lsize == int(rsize):
			print('#!same with remote')
			print('#!local: %s %d' % (fl,lsize))
			print('#!remote: %s %s' % (rpath,rsize))
			print('rm %s' % fl)


for each in args.f:
	if os.path.isfile(each):
		fl_check(each)
	elif os.path.isdir(each):
		for fl in os.listdir(each):
			fl = os.path.realpath(fl)
			if os.path.isfile(fl):
				if fl.endswith('fq.gz') or fl.endswith('.md5'):
					fl_check(fl)



