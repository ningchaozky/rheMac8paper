#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tabs', nargs='*', help = 'tabs for the intersect' )
parser.add_argument('-col','-c', nargs='*', help = 'col for intersect' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def exc(string):
    exclude = [ 'modProbes' ]
    for each in exclude:
        if each in string:
            return True 
    return False
tabs = args.tabs
sets = []
if args.col:
    cols = [ int(i) - 1 for i in args.col ]
else :
    cols = [ 0 for i in args.tabs ]
p = re.compile(r'\s+')
for i,fl in enumerate(tabs):
    genes = []
    fh = open(fl)
    col = cols[i]
    for line in fh :
        if exc(line):
            continue
        line_arr = p.split(line.strip())
        try :
            genes.append(line_arr[col])
        except :
            exit()
    fh.close()
    if not i :
        lst = set ( genes )
    else :
        lst = lst.intersection(genes)
for gene in lst :
    print(gene)

