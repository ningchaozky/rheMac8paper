#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'names', nargs='+', help = '' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


infor = defaultdict( int )
cmd = '''echo dir GSA | ftp submit.big.ac.cn'''
for line in system.run( cmd, shell = True ):
    line_arr = [ i for i in line.strip().split(' ') if i ]
    infor[line_arr[-1]] = int(line_arr[4])

for name in args.names:
    name_base = os.path.basename( name )
    if not os.path.exists( name ) :
        print ( name, 'not in local' )
        continue
    if name_base in infor:
        print ( name, 'remote own', infor[name_base], 'size' )
    else :
        local_size = os.path.getsize( name )
        if name_base in infor and infor[name_base] == local_size:
            print ( name, 'remote==local', 'yes' )
        elif name_base in infor and infor[name_base] == local_size:
            print ( name, 'remote==local', 'no' )
        else :
            print ( name, 'remote not own')




















