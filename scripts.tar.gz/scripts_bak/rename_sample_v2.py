#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.ip as ipKit
import ningchao.nBio.rheMac as rh
import ningchao.nSys.parse as pKit
import ningchao.nSys.trick as trKit
import ningchao.nSys.system as sysKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-ini', nargs='?', help ='ini for the project', default = '/dataE/rawdata/rheMac/work.js')
parser.add_argument('-t', choices = ['RNA','H3K4me3','CTCF','H3K27me3','H3K27ac','pol2'], help ='', required = True )
parser.add_argument('-dir', nargs = '*', help ='dir|dirs you want to change the file to the short name', default = ['.'])
parser.add_argument('-k', nargs = '*', help ='key|keys for you find file', required = True )
parser.add_argument('-f', nargs = '*', help ='fiter|fiters for you find file. default ['']', default = [''])
parser.add_argument('-ia', action = 'store_true', help ='include addtional sequence?')
parser.add_argument('-s', nargs = '?', help ='suffix for the link file', required = True)
parser.set_defaults(bar=42, baz='badger')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

dirs = args.dir
typ = args.t
Infor = {}
keys = args.k
fiter = args.f

raw = '/pnas/liujiang_group/ningch/data/chipseq/neuro/rawdata/'
ini = args.ini
if ipKit.local_ip() == '192.168.118.81':
	ini = '/pnas/liujiang_group/ningch/data/chipseq/neuro/work.js'
d = pKit.parse_ini(ini,typ ='json').to_dict()



for period in d['period']:
	for region in d['period'][period]:
		for marker in d['period'][period][region]:
			dt = d['period'][period][region][marker]
			marker_dir = raw + '/'.join([period,region,marker])
			if marker in typ:
				for rep in dt:
					short_name = '.'.join([period,region,rep])
					if isinstance(dt[rep],list ):
						if args.ia :
							for i,v in enumerate(dt[rep]):
								add_dir = '/'.join([marker_dir, v])
								ff = sysKit.dir_find_file(add_dir,fiter,keys)
								trKit.set1dict(Infor,rh.short('.'.join([period,region,rep,str(i)])) ,ff)
						merge_dir = '/'.join([marker_dir, rep])
						ff = sysKit.dir_find_file(merge_dir,fiter,keys)
						trKit.set1dict(Infor,rh.short('.'.join([period,region,rep])),ff)
					elif isinstance(dt[rep],str ):
						fl_dir = '/'.join([marker_dir, dt[rep]])
						ff = sysKit.dir_find_file(fl_dir,fiter,keys)
						trKit.set1dict(Infor,rh.short(short_name),ff)


for each in Infor:
	if os.path.exists(Infor[each]):
		print('ln -s %s %s' % (Infor[each],each + '.%s' % args.s))
		print('\n')


