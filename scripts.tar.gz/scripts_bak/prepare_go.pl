#!/usr/bin/perl  -w

unless(@ARGV){
	print "\nUsage: $0 gff3 cuffdiff_output_dir cuffdiffgenes\n\n";
}
else{

#get gene names;
open $gff3,"$ARGV[0]";
my %genes;
while(<$gff3>){
	my @tmp = split /\t/,$_;
	if(@tmp > 8 && $tmp[2] =~ /^gene/){
		my @id = split /[:;]/,$tmp[8];
		$genes{"$id[1]"} = 0;
	}
}

#my match 
my %match;
my $genes_fpkm_tracking;
open $genes_fpkm_tracking,"< $ARGV[1]/genes.fpkm_tracking";
<$genes_fpkm_tracking>;
while(<$genes_fpkm_tracking>){
	my @tmp = split /\t/,$_;
	my @genes = split /,/,$tmp[4];
	for(@genes){
		unless(/^-/){
			$match{$tmp[0]} .= "$_\t";
		}
	}
}


my $diff_genes;
open $diff_genes,"$ARGV[2]";
<$diff_genes>;
while(<$diff_genes>){
	chomp;
	my @tmp = split /\t/,$_;
	if(defined $match{$tmp[0]}){
		my @tmp = split /\t/,$match{$tmp[0]};
		for(@tmp){
			unless(/^-/){
				$genes{$_} = 1;
			}
		}
	}
}

while(my($k,$v) = each %genes){
	if($k =~ /[01]/){
		print "$k\t$v\n";
	}
}

}
