#!/usr/bin/perl -w

unless(@ARGV){
	print "\nUsage:\t$0 file.sam > file.stat\n\n";
}
else{

open $sam, "$ARGV[0]";
#initialize
my @tmp = ();
my $reads = 0;
my $flag = 0;
my $paired = 0;
my $unpaired = 0;
my $two_proper_mapped = 0;
my $unmapped = 0;
my $mapped = 0;
my $read_1 = 0;
my $read_2 = 0;
my $paired_pos = 0;
my $paired_neg = 0;
my $multi_mapped = 0;
my $secondary = 0;
my $unpaired_rev_com = 0;
my $unpaired_mapped = 0;
#get value 
while(<$sam>){
	@tmp =  split /\t/,$_;
	if(@tmp > 8){
		$reads++;
		$flag = $tmp[1];
		if($flag & 0x1){
			$paired++;
		}
		else{
			$unpaired++;
		}

		if($flag & 0x2){
			$two_proper_mapped++;
		}

		if($flag & 0x4){
			$unmapped++;
		}
		else{
			$mapped++;
		}

		if($flag & 0x40){
			unless($flag & 0x4){
				$read_1++;
			}
		}

		if($flag & 0x80){
			unless($flag & 0x4){
				$read_2++;
			}
		}

		unless($flag & 0x4){
			unless($flag & 0x10){
				$paired_pos++;
			}
			else{
				$paired_neg++;
			}
		}
		
		if($flag & 0x800){
			$multi_mapped++;
		}

		if($flag & 0x100){
			$secondary++;
		}

		if($flag & 0x0){
			if($flag & 0x10){
				$unpaired_rev_com++;
			}
			unless($flag & 0x4){
				$unpaired_mapped++;
			}
		}

		if($tmp[5] =~ /N/){
			$AS++;
		}
	}
}

close $sam;
# format 


$reads_out = $reads;
$mapped_out = $mapped.'('.(sprintf "%.2f",$mapped*100/$reads).'%)';
$paired_out = $paired.'('.(sprintf "%.2f",$paired/$reads*100).'%)';
$unpaired_out = $unpaired.'('.(sprintf "%.2f",$unpaired/$reads*100).'%)';
$uniq_mapped_out = ($mapped - $secondary).'('.(sprintf "%.2f",($mapped-$secondary)/$reads*100).'%)';
$read_1_out = $read_1.'('.(sprintf "%.2f",$read_1/$reads*100).'%)';
$read_2_out = $read_2.'('.(sprintf "%.2f",$read_2/$reads*100).'%)';
$pos_out = ($paired_pos + $unpaired_mapped - $unpaired_rev_com).'('.(sprintf "%.2f",($paired_pos + $unpaired_mapped - $unpaired_rev_com)/$reads*100).'%)';
$neg_out = ($paired_neg + $unpaired_rev_com).'('.(sprintf "%.2f",($paired_neg + $unpaired_rev_com)/$reads*100).'%)';
$AS ||= 0;
$as_out  = $AS.'('.(sprintf "%.2f",$AS/$reads*100).'%)';
$no_as_out = ($mapped - $secondary - $AS).'('.(sprintf "%.2f",($mapped - $secondary - $AS)*100/$reads).'%)';
$tow_proper_out = $two_proper_mapped.'('.(sprintf "%.2f",$two_proper_mapped/$reads*100).'%)';
$unmapped_reads_out = $unmapped.'('.(sprintf "%.2f",$unmapped/$reads*100).'%)';
$secondary_out = $secondary.'('.(sprintf "%.2f",$secondary/$reads*100).'%)';
#out put 

print "Total Reads\t$reads_out\n";
print "Total Mapped\t$mapped_out\n";
print "Multiple mapped\t$secondary_out\n";
print "Uniquely mapped\t$uniq_mapped_out\n";
print "Read_1\t$read_1_out\n";
print "Read_2\t$read_2_out\n";
print "Reads mapped to '+'\t$pos_out\n";
print "Reads mapped to '-'\t$neg_out\n";
print "Splice reads\t$as_out\n";
print "Non-splice reads\t$no_as_out\n";
print "Paired mapped\t$tow_proper_out\n";
print "Unpaired reads\t$unpaired_out\n";
print "Paired reads\t$paired_out\n";
print "Unmapped reads\t$unmapped_reads_out\n";
}
