#!/usr/bin/env python
import os 
import sys
from Bio import SeqIO
import subprocess as sp
import ningch as nc

nc.usage('file: project.ini str(start)')

parameters = {}

d = SeqIO.to_dict(SeqIO.parse(sys.argv[1], "fasta"))

#Trim
trim = open('trim.sh','w')
samples = str(d['sample']._seq).split(',')
raw_data_dir = str(d['raw_data']._seq)
clean_data_dirs = []

for each in samples:
	clean_data_dir = str(os.path.join(d['raw_data']._seq,each))
	cmd_mkdir,cmd_cd,cmd_trim,typ = '','','',''
	cmd_mkdir = 'mkdir -p %s\n'  % clean_data_dir
	cmd_mkdir = nc.check_and_annot(cmd_mkdir,work_dir)
	trim.write(cmd_mkdir)
	cmd_cd += '\ncd  %s'  % work_dir
	trim.write(cmd_cd)
	trim_prefix = os.path.join(raw_data_dir,each)
	trim_sra = nc.check_and_annot('\nfastq-dump --split-files %s' % os.path.join(raw_data_dir,trim_prefix+'.sra'), trim_prefix+'/%s_1.fastq' % each)
#check 2.fq
	if os.path.exists(trim_prefix+'/%s_1.fastq' % each):
		typ = 'PE'
	if typ == 'PE':
		cmd_trim += '\njava -jar /home/ningch/soft/Trimmomatic-0.33/trimmomatic-0.33.jar %s -threads 8 -trimlog %s/trimmomatic.log  %s_1.fastq %s_2.fastq %s/1P.fq %s/1U.fq %s/2P.fq %s/2U.fq\
		ILLUMINACLIP:/home/ningch/soft/Trimmomatic-0.33/adapters/customed_adapter.fa:2:30:10  MINLEN:36 2>%s/clipad.txt' % (typ,work_dir,os.path.join(work_dir,each),os.path.join(work_dir,each),work_dir,work_dir,work_dir,work_dir,work_dir)
	if typ == 'SE':
		cmd_trim += '\njava -jar /home/ningch/soft/Trimmomatic-0.33/trimmomatic-0.33.jar %s -threads 8 -trimlog %s/trimmomatic.log \
		%s_1.fastq %s/1.fq ILLUMINACLIP:/home/ningch/soft/Trimmomatic-0.33/adapters/customed_adapter.fa:2:30:10 MINLEN:36 2>%s/clipad.txt' % (typ,work_dir,os.path.join(work_dir,each),work_dir,work_dir)
	if os.path.exists('%s/clipad.txt' % work_dir) and nc.check_trim('%s/clipad.txt' % work_dir):
		cmd_trim = nc.annot(cmd_trim)
		trim_sra = nc.annot(trim_sra)
	trim.write(trim_sra)
	trim.write(cmd_trim)
	trim.write('\n\n\n')
	clean_data_dirs.append(work_dir)
trim.close()

exit()

#Maping
if 'bowtie' in  d['aligner']._seq:
	map_cmd = open('mapping_bowtie.sh','w')
	for each in samples:
		print(each)
		tmp_dir = os.path.join(parameters['work_dir'],'Map',each)
		raw_read_dir = os.path.join(parameters['raw_data_dir'])
		cmd = '/p300/liujiang_group/ningcbowtie2 -p 8 --refout -x %s -1 %s/1P.fq -2 %s/2P.fq -S %s/bowtie_mapped.sam 2> %s/bowtie_mapping.rate' % (parameters['map_index'],tmp_dir,tmp_dir,tmp_dir,tmp_dir)
		cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools view -Sb %s/bowtie_mapped.sam > %s/bowtie_mapped.bam' % (tmp_dir,tmp_dir)
		cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools sort %s/bowtie_mapped.bam -o %s/bowtie_mapped.sorted.bam' % (tmp_dir,tmp_dir)
		cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools index %s/mapped.sorted.bam' % tmp_dir
		cmd += '\nperl /home/ningch/soft/ChIP_seq/scripts/Map/circos_for_reads_density.pl -a %s -b %s/mapped.sorted.bam -c 1-20 -o reads.density' % (parameters['genome'],tmp_dir)
		cmd += '\n\n\n\n'
		print(cmd, file=map_cmd)
	map_cmd.close()

if 'bwa' in d['aligner']._seq:
	map_cmd = open('mapping_bwa.sh','w')
	typ = ''
	for each in clean_data_dirs:
		work_dir = each
		if os.path.exists(os.path.join(work_dir,'2P.fq')):
			typ = 'PE'
		else:
			typ = 'SE'
		cmd_map,cmd_sort,cmd_dup,cmd_ciro,cmd_bamTobed,cmd_intersect,cmd_fpkm,cmd_fpkm_sort = '','','','','','','',''
		raw_read_dir = os.path.join(d['raw_data']._seq)
		cmd ='cd %s' % work_dir
		map_cmd.write(cmd)
		#input and output
		map_out_file = '%s/bwa_mapping.sam' % work_dir
		map_uniq_file = '%s/bwa_mapping.uniq.sam' % work_dir
		read_1 = '%s/1P.fq' % work_dir
		read_2 = '%s/2P.fq' % work_dir
		read_se = '%s/1.fq' % work_dir
		map_uniq_sort = '%s/bwa_mapped.uniq.sorted.bam' % work_dir
		MarkDup_In = '%s/bwa_mapped.uniq.sorted.bam' % work_dir
		MarkDup_Out = '%s/bwa_mapped.uniq.sorted.dedup.bam' % work_dir
		MarkDup_Matrix = '%s/bwa_metrics.txt' % work_dir
		bamToBed_In = MarkDup_Out
		name = os.path.basename(str(d['chr_intersect_bed']._seq)).replace('.bed','')
		bamToBed_Out = '%s/bwa_mapped.uniq.sorted.dedup.bed' % work_dir
		dePaired_Out = '%s/bwa_mapped.uniq.sorted.dedup.dePaired.bed' % work_dir
		dePaired_In = bamToBed_Out
		intersect_In = dePaired_Out
		intersect_Out = '%s/bwa_mapped.uniq.sorted.dedup.dePaired.intersect.%s.bed' % (work_dir,name)
		fpkm_In = intersect_Out
		fpkm_Out = '%s/bwa_mapped.uniq.sorted.dedup.dePaired.intersect.%s.fpkm.xls' % (work_dir,name)
		fpkm_sort_In = fpkm_Out
		fpkm_sort_Out = '%s/bwa_mapped.uniq.sorted.dedup.dePaired.intersect.%s.sort.xls' % (work_dir,name)
		adj_factor = '1'
		if typ == 'PE':
			cmd_map = '\n#/home/ningch/soft/bwa/bwa mem %s %s %s -t 8 > %s' % (d['map_index']._seq,read_1,read_2,map_out_file)
		if typ == 'SE':
			cmd_map = '\n#/home/ningch/soft/bwa/bwa mem %s %s -t 8 > %s' % (d['map_index']._seq,read_se,map_out_file)
		cmd_map = nc.check_and_annot(cmd_map,map_out_file)
		map_cmd.write(cmd_map)
		cmd_uniq = '\n#get_uniq_sam_from_bwaMem.py %s %s' % (map_out_file,map_uniq_file)
		cmd_uniq = nc.check_and_annot(cmd_uniq,map_uniq_file)
		map_cmd.write(cmd_uniq)
		cmd_sort = '\njava -jar /home/ningch/soft/picard.jar SortSam INPUT=%s OUTPUT=%s SORT_ORDER=coordinate' % (map_uniq_file,map_uniq_sort)
		cmd_sort = nc.check_and_annot(cmd_sort,map_uniq_sort)
		map_cmd.write(cmd_sort)
		cmd_dup = '\njava -jar /home/ningch/soft/picard.jar MarkDuplicates METRICS_FILE=%s I=%s O=%s' % (MarkDup_Matrix,MarkDup_In,MarkDup_Out)
		cmd_dup = nc.check_and_annot(cmd_dup,MarkDup_Out)
		map_cmd.write(cmd_dup)
		cmd_ciro = '\n#perl /home/ningch/soft/ChIP_seq/scripts/Map/circos_for_reads_density.pl -a %s -b %s/mapped.sorted.bam -c 1-20 -o reads.density' % (d['genome']._seq,work_dir)
		cmd_bamTobed = '\nbamToBed -i %s > %s' % (bamToBed_In,bamToBed_Out)
		cmd_bamTobed = nc.check_and_annot(cmd_bamTobed,bamToBed_Out)
		map_cmd.write(cmd_bamTobed)
		cmd_dePaired = '\ndePaired.py %s %s' % (dePaired_In,dePaired_Out)
		cmd_dePaired = nc.check_and_annot(cmd_dePaired,dePaired_Out)
		map_cmd.write(cmd_dePaired)
		cmd_intersect = '\nbedtools intersect -a %s -b %s -wo > %s' % (d['chr_intersect_bed']._seq,intersect_In,intersect_Out)
		cmd_intersect = nc.check_and_annot(cmd_intersect,intersect_Out)
		map_cmd.write(cmd_intersect)
		cmd_fpkm = '\nget_rpkm_from_intersect_bed.py %s,1,2,3 %s %s' % (intersect_Out,fpkm_Out,adj_factor)
		cmd_fpkm = nc.check_and_annot(cmd_fpkm,fpkm_Out)
		map_cmd.write(cmd_fpkm)
		cmd_fpkm_sort = '\nsort -k1,1 -k2,2n %s > %s' % (fpkm_sort_In,fpkm_sort_Out)
		cmd_fpkm_sort = nc.check_and_annot(cmd_fpkm_sort,fpkm_sort_Out)
		map_cmd.write(cmd_fpkm_sort)
		map_cmd.write('\n\n\n')

#merge the same groups
##below use variables
fpkms = {}
##
groups = str(d['groups']._seq).split('~')
grp,make,merge_cmd = {},{},''
merge_shell = open('merge_groups.sh','w')
for each in groups:
	each_sp = each.split(':')
	grp[each_sp[0]] = each_sp[1].split(',')

group_make_up = str(d['group_make_up']._seq).split('~')
for each in group_make_up:
	each_arr = each.split(':')
	merge_sam = ''
	make[each_arr[0]] = each_arr[1].split(',')
	work_dir = str(os.path.join(d['work_dir']._seq,each_arr[0]))
	#define in and out
	merge_Out = '%s/%s/bwa_merge.uniq.sorted.dedup.bam' % (d['work_dir']._seq,each_arr[0])
	bamTobed_In = '%s/bwa_merge.uniq.sorted.dedup.bam' % work_dir
	bamTobed_Out = '%s/bwa_merge.uniq.sorted.dedup.bed' % work_dir
	dePaired_In = bamTobed_Out
	dePaired_Out = '%s/bwa_merge.uniq.sorted.dedup.deParied.bed' % work_dir
	intersect_In = dePaired_Out
	intersect_Out = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.bed' % (work_dir,name)
	fpkm_Out = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.fpkm.xls' % (work_dir,name)
	fpkm_sort_In = fpkm_Out
	fpkm_sort_Out = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.sort.fpkm.xls' % (work_dir,name)
	cmd_bamTobed,cmd_intersect,cmd_fpkm,cmd_fpkm_sort,adj_factor = '','','','','1'

	#check PE or SE
	for samp in make[each_arr[0]]:
		samp = samp.replace('SE','')
		merge_sam += ' I=%s/bwa_mapped.uniq.sorted.dedup.bam' % os.path.join(d['raw_data']._seq,samp)
	cmd_mkdir = '\n#Merge group files\n\nmkdir -p %s' % work_dir
	if os.path.exists(work_dir):
		cmd_mkdir = nc.annot(cmd_mkdir)
	merge_shell.write(cmd_mkdir)
	merge_shell.write('\ncd %s' % work_dir)
	cmd_merge = '\njava -jar /home/ningch/soft/picard.jar MergeSamFiles %s OUTPUT=%s' % (merge_sam,merge_Out)
	cmd_merge = nc.check_and_annot(cmd_merge,merge_Out)
	merge_shell.write(cmd_merge)
	cmd_bamTobed = '\nbamToBed -i %s > %s' % (bamTobed_In,bamTobed_Out)
	cmd_bamTobed = nc.check_and_annot(cmd_bamTobed,bamTobed_Out)
	merge_shell.write(cmd_bamTobed)
	dePaired_cmd = nc.check_and_annot('\ndePaired.py %s %s' % (dePaired_In,dePaired_Out),dePaired_Out)
	merge_shell.write(dePaired_cmd)
	name = os.path.basename(str(d['chr_intersect_bed']._seq)).replace('.bed','')
	cmd_intersect = '\nbedtools intersect -a %s -b %s -wo > %s' % (d['chr_intersect_bed']._seq,intersect_In,intersect_Out)
	cmd_intersect = nc.check_and_annot(cmd_intersect,intersect_Out)
	merge_shell.write(cmd_intersect)
	cmd_fpkm = '\nget_fpkm_from_intersect_bed.py %s %s %s %s' % (dePaired_Out,intersect_Out,d['chr_intersect_bed']._seq,fpkm_Out)
	cmd_fpkm = nc.check_and_annot(cmd_fpkm,fpkm_Out)
	merge_shell.write(cmd_fpkm)
	cmd_fpkm_sort = nc.check_and_annot('\nsort -k1,1 -k2,2n %s > %s' % (fpkm_sort_In,fpkm_sort_Out),fpkm_sort_Out)
	merge_shell.write(cmd_fpkm_sort)
	merge_shell.write('\n\n\n')
	
	if fpkm_Out not in fpkms:
		fpkms[os.path.basename(work_dir)] = fpkm_Out


#merge fpkms into one file

fpkm_shell = open('rpkm.sh','w')
fpkm_files = ''
for key in fpkms:
	fpkm_files += key+','+fpkms[key]+','+'4'+' '
fpkm_shell.write('cd %s' % d['work_dir']._seq)
name = os.path.basename(str(d['chr_intersect_bed']._seq)).replace('.bed','')
fpkm_cat_cmd = '\nextract_fpkm_and_merge.py %s > %s/%s.fpkms.xls' % (fpkm_files,d['work_dir']._seq,name)
if os.path.exists('%s/%s.fpkms.xls' % (d['work_dir']._seq,name)):
	fpkm_cat_cmd = nc.annot(fpkm_cat_cmd)
fpkm_shell.write(fpkm_cat_cmd)
cor_In = '%s.fpkms.xls' % name
cor_Out = 'exp.%s.cor.xls' % name 
fpkm_cat_cmd = '\ncor.R %s %s' % (cor_In,cor_Out)
if os.path.exists(cor_Out) and os.path.getsize(cor_Out) > 0:
	fpkm_cat_cmd = nc.annot(fpkm_cat_cmd)
fpkm_shell.write(fpkm_cat_cmd)
fpkm_shell.close()

#each sample
#below use variables
sample_treat,sample_input = [],[]
##
merge_sample_shell = open('merge_sample.sh','w')
merge_cmd,merge_group,SAMPLE_DIR,SAMPLE_PAIR = '','',[],{}
for each in str(d['groups']._seq).split('~'):
	experiment = each.split(':')[0]
	exp_grp = each.split(':')[1].split('%')
	for exp_each in exp_grp:
		exp = exp_each.split('|')[0].split(',')
		inp = exp_each.split('|')[1].split(',')
		for i,j in enumerate(exp):
			SAMPLE_PAIR[j] = inp[i]
		INPUT,OUTDIR,INPUT_input = '','',''
		outdir = os.path.join(str(d['work_dir']._seq),experiment)
		REP_DIR = outdir
		for each in exp:
			INPUT += ' INPUT=%s' % os.path.join(d['work_dir']._seq,each,'bwa_merge.uniq.sorted.dedup.bam')
		for each in inp:
			INPUT_input += ' INPUT=%s' % os.path.join(d['work_dir']._seq,each,'bwa_merge.uniq.sorted.dedup.bam')
		if not os.path.exists(outdir):
			for each in str(d['name_marker']._seq).split(','):
				if each in INPUT:
					OUTDIR = outdir+'_'+each
					SAMPLE_DIR.append(OUTDIR)
					cmd_mkdir = 'mkdir -p %s\n' % OUTDIR
					if os.path.exists(OUTDIR):
						cmd_mkdir = nc.annot(cmd_mkdir)
		merge_sample_shell.write(cmd_mkdir)
		merge_sample_shell.write('cd %s\n' % OUTDIR)
		treat_bam = '%s/bwa_merge.uniq.sorted.dedup.bam' % OUTDIR
		bamToBed_Input_treat = '%s/bwa_merge.uniq.sorted.dedup.bam' % OUTDIR
		bamToBed_Output_treat = '%s/bwa_merge.uniq.sorted.dedup.bed' % OUTDIR
		dePaired_Out_treat = '%s/bwa_merge.uniq.sorted.dedup.dePaired.bed' % OUTDIR
		cmd_bamTobed,cmd_intersect,cmd_fpkm,cmd_fpkm_sort,name = '','','','',os.path.basename(str(d['chr_intersect_bed']._seq)).replace('.bed','')
		cmd_bamTobed,cmd_intersect,cmd_fpkm,cmd_fpkm_sort = '','','',''
		Intersect_Output_treat = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.bed' % (OUTDIR,name)
		fpkm_Output_treat = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.fpkm.xls' % (OUTDIR,name)
		fpkm_sort_Output_treat = '%s/bwa_merge.uniq.sorted.dedup.dePaired.intersect.%s.fpkm.sort.xls' % (OUTDIR,name)
		Input_bam = '%s/bwa_merge_Input.uniq.sorted.dedup.bam' % OUTDIR
		merge_Out = Input_bam
		bamTobed_In = merge_Out
		bamTobed_Out_Input = '%s/bwa_merge_Input.uniq.sorted.dedup.bed' % OUTDIR
		name = os.path.basename(str(d['chr_intersect_bed']._seq)).replace('.bed','')
		dePaired_In_Input = bamTobed_Out
		dePaired_Out_Input = '%s/bwa_merge_Input.uniq.sorted.dedup.dePaired.bed' % OUTDIR
		Intersect_Out_Input = '%s/bwa_merge_Input.uniq.sorted.dedup.dePaired.intersect.%s.bed' % (OUTDIR,name)
		fpkm_Out_Input = '%s/bwa_merge_Input.uniq.sorted.dedup.dePaired.intersect.%s.fpkm.xls' % (OUTDIR,name)
		fpkm_sort_Out_Input = '%s/bwa_merge_Input.uniq.sorted.dedup.dePaired.intersect.%s.sort.fpkm.xls' % (OUTDIR,name)

		cmd_merge_treat = nc.check_and_annot('java -jar /home/ningch/soft/picard.jar MergeSamFiles %s OUTPUT=%s\n' % (INPUT,treat_bam),treat_bam)
		merge_sample_shell.write(cmd_merge_treat)
		cmd_bamTobed = nc.check_and_annot('bamToBed -i %s > %s\n' % (bamToBed_Input_treat,bamToBed_Output_treat),bamToBed_Output_treat)
		merge_sample_shell.write(cmd_bamTobed)
		dePaired_cmd = nc.check_and_annot('dePaired.py %s %s\n' % (bamToBed_Output_treat,dePaired_Out_treat),dePaired_Out_treat)
		merge_sample_shell.write(dePaired_cmd)
		cmd_intersect = nc.check_and_annot('bedtools intersect -a %s -b %s -wo > %s\n' % (d['chr_intersect_bed']._seq,dePaired_Out_treat,Intersect_Output_treat),Intersect_Output_treat)
		merge_sample_shell.write(cmd_intersect)
		cmd_fpkm = nc.check_and_annot('get_fpkm_from_intersect_bed.py %s %s %s %s\n' % (Intersect_Output_treat,Intersect_Output_treat,d['chr_intersect_bed']._seq,fpkm_Output_treat),fpkm_Output_treat)
		merge_sample_shell.write(cmd_fpkm)
		cmd_fpkm_sort = nc.check_and_annot('sort -k1,1 -k2,2n %s > %s\n' % (fpkm_Output_treat,fpkm_sort_Output_treat),fpkm_sort_Output_treat)
		merge_sample_shell.write(cmd_fpkm_sort)
		cmd_merge_input = nc.check_and_annot('java -jar /home/ningch/soft/picard.jar MergeSamFiles %s OUTPUT=%s\n' % (INPUT_input,Input_bam),Input_bam)
		merge_sample_shell.write(cmd_merge_input)
		cmd_bamTobed = nc.check_and_annot('bamToBed -i %s > %s\n' % (Input_bam,bamTobed_Out_Input),bamTobed_Out_Input)
		merge_sample_shell.write(cmd_bamTobed)
		dePaired_cmd = nc.check_and_annot('dePaired.py %s %s\n' % (bamTobed_Out_Input,dePaired_Out_Input),dePaired_Out_Input)
		merge_sample_shell.write(dePaired_cmd)
		cmd_intersect = nc.check_and_annot('bedtools intersect -a %s -b %s -wo > %s\n' % (d['chr_intersect_bed']._seq,dePaired_Out_Input,Intersect_Out_Input),Intersect_Out_Input)
		merge_sample_shell.write(cmd_intersect)
		cmd_fpkm = nc.check_and_annot('get_fpkm_from_intersect_bed.py %s %s %s %s\n' % (Intersect_Out_Input,Intersect_Out_Input,d['chr_intersect_bed']._seq,fpkm_Out_Input),fpkm_Out_Input)
		merge_sample_shell.write(cmd_fpkm)
		cmd_fpkm_sort = nc.check_and_annot('sort -k1,1 -k2,2n %s > %s\n' % (fpkm_Out_Input,fpkm_sort_Out_Input),fpkm_sort_Out_Input)
		merge_sample_shell.write(cmd_fpkm_sort)
		merge_sample_shell.write('\n\n')
		
		sample_treat.append(dePaired_Out_treat)
		sample_input.append(dePaired_Out_Input)
merge_sample_shell.close()


sample_treat_iter,sample_input_iter = sample_treat,iter(sample_input)

pk_shell = open('peak_calling.sh','w')
for each in sample_treat_iter:
	if 'H3K4me3_ChIPSeq_oocytes' not in each:
		continue
	work_dir = os.path.dirname(each)
	file_name = os.path.basename(each)
	name = file_name.replace('.bam','.')
#callpeak parameters
	pvalue = '1e-3'
	name = name+'p_%s' % pvalue
	masc2_Out_xls = os.path.join(work_dir,'%s_peaks.xls' % name)
	pk_shell.write('cd %s' % work_dir)
	chr_xls = os.path.join(work_dir,'%s_peaks.chr.xls' % name)
	treat_bgd_In = '%s/%s_treat_pileup.bdg' % (work_dir,name)
	treat_bgd_Out = '%s/%s_treat_pileup.chr.bdg' % (work_dir,name)

	peak_cmd = '\nmacs2 callpeak -t %s -c %s -n %s -f BAM -g mm -m 5 50 -p %s --broad -B' % (each,next(sample_input_iter),name,pvalue)
	if os.path.exists(masc2_Out_xls) and os.path.getsize(masc2_Out_xls) > 0:
		peak_cmd = nc.annot(peak_cmd)
	pk_shell.write(peak_cmd)
	bed_cmd = '\n#awk \'{if(($1!~/#/) && ($1!~/chr/)) print $1"\\t"$2"\\t"$3"\\t"$10}\' %s_peaks.xls | sed \'1d\' > %s_peaks.bed' % (name,name)
	if os.path.exists('%s/%s_peaks.bed' % (work_dir,name)):
		bed_cmd = nc.annot(bed_cmd)
#	pk_shell.write(bed_cmd)
	chr_cmd = '\nclean_no_chr_line.py %s' % masc2_Out_xls
	if os.path.exists(chr_xls) and os.path.getsize(chr_xls) > 0:
		chr_cmd = nc.annot(chr_cmd)
	pk_shell.write(chr_cmd)
	treat_bgd_cmd = '\nclean_no_chr_line.py %s' % treat_bgd_In
	if os.path.exists(treat_bgd_Out) and os.path.getsize(treat_bgd_Out) > 0:
		treat_bgd_cmd = nc.annot(treat_bgd_cmd)
	pk_shell.write(treat_bgd_cmd)
#peak filter parmeters
	peak_length = 146
	pvalue = '1'
	pipeup = '4.13'
	fc = '1'
	qvalue = '0.0000'
	fiter_In = '%s/%s_peaks.chr.xls' % (work_dir,name)
	fiter_Out = '%s/%s_peaks.chr.fiter_%d_logpvalue%s_pileup%s_fc%s.xls' % (work_dir,name,peak_length,pvalue,pipeup,fc)
	
	fiter_cmd = '\npick_up_chipseq_peak.py %d %s %s %s %s %s > %s' % (peak_length,pipeup,pvalue,fc,qvalue,fiter_In,fiter_Out)
	if os.path.exists(fiter_Out) and os.path.getsize(fiter_Out) > 0:
		fiter_cmd = nc.annot(fiter_cmd)
	pk_shell.write(fiter_cmd)
	peak_len_cmd = '\nchiseq_peak_cover.py %s %s' % (fiter_Out,d['chr_size']._seq)
	xls_name_len = fiter_Out.split('.')
	xls_name_len.insert(-1,'peak_len')
	xls_name_len = '.'.join(xls_name_len).replace('.xls','.txt')
	if os.path.exists(xls_name_len) and os.path.getsize(xls_name_len) > 0:
		peak_len_cmd = nc.annot(peak_len_cmd)
	pk_shell.write(peak_len_cmd)
	
	no_filter_cmd = '\nchiseq_peak_cover.py %s/%s_peaks.chr.xls %s' % (work_dir,name,d['chr_size']._seq)
	if os.path.exists('%s/%s_peaks.chr.peak_len.txt' % (work_dir,name)):
		no_filter_cmd = nc.annot(no_filter_cmd)
	pk_shell.write(no_filter_cmd)
#pull nearBy peaks togetor
	peak_span = list(range(0,12500,500))
	for each in peak_span:
		span_bed = os.path.join(fiter_Out.replace('.xls','')+'.merge_%s.bed' % each)
		span_cmd = '\nmerge_peak_xK.py %s %d > %s' % (fiter_Out,each,span_bed)
		sort_bed = span_bed.split('.')
		sort_bed.insert(-1,'sort')
		sort_bed = '.'.join(sort_bed)
		if os.path.exists(span_bed):
			span_cmd = nc.annot(span_cmd)
		pk_shell.write(span_cmd)
		sort_cmd = '\nsort -k1,1 -k2,2n %s > %s' % (span_bed,sort_bed)
		if os.path.exists(sort_bed):
			sort_cmd = nc.annot(sort_cmd)
		pk_shell.write(sort_cmd)
		merge_bed = sort_bed.split('.')
		merge_bed.insert(-1,'merge')
		merge_bed = '.'.join(merge_bed)
		bed_merge_cmd = '\nbedtools merge -i %s > %s' % (sort_bed,merge_bed)
		if os.path.exists(merge_bed):
			bed_merge_cmd = nc.annot(bed_merge_cmd)
		pk_shell.write(bed_merge_cmd)
	pk_shell.write('\n\n\n')
pk_shell.close()

#special command for analysis

#promoter median value

name_list = []
promoter = open('promoter.sh','w')
for each in sample_treat:
	work_dir = os.path.dirname(each)
	bed_name = each
	coverageBed_output = os.path.join(work_dir,'promoter_coverageBed.xls')
	rpkm_from_coverageBed_Out = coverageBed_output.replace('.xls','rpkm.xls')
	promoter_top_Input = rpkm_from_coverageBed_Out
	top_pro_Output = rpkm_from_coverageBed_Out.replace('rpkm.xls','rpkm.1k-10k.txt')
	promoter.write('cd %s\n' % work_dir)
	
	coverageBed_cmd = nc.check_and_annot('coverageBed  -a %s -b %s  > %s\n' % (d['promoter']._seq,bed_name,coverageBed_output),coverageBed_output)
	promoter.write(coverageBed_cmd)
	rpm_cmd = nc.check_and_annot('fpkm_from_coverageBed.py  %s,5 %s > %s\n' % (coverageBed_output,bed_name,rpkm_from_coverageBed_Out),rpkm_from_coverageBed_Out)
	promoter.write(rpm_cmd)
	top_pro_cmd = nc.check_and_annot('promoter_top.py %s,4 %d,%d > %s' % (rpkm_from_coverageBed_Out,1000,10000,top_pro_Output),top_pro_Output)
	promoter.write(top_pro_cmd)
	promoter.write('\n\n')

	name_list.append(os.path.join(work_dir,top_pro_Output))
	


#below use variables
factor_file = ''
rpkm_adj_below = []
##

work_dir,name_str = '',[]
factor_hd = open('factor.sh','w')
for each in name_list:
	work_dir = os.path.dirname(os.path.dirname(each))
	tmp_str = ','.join([os.path.basename(os.path.dirname(each)),each,'2'])
	name_str.append(tmp_str)
name_str = ' '.join(name_str)
factor_hd.write('cd %s\n' % work_dir)
name = os.path.join(work_dir,'values_factor.txt')
adj_calc_input = name
adj_calc_output = 'values_factor.adj.xls'
adj_factor_cmd = 'extract_excl_col_and_add_name.py %s > %s\n' % (name_str,name)
draw_output = '%s.pdf' % adj_calc_output.replace('.xls','.pdf')
adj_factor_cmd = nc.check_and_annot(adj_factor_cmd,name)
factor_hd.write(adj_factor_cmd)

adj_calc_cmd = nc.check_and_annot('calculate_adjust_factor.py %s  H3K4me3_ChIPSeq_E14_500 > %s\n' % (name,adj_calc_output), adj_calc_output)
factor_hd.write(adj_calc_cmd)
draw_cmd = nc.check_and_annot(('draw_adj_factor.R %s %s\n' % (adj_calc_output,draw_output.replace('.pdf',''))),draw_output)
factor_hd.write(draw_cmd)

factor_file = os.path.join(work_dir,adj_calc_output)
factor_hd.write('\n\n')


#peak RPKM change between samples
change_hd = open('RPKM_change.sh','w')
oocyte_peaks_bed = '/home/ningch/data/chip-seq/mouse/H3K4XX/H3K4me3_ChIPSeq_oocytes/TSS_containing_peaks.bed'
oocyte_peaks_noTss_bed = '/home/ningch/data/chip-seq/mouse/H3K4XX/H3K4me3_ChIPSeq_oocytes/No_TSS_containing_peaks.bed'
factor_file = factor_file

for each in sample_treat:
#variables
	if 'H3K4me3' not in each:
		continue
	work_dir = os.path.dirname(each)
	intersect_out = each.replace('.bed','.intersect_oocytes_Tss_peaks.bed')
	print(intersect_out)
	intersect_out_v = each.replace('.bed','.intersect_oocytes_noTss_peaks.bed')
	treat_bed = each
	rpkm_out = intersect_out.replace('.bed','.rpkm')
	rpkm_out_v = intersect_out_v.replace('.bed','.rpkm')
	adj_factor = nc.pick_value_from_excl(factor_file,os.path.basename(work_dir)+'_adj',5)
	adj_rpkm_v = rpkm_out_v+'.sort.adjBy%s' % adj_factor
	adj_rpkm = rpkm_out+'.sort.adjBy%s' % adj_factor
	adj_rpkm_output = ''
#cmd and write to file
	change_hd.write('cd %s\n' % work_dir)
	intersect_cmd = 'bedtools intersect -a %s -b %s -wo > %s\n' % (treat_bed,oocyte_peaks_bed,intersect_out)
	intersect_cmd = nc.check_and_annot(intersect_cmd,intersect_out)
	change_hd.write(intersect_cmd)
	RPKM_cmd = 'get_rpkm_from_intersect_bed.py %s,7,8,9 %s %s\n' % (intersect_out,rpkm_out,adj_factor)
	RPKM_cmd = nc.check_and_annot(RPKM_cmd,rpkm_out)
	change_hd.write(RPKM_cmd)
	intersect_cmd_v = 'bedtools intersect -a %s -b %s -wo > %s\n' % (treat_bed,oocyte_peaks_noTss_bed,intersect_out_v)
	intersect_cmd_v = nc.check_and_annot(intersect_cmd_v,intersect_out_v)
	change_hd.write(intersect_cmd_v)
	RPKM_cmd_v = 'get_rpkm_from_intersect_bed.py %s,7,8,9 %s %s\n' % (intersect_out_v,rpkm_out_v,adj_factor)
	RPKM_cmd_v = nc.check_and_annot(RPKM_cmd_v,rpkm_out_v)
	change_hd.write(RPKM_cmd_v)
	change_hd.write('\n\n')
#below need variables
	
	rpkm_adj_below.append(adj_rpkm)
	rpkm_adj_below.append(adj_rpkm_v)
change_hd.close()



#draw box plot 
tss_str,no_tss_str = '',''
boxPlot = open('box.sh','w')
for pos,each in enumerate(rpkm_adj_below):
	work_dir = os.path.dirname(os.path.dirname(each))
	name = os.path.basename(os.path.dirname(each))+'_adj'
	if pos%2 == 1:
		tss_str += '%s,%s,4 ' % (name,each)
	else:
		no_tss_str += '%s,%s,4 ' % (name,each)


boxPlot.write('cd %s\n' %work_dir)
tss_pdf = os.path.join(work_dir,'boxPlotData_tss_adj.pdf')
tss_no_pdf = os.path.join(work_dir,'boxPlotData_noTss_adj.pdf')
if 1:
	nc.excl_merger(tss_str,os.path.join(work_dir,'boxPlotData_tss_adj.xls'))
	nc.excl_merger(no_tss_str,os.path.join(work_dir,'boxPlotData_noTss_adj.xls'))

tss_boxPlot_cmd = 'draw_box_plot.R boxPlotData_tss_adj.xls boxPlotData_tss_adj\n'
tss_boxPlot_cmd = nc.check_and_annot(tss_boxPlot_cmd,tss_pdf)
boxPlot.write(tss_boxPlot_cmd)

tss_boxPlot_cmd = 'draw_box_plot.R boxPlotData_noTss_adj.xls boxPlotData_noTss_adj\n'
tss_boxPlot_cmd = nc.check_and_annot(tss_boxPlot_cmd,tss_no_pdf)
boxPlot.write(tss_boxPlot_cmd)

































if 0:
	if inp != '' and samp != '':
		if os.path.exists('%s/%s_peaks.xls' % (os.path.dirname(samp),prefix)):
			pk_cmd += '\n#cd %s' % os.path.dirname(samp)
			pk_cmd += '\n#macs2 callpeak -t %s -c %s -n %s -f BAM -g mm -m 5 50 -p 1e-5 --broad -B' % (samp,inp,prefix)
		else:
			pk_cmd += '\ncd %s' % os.path.dirname(samp)
			pk_cmd += '\nmacs2 callpeak -t %s -c %s -n %s -f BAM -g mm -m 5 50 -p 1e-5 --broad -B' % (samp,inp,prefix)
			pk_cmd += '\n#awk \'{if(($1!~/#/) && ($1!~/chr/)) print $1"\\t"$2"\\t"$3"\\t"$10}\' %s_peaks.xls | sed \'1d\' > %s_peaks.bed' % (each+'/'+prefix,each+'/'+prefix) 
		print(pk_cmd, file=pk_shell)
pk_shell.close()

rep_exp_dirs = os.listdir(str(d['work_dir']._seq))
each_rep_shell = open('each_rep_peak_calling.sh','w')
for each in SAMPLE_PAIR:
	pk_cmd ='#Peak calling for each sample'
	outdir = os.path.join(str(d['work_dir']._seq),each)
	t = os.path.join(os.path.join(str(d['work_dir']._seq),each),'bwa_merge.bam')
	prefix = os.path.basename(outdir)
	c = os.path.join(os.path.join(str(d['work_dir']._seq),SAMPLE_PAIR[each]),'bwa_merge.bam')
	if os.path.exists('%s/%s_peaks.xls' % (outdir,prefix)):
		pk_cmd += '\n#cd %s' % outdir
		pk_cmd += '\n#macs2 callpeak -t %s -c %s -n %s -f BAM -g mm -m 5 50 -p 1e-5 --broad -B' % (t,c,prefix)
		pk_cmd += '\n#awk \'{if(($1!~/#/) && ($1!~/chr/)) print $1"\\t"$2"\\t"$3"\\t"$10}\' %s_peaks.xls | sed \'1d\' > %s_peaks.bed\n\n' % (each+'/'+prefix,each+'/'+prefix)
	else:
		pk_cmd += '\ncd %s' % outdir
		pk_cmd += '\nmacs2 callpeak -t %s -c %s -n %s -f BAM -g mm -m 5 50 -p 1e-5 --broad -B' % (t,c,prefix)
		pk_cmd += '\nawk \'{if(($1!~/#/) && ($1!~/chr/)) print $1"\\t"$2"\\t"$3"\\t"$10}\' %s_peaks.xls | sed \'1d\' > %s_peaks.bed\n\n' % (each+'/'+prefix,each+'/'+prefix)
	print(pk_cmd, file=each_rep_shell)
exit()


if 0:
	cmd += '\nmacs2 callpeak -t %s -c %s -n %s -f SAM -g mm -m 5 50 -p 1e-5 --broad -B' % (smp,ctr,each)
	cmd += '\n\n## Plot peak length figure ##'
	cmd += '\nperl /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/peak_length.pl %s_peaks.xls > %s_peaks.length' % (each,each)
	cmd += '\nRscript /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/Peaklength.R %s_peaks.length %s_peak.length' % (each, each)
	cmd += '\n\n## Plot peak genome distribution figure ##'
	cmd += '\nperl /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/circos_for_peak_density.pl -a %s -b %s_peaks.xls -c 1-20 -o  %s.peak.distribution' % (parameters['genome'],each,each)
	cmd += '\nsort -k1,1 -k2,2n %s_treat_pileup.bdg > %s_treat_pileup.bedGraph' % (each,each)
	cmd += '\nsort -k1,1 -k2,2n  %s_control_lambda.bdg > %s_control_pileup.bedGraph' % (each,each)
	cmd += '\n/home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/bedGraphToBigWig %s_treat_pileup.bedGraph %s.fai %s.bigWig' % (each,parameters['genome'],each)
	cmd += '\n#/home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/bedGraphToBigWig %s_control_pileup.bedGraph %s.fai %s.bigWig' % (each,parameters['genome'],each)
	cmd += '\n\n\n'
	print(cmd, file=peak_calling_shell)
	merge_cmd += '\n\n#Merge group files\njava -jar /home/ningch/soft/picard.jar MergeSamFiles %s OUTPUT=%s/%s_merge.bam\n\n' % (merge_group,tmp_dir,each)
print(merge_cmd, file=map_cmd)
peak_calling_shell.close()

exit()
















