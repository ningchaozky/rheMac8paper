#!/usr/bin/env Rscript

args <- commandArgs()
if(length(args) < 6){
	stop("\nUsage:\n",sub(".*=","",args[4])," fpkm_input color_file out_prefix\n\n")
}

library(genefilter)
library(geneplotter)
library(gplots)

infile <- args[6]
color <- args[7]
outfile <- args[8]

outPDFfile <- paste(outfile,".pdf",sep="")
	
iPSexpTotal<-read.table(infile,header=TRUE,sep="\t",row.names=1)
marker <- read.table(color,header=TRUE)
rc <- as.vector(unlist(marker$color))
rn <- as.vector(unlist(marker$need))
iPSexp<-as.matrix(iPSexpTotal)

hclust2 <- function(x, method="average", ...){
  hclust(x, method=method, ...)
}
dist2 <- function(x, ...){
  as.dist(1-cor(t(x), method="pearson"))
}

### dendrogram for showing clustering in row or column or both
### key for color Key appearance or not
pdf(outPDFfile)
#hmp=heatmap.2(iPSexp, col=colorpanel(999,"green","black","red"), font=2, Rowv=T, Colv=F, scale="row", dendrogram=c("row"), colRow = rc, RowSideColors=rc, hclustfun=hclust2, distfun=dist2, key=T, symkey=F, density.info="none", trace="none")
hmp=heatmap.2(iPSexp, col=colorpanel(999,"green","black","red"), font=2, Rowv=T, Colv=F, scale="row", dendrogram=c("row"), RowSideColors = rc, labRow=rn,  hclustfun=hclust2, distfun=dist2, key=T, symkey=F, density.info="none", trace="none")
dev.off()
