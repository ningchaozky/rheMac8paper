#!/usr/bin/env python3

import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='prepare washu for rh8', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-t', choices = ['scaffoldInfo','refGene','xenoRefGene','refGeneTbi','xenoRefGeneTbi'], help ='key words for include in file name')
parser.add_argument('-i', nargs='?', help ='reference')
parser.add_argument('-o', nargs='?', help ='output file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

outType = args.t
infile = args.i
chroms = chromosome.chr('rh8', mt = False ).chr
def write(fh,lst):
    line = '\t'.join([str(i) for i in lst]) + '\n'
    fh.write(line)

def check(outType = outType, output = args.o):
    ofh = sys.stdout
    if os.path.exists(outType):
        sys.stderr.write('warning: exists %s\n' % outType)
    if output :
        ofh = open(outType, 'w')
    return ofh


if outType == 'scaffoldInfo':
    ofh = check()
    chroms = chromosome.chr('rh8', mt = True ).chr
    write(ofh,['ROOT','other',0])
    write(ofh,['ROOT','chromosome',0])
    for key in chroms:
        write(ofh,['chromosome',key,chroms[key]])

if outType == 'refGene' or outType == 'xenoRefGene':
    def parse(line):
        line_arr = line.strip().split('\t')
        gene_id = line_arr[1]
        chrom = line_arr[2]
        start = line_arr[4]
        end = line_arr[5]
        name = line_arr[12]
        lst = [[chrom,start,end,name]]
        lst.append([chrom,start,end,gene_id])
        return lst
    ofh = check()
    fh = open(infile)
    for line in fh:
        lst = parse(line)
        for each in lst:
            if each[0] not in chroms:
                continue
            write(ofh,each)

if outType == 'refGeneTbi' or outType == 'xenoRefGeneTbi':
    def sort(lst):
        infor = {}
        uniq = []
        lst = [ i for i in lst if len(i) == 2 ]
        for j,each in enumerate(lst):
            if each not in uniq:
                uniq.append(each)
        lst = uniq[:]
        for start,end in lst:
            trick.set1dict(infor,start,[])
            infor[start].append(start)
            infor[start].append(end)
        out = sorted(list( infor.items() ), key = lambda x: x[0], reverse=False)
        #python2
        #out = sorted(list(infor.items()), lambda x, y: cmp(x[0], y[0]), reverse=False)
        lst = [ v for i,v in out ]
        for i,each in enumerate(lst):
            if len(each) == 4:
                if each[0] == each[1] :
                    lst[i] = [each[2],each[3]]
                if each[2] == each[3] :
                    lst[i] = [each[0],each[1]]
        try :
            lst = [ (i,v) for i,v in lst if i != v ]
        except :
            print(lst)
            print('wrong')
        return lst
    def utr(exons,txStart,txEnd, chain = '+'):
        thin = []
        thick = []
        txStart = int(txStart)
        txEnd = int(txEnd)
        if abs(txStart - txEnd) <= 5:
            for i,each in enumerate(exons):
                thin.append(each)
            return sort(thin),sort(thick)
        for i,each in enumerate(exons):
            estart = int(each[0])
            eend = int(each[1])
#tx start and end all in one exon
            if estart <= txStart <= txEnd <= eend:
                thin.append((estart,txStart))
                thin.append((txEnd,eend))
                thick.append((txStart,txEnd))
            elif estart <= txStart <= eend <= txEnd:
                thin.append((estart,txStart))
                thick.append((txStart,eend))
            elif txStart <= estart <= txEnd <= eend:
                thin.append((txEnd,eend))
                thick.append((estart,txEnd))
# should concern the chain
            else :
                if eend <= txStart:
                    thin.append((estart,eend))
                elif  estart >= txEnd:
                    thin.append((estart,eend))
                elif txStart <= estart and eend <= txEnd:
                    thick.append((estart,eend))
                else :
                    print('wrong2')
#        return sort(thin),sort(thick)
        return thin,sort(thick)
    def parse(line):
        line_arr = line.strip().split('\t')
        gene_id = line_arr[1]
        chrom = line_arr[2]
        start = line_arr[4]
        chain = line_arr[3]
        end = line_arr[5]
        name = line_arr[12]
        txStart = line_arr[6]
        txEnd = line_arr[7]
        starts = [ i for i in line_arr[9].split(',') if i != '' ]
        ends = [ i for i in line_arr[10].split(',') if i != '' ]
        exons = list(zip(starts,ends))
        thins, thicks = utr(exons,txStart,txEnd)
        return gene_id,chrom,start,end,name, thins, thicks, chain, line_arr
    def show(lst):
        return str(lst).replace('(','[').replace(')','],').replace(',,',',')
    fh = open(infile)
    ofh = check()
    for desc_id,line in enumerate(fh):
        gene_id,chrom,start,end,name, thins, thicks, chain, line_arr = parse(line)
        desc = ['name:"%s"' % gene_id]
        desc.append('id:%s' % str(desc_id + 1))
        desc.append('strand:"%s"' % chain)
        desc.append('struct:{thin:%s,thick:%s,}' % (show(thins),show(thicks)))
        desc.append('desc:"%s"' % name)
        desc.append('name2:"%s"' % name)
        desc = ','.join(desc).replace('thin:[],','').replace('thick:[]','').replace(',,',',')
#        write(ofh, line_arr)
        write(ofh,[chrom,start,end,desc])











    
