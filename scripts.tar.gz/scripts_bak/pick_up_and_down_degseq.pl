#!/usr/bin/perl
use strict;
unless(@ARGV){
	print "\nUsage: $0 output_score.txt fc pValue output gff3\n\n";
}
else{

my $fc = $ARGV[1];
my $pValue = $ARGV[2];
my $out,
my @diff;
my $diff;
my $diff_input;
my $out_up;
my $out_down;
my $title_up;
my $title_down;
my $fasta;
my %trans;
my $name;
if(0){
open $fasta,"$ARGV[4]";
while(<$fasta>){
	chomp;
	if(/>/){
		s/>//;
		s/\s+.*//;
		$name = $_;
	}
	else{
		$trans{$name} .=  $_;
	}
}
}
#pick id 

my %gene;
my $gff3;
open $gff3,"$ARGV[4]";
while(<$gff3>){
	my @tmp = split /\t/,$_;
	my @tmp_des = split /;/,$tmp[8];
	if($tmp[2] =~ /gene$/i){
		$tmp_des[0] =~ s/ID=gene://i;
		$tmp_des[1] =~ s/Name=//i;
		$gene{$tmp_des[1]} =$tmp_des[0];
		if($tmp[2] =~ /pseudogene/i){
			$tmp_des[2] =~ s/Parent=gene://i;
			$gene{$tmp_des[1]} =$tmp_des[2];
		}
	}
}





open $diff_input,"$ARGV[0]";
my $head = <$diff_input>;
system("mkdir -p $ARGV[3]") unless(-d $ARGV[3]);
open $out_up,">  $ARGV[3]/up.txt";
print $out_up $head;
open $out_down,">  $ARGV[3]/down.txt";
print $out_down $head;
open $title_up,">  $ARGV[3]/up_title.txt";
open $title_down,">  $ARGV[3]/down_title.txt";
while(<$diff_input>){
	chomp;
	my @tmp = split /\t/,$_;
	if($tmp[6] < $pValue){
		if($tmp[4] > 0 && $tmp[4] > $fc){
			print $out_up "$_\n";
			if($gene{$tmp[0]}){
				print $title_up "$gene{$tmp[0]}\t$tmp[7]\n";
			}else{
				print $title_up "$tmp[0]\t$tmp[7]\n";
			}
		}
		elsif($tmp[4] < 0 && abs($tmp[4]) > $fc){
			print $out_down "$_\n";
			if($gene{$tmp[0]}){
				print $title_down "$gene{$tmp[0]}\t$tmp[7]\n";
			}else{
				print $title_down "$tmp[0]\t$tmp[7]\n";
			}
		}
	}
}
}
