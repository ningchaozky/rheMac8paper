#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import gzip
import argparse
from ningchao.nSys import trick
example = '''sumstats.gz'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('sumstatsgz', nargs='?', help ='sumstats.gz file')
parser.add_argument('--index_snp', nargs='+', help ='index_snp file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    gfh = gzip.open( args.sumstatsgz )
    index_snp = args.index_snp
    col = len(index_snp) == 2 and int(index_snp)[1] - 1 or 0 
    fh = index_snp and open(index_snp[0]) or ''
    return gfh,fh,col


def index( fh, col):
    rs = []
    for line in fh:
        line_arr = line.strip().split('\t')
        out = trick.lst(line_arr).get('rs', regular = True, returnType = 'list' )
        rs.extend(out)
    return rs
if __name__ == '__main__':
    gfh, fh, col = parse( args )
    rs = index( fh, col )
    j = 0
    print(next(gfh), end=' ')
    for line in gfh :
        line_arr = line.strip('\n').split('\t')
        if line_arr[0] not in rs:
            if line_arr[1] != '':
                line_arr[-1] = '0.1'
                #line_arr[1:-1] = ['' for i in line_arr[1:-1]]
        print('\t'.join(line_arr))































