#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick, system
from collections import defaultdict

desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs='+', help = 'excels with only one header and one index column. last table should be RNA')
parser.add_argument( '-fc', nargs='?', help = 'fold change at least', default = 2, type = float)
parser.add_argument( '-pick_use_name', nargs='?', help = 'bw|bam', default = 'bw|bam')
parser.add_argument( '-t', nargs='+', help = 'match 1 max the max with same peirod |prime 2', default = [ 'match', 1 ])
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_span( lst, **kwargs):
    stages = [ system.dir.str_map_peirod( lst[i][0], pub = False) for i in range( 2 )]
    smax, smin = max(stages), min(stages)
    span = smax - smin
    return span

def symbols_get_overlap( dit, **kwargs ):
    rout = defaultdict( set )
    before, last = split_dit_by_last_tab( dit, **kwargs)
    if 'prime' in args.t:
        for max_peirod in system.dir.peirods( prefrontal_raw = True ):
            if max_peirod == 'E50' :
                continue
            if max_peirod in dit :
                #last tab max_peirod symbols
                max_peirod_symbols = list( dit[max_peirod].values() )
                last_tab_max_peirod_symbols, before_peirods_symbols = max_peirod_symbols[-1], []
                last_tab_max_peirod_before_peirods = [ i for i in system.dir.get_before_peirods(max_peirod, span = int(args.t[1])) if i in dit.keys()]
                print ( 'max_peirod:', max_peirod, 'before_peirods', *last_tab_max_peirod_before_peirods, file = sys.stderr)
                for p in last_tab_max_peirod_before_peirods:
                    for max_peirod_symbols_before in list(dit[p].values())[ : -1 ]:
                        print ( 'prime:', p, len( max_peirod_symbols_before))
                        before_peirods_symbols.extend( list(max_peirod_symbols_before) )
            before_peirods_symbols = set(before_peirods_symbols)
            symbols = set.intersection( before_peirods_symbols, last_tab_max_peirod_symbols )
            rout[ max_peirod ] = symbols
            print ( 'select:', max_peirod, len(symbols) )
    elif 'match' in args.t :
        for max_peirod in dit :
            #intersection
            symbols = set.intersection( set.union( *before[max_peirod].values() ), *last[max_peirod].values() )
            rout[ max_peirod ] = symbols
    return rout


def split_dit_by_last_tab( dit, **kwargs ):
    before, last, peirods = defaultdict( dict ), defaultdict( dict ), system.dir.peirods( prefrontal_raw = True )
    for peirod in dit :
        for tab in dit[peirod]:
            if tab == args.tabs[-1]:
                last[peirod][tab] = dit[peirod][tab]
            else :
                before[peirod][tab] = dit[peirod][tab]
    return before, last

def parse(**kwargs):
    infor = defaultdict( lambda : defaultdict( list) )
    peirods, symbols = system.dir.peirods('pre'), defaultdict( lambda : defaultdict( set) )
    for tab in args.tabs:
        with open( tab ) as f :
            header = next(f).rstrip().split('\t')
            header_mapped = [ system.dir.str_map_peirod(i, raw = i) for i in header ]
            need_peirods = [ i for i in header_mapped if i in peirods ]
            for line in f :
                arr = line.rstrip().split('\t')
                dit = dict( zip( header_mapped, arr) )
                order = { p:dit[p] for p in need_peirods }
                order = sorted( order.items(), key = lambda x: float( x[1] ), reverse = True)
                if not float( order[0][1] ):
                    continue
                #if 'match' in args.t :
                #    span = get_span( order, **kwargs)
                    #print ( span )
                #same_key = '|'.join([ order[i][0] for i in range( args.l )])
                symbol = arr[0].split('.')[0]
                max_peirod = order[0][0]
                infor[tab][ symbol ].append( line.strip() )
                symbols[ max_peirod ][ tab ].add( symbol )
    symbols = symbols_get_overlap( symbols )
    symbols_sorted_peirods = system.dir.sort( list(symbols.keys()) )
    for tab in args.tabs:
        with open( tab ) as f :
            output = open( os.path.basename(tab) + '.{}'.format(args.t[0]), 'w')
            header = next(f).rstrip().split('\t')
            print ( *header, sep = '\t', file = output)
            #header_mapped = [ system.dir.str_map_peirod(i, raw = i) for i in header ]
            for peirod in symbols_sorted_peirods:
                for symbol in symbols[peirod]:
                    print ( *infor[tab][symbol], sep = '\n', file = output )


if __name__ == '__main__':
    kwargs = vars( args )
    kwargs.update( {'log': False } )
    parse( **kwargs )





















