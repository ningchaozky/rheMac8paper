#!/usr/bin/perl
use strict;

unless(@ARGV){
	die "Usage: $0 input.txt\n";
}
print "FC\tP.Value\n";
my $degseq_output;
open $degseq_output,"$ARGV[0]";
<$degseq_output>;
while(<$degseq_output>){
	chomp ;
	my @tmp = split /\t/,$_;
	print 2**$tmp[2];
	print "\t";
	print $tmp[5];
	print "\n";
}


sub log10 {
 my $n = shift;
 return log($n)/log(10);
}
