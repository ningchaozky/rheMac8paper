#!/usr/bin/env python
import sys
import os


def help():
	print('\n\tUsage:',sys.argv[0],'fdr','fc','x-vs-y_degseq.txt')
	print('\tEg:',sys.argv[0],'1e-3','2','g1-vs-g15_degseq.txt\n')

if len(sys.argv) <= 1:
	help()
	exit()

files = os.popen('find %s -name \'*_degseq.txt\'' % sys.argv[-1])
for file in files:
	file = file.strip('\n')
	file_handle = open(file)
	out_file = file.replace('degseq.txt',('%s_%s.txt' % (sys.argv[1],sys.argv[2])))
	file_output_handle = open(out_file,'w')
	print(next(file_handle), end=' ', file=file_output_handle)
	for line in file_handle:
		line_arry = line.split('\t')
		if not line_arry[7].startswith('NA') and abs(float(line_arry[4])) > float(sys.argv[2]) and float(line_arry[6]) < float(sys.argv[1]):
			print(line, end=' ', file=file_output_handle)
	file_handle.close()
