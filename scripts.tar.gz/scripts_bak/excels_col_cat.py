#!/usr/bin/env python
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='cat excl special column together. title name is the excl file name')
parser.add_argument('-e', nargs='+', help ='excl col excl col; excl 2 ...')
parser.add_argument('-sf', nargs='+', help ='fiter keys for excl you want to fitter in the output title')
parser.add_argument('-H', action='store_true', help ='header include')

parser.add_argument('-o', nargs='?', help ='output file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

Infor = {}
title_name = []
excls = iter(args.e)
for excl in excls:
	name = excl.split('.')
	name = [i for i in name if i not in args.sf]
	name = '.'.join(name)
	title_name.append(name)
	col = int(next(excls)) - 1
	efh = open(excl)
	if args.H:
		next(efh)
	for line in efh:
		line_arr = line.strip().split('\t')
		trickTookit.set2dict(Infor,line_arr[0],name,line_arr[col])
	efh.close()

ids = trickTookit.uList(list(Infor.keys()))

out = open(args.o,'w')
out.write('id'+'\t'+'\t'.join(title_name) + '\n')

for gene in ids:
	line = []
	for name in title_name:
		if name in Infor[gene]:
			line.append(Infor[gene][name])
		else :
			line.append('0')
	out.write(gene+'\t'+'\t'.join(line) + '\n')

out.close()







