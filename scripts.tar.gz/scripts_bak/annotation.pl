#!/usr/bin/env perl
use strict;
use warnings;
use Switch;
use File::Basename;
my $usage = "#Usage: $0 ncbi|ref50|ref90|tr blast_num_threads protein_fasta\n";
@ARGV || die $usage;
my ($db,$dbname,@line);
switch($ARGV[0]){
    case /^ncbi/i       {$db = "/data/Database/nr/nr";}
    case /^ref50/i      {$db = "/Storage/data002/ningch/data/uniprot/UniRef50.fasta";}
    case /^ref90/i      {$db = "/Storage/data002/ningch/data/uniprot/UniRef90.fasta";}
    case /^t\r/i        {$db = "/Storage/data002/ningch/data/uniprot/uniprot_trembl.fasta";}
    case /^kb/i         {$db = "/Storage/data002/ningch/data/uniprot/uniprot_sprot.fasta";}
    case /^goncbi/i     {$db = "/Storage/data002/ningch/data/uniprot/idmapping_ncbi.fa";}
    case /^goref50/i    {$db = "/Storage/data002/ningch/data/uniprot/idmapping_ref50.fa";}
    case /^goref90/i    {$db = "/Storage/data002/ningch/data/uniprot/idmapping_ref90.fa";}
    case /^gosp/i       {$db = "/Storage/data002/ningch/data/uniprot/idmapping_uniprot.fa";}
    case /^goname/      {$db = "/Storage/data002/ningch/data/gene_othrology_information/GO_id_title_flat.fa";}
    else                {print "previous case not true";}
}


$dbname = basename $db;

print "blastp -query $ARGV[2] -db $db -evalue 1e-3 -max_target_seqs 5 -num_threads $ARGV[1] -out $ARGV[2]2$dbname -outfmt \'6 qlen slen qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore\'\n";
print "acc2title.pl $ARGV[0] $ARGV[2]2$dbname  $ARGV[2]2$dbname\_title\n";
