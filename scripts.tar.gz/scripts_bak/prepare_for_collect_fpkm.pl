#!/usr/bin/perl
use strict;

unless(@ARGV){
	die "Usage: $0 extract-as-fpkm_out\n";
}
my $file;
open $file,"$ARGV[0]";
while(<$file>){
	my @tmp = split /\t/,$_;
	unless($tmp[1] =~ /^X/){
		print;
	}
}
