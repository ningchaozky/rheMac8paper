#!/usr/bin/env python3
import os
import sys
import time
import argparse
import threading
import subprocess as sp
from ningchao.nSys import trick, system, fix

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'dir', nargs = '?', help = 'reference' )
parser.add_argument( '-p', nargs = '+', help = '''pattern for zip the file, ['fastq$','fq$']''', default = ['fastq$','fq$'] )
parser.add_argument( '-cpu','-c', nargs = '?', help = 'pattern for zip the file', default = 4, type = int )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


sem=threading.Semaphore(args.cpu) #限制线程的最大数量为4个
 
def zipFls( fls ):
  with sem: #锁定线程的最大数量
    for fl in fls:
        gz = fl + '.gz'
        md5 = fl+'.gz.md5'
#800M
        if os.path.exists( gz ) and os.path.getsize(gz) > 800000000 :
            print ( '#Zip file exist {}, and ignore'.format(gz), file = sys.stderr )
        else :
            cmd = 'gzip -c {} > {} && md5sum {} > {}'.format( fl, gz, gz, md5)
            print( '#GZIP {} to {}'.format(fl,gz), threading.current_thread().name, cmd, file = sys.stdout)
            c = sp.Popen( cmd, shell = True, stdout = sp.PIPE, stderr = sp.PIPE )
            std, err = c.stdout, c.stderr
            print ('#Done {} ERR is:'.format(fl), list(err), file = sys.stderr)
            print ('#Done {} stdout is:'.format(fl), list(std), file = sys.stderr)
fls = system.dir( args.dir ).npick('fastq$', n = args.cpu, depth = 10)
for fl in fls:
    p = threading.Thread( target = zipFls, args = ( fl, ))
    p.start() 
    #p.join()




























