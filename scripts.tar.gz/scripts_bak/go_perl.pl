#!/usr/bin/env perl 
use strict;
use warnings;
use GO::Parser;

@ARGV or die "#Usage: $0 go_id\n";

my $go_id = $ARGV[0];
# ** FETCHING GRAPH OBJECTS FROM AN ONTOLOGY FILE **
  my $parser = new GO::Parser({handler=>'obj'}); # create parser object
  $parser->parse("/Storage/data002/ningch/data/gene_othrology_information/gene_ontology.obo"); # parse file -> objects
  my $graph = $parser->handler->graph;  # get L<GO::Model::Graph> object
  my $term = $graph->get_term($go_id);   # fetch a term by ID
  printf "Got term: %s %s\n", $term->acc, $term->name;
  my $parent_terms = $graph->get_parent_terms($term->acc);
  foreach my $par_term (@$parent_terms) {
    printf " Parents term:\t%s\t%s\n", $par_term->acc, $par_term->name;
  }

  my $ancestor_terms = $graph->get_recursive_parent_terms($term->acc);
  foreach my $anc_term (@$ancestor_terms) {
    printf " Ancestor term:\t%s\t%s\n", $anc_term->acc, $anc_term->name;
  }

  my $child_terms = $graph->get_child_terms($term->acc);
  foreach my $chi_term (@$child_terms) {
    printf " Child term:\t%s\t%s\n", $chi_term->acc, $chi_term->name;
  }

  my $Offspring_terms = $graph->get_recursive_child_terms($term->acc);
  foreach my $off_term (@$Offspring_terms) {
    printf " Offspring term:\t%s\t%s\n", $off_term->acc, $off_term->name;
  }
