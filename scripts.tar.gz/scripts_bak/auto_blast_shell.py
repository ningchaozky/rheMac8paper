#!/usr/bin/env python
import os
import sys


if len(sys.argv) <= 1:
	print(sys.argv[0],'program','db','query','num','out')
	exit()

cmd_array = []
sys.argv.pop(0)
sys.argv[1] = '-db ' + sys.argv[1]
sys.argv[2] = '-query ' + sys.argv[2]
sys.argv[3] = '-num_threads ' + sys.argv[3]
sys.argv[4] = '-out ' + sys.argv[4]
for each in sys.argv:
	cmd_array.append(each)
cmd_array.append("-outfmt \'6 qlen slen qseqid sseqid pident length mismatch gapopen qstart qend\
 sstart send evalue bitscore\' -max_target_seqs 5")
cmd = ' '.join(cmd_array)
print(cmd)






