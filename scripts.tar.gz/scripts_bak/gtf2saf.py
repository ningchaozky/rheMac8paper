#!/usr/bin/env python3
import os
import sys
import argparse
import pyranges as pr
from ningchao.nSys import trick
from ningchao.nBio import gtf

example = ''' reference gtf to saf for featureCounts'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'g', nargs = '?', help = 'gtf file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

for line in open( args.g ):
    if line.startswith('#'):
        continue
    line_arr = line.rstrip('\n').split('\t')
    if line_arr[2] == 'exon':
        infor = gtf.gtfDsp2dict( line_arr[-1] )
        gene_id = infor['gene_id']
        if 'gene_name' in infor:
            gene_name = '|'.join( [ gene_id, infor['gene_name'] ] )
        else :
            gene_name = gene_id
        start, end = line_arr[3:5]
        chain = line_arr[6]
        print ( gene_name, line_arr[0], start, end, chain, sep = '\t')


















