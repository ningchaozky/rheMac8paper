#!
use strict;
use warnings;
use threads qw(yield);
use Thread::Semaphore;

my @array = qw(a b c d e f g h);
my @children;
my @results;

my $semaphore = Thread::Semaphore->new(2);
for my $i (1..5)
{
	for my $j(1..2)
	{
		threads->create(sub{\&sub_fork(threads->tid(),@array)});
	}
	sleep(1);
	threads->yield();
}
sub sub_fork
{
	my ($tid,@temp) = (shift,@_);
	$semaphore->down(1);
	my $pid = fork();
	if ($pid) {
       		push (@children, $pid);
		print "$tid -- Running another child process - $pid.\n";
    	}
	else {
		print "@array\n";
	}

	$semaphore->up(1);
#	sleep (2);
}