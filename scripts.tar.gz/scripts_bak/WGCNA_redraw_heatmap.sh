#!/usr/bin/env sh
###
### cor pvalue order from wgcna output
###
### Usage:
###   any word for redraw
###
###
help() {
        awk -F '###' '/^###/ { print $2 }' "$0"
}
if [[ $# == 0 ]] || [[ "$1" == "-h" ]]; then
        help
        exit 1
fi


wgcna_module_sort.py *moduleEigengenes.tab

excel_extract.py  *moduleEigengenes.pvalue.tab -n *moduleEigengenes.tab.order  -eH > moduleEigengenes.pvalue.order.tab
excel_extract.py  *moduleEigengenes.tab -n *moduleEigengenes.tab.order  -eH > moduleEigengenes.order.tab

WGCNA_redraw_heatmap.r moduleEigengenes.order.tab moduleEigengenes.pvalue.order.tab

#for p in E50 E90 E120 P0 4M 45Y 20Y; do
#    show `cat ${p}*moduleEigengenes.tab.orderFls` -pt heatmap > $p.hypergeometric.sh
#done
























