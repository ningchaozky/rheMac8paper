#!/usr/bin/env python3
import os
import re
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import pandas as pd
import numpy as np
import pyBigWig
from collections import defaultdict
from ningchao.nSys import trick, parse, system, fix
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'gene', nargs = '?', help = 'gene list')
parser.add_argument( 'spdini', nargs = '?', help = 'spd bed and bw file')
parser.add_argument( '-transcripts2gene', nargs = '?', help = 'transcripts_bed file', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.gene2transcripts')
parser.add_argument( '-rbed', nargs = '?', help = 'region bed for calculate spd signal', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.geneBody.updown5K')
#parser.add_argument( '-rbed', nargs = '?', help = 'region bed for calculate spd signal', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.promoter')
parser.add_argument( '-rna', nargs = '?', help = '/farangism/ningch/earyly_embryo/RNA/transcripts.exp.tpm', default = '/farangism/ningch/earyly_embryo/RNA/transcripts.exp.tpm')
parser.add_argument( '-t', choices = [ 'median', 'mean', 'max', 'min', 'stdev', 'cov', 'sum' ], help ='region for the extract values', required = True  )
parser.add_argument( '-num', nargs='?', help = 'number of split the bed line', default = 10, type = int )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def gene2transIds( args ):
    gene2trans = []
    with open( args.gene ) as f :
        genes = [ i.strip().upper() for i in f.readlines() ]
    with open( args.transcripts2gene ) as f :
        for line in f :
            line_arr = line.strip().split('\t')
            gene, transcript_id = line_arr[0].upper(), line_arr[1]
            if gene in genes:
                gene2trans.append( transcript_id )
    return gene2trans

def transId2inoutspd( gene2trans, args ):
    spdbed = parse.ini( args.spdini ).to_dict()['bed']
    [ spdbed.pop(i) for i in [ 'mESC', 'merge'] ]
    inOutBed = defaultdict( lambda : defaultdict ( str ) )
    trans_select_bed = open( '{}.select.bed'.format( os.path.basename(args.gene)), 'w')
    with open( args.rbed ) as f :
        for line in f:
            line_arr = line.strip().split('\t')
            if line_arr[3] in gene2trans:
                print ( line.strip(), file = trans_select_bed )
    trans_select_bed.close()
    for peirod in spdbed:
        if peirod not in inOutBed:
            inOutBed[peirod]['in'] = open( '{}.in.bed'.format( peirod  ), 'w')
            inOutBed[peirod]['out'] = open( '{}.out.bed'.format( peirod  ), 'w')
        pbed = spdbed[ peirod ]
        cmd = 'bedtools intersect -b {} -a {} -wa'.format( pbed, trans_select_bed.name )
        for line in system.run( cmd, shell = True ):
            line_arr = line.strip().split('\t')
            print ( line.strip(), file = inOutBed[peirod]['in'] )
        cmd = 'bedtools intersect -b {} -a {} -wa -v'.format( pbed, trans_select_bed.name )
        for line in system.run( cmd, shell = True ):
            line_arr = line.strip().split('\t')
            print ( line.strip(), file = inOutBed[peirod]['out'] )
    for peirod in inOutBed:
        for typ in inOutBed[peirod]:
            inOutBed[peirod][ typ  ].close()
            inOutBed[peirod][ typ ] = inOutBed[peirod][ typ ].name
    inOutBed['geneTransBed'] = trans_select_bed.name
    return inOutBed

def bed_gene_exp( bed, args ):
    geneTransBed = bed.pop('geneTransBed')
    exp_df = pd.read_csv( args.rna, header = 0, index_col = 0, sep = '\t')
    exp = exp_df.T.to_dict()
    out = defaultdict( lambda : defaultdict( str ) )
    for peirod in bed:
        for typ in bed[peirod]:
            out[peirod][typ] = bed[peirod][typ]
            tbed_with_exp = open( fix.fix( out[peirod][typ] ).insert('exp'), 'w')
            out[peirod]['exp'] = tbed_with_exp.name
            print ( peirod, bed[peirod][typ], file = sys.stderr )
            with open( bed[peirod][typ] ) as f:
                for line in f:
                    line_arr = line.strip().split('\t')
                    trans_id = line_arr[3]
                    exp_peirod = peirod
                    if 'blastocyst' == peirod:
                        exp_peirod = 'ICM'
                    print ( *line_arr, exp[ trans_id ][ exp_peirod ], sep = '\t', file = tbed_with_exp )
    with open( geneTransBed ) as f :
        out['geneTransBed'] = open( fix.fix( geneTransBed ).insert('exp'), 'w' )
        print ( 'trans_id', *exp_df.columns, sep = '\t', file = out['geneTransBed'] )
        for line in f:
            line_arr = line.strip().split('\t')
            trans_id = line_arr[3]
            print ( trans_id, *exp[trans_id].values(), sep = '\t', file = out['geneTransBed'] )
        out['geneTransBed'].close()
        out['geneTransBed'] = out['geneTransBed'].name
        out['geneTransBedCut'] = fix.fix( out['geneTransBed'] ).insert('cut1')
        cmd = 'del_no_express.py {} -c cut -v 0 > {}'.format( out['geneTransBed'], out['geneTransBedCut'] )
        os.system( cmd )
        rna_select_bed = fix.fix( out['geneTransBedCut']  ).insert('selectBed')
        out['rna_select_bed'] = rna_select_bed
        cmd = '''excel_extract_v2.py {},index_col,4,header,None -b {} -ipos 4 | cut -f1,2,3,4,5,6 | sed '1d' > {} '''.format( args.rbed, out['geneTransBedCut'], rna_select_bed )
        os.system( cmd )
    return out



def bed_get_bwSignal( rna_select_bed, args ):
    bw = defaultdict( str )
    spdbw = parse.ini( args.spdini ).to_dict()['bw']
    [ spdbw.pop(i) for i in [ 'mESC', 'oocyte'] ]
    for peirod in spdbw:
        bw[peirod] = pyBigWig.open( spdbw[peirod] )
    bed_with_signal = open( fix.fix( rna_select_bed ).insert( 'signal' ), 'w' )
    print ( 'trans_id', *bw.keys(), file = bed_with_signal, sep = '\t')
    with open( rna_select_bed ) as f:
        for line in f:
            line_arr = line.strip().split('\t')
            chrom, start, end = line_arr[0:3]
            start, end = int( start ), int( end )
            chrom = 'chr' + chrom
            if 'chrY' in chrom:
                continue
            signal = [ signal_extract( chrom, start, end, bw, args) for peirod, bw in bw.items() ]
            print ( line_arr[3], *signal, file = bed_with_signal, sep = '\t')
    bed_with_signal.close()
    return bed_with_signal.name

def signal_extract( chrom, start, end, bw, args):
    try :
        if args.t == 'sum':
            values = [  np.nansum( bw.values( chrom, start, end )) ]
        elif args.t == 'median':
            values = [ np.nanmedian( bw.stats( chrom, start, end, nBins = args.num ) ) ]
        else :
            values = bw.stats( chrom, start, end, type = args.t, nBins = args.num )
    except :
        print('Wrong', chrom, start, end)
        print ( bw.values( chrom, start, end ) )
    val = round( sum(values), 4  )
    if args.t == 'sum':
        val = val * 1000 / ( end - start )
    return val

if __name__ == '__main__':
    gene2trans = gene2transIds( args )
    inOutBed = transId2inoutspd( gene2trans, args )
    bed_with_exp = bed_gene_exp( inOutBed, args )
    bed_get_bwSignal( bed_with_exp['rna_select_bed'], args )






















