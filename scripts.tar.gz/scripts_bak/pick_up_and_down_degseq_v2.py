#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help ='degseq output file')
parser.add_argument('-lfc', nargs='?', help ='log fold change', default = 2, type = float)
parser.add_argument('-p', nargs='?', help = 'pvalue for select gene', default = 0.001, type = float)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

tfh = open(args.tab)
title = next( tfh ).split('\t')
#print [ v for i,v in enumerate(title) if i in [0,2,5,6]]
#Row.names       baseMean        log2FoldChange  lfcSE   stat    pvalue  padj    E50.PFC.RNA.rep1        E50.PFC.RNA.rep2        E90.PFC.RNA.rep1        E90.PFC.RNA.rep2
def parse(line):
    line_arr = line.strip().split('\t')
    name = line_arr[0]
    lfc = float(line_arr[2])
    pv = float(line_arr[5])
    qv = float(line_arr[6])
    return name,lfc,pv,qv


for line in tfh:
    if '\tNA' in line:
        continue
    name,lfc,pv,qv = parse(line)
    if lfc > args.lfc and qv < args.p :
        print('up', line, end = '', sep = '\t')
    elif lfc < -args.lfc and qv < 0.05:
        print('down', line, end = '', sep = '\t')




