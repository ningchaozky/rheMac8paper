#!/usr/bin/env Rscript


####################################
#draw venn diagram with Venerable
#package in R
#Date: 2016/01/02
####################################

library(Vennerable)

Args <- commandArgs()

workdir <- Args[6]
file1 <- Args[7]
file2 <- Args[8]
file3 <- Args[9]
file4 <- Args[10]
outfile <- Args[11]

pdf(outfile)

setwd(workdir)

first <- read.table(file1,sep="\t")
second <- read.table(file2,sep="\t")
third <- read.table(file3,sep="\t")
fourth <- read.table(file4,sep="\t")

first_arr <- as.vector(first$V1)
second_arr <- as.vector(second$V1)
third_arr <- as.vector(third$V1)
fourth_arr <- as.vector(fourth$V1)

VennObject <- list(BEA_6h=first_arr,BEA_24h=second_arr,FA_6h=third_arr,FA_24h=fourth_arr)

str(VennObject)

VennFigure <- Venn(VennObject)

VennFigure

p <- plot(VennFigure, doWeights = FALSE,type="ellipses")

print(p)

dev.off()

