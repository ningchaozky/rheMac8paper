#!/usr/bin/env Rscript
#first
#vegan can use for spider line
alen <- commandArgs()
library(argparser)
p <- arg_parser('tsne matrix data')
p <- add_argument(p, "--matrix", help="matrix for plot each with one col")
p <- add_argument(p, "--dim", help="dimensions. 2(default)|3")
p <- add_argument(p, "--out", help="output file", default="output")
if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
args <- parse_args(p)

data_frame <- read.table(args$matrix,header = T)
tsne <- t(as.matrix(data_frame))
pdf(paste(args$out,".tSNE.pdf",sep=''))
#plot(mds, type = 'n', axes = FALSE, xlab = 'dim1', ylab = 'dim2')
pch <- c(21,22,17,12,7)
plot(tsne, xaxt="n", yaxt="n", xlab = 't-SNE_1', ylab = 't-SNE_2', pch=pch, col=1:5)
text(tsne[, 1], mds[, 2], rownames(tsne))
dev.off()

#pdf(paste(args$out,"hc.pdf",sep=''))
#hc <- hclust(dist)
#plot(hc)
#dev.off()












