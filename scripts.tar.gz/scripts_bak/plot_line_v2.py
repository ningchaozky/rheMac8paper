#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import matplotlib
import numpy as np
matplotlib.use('Agg')
import pandas as pd
import matplotlib.pyplot as plt
import argparse
from ningchao.nSys import trick,color,fix
from ningchao.nBio import neuron

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tab', nargs='?', help = 'reference' )
parser.add_argument( '-t', action = 'store_true', help = 'transposition' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def main():
    prefix = fix.fix(args.tab)
    df = pd.read_csv( args.tab, sep = '\t', header = 0, index_col = 0 )
    df = df if args.t else df.T
    fig, ax = plt.subplots(figsize=(10,9))
    df.plot.line()
    #ax.set_yscale('log', basey = 10)
    #ax.set_xscale('log', basex = 10)
    plt.savefig(prefix.append('pdf') )
    


if __name__ == '__main__':
    main()
exit()
tfh = open(args.tab)
header = tfh.next().strip().split('\t')
sys.stderr.write('\t'.join(header) + '\n')
header.pop(0)
fig, ax = plt.subplots(figsize=(10,9))
x = list(range(len(header)))
for i,line in enumerate(tfh):
    line_arr = line.strip().split('\t')
    gene = line_arr.pop(0)
    if gene.split('.')[0].upper() in genes:
        sys.stderr.write(line)
        ax.plot(x, line_arr, color.plt().linestype(), color = color.plt().colors(), marker = color.plt().markers(), label = gene.split('.')[0] )
ax.legend(loc=1, shadow=True)
plt.xticks(np.arange(len(header)), header, rotation = 45 )
plt.savefig(prefix.append('pdf') )



