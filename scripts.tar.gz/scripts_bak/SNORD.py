#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s SNORD.bed' % sys.argv[0], formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('SNORD', nargs='?', help ='')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

sfh = open(args.SNORD)

def parse(line):
    line_arr = line.strip().split('\t')
    marker = line_arr.pop(-1)
    line_arr[3] = line_arr[3].split('.')[0]
    return line_arr,(line_arr[0],line_arr[1],line_arr[2]),marker

uniq = []
gene_add = {}
for line in sfh:
    line_arr,key,marker = parse(line)
    trick.set2dict(gene_add,line_arr[3],'num', 0)
    trick.set2dict(gene_add,line_arr[3],'version', marker)
    if key not in uniq :
        gene_add[line_arr[3]]['num'] += 1
        line_arr[3] = line_arr[3] +'.' +gene_add[line_arr[3]]['version'] +'.' + str(gene_add[line_arr[3]]['num'])
        print('\t'.join(line_arr) + '\n', end=' ')



































