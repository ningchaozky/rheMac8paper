#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import gtf
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed', default = '/home/ningch/data/genome/rheMac8/exon/ref_ensemble_xeonRefGene.bed')
parser.add_argument( '-gtfs', nargs='*', help ='annot gtfs' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

coding_gene = []
for g in args.gtfs:
    fh = open(g)
    for line in fh:
        if line.startswith('#'):
            continue
        line_arr = line.strip().split('\t')
        if line_arr[2] == 'gene':
            line_infor = gtf.gtfDsp2dict(line_arr[8])
            if 'gene_biotype' in line_infor and 'gene_name' in line_infor:
                if line_infor['gene_biotype'] == 'protein_coding':
                    coding_gene.append(line_infor['gene_name'].upper())




bfh = open(args.bed)
for line in bfh:
    line_arr = line.strip().split('\t')
    gene = line_arr[3].split('.')[0]
    if gene not in coding_gene:
        sys.stdout.write(line)

















