#!/usr/bin/env python
import sys

if len(sys.argv) <= 1:
	print(sys.argv[0],'sra_fastq')
	exit()


file = open(sys.argv[1])

for line in file:
	if line.startswith('+SRR'):
		print('+')
	else:
		print(line, end=' ')
