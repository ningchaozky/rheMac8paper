#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='extract excl by col, can you to order for some use')
parser.add_argument('-n', nargs='+', help ='names you want to put in you flat file| the file contain order names for each line, if len == 2 will change the name of title', required = True)
parser.add_argument('-e', nargs='*', help ='excl file col. default e 1', required = True)
parser.add_argument('-o', nargs='?', help ='output file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

order = args.n
newName = {}
if os.path.exists(order[0]):
	orfh = open(order[0])
	order = []
	for line in orfh:
		line_arr = line.strip().split('\t')
		if len(line_arr) == 1 or len(line_arr) > 2 :
			trKit.set1dict(newName,line_arr[0],line_arr[0])
		elif len(line_arr) == 2 :
			trKit.set1dict(newName,line_arr[0],line_arr[1])
		else :
			print('#!please check you order file')
			exit(2)
		order.append(line_arr[0])
ecol = 0
if len(args.e) == 2 :
	ecol = int(args.e[1]) - 1

out = sys.stdout
if args.o:
	out = open(args.o,'w')

xls_fh = open(args.e[0])
title = xls_fh.next().strip().split('\t')
order = trKit.indexLst(title, order = order)
out.write('\t'.join(trKit.valLst(title,order)) + '\n')
Infor,original_order = {},[]
for line in xls_fh:
	line_arr = line.strip().split('\t')
	out.write('\t'.join(trKit.valLst(line_arr,order)) + '\n')

xls_fh.close()
out.close()
