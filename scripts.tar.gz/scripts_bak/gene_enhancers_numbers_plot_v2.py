#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
from scipy.stats import zscore
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
plt.tight_layout()
import pandas as pd
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system

desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs = '?', help = 'merge.hicItersection.hicCut.sum')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def num_to_bin(num):
    sbins = [ 1, 3, 5, 7, 9, 10, 15, 20, 25, 30, 35 ]
    for s in sbins[::-1]:
        if num // s >= 1 :
            return s
def parse():
    periods = system.dir.periods( prefrontal_raw = True )
    genes, enhancers = defaultdict( lambda : defaultdict( set ) ), defaultdict( lambda : defaultdict( set ) )
    with open( args.tab ) as f:
        header = f.readline().rstrip().split('\t')
        for line in f:
            line_arr = line.rstrip().split('\t')
            gene_enh = line_arr[0]
            gene_enh_arr = gene_enh.split('|')
            key = '\t'.join( gene_enh_arr[-3:] )
            symbol = gene_enh_arr[0].split('.')[0].upper()
            dit = dict( zip( header[1:], line_arr[1:] ) )
            for p in periods:
                p = '0M' if p == 'P0' else p
                intera = '{}.PFC.AC.ppois.bw.hicInteraction'.format(p)
                if intera in dit:
                    interaction = dit[intera]
                    if interaction == 'yes':
                        genes[ p ][ symbol ].add( key )
                        enhancers[ p ][ key ].add( symbol )
    pdata = defaultdict( lambda : defaultdict( str ) )
    infor = defaultdict( lambda : defaultdict( lambda : defaultdict( lambda : defaultdict( int) ) ) )
    for p in periods:
        SE,typical = [], []
        p = '0M' if p == 'P0' else p
        for symbol in genes[p]:
            for enh in genes[ p ][ symbol ]:
                enh_arr = enh.split('\t')
                length = int(enh_arr[2]) - int(enh_arr[1])
                t = 'SE' if length >= 8000 else 'typical'
                infor[p][ num_to_bin(len(genes[p][symbol])) ][ num_to_bin( len(enhancers[p][enh]) ) ][ t ] += 1
                if 0 :
                    if t == 'SE':
                        SE.append( [ p, len(genes[p][symbol]), len(enhancers[p][enh]), t ] )
                    else :
                        typical.append( [ p, len(genes[p][symbol]), len(enhancers[p][enh]), t ] )
        #df = pd.DataFrame( [ *SE, *typical ], columns = ['p','symbol_num', 'enh_num', 't'] )
        #df_compare = df.groupby([ 'p', 'symbol_num', 'enh_num','t']).size().reset_index(name='counts')
        #pdata[p] = df

    fig,ax = plt.subplots( len(infor) + 1, figsize=(10,30 ))
    merge_symbol_enhancer = defaultdict( lambda : defaultdict( float) )
    for pi, p in enumerate(infor):
        lst = []
        for enh_num in infor[p]:
            for symbol_num in infor[p][enh_num]:
                if 'SE' in infor[p][enh_num][symbol_num] and 'typical' in infor[p][enh_num][symbol_num]:
                    ratio = infor[p][enh_num][symbol_num]['SE'] / infor[p][enh_num][symbol_num]['typical']
                    lst.append( [ enh_num, symbol_num, ratio ])
                    merge_symbol_enhancer[symbol_num][p] = ratio

        df = pd.DataFrame( lst, columns = ['symbol_num', 'enh_num', 'r'] )
        df.to_csv( p + '.1infor.tab', sep = '\t', header = None)
        #index = df.index.union(df.columns)
        #df2 = df.reindex(index=index, columns=index, fill_value=0)
        df2 = df.pivot( index=['enh_num'], columns=['symbol_num'] ).fillna(0)
        #.rename_axis(columns = None).reset_index()
        outtab = p + '.infor.tab'
        df2.to_csv( outtab, sep = '\t', header = True )
        os.system(''' sed -i '1d' {} '''.format(outtab) )
        os.system(''' sed -i '2d' {} '''.format(outtab) )
        df_heatmap = pd.read_csv( outtab, sep = '\t', header = 0, index_col = 0)
        sns.heatmap( df_heatmap.apply(zscore), cmap = 'magma', robust = True, linewidths = 0, linecolor = None, ax = ax[pi])
        fig.savefig( 'testfdafasdfas2.pdf', dpi=250, transparent = True, facecolor = fig.get_facecolor(), edgecolor='none')
        #os.system(''' heatmap_seaborn.py {}'''.format(outtab) )
        pdata[p] = df
    merge_symbol_enhancer_df = pd.DataFrame( merge_symbol_enhancer ).T
    merge_symbol_enhancer_df.to_csv( 'merge_symbol_enhancer_df.tab', sep = '\t', header = True )
    return pdata

def plot( dfs ):
    fig,ax = plt.subplots( len(dfs) + 1, figsize=(10,30), sharex = True, sharey = True )
    i = 0
    for p in dfs:
        sns.barplot( x = 'symbol_num', y = 'r', data = dfs[p], ax = ax[i] )
        i += 1
    plt.savefig( 'testfdafasdfas.pdf', dpi=250, transparent = True, facecolor = fig.get_facecolor(), edgecolor='none')


        #for symbol, ens in sorted( genes[p].items(), key = lambda x: len(x[1]), reverse = True ):

if __name__ == '__main__':
    df = parse()
    plot(df)



























