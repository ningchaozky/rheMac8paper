#!/usr/bin/env python
import sys
import os
import os.path
import urllib.request, urllib.parse, urllib.error
import re
import argparse
from bs4 import BeautifulSoup as bs
from multiprocessing import Pool, cpu_count
from django.template import Template, Context, loader
from django.conf import settings
settings.configure(DEBUG=True, TEMPLATE_DEBUG=True, TEMPLATE_DIRS=(sys.path[0],'/awg/users/ningch/software/pathway/script/hang_up',))

def file_wash(filename):
    washed = []
    k = 0
    for eachLine in open(filename):
        if eachLine.strip() != '' and not eachLine.startswith('#Term') and len(eachLine.split('\t')) == 13:
            washed.append(eachLine.strip() + '\t' + str(k))
            k = k + 1

    return washed


def updown(file):
    up = {}
    down = {}
    deg_file = open(file).readlines()
    head_line = deg_file.pop(0)
    assert head_line.strip() != ''
    headline_sep = head_line.split()
    for i, e in enumerate(headline_sep):
        if 'log2' in e.lower() and 'fold' in e.lower() and 'change' in e.lower():
            col = i
            break

    for eachLine in deg_file:
        if eachLine.strip() != '':
            temp = eachLine.split()
            if float(temp[col]) < 0:
                down[temp[0].strip()] = temp[col].strip()
            else:
                up[temp[0].strip()] = temp[col].strip()

    return (up, down)


def main_flow(row):
    each = row.strip().split('\t')
    pathway = each[2].strip().lower()
    ko = [ one_ko.strip() for one_ko in each[8].strip().split('|') ]
    ko_last = ko.pop(-1)
    assert ko_last == ''
    gene = [ one_gene.strip() for one_gene in each[7].strip().split('|') ]
    for col in range(7, 12):
        temp = [ each_temp.strip() for each_temp in each[col].split('|') if each_temp.strip() != '' ]
        if list(set(temp)) == [] or list(set(temp)) == ['NA']:
            each[col] = 'NA'
        else:
            each[col] = ' '.join(temp)

    try:
        assert len(ko) == len(gene)
    except:
        print('assert error' + pathway)

    ko_gene = {}
    ko_red = []
    ko_yellow = []
    ko_green = []
    for i, each_ko in enumerate(ko):
        if each_ko != '':
            if each_ko not in ko_gene:
                ko_gene[each_ko] = {}
                ko_gene[each_ko]['up'] = []
                ko_gene[each_ko]['down'] = []
            if gene[i] in up:
                ko_gene[each_ko]['up'].append(gene[i])
            if gene[i] in down:
                ko_gene[each_ko]['down'].append(gene[i])

    API = 'http://www.kegg.jp/kegg-bin/show_pathway?' + pathway
    try:
        content = urllib.request.urlopen(API)
        soup = bs(content)
        map = soup.map
        for each_area in map.find_all('area'):
            ko_set = [ each_ko.strip() for each_ko in re.search('\\?(.*)', each_area['href']).group(1).split('+') ]
            flag_red = 0
            flag_green = 0
            for each_ko in ko_set:
                if each_ko in ko_gene:
                    if ko_gene[each_ko]['up'] != []:
                        flag_red = 1
                    if ko_gene[each_ko]['down'] != []:
                        flag_green = 1

            for each_ko in ko_set:
                if each_ko in ko_gene:
                    if flag_red == 1 and flag_green == 0:
                        ko_red.append(each_ko + '%09,red')
                    if flag_red == 0 and flag_green == 1:
                        ko_green.append(each_ko + '%09,green')
                    if flag_red == 1 and flag_green == 1:
                        ko_yellow.append(each_ko + '%09,yellow')

        API = 'http://www.kegg.jp/kegg-bin/show_pathway?' + pathway + '/'
        if ko_yellow != []:
            API += '/'.join(ko_yellow) + '/'
        if ko_red != []:
            API += '/'.join(ko_red) + '/'
        if ko_green != []:
            API += '/'.join(ko_green) + '/'
    except:
        print(pathway + ' detail map fail...')
        term = ['#', each[0]] + each[3:-2] + [each[-1]]

    try:
        content = urllib.request.urlopen(API)
        soup = bs(content)
        img = soup.find_all('img')
        for each_img in img:
            if each_img.has_attr('name') and each_img['name'] == 'pathwayimage':
                pic_url = 'http://www.kegg.jp' + each_img['src']
                break

        urllib.request.urlretrieve(pic_url, filename='src/%s.png' % pathway)
        map = soup.map
        for each_area in map.find_all('area'):
            ko_set = [ each_ko.strip() for each_ko in re.search('\\?(.*)', each_area['href']).group(1).split('+') ]
            each_area['href'] = 'http://www.kegg.jp' + each_area['href']
            inner_html = '<ul>'
            for each_ko in ko_gene:
                if each_ko in ko_set:
                    inner_html += '<li>%s</li>' % each_ko
                    if ko_gene[each_ko]['up'] != []:
                        inner_html += '<ul><li><font color=\\"red\\">Up regulated genes</font></li><ul><font color=\\"red\\">%s</font></ul></ul>' % ' '.join([ each_gene + '(' + up[each_gene] + ')' for each_gene in ko_gene[each_ko]['up'] ])
                    if ko_gene[each_ko]['down'] != []:
                        inner_html += '<ul><li><font color=\\"green\\">Down regulated genes</font></li><ul><font color=\\"green\\">%s</font></ul></ul>' % ' '.join([ each_gene + '(' + down[each_gene] + ')' for each_gene in ko_gene[each_ko]['down'] ])

            inner_html += '</ul>'
            if inner_html != '<ul></ul>':
                each_area['onmouseover'] = 'javascript: showInfo("' + inner_html + '");'
                del each_area['onmouseout']

        t = loader.get_template('Kegg_map_template.html')
        c = Context({'title': pathway,
         'map_content': str(map.prettify(formatter=None)),
         'image': pathway + '.png'})
        html = t.render(c)
        open('src/' + pathway + '.html', 'w').write(html)
        link = 'src/' + pathway + '.html'
        term = [link, each[0]] + each[3:-2] + [each[-1]]
    except:
        print(pathway + ' detail map fail...')
        term = ['#', each[0]] + each[3:-2] + [each[-1]]

    return term


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='KEGG pathway enrichment web visualization')
    parser.add_argument('--table', required=True, help='standard formated pathway enrichment input file')
    parser.add_argument('--diff', required=True, help='differential expression genes table generated from DEGseq or DEseq')
    argv = vars(parser.parse_args())
    filename = argv['table']
    DEG = argv['diff']
    name = os.path.basename(filename)
    assert not os.system('cp -r %s .' % (sys.path[0] + '/src'))
    if not os.path.exists('src'):
        assert not os.system('mkdir src')
    parallel_result = []
    row_pathway = file_wash(filename)
    up, down = updown(DEG)
    pool = Pool(processes=cpu_count())
    for eachrow in row_pathway:
        parallel_result.append(pool.apply_async(main_flow, (eachrow,)))

    pool.close()
    pool.join()
    result = [ '' for i in range(len(row_pathway)) ]
    for eachone in parallel_result:
        temp = eachone.get()
        result[int(temp[-1])] = temp[0:-1]

    t = loader.get_template('Table_template.html')
    c = Context({'terms': result})
    html = t.render(c)
    open(name + '_rendered_html_detail.html', 'w').write(html)
