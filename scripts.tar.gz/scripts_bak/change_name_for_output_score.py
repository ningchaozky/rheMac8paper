#!/usr/bin/env python
import sys
import os

if len(sys.argv) <= 1:
	print('Usage:',sys.argv[0],'descend_dir')
	exit()


files = os.popen('find . -mindepth 2 -maxdepth 2  -name output_score.txt')
for file in files:
	basename = os.path.basename(os.path.dirname(file))
	os.system('mv %s %s_degseq.txt' % (file.strip('\n'),basename))
	print(basename)
