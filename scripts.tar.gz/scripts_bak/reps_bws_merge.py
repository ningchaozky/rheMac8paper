#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.system as sysKit
import ningchao.nSys.fix as fixKit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( '-reps', nargs='*', help ='reps bws', required = True )
parser.add_argument( '-t', choices = ['max','sum'], help ='bw value deal', default = 'max' )
parser.add_argument( '-o', nargs = '?', help ='output file ', required = True )
parser.add_argument( '-s', action = 'store_true', help ='systeme excute')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
out = args.o
cmd = []
bdg = fixKit.change_suff(args.o,'bdg')
rm = [bdg]
del_chr = fixKit.insert_suff(bdg,'chr',-1)
rm.append(del_chr)
sort = fixKit.insert_suff(del_chr,'sort',-1)
rm.append(sort)
cmd.append('bigWigMerge -%s %s %s' % (args.t, ' '.join(args.reps), bdg))
stdout,stderr,rcode = sysKit.run('bedGraphToBigWig.py %s %s %s' % (bdg,args.o,'rh8'))
cmd.extend(stdout)
for each in cmd:
	each = each.strip()
	if not each:
		continue
	print(each)
	if args.s:
		os.system(each)
for each in rm:
	print('rm %s' % each)
	if args.s:
		os.system(each)









