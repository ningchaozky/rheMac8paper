#!/usr/bin/env python
import os
import sys
import argparse
from ningchao.nSys import parse,ip,env,system,trick
from ningchao.nBio import rheMac

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='transfer the file|files to local machine', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('f', nargs='*', help ='which file|files you want to transfer')
parser.add_argument('-fiterWords', nargs='?', help ='edit:/pnas/liujiang_group/ningch/soft/packages/ningchao/nBio/rheMac.py') 
parser.add_argument('-d', choices =['1','2','3','4'], help ='1:/dataB/ftp/pub/rheMac3/ 2:/home/ningch/data/chip-seq/rheMac/rawdata/', default = '1')
parser.add_argument('-nd', nargs='?', help ='file|files dir default:.', default = '.')
parser.add_argument('-js', nargs='?', help ='delete the // one', default = '/pnas/liujiang_group/ningch/data/chipseq/neuro/rheMac.js')
parser.add_argument('-n', nargs='*', help ='new name or names you want to change for the file. note:if this given, then the same length with file|files')
parser.add_argument('-s', action='store_true', help ='start transfer or not')
parser.add_argument('-rm', action='store_true', help ='remove remote')
parser.add_argument('-depth', type = int, default = 3, help ='depth after depth')
parser.add_argument('-force', action='store_true',help = 'force to over ride the work.js check')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

desPath = '/dataB/ftp/pub/rheMac3/'
ip = ip.local_ip()
js = args.js
now_dir = os.path.abspath(args.nd)
cmd,ftp,short_des_dir,dels = [],[],'',[]
if '24W' in now_dir :
    js = '/pnas/liujiang_group/ningch/data/chipseq/neuro/human.js'
d = parse.parse_ini(js,typ ='json').to_dict()
samples = []
for period in d["period"]:
    for region in d["period"][period]:
        for marker in d["period"][period][region]:
            for rep,name in list(d["period"][period][region][marker].items()):
                if isinstance(name,list):
                    samples.extend(name)
                if isinstance(name,str):
                    samples.append(name)
dirs = {'1':'/dataB/ftp/pub/rheMac3/', '2': '/home/ningch/data/chip-seq/rheMac/rawdata/','3':'','4':''}
Infor = {}
rdir = os.path.abspath(args.f[0])
rdir = iter(rdir.split('/'))
tmp = []
for each in rdir:
    if each == 'rawdata':
        for i in range(args.depth):
            tmp.append(next(rdir))
rdir = '/'.join(tmp)
argsd = dirs[args.d]
if not argsd:
    short_des_dir = rdir
    des_dir = '/'.join([desPath,short_des_dir])
    des_dir = des_dir.replace('//','/').replace('///','/')
else :
    short_des_dir = argsd
    des_dir = '/'.join([argsd,rdir])



for i,fl in enumerate(args.f):
    new_name = ''
    if args.n:
        new_name = args.n[i].replace('/','.')
    else :
        new_name = rheMac.short(os.path.basename(fl))
        if 'merge' in os.path.realpath(fl):
#           new_name = short_des_dir.replace('/','.') + new_name.replace('merge','')
#           new_name = new_name.replace('merge','')
            new_name = rheMac.short(new_name)
        if new_name.startswith('.'):
            new_prefix = rheMac.short(rdir.replace('/','.'))
            new_name = new_prefix + new_name
        
        new_name_arr = new_name.split('.')
        new_name = '.'.join(rheMac.label(new_name_arr))
    start = os.path.join(now_dir,fl)
    end = '/'.join([des_dir,new_name]).rstrip('/').replace('//','/')
    start = start.replace('/./','/')
    end = end.replace('/./','/')
    trick.set2dict(Infor,start,'cmd',[])
    trick.set2dict(Infor,start,'end',end.replace('//','/'))
    trick.set2dict(Infor,start,'rm_remote','ssh ningch@192.168.76.34 rm %s' % end)
    Infor[start]['cmd'].append(system.mkdir('ssh ningch@192.168.76.34 mkdir -p %s' % des_dir))
    if ip == '192.168.118.81' or ip == '192.168.118.82':
        if not system.run('ssh ningch@192.168.76.34 test -d %s' % des_dir):
            Infor[start]['cmd'].append('ssh ningch@192.168.76.34 mkdir -p %s' % des_dir)
        Infor[start]['cmd'].append('scp %s ningch@192.168.76.34:%s' % (start,end))
        ftp_url = end.replace('/dataB/ftp/pub','ftp://192.168.76.34/pub').replace('//','/').replace('ftp:/','ftp://')
        trick.set2dict(Infor,start,'ftp',ftp_url)

print('\n\n')


for each in Infor:
    if args.rm:
        print(Infor[each]['rm_remote'])
        if args.s:
            os.system(Infor[each]['rm_remote'])
        continue
    if len(trick.lst( each.split('/') ).intersect(samples)) == 0 :
        print('echo %s not in the work.js' % each)
        if not args.force:
            continue
#       elif not args.n:
#           continue
    if trick.lst(each.split('/')).intersect(dels) != []:
        print('echo %s delete for # in work.js' % each)
        continue
    if '/rep' in each:
        if not args.n:
            print('echo %s addtional sequence should check by manual ' % each, file=sys.stderr)
    stdout,stderr,stat = system.run('ssh 192.168.76.34 file_stat_v2.py %s' % Infor[each]['end'], wait = 'yes')
    stdout_return = stdout.next().strip()
    if 'not file or dir' in stdout_return or stdout_return == '':
        print('echo 34 %s doenot exists\n' % Infor[each]['end'])
        for cmd in Infor[each]['cmd']:
            print(cmd)
            if args.s:
                system.run(cmd)
    elif Infor[each]['end'] in stdout_return:
        remote_size = stdout_return.split('\t')[1]
        local_size = os.path.getsize(each)
        if local_size != int(remote_size):
            print('echo %s 81|83 : %s' % (each,local_size))
            print('echo %s 34: %s' % (Infor[each]['end'],remote_size))
            for cmd in Infor[each]['cmd']:
                print(cmd)
                if args.s:
                    system.run(cmd)
        else :
            print('echo %s eq %s' % (each,end))
    else :
        print('ssh 192.168.76.34 file_stat_v2.py %s' % Infor[each]['end'])
    print('echo ' + Infor[each]['ftp'])
    print('\n\n')









