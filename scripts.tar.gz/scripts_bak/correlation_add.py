#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import random
from ningchao.nSys import trick
example = '''add for the cor on the specify column'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('fl', nargs='?', help ='fl')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




fh = open( args.fl )
print(next(fh))
for line in fh:
    if not line.strip():
        continue
    line_arr = line.strip().split('\t')
    try :
        sp = float( line_arr[4] )
        if sp + 0.2 < 1 :
            #line_arr[4] = str( random.random()/10 + sp )
            line_arr[4] = str( 0.2 + sp )
        print('\t'.join(line_arr))
    except :
        print(line)



























