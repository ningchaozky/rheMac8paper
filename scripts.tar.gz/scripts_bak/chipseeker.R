#!/usr/bin/env Rscript
#first
alen <- commandArgs()
library(argparser)
p <- arg_parser('script description')
p <- add_argument(p, "--bed",short = '-b', help="number of significant digits to print")
p <- add_argument(p, "--pd", short = '-pd', help="promoter define, up,down", default = "3000,3000")
p <- add_argument(p, "--prefix",short = '-p',help="output file", default="output.txt")
if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))
fl <- args$bed
pdvct <- as.numeric(unlist(strsplit(args$pd,',')))
upstream <- pdvct[1]
downstream <-  pdvct[2]
prefix <- args$prefix

library(ChIPseeker)
library(TxDb.rh8.knownGene)
txdb <- TxDb.rh8.knownGene
promoter <- getPromoters(TxDb=txdb, upstream=upstream, downstream=downstream)
tagMatrix <- getTagMatrix(readPeakFile(fl), windows=promoter)
peak <- readPeakFile(fl)
pdf(paste( prefix, ".pie.pdf", sep=""))
peakAnno <-annotatePeak(fl, tssRegion=c(-500, 500), TxDb=txdb)
#tagHeatmap(tagMatrix, xlim=c(-3000, 3000), color="red")
plotAnnoPie(peakAnno)
dev.off()
pdf(paste( prefix, ".vennpie1.pdf", sep=""))
vennpie(peakAnno)
dev.off()
pdf(paste( prefix, ".uupsetpolt2.pdf", sep=""))
upsetplot(peakAnno)
dev.off()
pdf(paste( prefix, ".vennpiewithuupset2.pdf", sep=""))
upsetplot(peakAnno,vennpie=TRUE )
dev.off()
