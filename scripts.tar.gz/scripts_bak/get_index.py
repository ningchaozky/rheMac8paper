#!/usr/bin/env python
import os
import sys
import gzip
import argparse
import ningchao.nSys.env as envKit
import ningchao.nSys.trick as trKit
import ningchao.nSys.file as fileKit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('-f', nargs = '*', help ='file|files for index find | all for list index')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

dit = {1:'ATCACG',2:'CGATGT',3:'TTAGGC',4:'TGACCA',5:'ACAGTG',6:'GCCAAT',
7:'CAGATC',8:'ACTTGA',9:'GATCAG',10:'TAGCTT',11:'GGCTAC',12:'CTTGTA'}

if args.f != ['all']:
	for each in args.f:
		handle = fileKit.check(each).nOpen()
		index = handle.next().split(' ')[1].replace('1:N:0:','')
		index = index.replace('2:N:0:','').strip()
		print('raw\tindex\treal')
		for each in dit:
			if index.replace('N','') in dit[each]:
				print('\t'.join([index,str(each),dit[each]]))
elif args.f == ['all']:
	for each in [(k,dit[k]) for k in sorted(dit.keys())]:
		print('\t'.join([str(i) for i in each]))
	print(sorted(list(dit.items()), lambda x, y: cmp(x[0], y[0]), reverse=False))




