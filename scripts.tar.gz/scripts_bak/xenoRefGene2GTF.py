#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick
from collections import defaultdict

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('xenoRefSeqGene', nargs = '?', help = 'xenoRefSeqGene txt file')
parser.add_argument('-source', nargs = '?', help = 'source for the gene. default xeon', default = 'xeon')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parameter_parse( p ):
    return '{}.sql'.format( p ), '{}.txt'.format( p )

def gtitle( sql ):
    out = []
    gfh = open( sql )
    for line in gfh:
        obj = re.match(r'^\s+`(\w+)`', line)
        if obj:
            out.append( obj.group(1) )
    sys.stderr.write( str( out ) +'\n')
    return out

def zero( string ):
    if not int( string ):
        return 1
    else :
        return string


def main( title, txt):
    fh = open( txt )
    transcripts = defaultdict( int )
    for line in fh:
        if '[(' in line or 'chrUn' in line:
            continue
        line_arr = line.rstrip().split('\t')
        line_infor = dict( zip( title, line_arr ) )
        transcripts [ line_infor['name2'] ] += 1
        gene_id, strand, chrom = line_infor['name'], line_infor['strand'], line_infor['chrom']
        if 'NM_' in gene_id:
            gene_biotype = 'coding'
        else :
            gene_biotype = 'noncoding'
        tStarts, blockSizes = line_infor['exonStarts'].strip(',').split(','), line_infor['exonEnds'].strip(',').split(',')
        Symbol = line_infor['name2']
        print ( chrom, args.source, 'gene', zero( line_infor['txStart']), zero( line_infor['txEnd']), '.', strand, '.', '''gene_id "{}", gene_name "{}", gene_biotype "{}"'''.format( gene_id, Symbol, gene_biotype), sep = '\t')
        for start, end in zip( tStarts, blockSizes):
            print ( chrom, args.source, 'exon', zero( start ), zero( end), '.', strand, '.', '''gene_id "{}"; gene_name "{}"; gene_biotype "{}"; transcript_id  "{}_t{}"'''.format( gene_id, Symbol, gene_biotype, Symbol, transcripts [ line_infor['name2'] ]), sep = '\t')


if __name__ == '__main__':
    sql, txt = parameter_parse( args.xenoRefSeqGene )
    title = gtitle( sql )
    main( title, txt )


























