#!/usr/bin/env python
import os
import sys
import ningchao.usage as u
import ningchao.nBio.chromosome as c
import ningchao.nSys.fix as f
import ningchao.nSys.soft as s


u.usage('file:bedGraph file:bigWig str:hg19|mm10|rh3|rh8')
sizeFile = ''
if sys.argv[3] == 'hg19':
    sizeFile = c.chr('hg19').abspth
if sys.argv[3] == 'mm10':
    sizeFile = c.chr('mm10').abspth
if sys.argv[3] == 'rh3':
    sizeFile = c.chr('rh3').abspth
if sys.argv[3] == 'rh8':
    sizeFile = c.chr('rh8').abspth
bedGraphToBigWig = 'bedGraphToBigWig'
bdg, sp, bw = sys.argv[1], sys.argv[3], sys.argv[2]
chrbdg = f.insert_suff(sys.argv[1],'chr',-1)
bdg_clip = f.insert_suff( chrbdg, 'clip', -1 )
sort_out = f.insert_suff(f.insert_suff( bdg_clip, 'chr',-1),'sort',-1)

cmd = 'clean_no_chr_line.py %s %s' % ( bdg, sp)
print(cmd)
cmd = 'bedClip %s %s %s' % ( chrbdg, sizeFile, bdg_clip )
print(cmd)
cmd = 'sort -k1,1 -k2,2n %s > %s' % ( bdg_clip, sort_out )
print(cmd)
cmd = '%s %s %s %s' % ( bedGraphToBigWig, sort_out, sizeFile, bw)
print(cmd)
cmd = 'rm %s' % ' '.join([bdg, chrbdg, sort_out])
print(cmd)







