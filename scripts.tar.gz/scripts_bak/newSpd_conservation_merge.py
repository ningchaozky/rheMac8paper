#!/usr/bin/env python3
import os
import sys
import gzip
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.barplot( palette="Set3" )
sns.set_style("ticks")
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import pandas as pd
from io import StringIO
from collections import defaultdict
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'Dir', nargs = '?', help = 'dir for find files')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def check( group_labels, group_boundaries):
    pair = dict(zip( group_labels,  zip(group_boundaries[0:-1], group_boundaries[1:])))
    pair = { range(*v): i for i,v in pair.items() }
    return pair
if __name__ == '__main__':
    fls, infor, lst = system.dir( args.Dir ).fls('gz$'), defaultdict( list ), []
    for fl in fls:
        with gzip.open( fl ) as f :
            header = next(f).decode()
            header_json = json.load( StringIO(header.replace('@','')) )
            group_labels, group_boundaries = header_json['group_labels'], header_json['group_boundaries']
            typ = check( group_labels, group_boundaries )
            if len( group_labels ) != 3 :
                continue
            bs = header_json['bin size'][0]
            up, down, body = header_json["upstream"][0]//bs, header_json['downstream'][0]//bs, header_json['body'][0]//bs
            sample_bins = range( up, up + body )
            for j,line in enumerate( f ):
                line_arr = line.decode().strip().split('\t')
                signals = [ float(i) for i in line_arr[6:] ]
                for key in typ:
                    try :
                        if j in key:
                            label = typ[key]
                            label = trick.string.replace( label, {'_new.bed.':'_'} )
                            peirod, beforePeirod, newOrStable = label.replace('.bed','').split('_')
                            break
                    except :
                        print (j, key)
                        exit()
                #print ( peirod, beforePeirod, newOrStable )
                signals = [ signals[i] for i in sample_bins ]
                for signal in signals:
                    lst.append([ peirod, newOrStable, signal])
    df = pd.DataFrame( lst, columns = [ 'peirod', 'newOrStable', 'signal'] )
    df1 = df[df.newOrStable == 'shuffle']
    df2 = df[df.newOrStable == 'new']
    df3 = df[df.newOrStable == 'stable']
    df = pd.concat( [ df1, df2, df3] )
    dfs = []
    for peirod in system.dir.sort( set(list(df.peirod)), up = '', down = ''  ):
        dfs.append( df[df.peirod == peirod] )
    dfs.pop(-1)
    df = pd.concat( dfs )
    fig, ax = plt.subplots( 1, figsize=(10,15), sharex=True, sharey=True, subplot_kw=dict(projection = None))
    sns.boxplot( x = 'peirod', y = 'signal', hue = 'newOrStable', data = df, showfliers = False, ax = ax)
    plt.savefig( 'cons.pdf', dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none' )









































