#!/usr/bin/env python
import sys


if len(sys.argv) <= 1:
	print('Usage: ',sys.argv[0],'fpkm','matrix')
	exit()

if len(sys.argv) == 3:
	fpkm = float(sys.argv[1])
else:
	fpkm = 1

xls = open(sys.argv[-1])


print(next(xls), end=' ')


for line in xls:
	tmp = line.split('\t')
	name = tmp[0]
	nums = tmp[1:]
	all = 0
	for num in nums:
		if float(num) >= fpkm:
			all = 1
	if all ==1:
		print(line, end=' ')
	all = 0
