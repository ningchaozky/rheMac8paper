#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
plt.tight_layout()
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tabs', nargs='+', help = 'gene enhancer number tab')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def parse():
    genes, enhancers = defaultdict( lambda : defaultdict( set ) ), defaultdict( lambda : defaultdict( set ) )
    for tab in args.tabs:
        with open( tab ) as f:
            print ( f.readline() )
            for line in f:
                line_arr = line.rstrip().split('\t')
                key = '\t'.join( line_arr[:3] )
                symbol = line_arr[3].split('.')[0].upper()
                genes[ tab ][ symbol ].add( key )
                enhancers[ tab ][ key ].add( symbol )
    for tab in args.tabs:
        for symbol, ens in sorted( enhancers[tab].items(), key = lambda x: len(x[1]), reverse = True ):
            print ( symbol, len(ens) )



if __name__ == '__main__':
    parse()




























