#!/usr/bin/env Rscript
alen <- commandArgs()
library( argparser )
p <- arg_parser('script description')
p <- add_argument(p, "work_dir", help= "dir for find files")
p <- add_argument(p, "--output_dir", help= "output for the dir", default = '../../../Norm_matrix/ICE/40k/')
p <- add_argument(p, "--pattern", short = '-p',help= "pattern for file files", default = 'HTC')
p <- add_argument(p, "--name", short = '-n',help= "prefix for the output")
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args( p, argv = commandArgs(trailingOnly = TRUE) )


suppressMessages( library("HiTC") )
dir <- args$work_dir
files <- list.files( dir, pattern = args$pattern, full.names=TRUE)
print(files)
lst <- sapply( files, import.my5C )
hic<- HTClist(lst)
hic<- hic[isIntraChrom(hic)]
hiC_iced <- HTClist(lapply(hic,normICE,max_iter=1500))
hiC_iced<- HTClist(lapply(hiC_iced,forceSymmetric))
c<-seqlevels(hiC_iced)


for( m in c){
    outfile = paste( args$output_dir, paste(args$name, m, "ICE_matrix.rout", sep="."), sep = "/")   
    #n<-paste(m,m,sep=""); export.my5C(hiC_iced[[n]], file= paste( dir, args$name, m, ".ICE_matrix.rout", sep=""), genome="rheMac8")
    n<-paste(m,m,sep=""); export.my5C(hiC_iced[[n]], file = outfile)

}




























