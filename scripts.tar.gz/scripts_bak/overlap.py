#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'm1', nargs='?', help = 'm1')
parser.add_argument( 'm2', nargs='?', help = 'm2')
parser.add_argument( '-i', nargs='?', help = 'ignore case')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()





























