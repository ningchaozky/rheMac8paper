#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, color

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use('ggplot')


example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bed', nargs = '?', help = 'merge the neighbors chromHMM_multi_bed_split output file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()








if __name__ == '__main__':
    with open( args.bed ) as f:
        next(f)
        dit = defaultdict( list )
        infor, infor_marker, whole = defaultdict( int ), defaultdict( str ), 0
        for line in f:
            line_arr = line.replace('None','0').strip().split('\t')
            name = line_arr[3].split('.')
            stat = name[1]
            marker = '.'.join(name[1:]).strip('.')
            length = int( line_arr[2] ) - int( line_arr[1] )
            infor[ stat ] += length
            infor_marker[stat] = marker
        for stat, length in sorted ( infor.items(), key = lambda x: int(x[0]), reverse = False):
            whole += length
            dit['stat'].append( stat )
            dit['percent'].append( length / 2725521370)
            print ( stat, infor_marker[stat], length)
        #print ( whole, file = sys.stdout)
        df = pd.DataFrame( dit )
        df = df[ ( df['percent'] > 0.001 ) & ( df['percent'] < 0.5) ]
        df.plot.bar(x='stat', y='percent', rot=0)
        plt.xticks(rotation=45)
        font = {'family' : 'normal',
            'weight' : 'bold',
            'size'   : 2}
        matplotlib.rc('font', **font)
        plt.savefig( 'test.pdf', dpi=250)




















