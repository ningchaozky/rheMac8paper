#!/usr/bin/env python
import sys
import os

def help():
	print('#Usage:',sys.argv[0],'fasta','identity','minlength','maxlength','selfRelatPID','blast_num_threads')
	exit()

db={'ncbi':'/data/Database/nr/nr','kb':'/Storage/data002/ningch/data/uniprot/uniprot_sprot.fasta','ref50':'/Storage/data002/ningch/data/uniprot/UniRef50.fasta'}
if len(sys.argv) <= 1:
	help()

if len(sys.argv) == 7:
	pid = sys.argv[2]
else:
	pid = 90

file = sys.argv[1]
name = os.path.splitext(file)[0]
print(('cp %s %s_tmp.fa' % (file,name)))

for i in range(6,0,-1):
	print('#This is %s times' % i)
	print(('trans_longest_orf.pl %s_tmp.fa %s_tmp_cds.fa %s_tmp_prot.fa %s 240' % (name,name,name,i)))
	print(('cap3 %s_tmp_cds.fa -p %s' % (name,pid)))
	print(('cat %s_tmp_cds.fa.cap.contigs %s_tmp_cds.fa.cap.singlets | getSuffix.pl - > %s_tmp_cds.fa' % (name,name,name)))
	print(('cap3 %s_tmp_cds.fa -p %s' % (name,pid)))
	print(('cat %s_tmp_cds.fa.cap.contigs %s_tmp_cds.fa.cap.singlets | getSuffix.pl - > %s_tmp_cds.fa' % (name,name,name)))
	print(('cap3 %s_tmp_cds.fa -p %s' % (name,pid)))
	print(('cat %s_tmp_cds.fa.cap.contigs %s_tmp_cds.fa.cap.singlets | getSuffix.pl - > %s_tmp_cds.fa' % (name,name,name)))

print(("mv %s_tmp_cds.fa %s_cap3.fa" % (name,name)))
result = os.popen('manul_del_seq.pl %s_cap3.fa %s %s %s %s' % (name,sys.argv[3],sys.argv[4],sys.argv[2],sys.argv[5]))
for line in result:
	print(line, end=' ')

files = os.listdir(os.getcwd())
for file in files:
	if file.endswith('_sef_len_deleted_prot.fa'):
		for key in db:
			print('#blastp -query %s -db %s -evalue 1e-3 -max_target_seqs 5 -num_threads %s -out %s2%s -outfmt \'6 qlen slen qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore\'' % (file,db[key],int(sys.argv[6]),file,key))
			print('#acc2title.pl %s %s2%s %s2%s_title' % (key,file,key,file,key))
