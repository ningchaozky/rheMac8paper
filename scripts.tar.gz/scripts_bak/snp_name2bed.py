#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('input', nargs='?', help ='name for the snp')
parser.add_argument('-old', nargs='?', help ='old snp infor', default = '/home/ningch/data/genome/Homo_sapiens/neuron/SNPs.rs.bed')
parser.add_argument('-c', nargs='?', help ='common_snp_infor', default = '/home/ningch/data/genome/Homo_sapiens/common_all_20180418.vcf')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
oldfh = open(args.old)
cfh = open(args.c)
old = {}
common = {}
def nor(line):
    if '[' in line:
        line = line.strip('[').strip(']').strip()
        line = line.strip('\'').strip('\'')
        line = line.replace('''\\t''','\t')
        line = line.replace('''\\t''','\t')
        line = line.replace('\']','')
        line = line + '\t' + ':'.join(line.split('\t'))
    return line
for line in oldfh:
    line = nor(line)
    line_arr = line.strip().split('\t')
    trick.set1dict(old, line_arr[3], line )
oldfh.close()

for line in cfh:
    if line.startswith('#'):
        continue
    line_arr = line.strip().split('\t')
    val = line_arr[0:3]
    val.insert(2, str(int(line_arr[1]) + 1))
    val = 'chr'+'\t'.join(val)
    trick.set1dict(common, line_arr[2], val)
    
ifh = open(args.input)
for line in ifh:
    name = line.strip().split('\t')[0]
    if name in old:
        sys.stderr.write('#' + name +': in the old\n')
        print(old[name].strip())
    elif name in common :
        print(common[name].strip())
    else :
        sys.stderr.write('#' +  name +':not in old and common\n')




















