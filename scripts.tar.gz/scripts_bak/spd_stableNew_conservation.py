#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, parse
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'spdIni', nargs = '?', help = 'ini for spd')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




if __name__ == '__main__':
    bed = parse.ini( args.spdIni ).to_dict(fpattern = 'merge|mES|GV')
    cmd = 'cat {} | bedtools sort -i -| bedtools merge -i -'.format(' '.join(bed.values()))
    print ( cmd )

























