#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
from collections import defaultdict
desc = ''' boundary_find_tad_bed.py chr1.E50.tad chr1.E90.tad -diff E50.E90.chr1.res  '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tads', nargs = '+', help = 'tads')
parser.add_argument( '-diff', nargs = '?', help = '')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def parse_tad():
    infor = defaultdict( lambda : defaultdict ( list ) )
    for tad in args.tads:
        with open( tad ) as f :
            tad_header = next(f).rstrip().split('\t')
            kwargs.update({'tad_header': tad_header })
            for line in f :
                line_arr = line.rstrip().split('\t')
                infor[line_arr[2]][tad].append( line_arr )
    kwargs.update({ 'infor': infor } )
    return infor

def check_tad_file():
    infor = kwargs.get('infor')
    tad_num = defaultdict( int )
    with open( args.diff ) as f :
        for line in f :
            if 'Non-Differential' in line :
                continue
            line_arr = line.rstrip().split('\t')
            if line_arr[0] in infor :
                for each in infor[line_arr[0]]:
                    for j in infor[line_arr[0]][each]:
                        tad_num[each] += 1
    tad_num_sorted = sorted( tad_num.items(), key = lambda x: x[1])
    return tad_num_sorted[-1][0]

def diff_output():
    infor = kwargs.get('infor')
    max_tab_match_file = check_tad_file()
    with open( args.diff ) as f :
        header = next(f).rstrip().split('\t')
        print ( *kwargs.get('tad_header'), *header, sep = '\t')
        for line in f :
            if 'Non-Differential' in line :
                continue
            line_arr = line.rstrip().split('\t')
            if line_arr[0] in infor :
                for f in infor[line_arr[0]]:
                    for each in infor[line_arr[0]][f]:
                        print ( *each, *line_arr, f, sep = '\t')

def main():
    infor = parse_tad()
    diff_output()

if __name__ == '__main__':
    kwargs = vars( args )
    main()




























