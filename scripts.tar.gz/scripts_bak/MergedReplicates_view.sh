#!/usr/bin/env sh
if [ $# -lt 1 ]; then
	echo $0 'MergedReplicates.bed'
	exit
fi




sed -i '1d' $1
grep -v MT $1 > $1.tmp ; mv $1.tmp $1
