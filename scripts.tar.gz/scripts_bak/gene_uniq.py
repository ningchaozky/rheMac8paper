#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,system
from ningchao.nBio import entrez

example = ''' gene file from exon uniq'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('gene', nargs = '+', help = 'gene for uniq')
parser.add_argument('-coding', choices = [ 'coding', 'nocoding', 'all'], help = 'default all', default = 'all' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    gene = args.gene
    col = len( gene ) >= 2 and int( gene[1] ) - 1 or 0
    std, err, rc = system.run( 'sort -k1,1 -k2,2n %s' % gene[0] )
    alias = entrez.hgnc( ).gene2alias( coding = args.coding )
    alias = trick.dit( alias ).rev(valType='list')
    sys.stderr.write('Length is %s' % str(len(alias)) + '\n') 
    return std, alias, col

def rename( line_arr, col, sstr):
    lstr = line_arr[col].split('.')
    lstr[0] = sstr
    line_arr[col] = '.'.join((lstr[0], lstr[-1]))
    return '\t'.join( line_arr )

if __name__ == '__main__':
    gene, alias, col = parse( args )
    infor, uniq_gene = {}, []
    for line in gene:
        line_arr = line.strip().split('\t')
        name = line_arr[col].split('.')[0].upper()
        trick.dinit( infor, name, 0 )
        infor[name] += 1        
        if infor[name] == 1 and name in alias:
            if alias[name] not in uniq_gene:
                uniq_gene.append( alias[name] )
            else :
                continue
            print(rename( line_arr, col, alias[name] ))






