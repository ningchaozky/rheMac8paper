#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='cat excl together by coloum')
parser.add_argument('-xls', nargs='*', help ='key words for include in file name ie:1(key),xls,1,2,3 1(key),xls2,1,2,3 ...')
parser.add_argument('-t', nargs='*', help ='title for new xls. ie:xls,t1,t2,t3 xls2,t1,t2,t3 ...')
parser.add_argument('-o', nargs='?', help ='output file')
parser.add_argument('-s', nargs='?', help ='seperator default \\t', default = '\t')
parser.add_argument('-null', nargs='?', help ='float: null exp value', default = 12345)
parser.add_argument('-H', action='store_true', help ='header or not?')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
if len(sys.argv) <= 1:
	help()


title = ['key']
sep = args.s
ofh = open(args.o,'w')

title_arr = args.t
ext_infor,out_keys = {},[]
for j,xls in enumerate(args.xls):
	xls_arr = xls.split(',')
	key_col = int(xls_arr.pop(0)) - 1
	xls = xls_arr.pop(0)
	cols = [int(i) - 1 for i in xls_arr]
	trickTookit.set2dict(ext_infor,xls,'key',key_col)
	trickTookit.set2dict(ext_infor,xls,'cols',cols)
	if args.t :
		trickTookit.set2dict(ext_infor,xls,'newTitle',title_arr[j].split(','))

ext = {}
for xls in ext_infor:
	print('#!! reading data %s' % xls)
	if not os.path.exists(xls):
		sys.stderr.write('#!!!! do\'n exists: %s' % xls + '\n')
		continue
	xlsfh = open(xls)
	if args.H:
		old_header = xlsfh.next().strip().split('\t')
		if not args.t:
			title.extend(trickTookit.getList(old_header,ext_infor[xls]['cols']))
	for line in xlsfh:
		line_arr = line.strip().split(sep)
		imp_key = trickTookit.getList(line_arr,ext_infor[xls]['key'])
		val_line_arr = trickTookit.getList(line_arr,ext_infor[xls]['cols'])
		trickTookit.set2dict(ext,xls,imp_key,val_line_arr)
		trickTookit.set2dict(ext,xls,'len',len(val_line_arr))
		out_keys.append(imp_key)

out_keys = set(out_keys)
for key in out_keys:
	line = [key]
	for xls in ext:
		if args.t:
			xls_title = ext_infor[xls]['newTitle']
			if not trickTookit.sublist(xls_title,title):
				title.extend(xls_title)
		if key in ext[xls]:
			line.extend(ext[xls][key])
		else :
			line.extend([null] * ext[xls]['len'])
		line = [str(i) for i in line]
	ofh.write('\t'.join(line) + '\n')
ofh.close()
trickTookit.header(args.o,title)










