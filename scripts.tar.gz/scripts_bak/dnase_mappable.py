#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('genome', nargs='?', help ='genome')
parser.add_argument('-len', nargs='?', help = 'reads length', default = 36, type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def dfa(string):
    return string.replace('.fa','')

cmds = []
g, l = args.genome, args.len
cmd = 'bowtie-build %s %s' % ( g, g)

cmds.append ( cmd )
fls = list ( system.dir( '.' ).fls('chr.*fa$') )
chrom_results = [ ]
for fl in fls:
    chrom = fl.replace('.fa','')
    cs = '%s.%s.K%s.mappable_only.bed' % ( chrom, dfa( g ), l )
    cmd = 'enumerateUniquelyMappableSpace.pl %s %s %s | bedops -m - > %s' % ( l, g, fl , cs)
    chrom_results.append( cs )
    cmds.append ('cd %s' % os.getcwd())
    cmds.append ( cmd + '\n\n\n')

cmd = 'bedops --ec -u %s > %s.K%s.mappable_only.bed' % (' '.join( chrom_results ), g, l)
cmds.append( cmd )

for cmd in cmds:
    print ( cmd )



























