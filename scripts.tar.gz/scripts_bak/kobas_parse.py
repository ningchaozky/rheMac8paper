#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('go', nargs='?', help = 'kobas output file')
parser.add_argument('-t', choices= [ 'pathway','go','all'] , help = 'kobas output file', default = 'all' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fh, typ = open( args.go ), args.t



def check( typ, line ):
    if typ == 'go' and 'GO:' in line :
        return True
    elif typ == 'pathway' and 'GO:' not in line:
        return True 
    elif typ == 'all' :
        return True 
    else :
        return False 

for line in fh:
    line_arr = line.strip().split('\t')
    if '|' in line:
        if check( typ, line ):
            print(trick.lst( line_arr[0:-2] ).join())































