#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import json
import argparse
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s jsonFile' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('json', nargs='?', help ='josn file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
jfh = open(args.json)
string = ''
next(jfh)

def convert(input):
        if isinstance(input, dict):
                return {convert(key): convert(value) for key, value in input.items()}
        elif isinstance(input, list):
                return [convert(element) for element in input]
        elif isinstance(input, str):
                return input.encode('ascii')
        else:
                return input

for line in jfh:
    string += line
    if line.startswith(']'):
        exit()
    if line.startswith('  }') and string.strip():
        dit = json.loads(string.strip(','), object_hook=convert)
        v1 = dit['AllelicEpigenome-Variant']['properties']['Subject']
        print(dit)
        string = ''























