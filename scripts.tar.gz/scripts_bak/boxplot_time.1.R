#!/usr/bin/env Rscript
library("optparse")
option_list = list(
	make_option(c("-f", "--file"), type="character", default=NULL, 
              help="输入文件名[default= %default]", metavar="character")
	)

opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)
library(xlsx)
library(ggplot2)
library(reshape2)
dat<-read.table(opt$file, sep = '\t', header = 1, stringsAsFactors=FALSE)
num <- dat[1,]
dat <- dat[-1,]
data <- list()
for (each in colnames(dat)){
	string <- as.matrix(dat[each])
	time <- as.POSIXct(string, format="%H:%M:%S")
	background <- time[1]
	case <- time[-1]
	print(background)
	lst <- list(as.double(difftime(case, background, units='mins')))
	names(lst) <- each
	data <- c(data, lst)
}
df <- as.data.frame(data)
df <- (na.omit(melt(df)))
namelst <- strsplit(as.character(df$variable), "_")
df$genetype <- (unlist((lapply((lapply(namelst, `[`, c(1,2))), function(x) paste(x, collapse="_")))) )
df$type <- (unlist((lapply((lapply(namelst, `[`, 3)), function(x) paste(x, collapse="_")))) )
df$each <- (unlist((lapply((lapply(namelst, `[`, c(1,2,3))), function(x) paste(x, collapse="_")))) )
pdf(paste(opt$file,'.pdf',collapse = '',sep = ''))
p <- ggplot(df, aes(x=each, y=value, colour = each)) 
#p <- p + geom_boxplot( aes(x=genetype, y=value, fill = type), position=position_dodge(0.8)) + theme_bw() + scale_fill_grey(start = 1, end = 1)
p <- p + stat_boxplot(geom ='errorbar', color = 'black', width=0.25)
#p <- p + geom_jitter( aes(x=each, y=value), binaxis='y', stackdir='center', stackratio=0.5, dotsize=0.2) 
p <- p + geom_boxplot(outlier.shape=NA, color="black", fill="gray") + theme_bw() + scale_fill_grey(start = 1, end = 1) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
p <- p + geom_jitter(position=position_jitter(width=.35, height=0))
#p <- p + geom_violin(trim = FALSE)
print(p) 
dev.off()
