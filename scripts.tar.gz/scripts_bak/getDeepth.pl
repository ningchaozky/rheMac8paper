#!/usr/bin/perl 
use warnings;
use strict;

=head
---------------------------------------------------------------------
Author: Ning Chao <ningchao@ioz.ac.cn>
---------------------------------------------------------------------
=cut

#@ARGV;
my $fp = $ARGV[0];
#print "$fp\n";
my $length;
my $count=0;
open FQ,"< $fp" || die "Can not open $fp\n";
while (1) {
	last if (eof(FQ));
my @fq;

		for (0..3) {
		$fq[$_] = <FQ>;
}
		chomp $fq[1];
		$length += length $fq[1];
		$count++;
}
my $deepth = ($length*2)/1024**3;
print "The deepth of your file is $deepth\n";
print "The reads number is $count\n";

close FQ;
