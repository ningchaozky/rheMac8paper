#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
import pandas as pd
from ningchao.nSys import trick, fix
from ningchao.nBio import rheMac
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help ='plotCorrelation -in gene.npz --whatToPlot scatterplot --corMethod spearman -o gene.png --removeOutliers --plotNumbers  --outFileCorMatrix gene.cor, gene.cor')
parser.add_argument('-p', nargs='?', help ='peirod compare with other stage. default E50', default = 'E50' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def name( string ):
    return string.replace( '.ppois.bw.qn.tmp.bw', '').replace('all.','').replace('.PFC','').replace('\'','')
peirods = rheMac.rheMac().peirods()
#peirods.append('liver')
fh, lines = open( args.mat ), []
for line in fh:
    if '#' in line :
        continue
    lines.append( line )
header = lines.pop(0)
trick.write ( header, peirods, sys.stderr)
header = [ name(i) for i in header.strip().split('\t') ]
header.insert(0,'name')
trick.write( header )
lst = [[] for i in peirods]
for line in lines:
    if '#' in line:
        continue
    line_arr = line.strip().split('\t')
    line_arr[1:] = [ float(i) for i in line_arr[1:]]
    if args.p in line:
        dit = dict(zip(header[1:], line_arr[1:]))
        for i, peirod in enumerate(peirods):
            keys = trick.lst( header ).get( peirod, regular = True )
            lst[i].extend( trick.dit(dit).get( keys ))
dit = dict(zip( peirods, lst ))
df = pd.DataFrame( dit )
#df.set_columns( peirods )
#df.header = header[1:]
df.to_csv(fix.fix(args.mat).append('cor.box'), sep = '\t', index = True)





























