#!/usr/bin/env Rscript
#first
alen <- commandArgs()
library(dplyr)
library(argparser)
library(reshape2)
library("EnhancedVolcano")
suppressMessages(library(DESeq2))
#library( vst )
p <- arg_parser('degseq2_raw.R -i PFC.CTCF.bed.raw  -in 1,2,3 -g X45Y.PFC.CTCF.rep2.0,X45Y.PFC.CTCF.rep1.0~E120.PFC.CTCF.rep2.0,E120.PFC.CTCF.rep1.0 -n 45Y~E120 -o PFC.CTCF.45vs120.tab')
p <- add_argument( p, 'input', help="input tab separtor file")
p <- add_argument( p, '-field', short = '-f', help="index col for input file")
p <- add_argument( p, '-group', short = '-g', help="1,2,3~4,5,6. colunms names compare" )
p <- add_argument( p, '-name', short = '-n', help="name1~name1." )
p <- add_argument( p, '-type', short = '-t', help="sequence type", default = 'paired-end')
p <- add_argument( p, '-pvalue', short = '-p', help="pvalue. 0.05", default = 0.05)
p <- add_argument( p, '-foldchange', short = '-c', help="fold change. 1.5", default = 1.5)
p <- add_argument( p, '-output', short = '-o', help="output file for diff" )
p <- add_argument( p, '-notSameBatch', short = '-b', help="not same batch will remove the batch effect", flag=TRUE )
if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}

argv <- parse_args(p)


cts <- read.table(argv$input,sep="\t", header = 1, check.names=FALSE )

if ( is.na(argv$group) | is.na(argv$name) ){
	print(names(cts))
	stop('please input group like: 45Y.PFC.CTCF.rep2.0,45Y.PFC.CTCF.rep1.0~E120.PFC.CTCF.rep2.0,E120.PFC.CTCF.rep1.0')
}

if (is.na(argv$name)){
	stop('please input name for your compare')
}


#cat(argv$group)
pvalue <- as.numeric(argv$pvalue)
fc <- as.numeric( argv$foldchange)
group <- unlist(strsplit(argv$group,'~'))
subcol <- strsplit(group,',')
names(subcol) <- unlist(strsplit(argv$name,'~'))
index_col <- as.numeric(unlist(strsplit(argv$field,',')))
if (length(index_col) > 1 ){
	paste_args <- c(cts[, index_col], sep = "\t")
	rownames(cts) <- do.call(paste, paste_args)
}else {
	rownames(cts) <- cts[, index_col]
}

cts_sub <- cts[, unlist(subcol)]
#cts_sub <- lapply(cts_sub,as.integer)
colData <- as.data.frame(unlist(subcol))
colData$condition <- substr(rownames(colData),1, nchar(rownames(colData))-1)
colData$type <- argv$type
rownames(colData) <- unlist(subcol)
colData <- colData[,-1]

if ( argv$notSameBatch ){
    colData$batch <- colData$condition
}else {
    colData$batch <- 'A'
}

colData <- colData %>% mutate(across(where( is.character ), factor))
print (colData)
dds <- DESeqDataSetFromMatrix(countData = cts_sub,
                              colData = colData,
                              design = ~ condition )
                              #design = ~ condition + batch)
dds <- DESeq(dds)
vsd <- vst(dds, blind=FALSE)
mat <- assay(vsd)
mat <- limma::removeBatchEffect(mat, vsd$Batch)
assay(vsd) <- mat
counts_batch_corrected <- assay(vsd)
#print ( counts_batch_corrected )
#resultsNames(dds)
pdf( file=paste(argv$out,'.pdf',sep =''), width = 8, height = 8 )
res <- results(dds, alpha=pvalue)
resLFC <- lfcShrink(dds, coef = resultsNames(dds)[2], type="apeglm", lfcThreshold = fc )
foldchange_2 = 3 * argv$foldchange
print ( subset(res, rownames(res) %in% c("FBgn0036565")))
#plotMA( res, ylim=c( -foldchange_2, foldchange_2))
#plotMA( resLFC, ylim=c( -foldchange_2, foldchange_2))
#topGene <- rownames(res)[ which.min(res$padj) ]
topGene <- c("FBgn0036565")
EnhancedVolcano( toptable = res,              # We use the shrunken log2 fold change as noise associated with low count genes is removed 
                x = "log2FoldChange",           # Name of the column in resLFC that contains the log2 fold changes
                y = "padj",                     # Name of the column in resLFC that contains the p-value
				lab = rownames(res),
              	pCutoff = pvalue,
                FCcutoff = 2,
				title = "fold change cutoff = 2, padj=0.001"
)
print ( res[topGene, ] )
print ( res )
print ( resLFC )
plotMA( res, ylim=c(-6,6))
with(res[topGene, ], {
 points(baseMean, log2FoldChange, col="dodgerblue", cex=2, lwd=2)
 text(baseMean, log2FoldChange, topGene, pos=2, col="dodgerblue")
})  #标记出一个特定的基因


#plotMA( resLFC )


#with( subset(res, rownames(res) %in% c("FBgn0036565")), {
#  #points(baseMean, log2FoldChange, col = "dodgerblue", cex = 2, lwd = 2)
#  #text(baseMean, log2FoldChange, c("FBgn0036565"), pos = 2, col = "dodgerblue")
#  points(0, 0, col = "dodgerblue", cex = 2, lwd = 2)
#  text(0, 0, c("FBgn0036565"), pos = 2, col = "dodgerblue")
#})
class(pvalue)
summary(res)
# 获取padj（p值经过多重校验校正后的值）小于0.05，表达倍数取以2为对数后大于1或者小于-1的差异表达基因。
table(res$padj < pvalue) #取P值小于0.05的结果
res <- res[order(res$padj), ]
resdata <-  merge(as.data.frame(res),as.data.frame(counts(dds,normalize=FALSE)),by="row.names",sort=FALSE)
# 得到csv格式的差异表达分析结果
write.table( resdata, file=argv$out, row.names = F, quote = FALSE, sep = "\t")
print ('yes')
print ( subset( res, pvalue < pvalue  ) )
print ('yes')

#diff_gene_deseq2_up <-subset( res, padj < pvalue & log2FoldChange > fc  )
diff_gene_deseq2_up <-subset( resdata, pvalue < 0.05 & log2FoldChange > 1.2 )
diff_gene_deseq2_down <-subset( resdata, pvalue < 0.05 & log2FoldChange < -1.2)
#diff_gene_deseq2_up <- row.names(diff_gene_deseq2_up)
#diff_gene_deseq2_down <- row.names(diff_gene_deseq2_down)
write.table(as.data.frame(diff_gene_deseq2_up),file=paste(argv$out,'.pick.up',sep =''),row.names = F,quote = FALSE,sep = "\t")
write.table(as.data.frame(diff_gene_deseq2_down),file=paste(argv$out,'.pick.down',sep =''),row.names = F,quote = FALSE,sep = "\t")
dev.off()



