#!/usr/bin/env perl 
use strict;
use warnings;

unless(@ARGV){
	die "#Usage: $0 xls\n";
}

my ($in,$i,$j,$len,@length,@line);
open $in,"$ARGV[0]";
$j = 0;
while(<$in>){
	$j++;
	@line = split /\t/,$_,-1;
	print "$j colomn numbers is\t" . scalar(@line) . "\n";
	$i = -1;
	for(@line){
		$i++;
		$len = length;
		unless($length[$i]){
			$length[$i] = 0;
		}
		if($len >= $length[$i]){
			$length[$i] = $len;
		}else{
			$length[$i] = $length[$i];
		}
	}
}

$i = 0;
for(@length){
	$i++;
	print "colum $i max length is $_\n";
}
