#!/usr/bin/env python3
import os
import sys
import sqlite3
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'fl', nargs = '?', help = 'data file to load into sqlite3 database')
parser.add_argument( 'table', nargs = '?', help = 'table name from database')
parser.add_argument( 'database', nargs = '?', help = 'sqlite3 database')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


con = sqlite3.connect( args.database )
cur = con.cursor()
fh = open( args.fl )
for line in fh:
    line_arr = line.strip('\n').split('\t')
    wstr = 'INSERT OR IGNORE INTO {} VALUES( {} )'.format( args.table, ','.join( [ '?' for i in line_arr ] ) )
    cur.execute( wstr, ( *line_arr, ) )
    #cur.execute('INSERT OR IGNORE INTO match VALUES( 2, 1)' )
con.commit()



























