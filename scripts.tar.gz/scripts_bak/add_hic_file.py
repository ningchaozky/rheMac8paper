#!/usr/bin/env python
import os
import sys
import copy
import argparse
from bs4 import BeautifulSoup
parser = argparse.ArgumentParser(prog = sys.argv[0],description='flush the files upload on http server')
parser.add_argument('-i', nargs='?', default = 'index.html', help ='html file. default the pwd html')
parser.add_argument('-s', nargs='?', default = 'hic', help ='file suffix for use')
parser.add_argument('-d', nargs='?', default = '/home/washU/pub', help ='work dir default /home/washU/pub')

if len(sys.argv) == 1:
        parser.print_help().__str__
        sys.exit(2)
args = parser.parse_args()

index = os.path.join(args.d,args.i)
fh = open(index)
html = BeautifulSoup(fh, 'html.parser')
fh.close()
index_tmp_file = open(index+'.tmp','w')
#template get
trs = html.find_all('tr')
print(trs)
exit()
new_trs,redup,template = [],[],''
for tr in trs:
	if tr.text in redup:
		tr.clear()
		continue
	else :
		print(tr.text)
		redup.append(tr.text)
	if 'test.hic' in tr.text:
		template = copy.deepcopy(tr)
print(redup)
table = html.table

for root,dirs,files in os.walk(os.path.dirname(index)):
	for each in files:
		suffix = os.path.splitext(each)[1].replace('.','')
		if suffix in args.s:
			print(template.td, file=index_tmp_file)
			template.a.string = each
			template.a['href'] = each
			table.append(copy.deepcopy(template))
#re dup in dirs
rs = html.find_all('tr')
for each in trs:
	if each.a:
		if each.a.string in redup:
			each.clear()
		else :
			redup.append(each.a.string)

print('''<HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">\n'''.strip(), file=index_tmp_file)
print(html, file=index_tmp_file)
index_tmp_file.close()

os.system('mv %s %s' % (index+'.tmp',index))

