#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-x', nargs='?', help ='reference')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
import colorsys


def man_cmap(cmap, value=1.):
    colors = cmap(np.arange(cmap.N))
    hls = np.array([colorsys.rgb_to_hls(*c) for c in colors[:,:3]])
    hls[:,1] *= value
    rgb = np.clip(np.array([colorsys.hls_to_rgb(*c) for c in hls]), 0,1)
    return mcolors.LinearSegmentedColormap.from_list("", rgb)

cmap = plt.cm.get_cmap("jet")

fig, (ax1, ax2, ax3) = plt.subplots(3)
x=np.linspace(0,1,64)

sc = ax1.scatter(x,np.ones_like(x), c=x, cmap=cmap)
fig.colorbar(sc, ax=ax1, orientation="horizontal")

sc = ax2.scatter(x,np.ones_like(x), c=x, cmap=man_cmap(cmap, 0.75))
fig.colorbar(sc, ax=ax2, orientation="horizontal")

sc = ax3.scatter(x,np.ones_like(x), c=x, cmap=man_cmap(cmap, 1.25))
fig.colorbar(sc, ax=ax3, orientation="horizontal")

plt.show()




























