#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import argparse
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("white")
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, fix
from ningchao.nData import data
from matplotlib.backends.backend_pdf import PdfPages

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'mats', nargs = '*', help = 'matrix output from annotatePeaks.pl')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def rename_matrix_to_peirod( string ):
    peirod = ['E50','E80','E90','E120','0M','4M','45Y','20Y','liver']
    raw_peak_file = fix.fix( string ).delete()
    for each in peirod:
        if each in string:
            return each, raw_peak_file

def line_num( file_in ):
    i = 0
    with open ( file_in ) as f:
        for line in f:
            i += 1
    return i

def matsToPlotDataFrame( mats ):
    dit = defaultdict( dict )
    for each in mats:
        temp_dit = defaultdict( int )
        sys.stderr.write( each )
        fh = open( each )
        next(fh)
        peirod, peaks_bed = rename_matrix_to_peirod( each )
        for i, line in enumerate( fh ):
            line_arr = line.strip().split('\t')
            annot_pos = line_arr[7].split(' ')[0].replace('promoter-TSS','TSS')
            temp_dit[annot_pos] += 1
            peak_pos = '\t'.join( line_arr[1:4] )
            #print ( peak_pos )
        fh.close()
        dit.update( { peirod : temp_dit} )
    return dit

if __name__ == '__main__':
    dit = matsToPlotDataFrame( args.mats )
    df = pd.DataFrame(dit)
    nData_defind_colors = data.data().color()
    melt = pd.melt( df.reset_index(), id_vars='index' )
    print ( melt )
    stacked_df = df.T
    #plt.bar(list(dit.keys()), dit.values(), color='g')
    with PdfPages('test.pdf') as pdf:
        for peirod in dit:
            labels, values = list( dit[peirod].keys()), list(dit[peirod].values())
            colors = [ nData_defind_colors[i] for i in labels ]
            #plt.pie(values, labels=labels, colors = colors)
            patches, texts = plt.pie(values, labels= None, colors = colors, shadow = True, startangle=90)
            plt.title(peirod)
            plt.legend( patches, labels, loc="center left", bbox_to_anchor=(-0.1, 1.), fontsize=8)
            pdf.savefig()
        g = sns.catplot(x='variable',y='value', kind = 'bar', data = melt, hue = 'index', ci="sd", alpha=.6, height=6, palette=sns.color_palette(colors, len(colors)))
        #g.despine(left=True)
        #plt.savefig( 'test.pdf', dpi=250)
        pdf.savefig()
        
        stacked_df.plot( kind = 'bar', stacked = True, color= colors )
        pdf.savefig()
        #pdf.close()
#print ( dit, peaks_num )






























