#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'exon', nargs='?', help = 'exon bed', default = sys.stdin, type = argparse.FileType('r'))
parser.add_argument( '-outputfile','-o', nargs='?', help = 'exon bed', default = sys.stdout, type = argparse.FileType('w'))
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def get_key( line ):
    line_arr = line.strip().split('\t')
    name_arr = line_arr[3].split('.')
    chrom, chain, start, end = line_arr[0], line_arr[-1], line_arr[1], line_arr[2]
    key = '.'.join( [ i for i in name_arr if 'copy' not in i ] )
    return key,chrom,chain,int( start ), int( end )


fsymbol,fchrom,fchain,fstart,fend = get_key( next(args.exon) )
startAndEnds = [ fstart, fend ]

num_file = open( args.outputfile.name +'.num', 'w' )

for line in args.exon:
    symbol,chrom,chain,start,end = get_key( line  )
    if symbol == fsymbol :
        startAndEnds.append(start)
        startAndEnds.append(end)
    else :
        startAndEnds.pop( 0 )
        startAndEnds.pop( -1 )
        introns = [(int( startAndEnds[i]), startAndEnds[i+1]) for i in range(0,len( startAndEnds ),2)]
        for i,v in enumerate( introns ):
            print ( fchrom, *v, '.'.join( [ fsymbol,'intron{}'.format(i)]), fchain, sep = '\t', file = args.outputfile)
        print ( fsymbol, i + 1, file = num_file, sep = '\t')
        fsymbol,fchrom,fchain,fstart,fend = symbol,chrom,chain,start,end
        startAndEnds = [ fstart, fend  ]
introns = [(int( startAndEnds[i]), startAndEnds[i+1]) for i in range(0,len( startAndEnds ),2)]
for i,v in enumerate( introns ):
    print ( fchrom, *v, '.'.join( [ fsymbol,'intron{}'.format(i)]), fchain, sep = '\t', file = args.outputfile)
print ( fsymbol, i + 1, file = num_file, sep = '\t')
























