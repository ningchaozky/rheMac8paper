#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
#plt.style.use('ggplot')
import argparse
import numpy as np
from collections import defaultdict
from ningchao.nSys import trick
from ningchao.nBio import bedKit
example = '''span_closest_feature.py generate spd.K9me3.bed.transcripts.5K.intersect\ntranscripts_match_gene.py generate spd.K9me3.bed.transcripts.5K.intersect.gene\ncd /farangism/ningch/earyly_embryo/H3K9me3/ 
/farangism/ningch/earyly_embryo/H3K9me3/spd.K9me3.signal.signal.mini spd.K9me3.bed.transcripts.5K.intersect.gene  '''
parser = argparse.ArgumentParser( prog = sys.argv[0] + os.linesep,description='{}'.format(example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'signal', nargs = '?', help = 'signal file form bed_bw_values_extract')
parser.add_argument( 'mapper', nargs = '?', help = 'spd.K9me3.bed.transcripts.5K.intersect.gene mapper for merge and get the signal')
parser.add_argument( '-c', choices = ['sum','max','min','median'], help =' all_peaks sum max min median', default = 'sum')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def parse_mapper( fl ):
    infor = defaultdict( list )
    pos = bedKit.bed.chrom_start_end(fl)
    with open ( fl )as f :
        for line in f:
            line_arr = line.strip().split('\t')
            gene = line_arr[-1]
            peak = [line_arr[i] for i in pos[0:3]]
            infor[gene].append( '\t'.join( peak ))
    for gene in infor:
        infor[gene] = list( set(infor[gene]) )

    return infor

def signal_to_dcit( signal ):
    infor = defaultdict( list )
    pos = bedKit.bed.chrom_start_end( signal )
    with open ( signal ) as fh:
        header = next(fh).strip().split('\t')
        header = [ v for i,v in enumerate(header) if i not in pos ]
        for line in fh:
            line_arr = line.strip().split('\t')
            key = '\t'.join([line_arr[i] for i in pos[0:3]])
            tmp = [ float(v) for i,v in enumerate(line_arr) if i not in pos]
            infor[key] = tmp
    return infor, header

if __name__ == '__main__':
    gene_match_peaks = parse_mapper( args.mapper)
    signal, header = signal_to_dcit( args.signal )
    print ( 'gene', *header, sep = '\t' )
    for gene in gene_match_peaks:
        array = []
        for peak in gene_match_peaks[gene]:
            if peak not in signal:
                print ( '#Waring: {} not in {}. check by hand'.format(peak, args.signal), file = sys.stderr)
            else :
                array.append( signal[peak] )
        if args.c == 'sum':
            vals = [ sum(x) for x in zip(*array)  ]
        elif args.c == 'max':
            vals = [ max(x) for x in zip(*array)  ]
        elif args.c == 'min':
            vals = [ min(x) for x in zip(*array)  ]
        elif args.c == 'median':
            vals = [ np.median(x) for x in zip(*array)  ]
        else :
            exit('Wrong input type for calculate')
        print ( gene, *[ round( i, 4) for i in vals], sep = '\t' )















