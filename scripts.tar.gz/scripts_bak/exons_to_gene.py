#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('f', nargs='?', help = 'forward bw')
parser.add_argument('r', nargs='?', help = 'reverse bw')
parser.add_argument('bed', nargs='?', help = 'exons beds')
parser.add_argument('-n', nargs='?', help = 'peiord name')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


cmd = 'bed_bw_values_extract.py %s %s -t sum -n %s -g rh8 -o %s' % ( args.f, args.bed, args.n, 'forward' )
print ( cmd )
cmd = 'bed_bw_values_extract.py %s %s -t sum -n %s -g rh8 -o %s' % ( args.r, args.bed, args.n, 'reverse' )
print ( cmd )

cmd = 'bw_matrix_insert_gene.py forward /home/soft/data/genome/rheMac8/annot/exons/exons.bed  > forward.exon'
print ( cmd )
cmd = 'bw_matrix_insert_gene.py reverse /home/soft/data/genome/rheMac8/annot/exons/exons.bed  > reverse.exon'
print ( cmd )

cmd = 'bw_exons_matrix_to_gene.py forward.exon > forward.exon.gene'
print ( cmd )
cmd = 'bw_exons_matrix_to_gene.py reverse.exon > reverse.exon.gene'
print ( cmd )

cmd = 'exons_values_add.py forward.exon.gene reverse.exon.gene > merge'
print ( cmd )
























