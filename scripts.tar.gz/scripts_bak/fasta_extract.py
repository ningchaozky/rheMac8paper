#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-k','key', nargs=2, help ='key words for include in file name', metavar = ('bar','baz'),action='store_const')
parser.add_argument('-T', action='store_true|store_false', help ='key words for include in file name')
parser.add_argument('-c', choices = [1,2,3],type = int, help ='choices', default = 1, required = True)
parser.add_argument('-g', nargs='*', default = 'rheMac3', help ='genome for bw',action='store_const|append_const|count')
parser.add_argument('-x', nargs='+', help ='reference')
parser.set_defaults(bar=42, baz='badger')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()
print args.k
print args.g





























