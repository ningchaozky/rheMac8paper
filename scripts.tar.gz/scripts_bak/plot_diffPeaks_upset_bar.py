#!/usr/bin/env python3
import os
import re
import sys
import matplotlib
import pandas as pd
import upsetplot
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import argparse
import matplotlib.backends.backend_pdf
from ningchao.nSys import trick, system
from collections import defaultdict

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'dir', nargs = '?', help = 'degseq2 output directory')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def raw_parse( fl ):
    fh, dit = open( fl ), {'pos': defaultdict( str ), 'neg':defaultdict( str ), 'all': defaultdict( str ) }
    header = next( fh ).strip().split('\t')
    for line in fh: 
        line_arr = line.strip().split('\t')
        line_dit = dict(zip(header, line_arr))
        name = re.sub(r'^\d+_', '', line_arr[0])
        if 'NA' in line_dit['log2FoldChange']:
            continue
        fc, pval = float( line_dit['log2FoldChange'] ), float( line_dit['pvalue'] )
        if fc > 1.5 and pval < 0.05 :
            dit['pos'][ name ] = float( fc )
            dit['all'][ name ] = float( fc )
        elif fc < -1.5 and pval < 0.05:
            dit['neg'][ name ] = float( fc )
            dit['all'][ name ] = float( fc )
    fh.close()
    return dit

if __name__ == '__main__':

    fls, order = system.dir(args.dir).fls('pick$'), []
    infor = { 'neg': defaultdict( list ), 'pos': defaultdict( list ), 'all': defaultdict( list ) }
    

    for fl in fls:
        p1,p2 = os.path.basename(fl.replace('.xls.pick','')).split('vs')
        raw = fl.replace('.pick','')
        raw_foldChange = raw_parse( raw )
        fh = open( fl )
        next( fh )
        for line in fh:
            name = re.sub(r'^\d+_', '', line.strip())
            for typ in raw_foldChange:
                if name in raw_foldChange[ typ ]:
                    #index for plot
                    if name not in order:
                        order.append( name )
                
                    if raw_foldChange[typ][name] > 0 :
                        infor[typ][ p1 ].append( name )
                    else :
                        infor[typ][ p2 ].append( name )
    
    #fig, axes = plt.figure(), defaultdict(str)
    #num_figs = len( infor.keys() )
    #fig.tight_layout()
    from matplotlib.backends.backend_pdf import PdfPages
    with PdfPages('test.pdf') as pdf:
        for i,typ in enumerate(infor):
            #fig_pos = '{}1{}'.format(num_figs, i + 1 ) 
            #axes[i] = fig.add_subplot( fig_pos )
            for key in infor[typ]:
                infor[typ][key] = list( set( infor[typ][key] ) )
            #ps = pd.Series( infor )
            #df = pd.DataFrame(  ).fillna( False )
            #df = pd.DataFrame(dict([ (k, pd.Series(v)) for k,v in infor.items() ])).fillna( False )
            infor_typ = trick.dit( infor[typ] ).to_df( order )
            df = pd.DataFrame( infor_typ )
            df.to_csv('test.txt',sep='\t')
            df = df.astype(bool)
            df = df.groupby(df.columns.tolist(),as_index=False).size()
            multi_index = list( df.columns )
            multi_index.pop(-1)
            df.set_index(multi_index, inplace = True )
            df = df.sort_values('size')
            #plt.sca( axes[i] )
            print ( plt.gca() )
            #upsetplot.plot( df['size'], fig = fig)
            upsetplot.plot( df['size'] )
            #df['num'] = df[df == True ].count(axis='columns') 
            print ( df )
            #plot( df['size'], sort_by="cardinality")
            #plot( df['size'], sort_by="cardinality")
            #plot( df )
            #fig.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
            pdf.savefig()
            plt.close()

    #pdf.close()























