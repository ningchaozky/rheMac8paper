#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def change_peirod ( string ):
    if '45Y' in string :
        return string.replace('45Y','4M')
    elif '4M' in string :
        return string.replace('4M','45Y')
    return peirod

#infor = defaultdict( lambda : defaultdict( lambda : defaultdict( list ) ) )
infor = defaultdict( lambda : defaultdict( list) )
pnum = defaultdict( int )
peirods = system.dir.peirods( prefrontal_raw = True ).keys()
new_list = defaultdict( list )
symbols = set()
for line in args.tab :
    line_arr = line.rstrip().split('\t')
    if line_arr[1] in symbols:
        continue
    symbols.add( line_arr[1] )
    gene = line_arr[1].split('.')[0].upper()
    file = line_arr[0]
    peirod = line_arr[-1]
    peirod = change_peirod( peirod )
    flst = file.split('.')
    marker = flst[1]
    typ = flst[2]
    if typ == 'meidan' :
        typ = 'broad'
    elif typ == 'max':
        typ = 'peak'
    else :
        typ = 'broad'
    #infor[ peirod ][marker][typ].append(gene)
    infor[ peirod ][ typ ].append(gene)
    pnum[ peirod ] += 1



peirods = system.dir.peirods( prefrontal_raw = True ).keys()
lst_ax1, lst_ax2 = [], []
for peirod in peirods :
    #for marker in infor[ peirod ]:
        for typ in infor[ peirod ] :
            symbols_num = len( infor[ peirod ][ typ ] )
            ratio = len(infor[ peirod ][ 'broad' ]) / len(infor[ peirod ][ 'peak' ])
            try :
                print ( symbols_num/pnum[peirod] )
            except :
                print ( peirod )
                exit()
            lst_ax1.append([ peirod, typ, symbols_num/pnum[peirod]])
        lst_ax2.append([ peirod, 'ratio', ratio])



df_ax1 = pd.DataFrame( lst_ax1, columns = [ 'peirod', 'typ', 'num'])
df_ax2 = pd.DataFrame( lst_ax2, columns = [ 'peirod', 'typ', 'num'])
print ( df_ax2)
#df.plot.bar()
ax=sns.barplot( data = df_ax1, x="peirod", y="num", hue = 'typ')
ax2 = ax.twinx()
axy = sns.lineplot( data = df_ax2, x="peirod", y="num", hue = 'typ', sort= False, ax = ax2 )
#axy.set( ylabel = None )
#axy.set_xticks( ticks = [], labels = )
plt.savefig( 'testfdsafad.pdf', dpi=250, transparent=True, edgecolor='none')






















