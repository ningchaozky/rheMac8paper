#!/usr/bin/env python
import ningch as nc
import os 
import sys

nc.usage('file:all_peaks_bed file:promoter_contian_bed path:output')




with open(sys.argv[3],'w') as fh:
	precent = str(float(nc.line_num(sys.argv[1]))/nc.line_num(sys.argv[2]))
	fh.write('promoter_contain_peaks_num'+'\t' +str(nc.line_num(sys.argv[1]))+'\t'+precent+'\n')
	fh.write('peaks_num'+'\t'+str(nc.line_num(sys.argv[2]))+'\t'+'1'+'\n')
