#!/usr/bin/env python
import os
import re
import sys
import argparse
import ningchao.nBio.chromosome as chrKit
import ningchao.nSys.trick as trKit
from ningchao.nSys import parse

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bs', nargs='*', help ='beds for binary. K4 K4.bed ...' )
parser.add_argument('-f', nargs='?', help ='fiter for the input', default = 'H2Aub|Pol2|K36me3' )
#parser.add_argument('-s', nargs='?', help ='genome size file', default = '/home/soft/data/genome/rheMac8/rheMac8.genome')
parser.add_argument('-op', nargs='?', help ='output file prefix for BianrizeBam sample.', required = True )
parser.add_argument('-d', nargs='?', help ='dir for output. BinarizeBam', default = 'BinarizeBam')
parser.add_argument('-b', nargs='?', type = int, help ='bin size for divide the genome. 200', default = 100)
parser.add_argument('-gs', nargs ='?', help ='genome size file', default = '/home/soft/data/genome/rheMac8/rheMac8.genome')
parser.add_argument('-header', action='store_false', help ='own no header?. default own header')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()
out = sys.stdout
infor = {}
#chrInfor = chrKit.chr('rh8', sexX = True ).chr
beds = iter(args.bs)
bins = args.b
chrInfor = parse.ini( args.gs, fpattern = 'MT|Y|M|chrUn_NW' ).to_dict()
chrInfor = { i : int(v) for i,v in chrInfor.items() }
chrInfor.update({ 'chr'+k:v for k,v in chrInfor.items() if 'chr' not in k })


markers = []
ignore_infor = []
for marker in beds:
    bed = next(beds)
    if args.f :
        if re.search(r'{}'.format(args.f), marker):
            print ('#Fiter the {} for not all own. manual'.format(marker))
            continue
    print ('#Deal with {}: {}|{}'.format( args.op, marker, bed))
    with open(bed) as bedfh:
            if args.header :
                next(bedfh)
            for line in bedfh:
                if 'track' in line :
                    continue
                line_arr = line.strip().split('\t')
                if 'chr' not in line_arr[0]:
                    line_arr[0] = 'chr' + line_arr[0]
                start = int(line_arr[1]) // bins
                end = int(line_arr[2]) // bins + 1
                if line_arr[0] not in chrInfor:
                    if line_arr[0] not in ignore_infor:
                        print ( '#Ignore {}: {}'.format(line_arr[0], bed))
                        ignore_infor.append( line_arr[0] )
                    continue
                for each in range( start, end):
                    trKit.dinit( infor, line_arr[0], each, marker, 1)
    markers.append(marker)

path = os.path.join(os.getcwd(),args.d)
if not os.path.exists(path) :
    os.mkdir(path)
prefix = args.op
for chrom in chrInfor:
    if chrom in ['chrY','chrM','chrMT']:
        continue
    fl = os.path.join( path, prefix + '_' + chrom + '_binary.txt')
    fh = open( fl, 'w')
    print ( prefix, chrom, sep = '\t', file = fh)
    print ( *markers, sep = '\t', file = fh )
    for pos in range( chrInfor[chrom] // bins ):
        line = []
        for marker in markers:
            if pos in infor[chrom] and marker in infor[chrom][pos]:
                line.append(infor[chrom][pos][marker])
            else :
                line.append(0)
        print( *line, sep = '\t', file = fh)

#print ('java -mx50000M -Djava.awt.headless=true -jar /home/soft/soft/ChromHMM/ChromHMM.jar LearnModel -b 100 BinarizeBam LearnModelBed 12 rh8' )















