#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
import argparse
from subprocess import getoutput
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs= '?', help = 'dir for bws')
parser.add_argument('-p1', nargs= '?', help = 'ppois.bw.qn.tmp.bw', default = 'ppois.bw.qn.tmp.bw')
parser.add_argument('-p2', nargs= '?', help = 'ppois.bw.qn.tmp.bw', default = 'ppois.bw.qn.tmp.bw')
parser.add_argument('-bed', nargs= '?', help = 'bed file care', default = '/home/soft/data/genome/rheMac8/annot/exons/gene.up3K.down2K')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

fls = ' '.join( [ i.strip() for i in os.popen( '''find.py {} -dir {} -s ' ' -sort peirod'''.format( args.p1, args.dir) ).readlines() ] )
cmd = 'computeMatrix scale-regions -S {} -o gene.gz -R {}'.format( fls, args.bed )
print ( cmd )

cmd = 'plotHeatmap -m gene.gz -out gene.gz.png'
print ( cmd )


fls = ' '.join( [ i.strip() for i in os.popen( '''find.py {} -dir {} -s ' ' -sort peirod'''.format( args.p2, args.dir) ).readlines() ] )
cmd = '''multiBigwigSummary BED-file -b {} -o gene.npz --BED {}'''.format( fls, args.bed )
print ( cmd )
print ( 'plotCorrelation -in gene.npz --whatToPlot heatmap --corMethod pearson -o gene.png --removeOutliers --plotNumbers --outFileCorMatrix gene.cor' )

print ('development_stage_cor_box_plot.py gene.cor')
print ('boxplot.py gene.cor.cor.box -y 1')
























