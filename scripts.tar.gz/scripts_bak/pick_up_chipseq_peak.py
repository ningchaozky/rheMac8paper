#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='cut off peaks')
parser.add_argument('-len', nargs='?', default = '100', help ='key work for getitem from env dict')
parser.add_argument('-pileup', nargs='?', default = '1', help ='js dir')
parser.add_argument('-p', nargs='?', default = 0.001, help ='pvalue')
parser.add_argument('-q', nargs='?', default = 0.001,help ='qvalue')
parser.add_argument('-fc', nargs='?', default = 2, help ='fold change')
parser.add_argument('-type', nargs='?', default = 'peak', help ='xls type peak|broad')
parser.add_argument('-xls', nargs='?', help ='')

exec(trickTookit.usage('parser'))

args = parser.parse_args()
xls = args.xls
fh = open(xls)
for each in fh:
	each = each.strip()
	each_arr = each.split('\t')
	if len(each_arr) >=7:
		if each.startswith('#'):
			continue
		if args.type == 'peak':
			pvalue = 10 ** -float(each_arr[6])
			qvalue = 10 ** -float(each_arr[8])
			fc = float(each_arr[7])
			pileup = float(each_arr[5])
			length = int(each_arr[3])
			if length >= int(args.len) and pileup >= float(args.pileup) and pvalue <= float(args.p) and fc >= float(args.fc) and qvalue <= float(args.q):
				print(each)
		elif args.type == 'broad':
			pass









