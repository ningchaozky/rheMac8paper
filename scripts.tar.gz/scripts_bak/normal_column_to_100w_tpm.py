#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system
from collections import defaultdict
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'tab file')
parser.add_argument( '-normal_to', nargs = '?', help  = '1000,000 for tpm', default = 1000000, type = float)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



adder = defaultdict( float )


with open( args.tab ) as f :
    header = next(f).rstrip().split('\t')
    for line in f :
        line_arr = line.rstrip().split('\t')
        for i,v in enumerate( line_arr[1:] ):
            adder[str(i+1)] += float(v)

with open( args.tab ) as f :
    header = next(f).rstrip()
    print ( header )
    for line in f :
        line_arr = line.rstrip().split('\t')
        for i,v in enumerate( line_arr[1:] ):
            line_arr[i+1] = (float(line_arr[i+1]) * (args.normal_to - 0.001) ) / adder[str(i+1)]
            line_arr[i+1] = round( line_arr[i+1], 2 )
        print ( *line_arr, sep = '\t' )

























