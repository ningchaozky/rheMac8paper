#!/usr/bin/env python
import os
import sys
import argparse
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
mpl.use('Agg')
plt.tight_layout()
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import pandas as pd
from pandas import read_csv
import itertools
import ningchao.nSys.fix as fixKit
from scipy.stats import wilcoxon, levene, ttest_ind
from collections import defaultdict
import seaborn as sns;sns.set(color_codes=True)
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('i', nargs = '?', help ='input data matrx' )
parser.add_argument('-fcol', nargs='*', type = int, help ='fiter out the colums for plot', default = [1] )
parser.add_argument('-p', nargs='?', help ='output prefix')
parser.add_argument('-y', nargs='?', type = float, help ='ymax for the boxplot', default = 25)
parser.add_argument('-ycut', nargs='?', type = float, help ='y cut now show in figs', default = 5)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

fcol = [ i - 1 for i in args.fcol ]
prefix = fixKit.change_suff(args.i,'').replace('.pdf','')
index = [ i-1 for i in  args.fcol ] 
if args.p:
	prefix = args.p.replace('.pdf','')
data = read_csv(args.i,sep = '\t', header = 0, index_col = 0)
infor =  data.T.to_dict() 
wilcoxon_test = defaultdict( list )
for pos in infor :
    for peiord in infor[pos]:
        if infor[pos][ peiord ] > args.ycut:
            wilcoxon_test[ peiord ].append( infor[pos][ peiord ] )
for p1, p2 in list(itertools.combinations( wilcoxon_test, 2)):
    if 'zygote' not in p1 + p2 :
        continue
    x,y = wilcoxon_test[p1], wilcoxon_test[p2]
    length = len(x) > len(y) and len(y) or len( x )
    print ( p1, p2, len(x), len(y), levene( x, y ) )
    print ( p1, p2, len(x), len(y), ttest_ind( x, y, equal_var = True))
    print ( p1, p2, len(x), len(y), wilcoxon( x[:length], y[:length]))
    
id_vars = list(data.columns[fcol])
melt = pd.melt(data,id_vars = id_vars)
melt = melt[melt['value'] > args.ycut]
ax=sns.boxplot(x='variable',y='value',data = melt, showfliers = False )
ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
plt.ylim((0, args.y))
PDF = prefix + '.pdf'
os.system('link_generate.py {}'.format(PDF))
plt.savefig( PDF, format='pdf',  bbox_inches='tight', pad_inches=+1 )












