#!/usr/bin/env python
import os
import sys
import ningchao.usage as u 
import ningchao.nSys.ip_addr as ip
import ningchao.nBio.sge as sgeTookit
import ningchao.nBio.pbs as pbsTookit

u.usage('file:*sh')

cpu = '1'
mem = '3'
split_times = '-1'
sh = sys.argv[1]
prefix = sh
work_dir = os.getcwd()

if ip.local_ip() != '10.1.1.1':
	obj = pbsTookit.pbs(cpu=cpu,mem=mem,work_dir=work_dir).split(prefix,sh,num=split_times)
	for each in obj:
		print('dsub %s' % each)
else :
	obj = sgeTookit.sge(cpu=cpu,mem=mem,work_dir=work_dir).split(prefix,sh,num=split_times)
	for each in obj:
		print('qsub %s' % each)
