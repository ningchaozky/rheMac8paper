#!/usr/bin/env python
import sys
if len(sys.argv) <= 1:
	print('#Usage',sys.argv[0],'swiss|ref100|ref90|ref50|trembl','title','idmapping_selected.tab')
	exit()

from GO_tookit import idmapping_select

mapping = idmapping_select(sys.argv[3],sys.argv[1])
title = open(sys.argv[2])
for line in title:
	line = line.rstrip()
	if(mapping.get(line)):
		print(line+'\t'+mapping.get(line))

