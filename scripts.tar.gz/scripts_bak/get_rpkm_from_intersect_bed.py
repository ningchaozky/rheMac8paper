#!/usr/bin/env python
import os
import sys
import subprocess as sp
import re
import ningch as nc 

if __name__ == "__main__":
	nc.usage(' '.join(['file:eg intersect.bed,1,2,3(can_get_from bedtools intersect)','file:rpkm_output','[adj_factor]']))
	bed = nc.sp_args(sys.argv[1])[0]
	bed_hd = open(bed)
	cols = [int(i)-1 for i in nc.sp_args(sys.argv[1])[1:]]
	stdout,stderr = nc.run_sys('wc -l %s' % bed)
	stdout = iter(stdout)
	reads_numer = int(stdout.next().replace(' %s' % bed,''))
	output = open(sys.argv[2],'w')
	fpkm_dict = {}
	for line in bed_hd:
		line_arr = line.strip().split('\t')
		key = '\t'.join([line_arr[i] for i in cols])
		if key not in fpkm_dict:
			fpkm_dict[key] = 0
		fpkm_dict[key] += 1
	for key in fpkm_dict:
		key_arr = key.split('\t')
		span = int(key_arr[2]) - int(key_arr[1])
		rpkm = str(fpkm_dict[key]*1000000000/(float(reads_numer)*span))
		output.write('\t'.join([key,rpkm])+'\n')
	output.close()
	stdout,stderr = nc.run_sys('sort -k1,1 -k2,2n %s' % sys.argv[2])
	adj_factor = 1
	if len(sys.argv) == 4:
		adj_factor = float(sys.argv[3])
	out = open(sys.argv[2]+'.sort.adjBy%s' % adj_factor,'w')
	for line in stdout:
		line_arr = line.strip().split('\t')
		line_arr[-1] = float(line_arr[-1])/adj_factor
		key = '\t'.join(line_arr[0:3])
		line_arr.append(fpkm_dict[key])
		out.write('\t'.join([str(i) for i in line_arr])+'\n')
	out.close()

		
