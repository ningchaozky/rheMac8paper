#!/usr/bin/env python
import os
import sys
import ningchao.usage as u
import ningchao.nBio.chromosome as c
import ningchao.nSys.fix as f
import ningchao.nSys.soft as s


u.usage('file:bedGraph file:bigWig str:hs|mm|rh3|rh8')
sizeFile = ''
if sys.argv[3] == 'hs':
	sizeFile = c.chr('hs').abspth
if sys.argv[3] == 'mm':
	sizeFile = c.chr('mm').abspth
if sys.argv[3] == 'rh3':
	sizeFile = c.chr('rh').abspth
if sys.argv[3] == 'rh8':
	sizeFile = c.chr('rh').abspth
bedGraphToBigWig = s.soft().abspth('bedGraphToBigWig')
cmd = 'grep -v chrMT | grep -v track %s > %s' % (sys.argv[1],f.insert_suff(sys.argv[1],'chr',-1))
print(cmd)
sort_out = f.insert_suff(f.insert_suff(sys.argv[1],'chr',-1),'sort',-1)
cmd = 'sort -k1,1 -k2,2n %s > %s' % (f.insert_suff(sys.argv[1],'chr',-1),sort_out)
print(cmd)
cmd = '%s %s %s %s' % (bedGraphToBigWig,sort_out,sizeFile,sys.argv[2])
print(cmd)









