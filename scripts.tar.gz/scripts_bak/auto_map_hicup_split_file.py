#!/usr/bin/env python
import os
import sys
import threading
import re

if len(sys.argv) <= 1:
	print (sys.argv[0],'split_fastq_dir:dir','hicup_config:file','pbs_template:file','threads:int','memory:mem','numsOfDsub:int')
	exit()

#/p200/liujiang_group/ningch/soft/hicup_v0.5.9/hicup_example.conf

fastqs = os.listdir(sys.argv[1])
configs = []
for each in fastqs:
	if each.startswith('1'):
		forward = each
		reverse = each.replace('1','2',1)
		config_template = open(sys.argv[2])
		config_each = open('%s.ini' % each,'w')
		configs.append('%s.ini' % each)
		for line in config_template:
			if line.startswith('Threads'):
				line = line.replace('6',sys.argv[4])
			if line.startswith('Outdir'):
				pattern = re.compile(r'Outdir: (.*)')
				line = pattern.sub(r'Outdir: %s' % os.path.abspath(os.curdir),line)
			config_each.write(line)
		print (os.path.join(sys.argv[1],forward),file=config_each)
		config_each.write(os.path.join(sys.argv[1],reverse))
		config_each.close()
	else:
		pass

pbss = []
for config in configs:
	pbs = open('%s.pbs' % config,'w')
	pbss.append('%s.pbs' % config)
	mapping_template = open(sys.argv[3])
	for each in mapping_template:
		if 'ppn' in each:
			each = each.replace('ppn=10','ppn=%s' % sys.argv[4])
		if 'mem' in each:
			each = each.replace('mem=12gb','mem=%sgb' % sys.argv[5])
		if each.startswith('#PBS -N '):
			each = '#PBS -N %s\n' % config
		if each.startswith('#PBS -d '):
			each = '#PBS -d %s\n' % os.path.abspath(os.curdir)
		if '-conf ' in each:
			each = each.replace('/p200/liujiang_group/ningch/soft/hicup_v0.5.9/hicup_example.conf',config)
		print (each,file=pbs,end = '')
	mapping_template.close()
	pbs.close()
	
pbss = iter(pbss)
shell = open('hicup.sh','w')
for each in pbss:
	pbs = os.path.join(os.path.abspath(os.curdir),each)
	print ('dsub %s' % pbs,file = shell)
	for i in range(1,int(sys.argv[-1])):
		try:
			pbs = os.path.join(os.path.abspath(os.curdir),pbss.__next__())
			print ('dsub %s' % pbs,file = shell)
		except StopIteration:
			pass







