#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import pandas as pd
import matplotlib
from functools import reduce
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib_venn
import venn
import random
import functools
from collections import defaultdict, Counter
import matplotlib.pyplot as plt
from ningchao.nSys import fix,system
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
from ningchao.nSys import trick, system, fileKit
example = ''' will merge the beds and calculate the overlap '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'beds', nargs = '+', help = 'beds for overlap' )
parser.add_argument( '-l', nargs = '+', help = 'label for the input beds, must same length compare beds if set' )
parser.add_argument( '-p', nargs = '?', help = 'parameters for the bedtools intersect', default = ' -wo ' )
parser.add_argument( '-o', nargs = '?', help = 'outputpdf name' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def printIntersections( dit ):
    out = reduce( set.intersection, (set(val) for val in dit.values()))
    for each in out :
        print ( each )

def generate_matrix():
    beds, index = kwargs.get('uniqBeds'), kwargs.get('index')
    infor = defaultdict( list )
    para, align = kwargs.get('p'), set()
    for bed in beds:
        print ( *bed, index, file = sys.stderr)
        bedfile = bed[0]
        cmd = 'bedtools intersect -a {} -b {} -wa'.format( index, bedfile)
        stdout = system.run( cmd, shell = True)
        pos = range(3)
        for line in stdout:
            key = line.rstrip()
            infor[bedfile].append( key )
    return infor


def plot_venn( infor ):
    infor = trick.dit( infor ).set()
    with open( 'venn.beds.data', 'w') as f:
        for line in trick.dit(infor).venn():
            print ( *line, sep = '\t', file = f)
    #printIntersections( infor )
    if len( infor ) <= 3 :
        set_labels = [ os.path.basename(i) for i in infor.keys() ]
        h = '''matplotlib_venn.venn%d( subsets = infor.values(), set_labels = set_labels  )''' % len( infor  )
        eval( h )
    else :
        labels = venn.get_labels( [ set([*i]) for i in infor.values() ], fill=['number', "percent"])
        h = '''venn.venn%d( labels = labels, names = infor.keys()  )''' % len( infor )
        v = eval( h )
    pdfname = fix.fix( args.o if args.o else '{}.venn.beds.pdf'.format(name) ).append('pdf')
    plt.savefig( pdfname, format = 'pdf')

def uniq_bed_lines():
    uniqBeds = []
    for bed in args.beds:
        uniq_bed, uniq_set, regions, uniq_regions = open( fix.fix(bed).append('venn.uniq.bed'), 'w' ), set(), 0, 0
        bed_min_len = 100000
        with open( bed ) as f :
            fline, seekPos = next(f), 0
            while True :
                if 'visibility' in fline :
                    seekPos += len(fline)
                    regions +=1
                    fline = next(f)
                else :
                    f.seek(seekPos)
                    break
            for line in f :
                regions +=1
                line_arr = line.rstrip().split('\t')
                key = '|||'.join(line_arr[0:3])
                length = int(line_arr[2]) - int(line_arr[1])
                if length < bed_min_len:
                    bed_min_len = length
                if key not in uniq_set:
                    uniq_regions += 1
                    #print ( *line.rstrip().split('\t')[0:3], sep='\t', file = uniq_bed)
                    print ( *line.rstrip().split('\t'), os.path.basename(uniq_bed.name)+'-|-'+str(uniq_regions), sep='\t', file = uniq_bed)
                    uniq_set.add(key)
        uniq_bed.close()
        uniq_merge_name = uniq_bed.name
        if kwargs.get('merge_source'):
            uniq_merge_name = bed_merge(uniq_bed.name)
        uniqBeds.append( [ uniq_merge_name, uniq_regions, bed_min_len] )
        print ( os.path.basename(bed), 'uniq output', uniq_merge_name, 'regions', regions, 'uniq_regions:', uniq_regions, file = sys.stderr)
    print ( uniqBeds )
    kwargs.update({'uniqBeds': uniqBeds })
    return uniqBeds

def bed_merge( *args ):
    name = ''.join(chr(random.randrange(65,90)) for i in range(6))
    index_merge_file = fix.fix(name).append('index.venn.merge.bed')
    cmd = 'cat {} | cut -f1,2,3| bedtools sort -i - | bedtools merge -i - > {}'.format( ' '.join(args), index_merge_file)
    stdout = system.run( cmd, shell = True )
    for line in stdout:
        print ( line )
    kwargs.update({ 'index': index_merge_file })
    return index_merge_file


if __name__ == '__main__':
    kwargs = vars( args )
    #build uniqBeds
    uniqBeds = uniq_bed_lines()
    index_bed = bed_merge(*[i[0] for i in uniqBeds ])
    name = ''.join(chr(random.randrange(65,90)) for i in range(6))
    #use uniqBeds build venn need data: venData
    venData = generate_matrix()
    plot_venn( venData )





























