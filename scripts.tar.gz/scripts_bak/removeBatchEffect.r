#!/usr/bin/env Rscript
#first
alen <- commandArgs()
suppressMessages(library(argparser))
p <- arg_parser('script description')
p <- add_argument(p, 'mat', help = 'matrix for removeBatchEffect ')
p <- add_argument(p, 'b', help = 'batch for each columns')
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))

data <- read.table( args$mat, sep = '\t', header = 1, check.names = 0, row.names = 1  )
batch <- unlist(strsplit( args$b,"\\,"))
dnames <- colnames( data  )
#drownames <- rownames( data )
if ( length( dnames ) != length( batch ) ){
    stop( stringr::str_interp('##Batch length ${length(batch)} ${batch} must same with colnames ${length(colnames(data))}, ${colnames( data  )}'))
}

pdf(stringr::str_interp('${args$mat}.removeBatchEffect.pdf'))
boxplot(data,main="Original", outline=FALSE )
y2 <- limma::removeBatchEffect( data, batch )
boxplot(as.data.frame(y2), main="Batch corrected", outline=FALSE)
dev.off()
fileOut <- stringr::str_interp('${args$mat}.removeBatchEffect.xls')
y2 <- round( y2, digits = 4)
write.table( data.frame( 'geneId' = rownames(y2), y2), file = fileOut, sep = '\t', row.names = FALSE, quote = FALSE)

























