#!/usr/bin/env python3
import os
import sys
import random
import argparse
import subprocess as sp
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bam', nargs = '?', help = 'bam file for split')
parser.add_argument( '-n', nargs = '?', help = 'line num for each bam', default = 10000000, type = int)
parser.add_argument( '-sn', action = 'store_true', help = 'sort by read name')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


samtools_path = system.run( 'which samtools', shell = True )[0]
header = system.run( 'samtools view -H {}'.format(args.bam), shell = True )
proc = sp.Popen( ('samtools', 'view', args.bam), stdout = sp.PIPE )
i = 0
sams = []
fhs = []
while True :
    line = proc.stdout.readline().decode().strip()
    if not i % args.n :
        rname = ''.join( random.sample( [ chr(i) for i in range(65,91) ], k = 8))
        fh = open( '{}.{}.sam'.format( rname, i ), 'w' )
        print ( *header, sep = '\n', file = fh )
        fhs.append( fh )
        if i >= 1 :
            fhs_nearest = fhs[ i// args.n -1 ]
            fhs_nearest.close()
            sams.append( fhs_nearest.name )
            #cmds = [ '/home/soft/soft/samtools/v1.10/bin/samtools', 'ls', '-lrtn']
            if 0 :
                if args.sn :
                    sortname = fix.fix( fhs_nearest.name ).change('sortByName.bam')
                    cmds = [ samtools_path, 'samtools', 'sort', '-n', fhs_nearest.name, '-o', sortname ]
                else :
                    sortname = fix.fix( fhs_nearest.name ).change('sortByCorr.bam')
                    cmds = [ samtools_path, 'samtools', 'sort', fhs_nearest.name, '-o', sortname ]
                os.spawnlp( os.P_NOWAIT, *cmds )
            if 1 :
                output_dir = fix.fix(fhs_nearest.name).append('split')
                cmds = [ "/home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh", "methylation_pipline_zhanjh.sh", fhs_nearest.name,  output_dir ]
                os.spawnlp( os.P_NOWAIT, *cmds  )
    print ( line, file = fh )

    i += 1
    if not line:
        break


[os.system('rm {}'.format(i)) for i in sams]

























