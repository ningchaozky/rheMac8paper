#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed input for prepare for the super enhancer')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
bfh = open(args.bed)
id_num = 0
lst = []

for line in bfh:
    if 'track' in line:
        continue
    if 'start' in line:
        continue
    line_arr = line.strip().split('\t')
    id_num += 1
    name = args.bed + '_' + str(id_num)
    lst.append(line_arr[0])
    lst.append(os.path.basename(name))
    lst.append('')
    lst.append(line_arr[1])
    lst.append(line_arr[2])
    lst.append('')
    lst.append('.')
    lst.append('')
    lst.append(os.path.basename(name))
    line = '\t'.join(lst)
    print(line)
    if '+' in line :
        print(line.replace('+','-'))
    elif '-' in line :
        print(line.replace('-','+'))
    lst = []


























