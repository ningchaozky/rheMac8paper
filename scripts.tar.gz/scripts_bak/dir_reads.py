#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import gzip
import argparse
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help = 'dir for reads cal')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fls = list( system.dir(args.dir).fls('_1.fq.gz', level = 10000) )
total = len( fls )
for num, fl in enumerate( fls ):
    fh = gzip.open(fl)
    sys.stderr.write('#Total %d, deal with %s, num %d\n' % (total, fl, num+1 ) )
    i = 0
    for line in fh:
        i += 1
    print('\t'.join([ fl, str(i/4) ]))






























