#!/usr/bin/env python
import ningchao.usage as uTookit
import ningchao.nSys.line as lTookit
import os
import sys

uTookit.usage('dir')

for root,dirs,files in os.walk(sys.argv[1]):
	for each in files:
		if 'MD5' in each:
			fn = os.path.abspath(os.path.join(root,each))
			work_dir = os.path.dirname(fn)
			fh = open(fn)
			first_line = fh.readline()
			name = lTookit.str_to_arr(first_line)[1].replace('_1.fq.gz','')
			name = name.replace('_2.fq.gz','')
			new_fh = open(os.path.join(work_dir,name+'.md5'),'w')
			new_fh.write(first_line)
			for fh_line in fh:
				new_fh.write(fh_line+'\n')
			new_fh.close()
			fh.close()
			print('#Done')
			print('rm %s' % fn)
