#!/usr/bin/env python
import re
import os
import sys
import ningchao.nBio.pbs as pbsTookit
from ningchao.nSys import trick, argv, system
argv.usage('q')
p = re.compile(r'\s+')
stdout, stderr, returncode = system.run('qstat -u ningch')
for each in stdout:
    each = each.decode()
    if 'ningch' in each:
        File = ''
        each_arr = p.split(each)
        infor = pbsTookit.infor([each_arr[0]])
        File= os.path.join(infor['work_dir'],infor['job name'])
        print('\t'.join(each_arr)+'\n'+File+'\n')
    else : 
        print(each, end=' ')




