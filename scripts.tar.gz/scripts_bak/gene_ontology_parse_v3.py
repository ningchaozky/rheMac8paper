#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
import argparse
from ningchao.nSys import trick,system
example = ''' v2 download dir'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs = '?', help = 'download use v2' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

fls = system.dir(args.dir).fls( pattern = 'html')
dit = {}
for fl in fls:
    fh = open(fl)
    goid = fl.replace('html.','').split('/')[-1]
    for line in fh:
        trick.dinit(dit, goid, [])
        gene = line.strip().split('\t')[2]
        dit[ goid ].append(gene.upper())
for goid in dit :
    print(goid, ','.join( trick.lst(dit[goid]).uniq() ))























