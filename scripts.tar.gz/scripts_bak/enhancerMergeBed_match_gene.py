#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import importlib
importlib.reload(sys)
import argparse
sys.setdefaultencoding('utf8')
from ningchao.nSys import trick
from ningchao.nBio import bed as Bed
example = '''mergeEnhBed Local.bed Distal.bed. local and distal should match gene first'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mbed', nargs='?', help ='enhancer merge bed')
parser.add_argument('-p', nargs='?', help ='promoter match gene bed', default = '/dataB/ftp/pub/rheMac3/prefrontal/enh/local/acAndDnase.vpromoter.merge.genes.bed')
parser.add_argument('-d', nargs='?', help ='distal match gene bed', default = '/dataB/ftp/pub/rheMac3/prefrontal/enh/distal/enhancer.genes.uniq.bed')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def intersect( mbed, bed ):
    fh, dit = Bed.bed( mbed ).intersect( bed ), {}
    for line in fh:
        line_arr = line.strip('\n').split('\t')
        key = '.'.join( line_arr[:3] )
        trick.dinit( dit, key, [])
        dit[key].extend( line_arr[6].split(',') )
    return dit

def write(mbed, pdit, ddit ):
    fh = open( mbed )
    for line in fh:
        line_arr = line.strip('\n').split('\t')
        key = '.'.join( line_arr )
        if key in pdit:
            line_arr.append( ','.join( pdit[key] ) )
        else :
            line_arr.append( '' )
        if key in ddit:
            line_arr.append( ','.join( ddit[key] ) )
        else :
            line_arr.append( '' )
        print('\t'.join( line_arr ))

if __name__ == '__main__':
    pdit = intersect( args.mbed, args.p )
    ddit = intersect( args.mbed, args.d )
    write( args.mbed, pdit, ddit )


























