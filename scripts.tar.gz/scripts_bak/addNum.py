#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = '''addNum for the index for uniq'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'matrix', nargs='?', help = '' )
parser.add_argument( '-col', nargs='+', help = 'which column for index', default = [ 1 ], type = int )
parser.add_argument( '-nah', action='store_true', help = 'header add' )
parser.add_argument( '-r', action='store_true', help = 'reverse the column' )
parser.add_argument( '-f', help = 'From second row, fit line out when meet' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()





def format( line, col, num):
    line_arr = line.strip().split('\t')
    key = '.'.join( trick.lst( line_arr  ).get( col )  )
    val = [ v for i,v in enumerate(line_arr) if i not in col  ]
    return '\t'.join( [ key+'.'+str(num), *val] )


if __name__ == '__main__':
    matrix, index, ofh = args.matrix, [ i - 1 for i in args.col ], sys.stdout
    if not args.r:
        fh = open(matrix)
        if args.nah :
            print ( format( next(fh), index, 0 ), file = sys.stderr)
        for i,line in enumerate(fh) :
            if args.f and i > 0 :
                if re.search(r'{}'.format(args.f), line):
                    print ('##Warning: ignoe {} for {}'.format(line, args.f), file = sys.stderr)
                    continue
            newline = format( line, index, i + 1)
            print ( newline, file = ofh )
    else :
        with open( matrix ) as fh:
            for line in fh:
                line_arr = line.strip().split('\t')
                keys = line_arr[0].split('.')
                line_arr = [ *keys, *line_arr[1:] ]
                print ('\t'.join(line_arr))


























