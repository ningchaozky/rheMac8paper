#!/usr/bin/env python
import os
import sys
import math
import argparse
import ningchao.nSys.fix as fixKit
import ningchao.nSys.color as colorTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='cut off peaks')
parser.add_argument('-bs', nargs='*', help ='bed|beds you want to show in ucsc browser')
parser.add_argument('-os', nargs='*', help ='output track names')
parser.add_argument('-c', nargs='*', help ='color for ucsc')
parser.add_argument('-t', choices=['view','superEnh'], default = 'view', help ='type you want bed to be')
exec(trickTookit.usage('parser'))
args = parser.parse_args()

beds = args.bs
colors = []
if not args.c :
	for i in range(len(beds)):
		colors.append(','.join([str(i) for i in colorTookit.color().random(num = 1)]))
else :
	colors = args.c


track_names = []
if args.os:
	if len(args.bs) == len(args.os):
		track_names = args.os
	elif len(args.os) == 1 :
		for i,each in enumerate(beds):
			track_names.append(args.os + '.' + str(i))
else :
	track_names = args.bs
	track_names = [ i.replace('.bed','') for i in track_names ]

def output_fl(bed,inst = 'view'):
	if bed.endswith('.bed'):
		output_fl = fixKit.insert_suff(bed,inst,-1)
	else :
		output_fl = bed + '.%s.bed' % inst
	if inst == 'superEnh':
		output_fl = output_fl.replace('.bed','.gff')
	sys.stderr.write(output_fl + '\n')
	return open(output_fl,'w')

def bed_view(beds,track_names):
	for j,bed in enumerate(beds):
		track_name = track_names[j]
		color = colors[j]
		out = output_fl(track_names[j],inst = 'view')
		bed_header = '''track name=%s description=%s visibility=2 itemRgb="On"''' % (track_name,track_name)
		out.write(bed_header+'\n')
		color_bed = colorTookit.colorBed(bed,track_name,color)
		if color_bed:
			for each in color_bed:
				out.write('\t'.join(each)+'\n')
			out.close()

def superEnh(beds):
	for j,bed in enumerate(beds):
		out = output_fl(bed,inst = 'superEnh')
		bfh = open(bed)
		prefix = bed.replace('.bed','')
		for j,line in enumerate(bfh):
			name = '%s_%d' % (prefix,j)
			if 'track' in line:
				continue
			line_arr = line.strip().split('\t')
			line_arr = line_arr[0:3]
			line_arr.insert(1,name)
			line_arr.insert(2,'')
			line_arr.append('')
			line_arr.append('.')
			line_arr.append('')
			line_arr.append(name)
			out.write('\t'.join(line_arr) + '\n')
if __name__ == '__main__':
	if args.t == 'view':
		bed_view(beds,track_names)
	if args.t == 'superEnh':
		superEnh(beds)
