#!/usr/bin/env python
import os 
import sys

if len(sys.argv) <= 1:
	print(sys.argv[0],'project.ini','start')
	exit()


ini = open(sys.argv[1])
parameters = {}

if len(sys.argv) >= 3:
	start = 1


def para(string,keyword,dictname):
	tmp = string.replace(keyword,'',1)
	tmp = tmp.replace('=','')
	tmp = tmp.strip()
	dictname[keyword] = tmp

for each in ini:
	each = each.strip()
	each_arr = each.split(' ')
	if each.startswith('project'):
		para(each,'project',parameters)
	if each.startswith('gtf'):
		para(each,'gtf',parameters)
	if each.startswith('work_dir'):
		para(each,'work_dir',parameters)
	if each.startswith('species'):
		para(each,'species',parameters)
	if each.startswith('sample'):
		para(each,'sample',parameters)
	if each.startswith('group'):
		para(each,'group',parameters)
	if each.startswith('backgroud_pair'):
		para(each,'backgroud_pair',parameters)
	if each.startswith('project'):
		para(each,'project',parameters)
	if each.startswith('compare'):
		para(each,'compare',parameters)
	if each.startswith('raw_data_dir'):
		para(each,'raw_data_dir',parameters)
	if each.startswith('map_index'):
		para(each,'map_index',parameters)
	if each.startswith('genome'):
		para(each,'genome',parameters)

samples = parameters['sample'].split(',')


#Trim
trim = open('trim.sh','w')
cmd = 'mkdir -p %s/Map'  % parameters['work_dir']
print(cmd, file=trim)
if not os.path.exists('%s/Map' % parameters['work_dir']):
	if start:
		os.system('cmd')
for each in samples:
	tmp_dir = os.path.join(parameters['work_dir'],'Map',each)
	tmp_read_prefix = os.path.join(parameters['raw_data_dir'],each)
	cmd = 'mkdir -p %s/Map/%s'  % (parameters['work_dir'],each)
	cmd += '\njava -jar /home/ningch/soft/Trimmomatic-0.33/trimmomatic-0.33.jar PE -threads 8 -trimlog %s/trimmomatic.log  %s_1.fastq %s_2.fastq %s/1P.fq %s/1U.fq %s/2P.fq %s/2U.fq \
	ILLUMINACLIP:/home/ningch/soft/Trimmomatic-0.33/adapters/customed_adapter.fa:2:30:10  MINLEN:36 2>%s/clipad.txt\n\n' % (tmp_dir,tmp_read_prefix,tmp_read_prefix,tmp_dir,tmp_dir,tmp_dir,tmp_dir,tmp_dir)
	print(cmd, file=trim)
#	if start:
#		os.system(cmd)
trim.close()


#Maping
map_cmd = open('mapping.sh','w')
for each in samples:
	tmp_dir = os.path.join(parameters['work_dir'],'Map',each)
	raw_read_dir = os.path.join(parameters['raw_data_dir'])
	cmd = '/home/ningch/soft/bowtie2-2.2.9/bowtie2 -p 8 -x %s -1 %s/1P.fq -2 %s/2P.fq -S %s/mapped.sam 2> %s/mapping.rate' % (parameters['map_index'],tmp_dir,tmp_dir,tmp_dir,tmp_dir)
	cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools view -Sb %s/mapped.sam > %s/mapped.bam' % (tmp_dir,tmp_dir)
	cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools sort %s/mapped.bam -o %s/mapped.sorted.bam' % (tmp_dir,tmp_dir)
	cmd += '\n/home/ningch/soft/samtools-1.3.1/samtools index %s/mapped.sorted.bam' % tmp_dir
	cmd += '\n#rm %s/mapped.bam' % tmp_dir
	cmd += '\n#Mapping reads counts'
	cmd += '\n#raw=$[$(wc -l %s/%s_1.fastq)/4]' % (raw_read_dir,each)
	cmd += '\n#/home/ningch/soft/bedtools/bamToBed -i %s/mapped.sorted.bam > %s/mapped.sorted.bed' % (tmp_dir,tmp_dir)
	cmd += '\n#awk -vRAW=$raw -vSAMPLEFILE=%s -vOFS=\'\\t\' \'{coordinates=$1":"$2"-"$3;total++;count[coordinates]++}END{for(coordinates in count){if(!max||count[coordinates]>max){max=count[coordinates];maxCoor= coordinates};if(count[coordinates]==1){unique++}}; print SAMPLEFILE,RAW*2,total,total*50/RAW,unique,unique*50/RAW,total-unique,(total-unique)*50/RAW}\' %s/mapped.sorted.bed >> %s/read.count.txt' % (each,tmp_dir,tmp_dir)
	cmd += '\n#Plot figure of reads density'
	cmd += '\n#cd %s' % tmp_dir
	cmd += '\n#perl /home/ningch/soft/ChIP_seq/scripts/Map/circos_for_reads_density.pl -a %s -b %s/mapped.sorted.bam -c 1-20 -o reads.density' % (parameters['genome'],tmp_dir)
	cmd += '\n\n\n\n'
	print(cmd, file=map_cmd)
map_cmd.close()

#peakcalling
groups = parameters['group'].split('~')
grp,comp,bg = {},{},{}
for each in groups:
	each_sp = each.split(':')
	grp[each_sp[0]] = each_sp[1].split(',')

backgroud_pair = parameters['backgroud_pair'].split('~')
for each in backgroud_pair:
	each_arr = each.split(':')
	bg[each_arr[0]] = each_arr[1]


#each sample
peak_calling_shell = open('peak_calling.sh','w')
for each in bg:
	cmd = '\n#Peak calling'
	map_dir = os.path.join(parameters['work_dir'],'Map')
	smp,ctr = '',''
	tmp_dir = os.path.join(parameters['work_dir'],'peak_calling',each)
	cmd += '\nmkdir -p %s; cd %s' % (tmp_dir,tmp_dir)
	for samp in grp[each]:
		smp += '%s/mapped.sam ' % (os.path.join(map_dir,samp))
	for bg_each in grp[bg[each]]:
		ctr += '%s/mapped.sam ' % (os.path.join(map_dir,bg_each))
	if not os.path.exists('%s.fai' % parameters['genome']):
		cmd += '\nsamtools faidx %s' % parameters['genome']
	cmd += '\nmacs2 callpeak -t %s -c %s -n %s -f SAM -g mm -m 5 50 -p 1e-5 --broad -B' % (smp,ctr,each)
	cmd += '\nawk \'{if(($1!~/#/) && ($1!~/chr/)) print $1"\\t"$2"\\t"$3"\\t"$10}\' %s_peaks.xls | sed \'1d\' > %s_peaks.bed' % (each,each) 
	cmd += '\n\n## Plot peak length figure ##'
	cmd += '\nperl /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/peak_length.pl %s_peaks.xls > %s_peaks.length' % (each,each)
	cmd += '\nRscript /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/Peaklength.R %s_peaks.length %s_peak.length' % (each, each)
	cmd += '\n\n## Plot peak genome distribution figure ##'
	cmd += '\nperl /home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/circos_for_peak_density.pl -a %s -b %s_peaks.xls -c 1-20 -o  %s.peak.distribution' % (parameters['genome'],each,each)
	cmd += '\nsort -k1,1 -k2,2n %s_treat_pileup.bdg > %s_treat_pileup.bedGraph' % (each,each)
	cmd += '\nsort -k1,1 -k2,2n  %s_control_lambda.bdg > %s_control_pileup.bedGraph' % (each,each)
	cmd += '\n/home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/bedGraphToBigWig %s_treat_pileup.bedGraph %s.fai %s.bigWig' % (each,parameters['genome'],each)
	cmd += '\n#/home/ningch/soft/ChIP_seq/scripts/Peak_calling/script/bedGraphToBigWig %s_control_pileup.bedGraph %s.fai %s.bigWig' % (each,parameters['genome'],each)
	cmd += '\n\n\n'
	print(cmd, file=peak_calling_shell)
peak_calling_shell.close()

compare = parameters['compare'].split('~')
for each in compare:
	each_arr = each.split('_vs_')
	cmd += '\nmkdir %s' % each_arr[0]
	cmd += '\ncd %s' % each_arr[0]
#	print bg[each_arr[0]]
#	print bg[each_arr[1]]
	cmd += '\nmkdir %s' % each_arr[1]
	cmd += '\nmkdir %s' % each
#	tmp_dir = os.path.join(parameters['work_dir'],each)
#	cmd += '\nmkdir %s\ncd %s' % (tmp_dir,tmp_dir)
#	print cmd
















