#!/usr/bin/env Rscript
#first
alen <- commandArgs()
library(argparser)
library(reshape2)

p <- arg_parser('degseq2_raw.R -i PFC.CTCF.bed.raw  -in 1,2,3 -g X45Y.PFC.CTCF.rep2.0,X45Y.PFC.CTCF.rep1.0~E120.PFC.CTCF.rep2.0,E120.PFC.CTCF.rep1.0 -n 45Y~E120 -o PFC.CTCF.45vs120.tab
')
p <- add_argument( p, "--input",short = '-i', help="input tab separtor file")
p <- add_argument( p, "--index", short = '-in', help="index col for input file")
p <- add_argument( p, "--group", short = '-g', help="1,2,3~4,5,6. colunms names compare" )
p <- add_argument( p, "--name", short = '-n', help="name1~name1." )
p <- add_argument( p, "--type", short = '-t', help="sequence type", default = 'paired-end')
p <- add_argument( p, "--pvalue", short = '-p', help="pvalue. 0.05", default = 0.05)
p <- add_argument( p, "--foldchange", short = '-fc', help="fold change. 1.5", default = 1.5)
p <- add_argument( p, "--out", short = '-o', help="output file for diff" )
if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
argv <- parse_args(p)

cts <- read.table(argv$input,sep="\t", header = 1, check.names=FALSE)

if ( is.na(argv$group) | is.na(argv$name) ){
	print(names(cts))
	stop('please input group like: X45Y.PFC.CTCF.rep2.0,X45Y.PFC.CTCF.rep1.0~E120.PFC.CTCF.rep2.0,E120.PFC.CTCF.rep1.0')
}

if (is.na(argv$name)){
	stop('please input name for your compare')
}


#cat(argv$group)
pvalue <- as.numeric(argv$pvalue)
fc <- as.numeric(argv$foldchange)
group <- unlist(strsplit(argv$group,'~'))
subcol <- strsplit(group,',')
names(subcol) <- unlist(strsplit(argv$name,'~'))
index_col <- as.numeric(unlist(strsplit(argv$index,',')))
if (length(index_col) > 1 ){
	paste_args <- c(cts[, index_col], sep = "\t")
	rownames(cts) <- do.call(paste, paste_args)
}else {
	rownames(cts) <- cts[, index_col]
}
cts <- cts[,-index_col]
cts_sub <- cts[, unlist(subcol)]
colData <- as.data.frame(unlist(subcol))
colData$condition <- substr(rownames(colData),1, nchar(rownames(colData))-1)
colData$type <- argv$type
rownames(colData) <- unlist(subcol)
colData <- colData[,-1]
library(DESeq2)
print (colData)
dds <- DESeqDataSetFromMatrix(countData = cts_sub,
                              colData = colData,
                              design = ~ condition)

dds <- DESeq(dds)
#resultsNames(dds)
res <- results(dds, alpha=pvalue)
summary(res)
# 获取padj（p值经过多重校验校正后的值）小于0.05，表达倍数取以2为对数后大于1或者小于-1的差异表达基因。
table(res$padj<0.05) #取P值小于0.05的结果
res <- res[order(res$padj), ]
diff_gene_deseq2 <-subset(res, padj < 0.1 & ( log2FoldChange > 0.6 | log2FoldChange < - 0.6 ) )
diff_gene_deseq2 <- row.names(diff_gene_deseq2)
resdata <-  merge(as.data.frame(res),as.data.frame(counts(dds,normalize=FALSE)),by="row.names",sort=FALSE)
# 得到csv格式的差异表达分析结果
write.table(resdata,file=argv$out,row.names = F,quote = FALSE,sep = "\t")
write.table(as.data.frame(diff_gene_deseq2),file=paste(argv$out,'.pick',sep =''),row.names = F,quote = FALSE,sep = "\t")

