#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('xenoRefSeqGene', nargs = '?', help = 'xenoRefSeqGene txt file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parameter_parse( p ):
    return '{}.sql'.format( p ), '{}.txt'.format( p )

def gtitle( sql ):
    out = []
    gfh = open( sql )
    for line in gfh:
        obj = re.match(r'^\s+`(\w+)`', line)
        if obj:
            out.append( obj.group(1) )
    sys.stderr.write( str( out ) +'\n')
    return out

def main( title, txt):
    fh = open( txt )
    for line in fh:
        if '[(' in line or 'chrUn' in line:
            continue
        line_arr = line.rstrip().split('\t')
        line_infor = dict( zip( title, line_arr ) )
        gene_id, strand, chrom = line_infor['name'], line_infor['strand'], line_infor['chrom']
        tStarts, blockSizes = line_infor['exonStarts'].strip(',').split(','), line_infor['exonEnds'].strip(',').split(',')
        for start, end in zip( tStarts, blockSizes):
            print ( gene_id, chrom, start, end, strand, sep = '\t')


if __name__ == '__main__':
    sql, txt = parameter_parse( args.xenoRefSeqGene )
    title = gtitle( sql )
    main( title, txt )


























