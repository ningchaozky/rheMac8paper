#!/usr/bin/env Rscript


args <- commandArgs()

library(ggplot2)
if (length(args) < 5){
	cat ("#Usage:",sub(".*=","",args[4],perl=T),"file:figData str: output_prefix\n");
}else{
	figData <- read.table(args[6],header = T, sep = "\t")
	colo <- rainbow(10000)
	colfunc <- colorRampPalette(c("white","blue","green","orange","black"))
	colo <- colfunc(100)
	coustom_theme <- theme(panel.grid.major = element_line(colour = "NA"),panel.grid.minor = element_line(colour = "NA"),
	panel.background = element_rect(fill = "NA", colour = "black",linetype = "solid"))
	p <- ggplot(figData, aes(pos, signal)) + geom_point(aes(colour = numbers), size = 0.6) + scale_colour_gradientn(colours = colo) + coustom_theme
	name <- paste(args[7],'.pdf',sep = '')
	ggsave(file=name,plot = p)


}





