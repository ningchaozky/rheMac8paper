#!/usr/bin/env bash

if [ $# == 0 ];
then
	echo "$0 olddb newdb"
	exit
fi

mysqlconn="mysql"
old_db=$1
new_db=$2
$mysqlconn -e "CREATE DATABASE $new_db"
params=$($mysqlconn -N -e "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE table_schema='$old_db'")
for name in $params; do
$mysqlconn -e "RENAME TABLE $old_db.$name to $new_db.$name";
done;
$mysqlconn -e "DROP DATABASE $old_db"
