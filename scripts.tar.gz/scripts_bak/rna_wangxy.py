#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
mpl.use('Agg')
import argparse
from collections import defaultdict
from ningchao.nSys import trick
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'xls', nargs='?', help = 'excel for input reads')
parser.add_argument( 'mean', nargs='?', help = 'mean lenght for the gene' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def get_length():
    infor = defaultdict( int )
    with open( args.mean ) as f:
        for line in f :
            line_arr = line.strip().split('\t')
            gene = line_arr[0].upper()
            infor[gene] = int( line_arr[1] )
    return infor

glen = get_length()
with open ( args.xls ) as f :
    header = next(f).strip().split('\t')
    print ( *header, 'mean', sep = '\t' )
    for line in f :
        line_arr = line.strip().split('\t')
        symbol = line_arr[0].upper()
        if glen.get( symbol ):
            print ( *line_arr, glen[ symbol ], sep = '\t' )


























