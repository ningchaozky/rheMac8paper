#!/usr/bin/env python
import sys
import os

def usage():
	print('\n\tUsage:',sys.argv[0],'title,col','xls,col\n')
	exit()
if len(sys.argv) <= 1:
	usage()


arg1 = sys.argv[1].split(',')
arg2 = sys.argv[2].split(',')

tcol = 0
if len(arg1) == 2:
	tcol = int(arg1[1]) - 1

xcol = 0
if len(arg2) == 2:
	xcol = int(arg2[1]) - 1

title_file = open(arg1[0])
xls_file = open(arg2[0])

title_list = []
for title_line in title_file:
	ttmp = title_line.strip().split('\t')
	title_list.append(ttmp[tcol])


for xls_line in xls_file:
	xtmp = xls_line.strip().split('\t')
	if xtmp[xcol] in title_list:
		sys.stdout.write(xls_line)
