#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import geneKit as gene
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'Tss', nargs='?', help ='can inclue other field' )
parser.add_argument( '-typ','-t', choices = ['tss','updown'], help ='tss file', default = 'tss')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

typ = args.typ
if typ == 'tss':
    dit = gene.infor().tss()
elif typ == 'updown':
    dit = gene.infor(sp = 'rh8').updown()
bed = open(args.Tss)
header = bed.next().strip().split('\t')
header.insert(3,'gene')
print('\t'.join(header))
counter = {}
for line in bed:
    line_arr = line.strip().split('\t') 
    chrom = line_arr[0]
    tss = str((int(line_arr[1]) + int(line_arr[2]))/2)
    key = '\t'.join([chrom,tss])
    trick.set1dict(counter,key,-1)
    counter[key] += 1
    gene = dit[key][-1][counter[key]]
    line_arr.insert(3,gene)
    print('\t'.join(line_arr))
























