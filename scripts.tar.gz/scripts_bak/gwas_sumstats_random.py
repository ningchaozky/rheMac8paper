#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import random
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('Input', nargs = '?', help = 'reference')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

fh = open( args.Input )
print(next(fh), end=' ')
for line in fh:
    line_arr = line.strip('\n').split('\t')
    if line_arr[3]:
        line_arr[3] = str( round(random.uniform(0, 9), 4) )
    print('\t'.join( line_arr )) 
    


























