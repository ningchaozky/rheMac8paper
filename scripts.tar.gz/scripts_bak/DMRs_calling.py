#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, status, fix, system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'cov1', nargs='?', help ='cov5 for compare' )
parser.add_argument( 'cov2', nargs='?', help = 'cov5 for compare' )
parser.add_argument( '-outputdir','-o', nargs='?', help = 'outputdir', default = '.' )
parser.add_argument( '-outputname','-n', nargs='?', help = 'output name for prefix' )
parser.add_argument( '-span','-s', nargs='?', help = 'span for merge', default = 4000000, type = int )
parser.add_argument( '-force','-f', nargs='*', help = 'force step', default = ['all'] )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



#preDMS
def preDMS():
    print ('preDMS ...', file = sys.stderr)
    cmds = []
    ### notice: bed1 are write behind bed2 in the output file
    outputname = kwargs.get('outputname') and kwargs.get('outputname') or '.'.join([ args.cov1, args.cov2 ])
    outputname = fix.fix(outputname).append( 'preDMS' )
    cmd = 'MatchingToGet.pl {} {} > {}'.format( *[os.path.abspath(i) for i in ( args.cov1, args.cov2)], outputname )
    cmd = status.cmd(wd = args.outputdir, **kwargs).accessory( cmd, flag = outputname )
    print( cmd )
    tmp = fix.fix(outputname).append('tmp')
    cmd = 'cut -f1,2,3,4,5,6,10,11,12 {} > {} && mv {} {}'.format( outputname, tmp, tmp, outputname )
    cmd = status.cmd(wd = args.outputdir, **kwargs).accessory( cmd, flag = tmp )
    print( cmd )
    kwargs.update({'preDMS': outputname})
    return kwargs


def split_DMS_pvalue():
    print ('split_DMS_pvalue ...', file = sys.stderr)
    cmd = 'split_DMS_pvalue.sh {} -n {}'.format( kwargs.get('preDMS'), kwargs.get('span') )
    cmd = status.cmd( wd = kwargs.get('outputdir'), **kwargs).accessory( cmd, flag = 'split_DMS_pvalue.sh' )
    print ( cmd )

def merge_DMS_qvalue():
    print ('merge_DMS_qvalue ...', file = sys.stderr)
    cmd = 'merge_DMS_qvalue.sh {}'.format( kwargs.get('preDMS') )
    cmd = status.cmd( wd = kwargs.get('outputdir'), **kwargs).accessory( cmd, flag = 'merge_DMS_qvalue.sh' )
    print ( cmd )
    kwargs.update({'qvalue': 'all.DMS.qvalue'})

def Get_DMR_From_DMS():
    print ('Get.DMR_From.DMS ...', file = sys.stderr)
    cmd = 'Get.DMR_From.DMS.sh {} {} {}'.format( os.path.abspath(args.cov1), os.path.abspath(args.cov2), kwargs.get('qvalue'))
    cmd = status.cmd( wd = kwargs.get('outputdir'), **kwargs).accessory( cmd, flag = 'Get.DMR_From.DMS.sh' )
    print( cmd )

if __name__ == '__main__':
    kwargs = vars( args )
    kwargs = preDMS()
    split_DMS_pvalue()
    merge_DMS_qvalue()
    Get_DMR_From_DMS()




















