#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help = 'ukm_chr2_3mb_control_vs_patient_chess_results.tsv')
parser.add_argument('wbb', nargs='?', help = 'hg38_chr2_3mb_win_100kb_step.bed')
parser.add_argument('-cut', nargs='+', help = 'cutoff list for matrix. SN,>0.5, z_ssim,<-1', required = True )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def parse( args ):
    cut = {}
    for each in args.cut:
        earr = each.split(',')
        trick.dinit( cut, earr[0], earr[1] )
    return args.mat, cut, args.wbb

def check( dit, cut ):
    i = 0
    for key in cut:
        cmd = 'float(%s)%s' % (dit[key], cut[key])
        if eval( cmd ):
            i += 1
    return i == len( cut )

def get_bins( mat ):
    bins = []
    fh = open( mat )
    header = next( fh ).strip().split('\t')
    trick.write( header, sys.stderr)
    for line in fh:
        if 'nan' in line:
            continue
        line_arr = line.strip().split('\t')
        dit = dict( zip( header, line_arr ) )
        if check( dit, cut ):
            bins.append( line_arr[0] )
            trick.write( line_arr, sys.stderr )
    return bins


if __name__ == '__main__':
    mat, cut, bedpe = parse( args )
    bins = get_bins( mat )
    bfh = open( bedpe )       
    for i,line in enumerate(bfh):
        if str(i) in bins:
            print ( line.strip() )





























