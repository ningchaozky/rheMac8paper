#!/usr/bin/env python3
import os
import sys
import math
import argparse
from ningchao.nSys import trick, system
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'd', nargs = '?', help = 'directory for find files')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()





def find_distribution():
    #infor = defaultdict( lambda : defaultdict ( lambda : defaultdict ( list ) ) )
    infor = defaultdict( lambda : defaultdict(  list ) )
    for stat_file in system.dir( args.d ).detail_fls('_12_segments.bed', sort = ['peirod','/','_']):
        peirod = system.dir.str_map_peirod( stat_file, up = '/', down = '_', rawPeirod = True, log = True )
        with open( stat_file ) as f :
            for line in f :
                line_arr = line.rstrip().split('\t')
                chrom,start,end,stat = line_arr
                length = int( end ) - int( start )
                infor[stat][peirod].append( length )
    return infor

if __name__ == '__main__':
    stat_length = find_distribution()
    fig, ax = plt.subplots( len(stat_length), figsize=(10,30), sharex=True, sharey=True )
    for i,stat in enumerate(stat_length):
        print ( stat )
        labels, data = [*zip(*stat_length[stat].items())]
        ax[i].boxplot(data)
        ax[i].title.set_text( stat )
    plt.xticks(range(1, len(labels) + 1), labels)
    plt.savefig( 'test.pdf', dpi=250, transparent=True, edgecolor='none')
























