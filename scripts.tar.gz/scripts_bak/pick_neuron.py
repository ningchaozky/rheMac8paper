#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s neuron.bed xenoRefGene.exon.hg.bed' % sys.argv[0], formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('neuron', nargs='?', help ='neuron.bed')
parser.add_argument('exon', nargs='?', help ='xenoRefGene.exon.hg.bed')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

neuron = args.neuron
exon = args.exon


def get(line, postab = 3, sep = '.', pos = 0):
    line_arr = line.strip().split('\t')
    out = line_arr[postab].split(sep)[pos]
    return out.upper()
genes = []
nfh = open(neuron)
for line in nfh:
    gene = get(line)
    if gene not in genes:
        genes.append(gene)

nfh.close()
efh = open(exon)
for line in efh:
    gene = get(line)
    if gene in genes:
        print(line, end=' ')
efh.close()



















