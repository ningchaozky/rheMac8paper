#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'pattern', nargs = '?', help = 'pattern for find bam')
parser.add_argument( '-dir', nargs = '?', help = 'dir for find', default = '.')
parser.add_argument( '-ref', nargs = '?', help = 'refSeq.gtf', default = '/home/soft/data/genome/hg19/gencode.v19.chr_patch_hapl_scaff.annotation.gtf')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



bams = list(system.dir(args.dir).fls( args.pattern, level = 1))

template = '''featureCounts -a {} -F SAF -p -s 0 -T 6 -P -o {} {}'''.format( args.ref, 'all.reads', ' '.join( bams))
#template = '''featureCounts.r -g {} -o {} -s {}'''.format( args.ref, 'all.reads', ' '.join(bams))
print ( template )

#% (gtf,each, out + '.' + each, am )'''
#count_cmd_2 = status.cmd_accessory(work_dir,flag +'.featureCount.%s' % each ,count_cmd_2,upper_infor = upperInfor)



























