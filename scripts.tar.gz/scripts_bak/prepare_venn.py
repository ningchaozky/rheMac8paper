#!/usr/bin/env python
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('-k', nargs='+', help ='key words for include in file name')
parser.add_argument('-T', action='store_true', help ='key words for include in file name')
parser.add_argument('-g', nargs='*', default = 'rheMac3', help ='genome for bw')
parser.add_argument('-x', nargs='+', help ='reference')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
print(args.k)
print(args.g)

