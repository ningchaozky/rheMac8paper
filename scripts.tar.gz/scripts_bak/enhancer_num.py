#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('addNum', nargs='?', help = 'gene enhancer list')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


afh = open( args.addNum )
header, infor = afh.next().strip().split('\t'), {}
for line in afh:
    line_arr = line.strip().split('\t')
    dit = dict(list(zip(header,line_arr)))
    dit.pop('gene')
    peirod = sorted(list(dit.items()), lambda x, y: cmp(float(x[1]), float(y[1])), reverse = True )[0][0]
    key = line_arr[0].split('.')
    key.pop(-1)
    key1 = '.'.join(key)
    key2 = key[0]
    trick.dit(infor).set( peirod, key2, key1, 0 )
    infor[peirod][key2][key1] += 1

fig_infor = {}
for peirod in infor:
    #lst = sorted(infor[peirod].items(), lambda x, y: cmp(float(x[1]), float(y[1])), reverse = False )
    for gene in infor[ peirod ]:
        max_interaction = sorted( list(infor[ peirod ][ gene ].items()), lambda x, y: cmp(float(x[1]), float(y[1])), reverse = True )[0]
        enhancer_num = max_interaction[1]
        if enhancer_num > 20 :
            sys.stderr.write( gene + '\n' )
        trick.dit(fig_infor).set(peirod, str(enhancer_num), 0 )
        fig_infor[peirod][str(enhancer_num)] += 1

for peirod in fig_infor:
    lst = sorted(list(fig_infor[peirod].items()), lambda x, y: cmp(float(x[0]), float(y[0])), reverse = False )
    fh = open(peirod, 'w')
    fh.write('enhancer_number' + '\t' + 'gene_num\n')
    for each in lst:
        fh.write('\t'.join([ str(i) for i in list(each)]) + '\n')
    fh.close()

























