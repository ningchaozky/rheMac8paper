#!/usr/bin/env python
import os
import sys


if len(sys.argv) <= 1:
	print(sys.argv[0],'str:hg38')
	exit()

if 'gbdb' not in sys.argv[1:]:
	if len(sys.argv[1:]) == 1 :
		prefix = 'rsync -avzP rsync://hgdownload.cse.ucsc.edu/mysql/'
		content = ['trackDb','hgFindSpec','chromInfo','gap','refGene','all_est','refSeqAli','ncbiRefSeq','ncbiRefSeqOther','refFlat','refLink','xenoRefGene','xenoRefSeqAli']
		for db in sys.argv[1:]:
			desDir = '/home/mysql_data/mysql/mysql/%s' % db
			if not os.path.exists(desDir):
				print('mkdir -p %s' % desDir)
			for each in content:
				myi = '.'.join([each,'MYI'])
				myd = '.'.join([each,'MYD'])
				frm = '.'.join([each,'frm'])
				db_need = [myi, myd, frm]
				for db_each in db_need:
					string = ('/'.join([prefix,db,db_each]) + ' %s' % desDir).replace('//','/').replace('rsync:/','rsync://')
					print(string)
	elif len(sys.argv[1:]) >= 2 :
		prefix = 'rsync -avzP rsync://hgdownload.cse.ucsc.edu/mysql/'
		db = sys.argv[1]
		desDir = '/home/mysql_data/mysql/mysql/%s' % db
		for each in sys.argv[2:]:
			myi = '.'.join([each,'MYI'])
			myd = '.'.join([each,'MYD'])
			frm = '.'.join([each,'frm'])
			db_need = [myi, myd, frm]
			for db_each in db_need:
				string = ('/'.join([prefix,db,db_each]) + ' %s' % desDir).replace('//','/').replace('rsync:/','rsync://')
				if os.path.exists(os.path.join(desDir,db_each)):
					print('!!! already download %s' % os.path.join(desDir,db_each))
					continue
				print(string)
			
else :
	for each in sys.argv[1:]:
		if 'gbdb' == each:
			continue
		dirname = os.path.dirname(each)
		if not os.path.exists(dirname):
			print('mkdir -p %s' % dirname)
		print(('rsync -avzP rsync://hgdownload.cse.ucsc.edu/%s' % each + ' %s' % each).replace('//','/').replace('rsync:/','rsync://'))
