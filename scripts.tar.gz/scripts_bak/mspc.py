#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nBio.rheMac as rhKit
import ningchao.nSys.env as envKit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep, description='merge biological replicate together')
parser.add_argument('-reps', nargs='+', type = str, help ='replicates', required = True )
parser.add_argument('-t', choices =['Biological','Technical'], default = 'Biological', help ='Biological|Technical')
parser.add_argument('-w', nargs='?', type = float, default = 0.1, help ='Sets weak threshold. 0.1, good for broad')
parser.add_argument('-s', nargs='?', type = float, default = 0.001, help ='Sets stringency threshold. 0.001, good for broad')
parser.add_argument('-pt', nargs='?', type = str, help ='peaks type. broad|peak, default broad', default = 'broad')
parser.add_argument('-n', nargs='?', type = str, help ='merge bed name in ftp server. guess from the pwd dir')
parser.add_argument('-m', choices=['Lowest','Highest'], type = str, help ='Sets the default peak to be used when multiple peaks from one sample intesect with a given peak. Possible values are: { Lowest, Highest }. Lowest|Highest, default broad', default = 'Highest')
parser.add_argument('-sys', action='store_true', help='excute?')


if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

reps = args.reps
#pretreatment to adaptor mspc
dstr = ['#','fold_enrichment','chrMT']

reps_arr = []

bed_name = []
bed_names = iter(os.path.abspath(os.getcwd()).split('/'))
for each in bed_names:
	if each == 'rawdata':
		bed_name.append(next(bed_names))
		bed_name.append(next(bed_names))
		bed_name.append(next(bed_names))



for rep in reps:
	fh = open(rep)
	rep_arr = rep.split('.')
	if 'rep1' in rep_arr:
		bed_name.append('rep1')
	if 'rep2' in rep_arr:
		bed_name.append('rep2')
	pretreat_tmp = rep + '.pretreat.tmp'
	reps_arr.append(pretreat_tmp)
	ofh = open(pretreat_tmp,'w')
	print('#pretreatment the replicate %s' % rep)
	for line in fh:
		line = line.strip()
		if line != '':
			if not trKit.lstInStr(dstr, line.strip(),typ = 'or'):
				line_arr = line.split('\t')
				out_line_arr = line_arr[0:3]
				out_line_arr.append(line_arr[8])
				out_line_arr.append(line_arr[5])
				ofh.write('\t'.join(out_line_arr) + os.linesep)
	ofh.close()
	
cmds = ['mono /pnas/liujiang_group/ningch/soft/MSPC_v2.2/MSPC.exe']
cmds.append('-i ' + ' -i '.join(reps_arr))
cmds.append('-m %s' % args.m)
cmds.append('-r %s' % args.t)
cmds.append('-w %s' % args.w)
cmds.append('-s %s' % args.s)

bed_name = '.'.join(bed_name)
bed_name = rhKit.short(bed_name)
print(bed_name)
#bed_name = bed_name.replace('.bed.bed','.bed')
cmd_line = ' '.join(cmds)
print(cmd_line)
if args.sys:
	os.system(cmd_line)
	os.system('bed_view.py -bs Session_01/MergedReplicates.bed -os %s' % bed_name)
	if not bed_name.endswith('.bed'):
		bed_name = bed_name + '.bed'
	os.system('bw_view.py -f %s -n %s -s -force' % (bed_name,bed_name))















