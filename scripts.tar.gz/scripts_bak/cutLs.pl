#!/usr/bin/perl -w

######################################################
#This script is aimed at extracting sequences wanted #
#with names listed in query file from the original   #
#file containing multi-FASTA sequences               #         
######################################################
use strict;
use Getopt::Long;


my $query;
my $target;
my $out;
#my $remained;
my $mode;
my $help;

GetOptions("q=s" => \$query,
           "t=s" => \$target,
           "o=s" => \$out,
           #"r=s" => \$remained,
           "m=i" => \$mode,
           "help|h" => \$help);
           
           
           
if( $help ) {
  print STDERR << "EOF";
Usage:
  perl $0
          -q  query file containing header information to be extracted
          -t  target file containing multiple FASTA-format sequences
          -o  output file          
          -m  1: in the same order as that in query file  2: search speed priority and memory-saving
          -h  print help info
EOF
  exit();
          	
}


if($mode == 1) {
  &extractSequenceByHeader($target,$query,$out);         ## order priority
} else {
  &AltextractSequenceByHeader($target,$query,$out);   ## less memory assumption
}


#
#subroutine for extracting sequences
#
sub extractSequenceByHeader{
  my ($in,$query,$outfile) = @_;
  my @header = ();
  open QUERY,"<$query" || die "Cannot open this file!$!";
  while(<QUERY>) {
    chomp;
    push @header,$_;
  }
  
  close QUERY;
  
  open IN,"<$in" || die "Cannot open this file!$!";
  my %sequence;
  my $name;
  while(<IN>) {
    chomp;
    if(/^>(\S+)/) {
    	$name = $1;
    }	
    if(/^\w+/) {
      $sequence{$name} .= $_;	
    }
  }
  
  close IN;
  
  open OUT,">",$outfile || die "Cannot write to this file!$!";
  
  #open REMAIN,">",$remainfile || die "Cannot write to this file!$!";
  
  #foreach my $key(keys %sequence) {
   # if(isExisted($key,\@header)) {
   #   &writeToFile($key,$sequence{$key},*OUT);	
   # }	
    #else {
      #&writeToFile($key,$sequence{$key},*REMAIN);	
    #}
  #}
  
  foreach my $i(0..$#header) {
  	if(defined $sequence{$header[$i]}) {
      &writeToFile($header[$i],$sequence{$header[$i]},*OUT);	
    }
  }
  
  close OUT;
  
  #close REMAIN;
  	
}


#
#alternative sequence extracter subroutine
#
sub AltextractSequenceByHeader{
  my ($in,$query,$outfile) = @_;
  my %header = ();
  open QUERY,"<$query" || die "Cannot open this file!$!";
  while(<QUERY>) {
    chomp;
    $header{$_} = 1;	
  }
  
  close QUERY;
  
  open IN,"<$in" || die "Cannot open this file!$!";
  open OUT,">",$outfile || die "Cannot write to this file!$!";
  
  #open REMAIN,">",$remainfile || die "Cannot write to this file!$!";
  
    #my %sequence;
  my $name;
  while(<IN>) {
    chomp;
    pos1:
    if(/^>(\S+)/) {
    	if(defined $header{$1}) {
    	  print OUT "$_\n";
    	  while(<IN>) {
    		  chomp;
    	    if(/^\w+/) {
            print OUT "$_\n";
          
          }	
          if(/^>/) {
            goto pos1;	
          }
        }
      } 
      #else {
      #  print REMAIN "$_\n";
      #  while(<IN>) {
      #    chomp;
      #    if(/^\w+/) {
      #      print REMAIN "$_\n";	
      #    }	
      #    if(/^>/) {
      #      goto pos1;	
      #    }
      #  }	
      #}	
      
    }
  }
  
  close IN;  
  
  close OUT;
  #close REMAIN;
  
  	
}

#
#subroutine for writing sequence into a specified file in fasta-format
#
sub writeToFile {
  my ($head,$seq,$file)	= @_;
  
  my $len = length $seq;
  print $file ">$head\n";
  for(my $i = 0; $i < $len; $i+=60) {
    my $substr = substr($seq,$i,60);
    print $file "$substr\n";	
  }
}


#
#subroutine for confirming whether an element belongs to an array
#
sub isExisted {
  my ($element,$arr) = @_;
  
  foreach (0..$#$arr) {
    if($arr->[$_] eq $element) {
      return 1;	
    }	
  }	
  
  return 0;
  
}