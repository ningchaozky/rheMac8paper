#!/usr/bin/perl 
use strict;
unless(@ARGV){
	die "\nUsage: $0 xls col1,col2,col3........\n\n";
}
my $xls;
open $xls,"$ARGV[0]";
my @cols = split /,/,$ARGV[1];
while(<$xls>){
	chomp;
	my @tmp = split /\t/,$_;
	my $out = '';
	for(@cols){
		$tmp[$_ - 1] = '';
	}
	for(@tmp){
		$out .= "$_\t";
	}
	$out =~ s/\t+$//g;
	$out =~ s/^\t+//g;
	$out =~ s/\t+/\t/g;
	print "$out\n";
}
