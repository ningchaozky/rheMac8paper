#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('snp', nargs='?', help ='reference')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

sfh = open(args.snp)
p = re.compile(r'\s+')
for line in sfh :
    if '[' in line:
        line = line.strip()
        line = line.replace('[','')
        line = line.replace(']','')
        line = eval(line)
        arr = line.split('\t')
        name = arr[0] + ':' + arr[1]
        line = line + '\t' + name
    line_arr = p.split(line.strip())
    if ',' in line_arr[3]:
        rs = [ i.strip() for i in line_arr[3].split(',') ]
        for each in rs:
            print(each)
    if int(line_arr[1]) >  int(line_arr[2]):
        tmp = line_arr[1]
        line_arr[1] = line_arr[2]
        line_arr[2] = tmp
    print('\t'.join(line_arr).strip())




























