#!/usr/bin/env python
import os
import sys
import argparse
import matplotlib
import numpy as np
matplotlib.use('Agg')
import pandas as pd
from pandas import read_csv
import itertools
import matplotlib.pyplot as plt
import ningchao.nSys.fix as fixKit
from scipy.stats import wilcoxon, levene, ttest_ind
from collections import defaultdict
import seaborn as sns;sns.set(color_codes=True)
import ningchao.nSys.trick as trKit
from ningchao.nSys import system

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('pattern', nargs = '?', help ='input data matrx' )
parser.add_argument('-dir', nargs = '?', help ='dir for find bed', default = '.' )
parser.add_argument('-fcol', nargs='*', type = int, help ='fiter out the colums for plot', default = [1] )
parser.add_argument('-p', nargs='?', help ='output prefix')
parser.add_argument('-y', nargs='?', type = float, help ='ymax for the boxplot', default = 25)
parser.add_argument('-ycut', nargs='?', type = float, help ='y cut now show in figs', default = 5)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def bed_get_size( **kwargs ):
    infor = defaultdict( list )
    fls = system.dir( kwargs.get('dir') ).fls( kwargs.get('pattern') )
    for fl in fls:
        print ( 'Use: ', fl, file = sys.stderr )
        with open (fl) as f :
            for line in f:
                line_arr = line.strip().split('\t')
                if len(line_arr) <= 3 :
                    print ( 'ignore', line_arr, fl, file = sys.stderr )
                    continue
                length = int( line_arr[2] ) - int( line_arr[1] )
                infor[fl].append( length )
    return infor
infor = bed_get_size( **vars(args) )
plot_data = []
sortinfor = system.dir.sort( infor, period = True )
sortinfor = infor.keys()
labels, data = [ i[0] for i in sortinfor ], [ i[1] for i in sortinfor  ]
periods = [system.dir.str_map_period(i, up ='',down='',period = True) for i in labels ]
for i,each in enumerate(data) :
    period = periods[i]
    for val in each:
        plot_data.append( [ i, val, period ] )
df = pd.DataFrame(plot_data, columns=['x', "peak_length","period"])
#plt.boxplot(data)
ax=sns.boxplot( x = 'x', y='peak_length',hue='period',data = df, showfliers = False )
plt.xticks(rotation=45, ha='right')
plt.xticks(range(1, len(labels) + 1), labels)
#plt.ylim((0, args.y))
plt.savefig(('prefix' + '.pdf'), format='pdf',  bbox_inches='tight', pad_inches=+1 )
exit()




fcol = [ i - 1 for i in args.fcol ]
prefix = fixKit.change_suff(args.i,'').replace('.pdf','')
index = [ i-1 for i in  args.fcol ] 
if args.p:
	prefix = args.p.replace('.pdf','')
data = read_csv(args.i,sep = '\t', header = 0, index_col = 0)
infor =  data.T.to_dict() 
wilcoxon_test = defaultdict( list )
for pos in infor :
    for peiord in infor[pos]:
        if infor[pos][ peiord ] > args.ycut:
            wilcoxon_test[ peiord ].append( infor[pos][ peiord ] )
for p1, p2 in list(itertools.combinations( wilcoxon_test, 2)):
    if 'zygote' not in p1 + p2 :
        continue
    x,y = wilcoxon_test[p1], wilcoxon_test[p2]
    length = len(x) > len(y) and len(y) or len( x )
    print ( p1, p2, len(x), len(y), levene( x, y ) )
    print ( p1, p2, len(x), len(y), ttest_ind( x, y, equal_var = True))
    print ( p1, p2, len(x), len(y), wilcoxon( x[:length], y[:length]))
    
id_vars = list(data.columns[fcol])
melt = pd.melt(data,id_vars = id_vars)
melt = melt[melt['value'] > args.ycut]
ax=sns.boxplot(x='variable',y='value',data = melt, showfliers = False )
ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
plt.ylim((0, args.y))
PDF = prefix + '.pdf'
os.system('link_generate.py {}'.format(PDF))
plt.savefig( PDF, format='pdf',  bbox_inches='tight', pad_inches=+1 )












