#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick,system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('d', nargs='?', help = 'dir for find fq.gz' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




fls = system.dir( args.d ).fls('_resultReadsPerGene.out.tab', depth = 10, abspath = True)
bakdir = '/uDiskE/rawdata'
for fl in fls:
    size = os.path.getsize(fl)
    if size < 20000 :
        exit('Check {}...'.format(fl))
    wd,fl = os.path.split(fl)
    name = os.path.join(bakdir, fl.replace('_resultReadsPerGene.out.tab',''))
    bam = system.dir(wd).fls('_resultAligned.sortedByCoord.out.bam', depth = 0)
    bam = list(bam)[0]
    stdout = system.run( 'samtools view -H {}'.format(bam), shell = True )
    for line in stdout :
        if 'VN:2.7.6a' in line :
            line_arr = [ i for i in line.strip().split(' ') if '.fq.gz' in i ]
            wd = os.path.dirname(line_arr[0])
            print ( 'cd {}\nsync_py6.py {} -to {} -p fq.gz -mtime 100000'.format( wd, wd, name ) )




























