#!/usr/bin/env python3
import os
import sys
import loompy
import argparse
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'matrix', nargs='?', help = '')
parser.add_argument( '-loom', nargs = '?', help ='this loom for row names index, can be different order', default = '/dataC/gaolei/single/lamanno.dev_all.loom')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


if __name__ == '__main__':
    out_loompy = fix.fix( args.matrix ).append( 'loom' )
    ds = loompy.connect( args.loom )
    index = ds.ra['Accession']
    print ( len(index), len(set( index )) )
    print ( 'index base on: {} output name: {}, index number: {}'.format( args.loom, out_loompy, len(index) ) )
    df = pd.read_csv( args.matrix, header = 0, index_col = 0, sep = '\t' )
    gene_name = dict( zip( df.index, df.pop('gene_name') ))
    selected_index = [ i for i in index if i in df.index ]
    no_in_index = [ i for i in index if i not in df.index ]
    i = 0
    for no_in_index_id in no_in_index:
        if no_in_index_id not in gene_name:
            i += 1
            print ( no_in_index_id, 'not in {}, {}'.format(args.matrix, i), file = sys.stderr )
            gene_name.update({no_in_index_id: no_in_index_id})
    print ( 'overlap genes: {}, append with 0: {}'.format( len(selected_index), len(no_in_index) ) )
    df = df.loc[selected_index]
    r,c = df.shape
    df_append = pd.DataFrame( [ [0]*c for i in range(len(no_in_index))], index = no_in_index, columns = df.columns)
    print ( 'append shape:', df_append.shape, 'raw data shape: ', df.shape )
    df = pd.concat([df, df_append], ignore_index = False, sort = False )
    print ( 'concat shape:', df.shape )
    df = df.fillna( 0 )
    df_numpy = df.to_numpy()

    row_attrs = {'Accession': list(df.index) }
    row_attrs.update({'Gene': [ gene_name[i] for i in df.index ] })
    col_attrs = {'CellID': list(df.columns) }
    loompy.create( out_loompy, df_numpy, row_attrs, col_attrs )
























