#!/bin/env perl 
#method=meth CpG(reads)/(meth CpG(reads)+unmeth CpG(reads)) in this region ; NOT the: sum(ml)/total_valid_CpGbut some paper has use the later for the whole genome methylation,and in my call_methyl perl script,just usedthe later for whole genome methylation!  
###This script is used to calculate the average methylation level(ml) of region (bed file),first you should used :bedtools intersect -a /media/yuanshenli/cell/data-experiment/share_script/execute_script/new_version.genebody_extract.script/human/hg19.TSS_up_down_2000_promoter.bed6 -b HGXBP1.nolambda.with.m_um.5.bed(NOT the file:HGXBP1.nolambda.5.bdg) -wa -wb >outfile     ###if feature file are too large,please split,run,and merge!!

$n=$ARGV[2]; #@ARGV[1];
open IN1,$ARGV[0]; #####@ARGV[0] is the outfile of bedtools intersect!!!!
foreach (<IN1>) {
chomp;
@meth=split "\t",$_;
#################################################3
#=pod
$x=1;
$range=$meth[0];
while($x <= ($ARGV[1]-1)){
$range .= "\t$meth[$x]";
$x++;
}
$hash_UM{$range} .= "$meth[-1]\t";
$hash_M{$range} .= "$meth[-2]\t";
#=cut
#$hash_UM{"$meth[0]\t$meth[1]\t$meth[2]\t$meth[3]\t$meth[4]\t$meth[5]\t$meth[6]\t$meth[7]\t$meth[8]\t$meth[9]"} .= "$meth[-1]\t";
#$hash_M{"$meth[0]\t$meth[1]\t$meth[2]\t$meth[3]\t$meth[4]\t$meth[5]\t$meth[6]\t$meth[7]\t$meth[8]\t$meth[9]"} .= "$meth[-2]\t"
}

foreach (keys %hash_UM){
@mi=split "\t",$hash_UM{$_};
$sum_UM=0;
foreach $mi(@mi) {
$sum_UM=$mi+$sum_UM;        ####count the sum of Un meth C reads
}
@m=split "\t",$hash_M{$_};
$sum_M=0;
foreach $m(@m) {
$sum_M=$m+$sum_M;            ##count the sum of Meth C raeds
}
if (@m >= $n){     ###$n=5,always !!!! the feture/region with at leat 5 CpG numbers are considered!!!! 
$aver=$sum_M/($sum_M+$sum_UM); ###calculate the meth level of a region,based on the reads of umC and mC!!! 
print $_,"\t",$aver,"\n";
#print $_,"\t",$aver,"\t",$sum_M,"\t",$sum_UM,"\n";
}
else{
#print $_,"\t","NA","\n";
}
}
close IN1;
