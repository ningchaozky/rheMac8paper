#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, fix
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tad', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
parser.add_argument( 'd', nargs='?', help ='outputdir')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


output = defaultdict( dict )
for line in args.tad:
    line_arr = line.rstrip().split('\t')
    chrom = line_arr[0]
    if chrom not in output :
        print ( fix.fix( args.tad ).insert(chrom))
        output[ chrom ] = open( os.path.join( args.d, fix.fix( args.tad ).insert(chrom)), 'w')
        print ('chrom', 'start', 'end', 'Level', sep = '\t', file = output[ chrom ])
    print ( chrom.replace('chr',''), *line_arr[1:4], 1, sep = '\t', file = output[ chrom ])



























