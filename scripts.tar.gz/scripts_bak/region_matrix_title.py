#!/usr/bin/env python
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='add title for the matrix which output from pipline')
parser.add_argument('-t', nargs='?', help ='title file ')
parser.add_argument('-m', nargs='?', help ='matrix output from')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()






