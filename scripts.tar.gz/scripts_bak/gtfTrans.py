#!/usr/bin/env python
import sys
import argparse
from ningchao.nSys import ip,env,trick
from ningchao.nBio import rheMac
parser = argparse.ArgumentParser(prog=sys.argv[0],description='gtf to ucsc browser flat txt')
parser.add_argument( '-a', choices = ['exonchipseeker','genechipseeker','cdschipseeker','transcriptschipseeker','splicingchipseeker',
'hommer.rna','hommer.genetsv','hommer.description',
'ucsc.ensemble','ensemble.gene_name','addchr','bed12',
'annot.exon','promoter'] )
parser.add_argument( 'gtf', nargs='?', help ='gtf file ' )
parser.add_argument( '-s', choices = ['rh3','rh8','GRCh37.68'],help = '', default = 'rh8' )
parser.add_argument( '-ss', nargs = '?', type = int, help = 'reference point start', default = 2000 )
parser.add_argument( '-se', nargs = '?', type = int, help = 'reference point end', default = 2000 )
parser.add_argument( '-t', choices = ['chr','nochr'],  help = 'chr gtf use?', default = 'chr' )
parser.add_argument( '-o', nargs='?', help ='output file.default stdout' )
if len(sys.argv) == 1:
        parser.print_help().__str__
        sys.exit(2)
args = parser.parse_args()

ip = ip.local_ip()
gtf = ''
if args.gtf:
    gtf = args.gtf
else :
    gtf = rheMac.gtf(typ = args.t,s = args.s)

chrm = list(range(1,24))
if args.t == 'chr':
    chrm = ['chr' + str(i) for i in chrm]
    chrm.append('chrX')
else :
    chrm = [str(i) for i in chrm]
    chrm.append('X')
Infor = {}
sys.stderr.write(gtf + '\n')
fh = open(gtf)
ofh = sys.stdout
if args.o:
    ofh = open(args.o,'w')

ss = args.ss
se = args.se
index = 0


if args.a == 'addchr':
    for line in fh:
        if line.startswith('#!'):
            ofh.write(line)
        else :
            line_arr = line.strip().split('\t')
            if str(line_arr[0]) in chrm:
                line_arr[0] = 'chr' + str(line_arr[0])
                ofh.write('\t'.join(line_arr) + '\n')
    exit('done')

exon_id = cds_id = trans_id = gene_id_chipseeker = 0
chain_rev = {}
exon_num = {}
lst =  []
cds_infor = {}
trans_id_infor = {}
exon_index = ''
for line in fh: 
        if line.startswith('#!'):
            continue
        line_arr = line.strip().split('\t')
        if str(line_arr[0]) not in chrm:
            continue
        gStart,gEnd,txStart,txEnd,cdsStart,cdsEnd,exStart,exEnd = '','','','','','','',''
        line_infor = trick.str2dict(line_arr[8])
        gene_id = line_infor['gene_id']
        transcript_id = ''
        if 'transcript_id' in line_infor:
            transcript_id = line_infor['transcript_id']
        else :
            index += 1
            trick.set2dict(Infor,gene_id,'index',str(index))
            if 'gene_name' in line_infor:
                #sys.stderr.write(line_infor['gene_name'] +'\n')
                trick.set2dict(Infor,gene_id,'gene_name',line_infor['gene_name'])
            else :
                trick.set2dict(Infor,gene_id,'gene_name',gene_id)
        if line_arr[2] == 'gene':
            gene_id_chipseeker += 1
            chain = line_arr[6]
            gStart = line_arr[3]
            gend = line_arr[4]
            if args.a == 'ensemble.gene_name':
                chrom = line_arr[0]
                if 'gene_name' in line_infor:
                    gene_name = line_infor['gene_name']
                    tmp_out = [ str(i) for i in [chrom,gStart,gend,gene_name+'.'+gene_id,0,chain] ]
                    if gene_name.startswith('ENSMMUG'):
                        continue
                    else :
                        ofh.write('\t'.join(tmp_out) +'\n')
                else :
                    continue
                    #sys.stderr.write(line)
            if args.a == 'promoter':
                if chain == '+':
                    if 'gene_name' in line_infor:
                        gene_id_key = gene_id +'.' + line_infor['gene_name']
                    else :
                        gene_id_key = gene_id +'.' + gene_id
                    tmp_line = [line_arr[0], str(int(gStart)-ss), str(int(gStart)+se), gene_id_key, '0', chain]
                else :
                    tmp_line = [line_arr[0], str(int(gend)-ss), str(int(gend)+se), gene_id_key, '0', chain]
                ofh.write('\t'.join(tmp_line) + '\n')
        if line_arr[2] == 'transcript':
            txStart = line_arr[3]
            txEnd = line_arr[4]
            trans_id += 1
            trans_id_infor[line_infor['transcript_id']] = str(trans_id)
            if args.a == 'transcriptschipseeker':
                ofh.write('\t'.join([str(trans_id),transcript_id,'',line_arr[0],line_arr[6],txStart,txEnd]) + '\n')
            if args.a == 'genechipseeker':
                ofh.write('\t'.join([Infor[gene_id]['index'],str(trans_id)]) + '\n')
        if line_arr[2] == 'CDS':
            cds_id += 1
            exon_num_cds = line_infor['exon_number']
            trick.set2dict(cds_infor, trans_id_infor[line_infor['transcript_id']], exon_num_cds,[])
            cds_infor[trans_id_infor[line_infor['transcript_id']]][exon_num_cds].append(str(cds_id))
            cdsStart = line_arr[3]
            cdsEnd = line_arr[4]
            if args.a == 'cdschipseeker':
                ofh.write('\t'.join([str(cds_id),'',line_arr[0],line_arr[6],cdsStart,cdsEnd]) + '\n')
        if line_arr[2] == 'exon':
            exon_id += 1
            exStart = line_arr[3]
            exEnd = line_arr[4]
            if args.a  == 'exonchipseeker':
                ofh.write('\t'.join([str(exon_id),'',line_arr[0],line_arr[6],exStart,exEnd]) +'\n')
            if args.a == 'annot.exon':
                if 'gene_name' in line_infor:
                    if exon_index != line_infor['gene_name']:
                        i = -1
                        exon_index = line_infor['gene_name']
                    i += 1
                    lst = [line_arr[0],line_arr[3],line_arr[4],line_infor['gene_name']+'.'+gene_id+'.exon_%d' % i,'0',line_arr[6], '2']
                    ofh.write('\t'.join(lst) + '\n')
        if transcript_id == '':
            continue
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'cdsStart',[])
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'cdsEnd',[])
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'txStart',txStart)
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'txEnd',txEnd)
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'exStart',[])
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'exEnd',[])
        if 'transcript_name' in line_infor:
            trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'transcript_name',line_infor['transcript_name'])
        else :
            trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'transcript_name',line_infor['transcript_id'])
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'gene_biotype',line_infor['gene_biotype'])
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'chr', str(line_arr[0]))
        trick.set4dict(Infor,gene_id,'transcripts',transcript_id,'chain',line_arr[6])
        Infor[gene_id]['transcripts'][transcript_id]['cdsStart'].append(cdsStart)
        Infor[gene_id]['transcripts'][transcript_id]['cdsEnd'].append(cdsEnd)
        Infor[gene_id]['transcripts'][transcript_id]['exStart'].append(exStart)
        Infor[gene_id]['transcripts'][transcript_id]['exEnd'].append(exEnd)
        if args.a == 'splicingchipseeker':
            if line_arr[2] == 'exon':
                trick.set1dict(exon_num,str(trans_id),[])
                exon_num[str(trans_id)].append(int(line_infor['exon_number']))
                lst.append([trans_id,line_infor['exon_number'],exon_id,'Null',line_arr[6],transcript_id])


if args.a == 'splicingchipseeker':
    for line in lst:
        transcript_id = line.pop()
        chain = line.pop()
        if str(line[0]) in cds_infor:
            if line[1] in cds_infor[str(line[0])]:
                line[3] = cds_infor[str(line[0])][line[1]][0]
        if chain == '-':
            line[1] = max(exon_num[ str(line[0]) ]) - int(line[1]) + 1
        line = [ str(i) for i in line ]
        ofh.write('\t'.join(line) + '\n')




times = {}
#for title 
if args.a == 'hommer.description':
        ofh.write('\t'.join(['GeneID','Unigene','RefSeq','Ensembl','name','alias','orf','chromosome','description','type']) + '\n')


for gene_id in Infor:
    index = Infor[gene_id]['index']
    gene_name = Infor[gene_id]['gene_name']
    trick.set1dict(times,gene_id,0)
    for transcript_id in Infor[gene_id]['transcripts']:
        transcripts = Infor[gene_id]['transcripts']
        transcript = Infor[gene_id]['transcripts'][transcript_id]
        txStart = transcript['txStart']
        txEnd = transcript['txEnd']
        chain = transcript['chain']
        chrom = transcript['chr']
        gene_biotype = transcript['gene_biotype']
        exStart = trick.uList(transcript['exStart'],deEmpty = 'yes')
        exEnd = trick.uList(transcript['exEnd'], deEmpty = 'yes')
        cdsStart = trick.uList(transcript['cdsStart'], deEmpty = 'yes')
        cdsEnd = trick.uList(transcript['cdsEnd'], deEmpty = 'yes')
        transcript_name = transcript['transcript_name']
#ucsc ensemble
        if args.a == 'ucsc.ensemble':
            times[gene_id] += 1
            if len(cdsStart) < 1:
                sys.stderr.write( 'nocds for %s' % gene_id + ','.join(cdsStart) + '\n')
                continue
            exonNum = len(exStart)
            score = '0'
            cdsStart = cdsStart[0]
            cdsEnd = cdsEnd[-1]
            arr = [str(i) for i in [times[gene_id],gene_id,chrom,chain,txStart,txEnd,cdsStart,cdsEnd,exonNum,','.join(exStart),','.join(exEnd),score,gene_name,'unk','unk','-1,'*exonNum]]
            ofh.write('\t'.join(arr) + '\n')

# hommer rna flat file
        if args.a == 'hommer.rna':
            lst = []
            if transcript_id == '':
                continue
            for i,v in enumerate(exStart):
                lst.append('E%s:%s' % (str(i+1),str(v)))
                lst.append('I%s:%s' % (str(i+1),str(exEnd[i])))
            lst.pop()
            desp = ','.join(lst)
            arr = [transcript_id,chrom,txStart,txEnd,chain,desp]
            ofh.write('\t'.join(arr) + '\n')
        if args.a == 'hommer.genetsv':
            if transcript_id == '':
                continue
            try :
                arr = [transcript_name,index,'rh8.'+index,transcript_id,gene_id,'',gene_name]
            except :
                print(transcript_id,transcript)
            ofh.write('\t'.join(arr) + '\n')
        if args.a == 'hommer.description':
            refSeq = gene_name
            if transcript_id == '':
                continue
            try :
                arr = [index,'rh8.'+index,transcript_id,gene_id,gene_name,'',chain,chrom,'', gene_biotype ]
            except :
                print(transcript_id,transcript)
        
            ofh.write('\t'.join(arr) + '\n')

# ensemble id to gene name
#        if args.a == 'ensemble.gene_name':
#            tmp_out = [ str(i) for i in [chrom,txStart,txEnd,gene_name+'.'+gene_id,0,chain] ]
#            if gene_name.startswith('ENSMMUG'):
#                continue
#            else :
#                ofh.write('\t'.join(tmp_out) +'\n')

#       if args.a == 'bed12':
#           print`
            




ofh.close()





