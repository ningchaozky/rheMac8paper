#!/usr/bin/env python3
import os
import sys
import argparse
import scipy.misc
import numpy as np
import nibabel as nib
import imageio
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#from PIL import Image
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('nii', nargs = '?', help = 'nii file')
parser.add_argument('-b', nargs = '?', help = 'back file', default = '/home/ningch/data/lijing/average.nii')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def back( arr ):
    lst, out = arr.tolist(), []
    [ out.extend(i) for i in lst ]
    return out, len(out)
img = nib.load( args.nii )
background = nib.load( args.b ).get_fdata()
img = img.get_fdata()
print ( img.shape )
x,y,z,j = img.shape
xb,yb,zb,jb = background.shape
for i in range( z ):
    val3d = img[ :, :, i ]
    val2d, len_val = back( val3d )
    x = range(len_val)
    #val3d = np.where( (-4 < val3d) & (val3d < 0.8), 0, 1 )
    #val3d[ (-2 < val3d) & (val3d <= 0.2) ] = 0
    if not i :
        new3d = val3d
        continue
    new3d = np.concatenate( val3d )
    #new3d.concatenate( val3d )
    #print ( new3d.shape )
    #exit()

    #val2d.sort()
    #max_slope = max([x - z for x, z in zip( val2d[:-1], val2d[1:])])
    #steepest = np.argmax(np.diff(np.array( val2d )))
    #print ( max_slope, steepest )
    #plt.imshow( val3d )
    #plt.plot(x, val2d)
    #print ( val3d )
    #plt.savefig('{}.png'.format( args.nii ))
    #exit()
xmax = img.max( axis = 0 )
ymax = img.max( axis = 1 )
zmax = img.max( axis = 2 )[ :, :, 0] 
backzmax = background.max( axis = 2 )[ :, :, 0] 
#plt.imshow( new3d.max(axis = 2) )
zmax = zmax * backzmax
plt.imshow( zmax )
plt.savefig('{}.png'.format( args.nii ))
#data = write_png( zmax, 1024, 1024)
#with open("my_image.png", 'wb') as fh:
#    fh.write(data)
#matplotlib.image.imsave('name.png', zmax)
#scipy.misc.toimage( zmax, cmin=0.0, cmax=...).save('outfile.jpg')
#scipy.misc.imsave('outfile.jpg', xmax)
#img_3d_max = np.amax( img )
#for i in range( img_3d_max.shape[2] ):
#    img_2d = [:, :, i]
#    print ( img_2d )
#img = np.asanyarray( nib.load( args.nii ))





















