#!/usr/bin/env Rscript


Args <- commandArgs()
library(cummeRbund)
cuff_data <- readCufflinks(Args[6])
gene_diff_data <- diffData(genes(cuff_data))
isform_diff_data <- diffData(isoforms(cuff_data))
sig_gene_data <- subset(gene_diff_data, (significant == 'yes'))
sig_isoform_data <- subset(isform_diff_data,(significant == 'yes'))
write.table(sig_gene_data, 'diff_genes.txt', sep = '\t',row.names = F, col.names = T, quote = F)
write.table(sig_isoform_data, 'diff_isform.txt', sep = '\t',row.names = F, col.names = T, quote = F)
