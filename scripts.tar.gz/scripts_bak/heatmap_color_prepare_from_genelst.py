#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,color
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('glst', nargs='?', help ='gene list for color')
parser.add_argument('-xls', nargs='*', help ='xls and columns for gene')
parser.add_argument('-t', nargs='?', help ='gene type', default = 'CNV')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
fh = open(args.glst)
genelst = []
for line in fh :
    line_arr = line.strip().split('\t')
    if len(line_arr) == 1 :
        genelst.append(line_arr[0].upper())

xls,col = args.xls
typ = args.t
xfh = open(xls)
color = ','.join([ str(i) for i in color.color().random01(num = 1) ])
for line in xfh :
    line_arr = line.strip().split('\t')
    gene = line_arr[int(col) - 1].split('.')[0].upper()
    if gene in genelst:
        arr = line_arr[0:4]
        arr.insert(3,color)
        arr.append(typ)
        print('\t'.join(arr))




























