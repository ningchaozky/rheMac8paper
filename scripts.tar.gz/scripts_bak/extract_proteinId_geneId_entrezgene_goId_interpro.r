#!/usr/bin/env Rscript
Args <- commandArgs()
if(length(Args) < 5){
	cat ("\nUsage:\n",sub(".*=","",Args[4]),"file [type]\n\ntype: ensembl_gene_id entrezgene refseq_mrna interpro interpro_description go_id ensembl_transcript_id ensembl_peptide_id ensembl_exon_id description and so on.other look biomaRt protocal\n\n")
}else{
if(length(Args) ==6){
	dataset	<-	"hsapiens_gene_ensembl"
	type	<-	"ensembl_gene_id"
}
if(length(Args) == 7){
	dataset	<-	Args[7]
	type	<-	"ensembl_gene_id"
}
if(length(Args) ==8){
	dataset	<-	Args[7]
	type	<-	Args[8]
}
library("biomaRt")
data		<-	read.table(Args[6],sep="\t",header=F)
data		<-	as.character(unlist(data[1]))
ensembl		<-	useMart("ensembl",dataset=dataset)
out			<-	getBM(attributes=c('ensembl_gene_id','entrezgene','refseq_mrna','interpro','interpro_description','go_id','ensembl_transcript_id','ensembl_peptide_id','ensembl_exon_id','description'), filters = type, values = data, mart = ensembl)

write.table(out,file = "match_id.txt", append=FALSE, quote=FALSE, row.names=F, col.names=F, sep="\t")
}
