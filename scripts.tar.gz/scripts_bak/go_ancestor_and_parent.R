#!/usr/bin/env Rscript

args <- commandArgs()
if(length(args) <5){
	stop("#Usage:\n",sub(".*=","",args[4])," bpa|bpp... bp.txt")
}
suppressMessages(library(GO.db))
infile <- args[7]
res <- readLines(infile)
fun <- function(type) {
	  switch(type,
		bpa = 'GOBPANCESTOR',
		cca = 'GOCCANCESTOR',
		mfa = 'GOMFANCESTOR',
		bpp = 'GOBPPARENTS',
		ccp = 'GOCCPARENTS',
		mfp = 'GOMFPARENTS')
}

sink(paste(args[7],args[6],'.txt',sep=''))
for (i in 1:length(res)){
	line = unlist((strsplit(res[i],"\t")))
	cat(paste(line, collapse = "\t"),"\n")
	ancestor <- eval(parse(text = paste(fun(args[6]),"$\'",line[2],"\'",sep='')))
	if(length(ancestor) > 0){
		ancestor_arr <- unlist(strsplit(ancestor,"\t"))
		for( j in 1:(length(ancestor_arr)-1)){
			line[2] <- ancestor_arr[j]
			cat(paste(line, collapse = "\t"),"\n")
		}
	}
}
sink()
