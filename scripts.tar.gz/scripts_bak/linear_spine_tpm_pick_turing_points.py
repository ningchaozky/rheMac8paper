#!/usr/bin/env python3
import os
import sys
import pandas as pd
from patsy import dmatrix
import statsmodels.api as sm
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=300)
import argparse
from ningchao.nSys import trick
from sklearn.metrics import mean_squared_error

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tpm', nargs = '?', help = 'tpm file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



variables = { 'E50': 50, 'E80': 80, 'E90' : 90, 'E120': 120, '0M': 166, '4M': 286, '45Y': 1808, '20Y': 7466 }
#variables = { 'E50': 1, 'E80': 2, 'E90' : 3, 'E120': 4, '0M': 5, '4M': 6, '45Y': 7, '20Y': 8 }

keys = {}
for k in variables.keys():
    for rep in ['rep1','rep2']:
        key = '.'.join([k,rep])
        keys[key] = variables[k]


values = list( variables.values() )

dataset=pd.read_csv( args.tpm, sep = '\t', header = 0, index_col = None )
sdf =  dataset.loc[ dataset['Geneid'] == 'XLOC_000002'] 
sdf = sdf.melt( id_vars=['Geneid'] )
for key in keys:
    sdf = sdf.replace( key, keys[key])

for knots in values:
    values.pop(0)
    values.pop(-1)
    values.pop(-1)
    values.pop(-1)
    knots = ','.join( [ str(i) for i in values ])
    print ( knots )
    spline_cube = dmatrix('bs(x, knots=( {} ))'.format( knots ), {'x': sdf['variable']})
    spline_fit = sm.GLM(sdf['value'], spline_cube).fit()

    natural_spline = dmatrix('cr(x, knots = ( {} ))'.format( knots ), {'x': sdf['variable']})
    spline_natural = sm.GLM(sdf['value'], natural_spline).fit()
    range = np.linspace( sdf['variable'].min(), sdf['variable'].max(), 8)
    cubic_line = spline_fit.predict(dmatrix('bs(range, knots=( {} ))'.format(knots), {'range': range}))
    line_natural = spline_natural.predict( dmatrix('cr(range, knots=( {} ))'.format(knots), {'range': range}))
#print ( line_natural.round(4).tolist() )
#print ( sdf.groupby('variable').mean() )
    print ( mean_squared_error( sdf.groupby('variable').mean(), line_natural.round(4).tolist()) )
    exit()
plt.plot(range, cubic_line, color='r', label='Cubic spline')
plt.plot(range, line_natural, color='g', label='Natural spline')
plt.legend()
plt.scatter( sdf['variable'], sdf['value'])
plt.xlabel('variable')
plt.ylabel('value')
plt.scatter( sdf['variable'], sdf['value'])
plt.savefig('test.pdf', width = 12, height = 12)
print ( sdf )




























