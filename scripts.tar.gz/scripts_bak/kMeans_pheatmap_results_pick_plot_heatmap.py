#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick
from collections import defaultdict

example = '''raw matrix and cluster'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'mat', nargs = '?', help = 'mat for kMeans_pheatmap')
parser.add_argument( 'cluster', nargs = '?', help = 'output of kMeans_pheatmap')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_cluster( cluster ):
    dit = defaultdict(list)
    with open( cluster ) as f :
        next( f )
        for line in f :
            line = line.strip().split('\t')
            dit[line[1]].append( line[0] )
    return dit

def pick( mat, rowname ):
    df = pd.read_csv( mat, sep = '\t' )
    return df[df.iloc[:, 0].isin( rowname )]



if __name__ == '__main__':
    cluster = get_cluster( args.cluster )
    lst = sorted ( cluster.items(), key = lambda x: int(x[0]), reverse = False )
    for clust, lst in lst:
        select = pick( args.mat, lst)
        select.to_csv('test.split.{}.tab'.format(clust), sep = '\t', index = None)




























