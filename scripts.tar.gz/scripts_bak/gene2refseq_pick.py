#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
from collections import defaultdict

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'xenoRefGene', nargs = '?', help = 'xenoRefGene.txt file' )
parser.add_argument( '-gene2refseq', nargs = '', help = 'download from ncbi', default = '/home/soft/data/genome/rheMac8/annot/gene2refseq' )
parser.add_argument( '-sp', nargs = '+', help = 'species', default = [ 10090, 9598, 9606 ] )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def sp_dit_get( sp, gene2refseq):
    fh, out = open( gene2refseq ), []
    for line in fh:
        line_arr = line.strip().split('\t')
        tax_id, refseq_id = line_arr[0], line_arr[7]
        if tax_id in sp :
            print ( refseq_id, tax_id, sep = '\t' )

def pick( lst, xenoRefGene ):
    fh = open( xenoRefGene )
    for line in fh:
        line_arr = line.strip('\t')
        if line_arr[1] in lst:
            print (line, )



if __name__ == '__main__':
    sp_dit_get( args.sp, args.gene2refseq )
    #pick( lst, args.xenoRefGene )
































