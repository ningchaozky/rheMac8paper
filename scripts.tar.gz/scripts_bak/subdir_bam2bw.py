#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system, fix
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'pattern', nargs = '?', help = 'pattern for find bam')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

template = '''bamCoverage --normalizeUsing BPM --numberOfProcessors 2 --outFileFormat bigwig --bam {} --binSize 1 --outFileName {}'''

fls = system.dir( '.' ).fls(args.pattern, level = 1)
for bam in fls:
    sort = fix.fix(bam).insert('sort')
    if not os.path.exists( sort +'.bai'):
        print ('samtools sort {} > {}'.format(bam, sort))
        print ('samtools index {}'.format( sort ))
    bw = fix.fix(sort).change('bw')
    if not os.path.exists( bw ):
        print ( template.format( sort, bw) )




























