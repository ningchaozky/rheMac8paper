/home/soft/soft/packages/ningchao/scripts/sync_py6.py	Tue Jun 14 10:01:55 2022	scp /home/soft/soft/packages/ningchao/scripts/sync_py6.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/hubTrack.py	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/hubTrack.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/03-HiC_pipe_CXP_HMM_TAD.py	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/03-HiC_pipe_CXP_HMM_TAD.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix.py	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix_combine.py	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix_combine.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/02-HiC_pipe_CXP_ICE.py	Tue Jun 14 10:21:16 2022	scp /home/soft/soft/packages/ningchao/scripts/02-HiC_pipe_CXP_ICE.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/sync_py6.py	Tue Jun 14 10:41:45 2022	scp /home/soft/soft/packages/ningchao/scripts/sync_py6.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 10:41:45 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 10:48:00 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 11:01:30 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 11:57:24 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/sync_py6.py	Tue Jun 14 13:36:49 2022	scp /home/soft/soft/packages/ningchao/scripts/sync_py6.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



/home/soft/soft/packages/ningchao/scripts/readme.status.txt	Tue Jun 14 13:36:49 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



01-HiC_pipe_CXP_matrix_for_wss.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix_for_wss.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



03-HiC_pipe_CXP_HMM_TAD.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/03-HiC_pipe_CXP_HMM_TAD.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



normal_column_to_100w_tpm.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/normal_column_to_100w_tpm.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



02-HiC_pipe_CXP_ICE.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/02-HiC_pipe_CXP_ICE.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



match_bulk_to_single_cell_data_cibersortx_prepare.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/match_bulk_to_single_cell_data_cibersortx_prepare.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



single_cell_infor_class.py	Fri Jun 24 12:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/single_cell_infor_class.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



01-HiC_pipe_CXP_matrix_for_wss.py	Sun Jun 26 15:37:13 2022	scp /home/soft/soft/packages/ningchao/scripts/01-HiC_pipe_CXP_matrix_for_wss.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



03-HiC_pipe_CXP_HMM_TAD.py	Sun Jun 26 15:37:13 2022	scp /home/soft/soft/packages/ningchao/scripts/03-HiC_pipe_CXP_HMM_TAD.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



02-HiC_pipe_CXP_ICE.py	Sun Jun 26 15:37:13 2022	scp /home/soft/soft/packages/ningchao/scripts/02-HiC_pipe_CXP_ICE.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



pick_line_from_maker_sqlite3.py	Sun Jun 26 15:37:13 2022	scp /home/soft/soft/packages/ningchao/scripts/pick_line_from_maker_sqlite3.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



sync_py6.py	Sun Nov 13 10:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/sync_py6.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methylation_pipline_zhanjh.sh	Sun Nov 13 10:52:25 2022	scp /home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methlation_piplie_zhanjh.py	Tue Nov 15 00:26:41 2022	scp /home/soft/soft/packages/ningchao/scripts/methlation_piplie_zhanjh.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



split_bam_n.py	Tue Nov 15 00:26:42 2022	scp /home/soft/soft/packages/ningchao/scripts/split_bam_n.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



conversionRate.sh	Tue Nov 15 00:26:42 2022	scp /home/soft/soft/packages/ningchao/scripts/conversionRate.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methylation_pipline_zhanjh.sh	Tue Nov 15 00:26:42 2022	scp /home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



bismark_to_bed.sh	Tue Nov 15 00:26:42 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



readme.status.txt	Tue Nov 15 12:41:36 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



split_bam_n.py	Tue Nov 15 12:41:36 2022	scp /home/soft/soft/packages/ningchao/scripts/split_bam_n.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methylation_pipline_zhanjh.sh	Tue Nov 15 12:41:36 2022	scp /home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methlation_piplie_zhanjh.py	Tue Nov 15 12:53:07 2022	scp /home/soft/soft/packages/ningchao/scripts/methlation_piplie_zhanjh.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



split_bam_n_and_methylation.py	Tue Nov 15 12:53:07 2022	scp /home/soft/soft/packages/ningchao/scripts/split_bam_n_and_methylation.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



readme.status.txt	Tue Nov 15 12:53:07 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methylation_pipline_zhanjh.sh	Tue Nov 15 12:53:07 2022	scp /home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts



methylation_pipline_zhanjh.sh	Sat Nov 19 12:38:49 2022	scp /home/soft/soft/packages/ningchao/scripts/methylation_pipline_zhanjh.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



hic_interaction_si_plot_v2_merge.py	Sat Nov 19 12:38:49 2022	scp /home/soft/soft/packages/ningchao/scripts/hic_interaction_si_plot_v2_merge.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.sh	Sat Nov 19 12:38:49 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_extracter_check.py	Sat Nov 19 12:38:49 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_extracter_check.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 00:26:06 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



split_sort_tab.py	Sun Nov 20 00:26:06 2022	scp /home/soft/soft/packages/ningchao/scripts/split_sort_tab.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bed_get_exon_num.py	Sun Nov 20 00:26:06 2022	scp /home/soft/soft/packages/ningchao/scripts/bed_get_exon_num.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



hic_interaction_si_plot_v2_merge.py	Sun Nov 20 00:26:06 2022	scp /home/soft/soft/packages/ningchao/scripts/hic_interaction_si_plot_v2_merge.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.sh	Sun Nov 20 00:26:06 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.sh ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 11:25:10 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



split_sort_tab.py	Sun Nov 20 11:25:10 2022	scp /home/soft/soft/packages/ningchao/scripts/split_sort_tab.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.py	Sun Nov 20 11:25:10 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



split_sort_tab.py	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/split_sort_tab.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed_methylation_bw.py	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed_methylation_bw.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.py	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.py ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.sh	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.sh ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



split_sort_tab.py.swp	Sun Nov 20 13:26:50 2022	scp /home/soft/soft/packages/ningchao/scripts/.split_sort_tab.py.swp ningch@192.168.118.83:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:34:17 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed_methylation_bw.py	Sun Nov 20 13:34:17 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed_methylation_bw.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.py	Sun Nov 20 13:34:17 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:35:26 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.py	Sun Nov 20 13:35:26 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:36:20 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:47:52 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



bismark_to_bed.py	Sun Nov 20 13:47:52 2022	scp /home/soft/soft/packages/ningchao/scripts/bismark_to_bed.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



readme.status.txt	Sun Nov 20 13:53:59 2022	scp /home/soft/soft/packages/ningchao/scripts/readme.status.txt ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



split_sort_tab.py	Sun Nov 20 13:53:59 2022	scp /home/soft/soft/packages/ningchao/scripts/split_sort_tab.py ningch@192.168.118.81:/pnas/liujiang_group/ningch/soft/packages/ningchao/scripts #ok



