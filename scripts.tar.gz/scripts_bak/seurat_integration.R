#!/usr/bin/env Rscript
#first
alen <- commandArgs()
suppressMessages(library(argparser))
suppressMessages(library(Seurat))
suppressMessages(library(SeuratData))
suppressMessages(library(patchwork))
p <- arg_parser('script description')
p <- add_argument(p, "mat1", help="mat1")
p <- add_argument(p, "mat2", help= "two mat integration")
p <- add_argument(p, '--prefix',help="output file prefix", default = 'testa')
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))

rdsOutputfile = paste( basename(args$prefix), "my_data.compart.rds", sep = '.')
print ( paste('outputrds file:', rdsOutputfile) )
pdf( paste(basename(args$prefix), "pdf", sep = '.') )

# install dataset
#InstallData("ifnb")
# load dataset
#LoadData("ifnb")

# split the dataset into a list of two seurat objects (stim and CTRL)
#ifnb.list <- SplitObject(ifnb, split.by = "stim")
ifnb.list <- list( args$mat1, args$mat2 )
names(ifnb.list) <- c('CTRL','STIM')


# normalize and identify variable features for each dataset independently
ifnb.list <- lapply(X = ifnb.list, FUN = function(x) {
	df <- read.table( x, sep = '\t', header = 1, check.names = 0, row.names = 1, stringsAsFactors = FALSE, na.strings="unknown")
    x <- CreateSeuratObject(counts = t(df) )
	x <- NormalizeData(x)
    #x <- FindVariableFeatures(x, selection.method = "vst", nfeatures = 3000)
    x <- FindVariableFeatures(x)
})

meta_dim = lapply( X = ifnb.list, FUN = function(x){
	dim(x)
})

# select features that are repeatedly variable across datasets for integration
features <- SelectIntegrationFeatures(object.list = ifnb.list)

ifnb.list <- lapply(X = ifnb.list, FUN = function(x) {
    x <- ScaleData(x, features = features, verbose = FALSE)
    x <- RunPCA(x, features = features, verbose = FALSE)
})



#immune.anchors <- FindIntegrationAnchors(object.list = ifnb.list, anchor.features = features,  reduction = "rpca", dims = 1:50,  reference = c(1,2))
immune.anchors <- FindIntegrationAnchors(object.list = ifnb.list, anchor.features = features, dims = 1:50 )
# this command creates an 'integrated' data assay
immune.combined <- IntegrateData(anchorset = immune.anchors, dims = 1:50)
# specify that we will perform downstream analysis on the corrected data note that the
# original unmodified data still resides in the 'RNA' assay
DefaultAssay(immune.combined) <- "integrated"

# Run the standard workflow for visualization and clustering
immune.combined <- ScaleData(immune.combined, verbose = FALSE)
immune.combined <- RunPCA(immune.combined, npcs = 30, verbose = FALSE)
immune.combined <- RunUMAP(immune.combined, reduction = "pca", dims = 1:30)
immune.combined <- RunTSNE(immune.combined, tsne.method = "Rtsne", dims = 1:30)
immune.combined <- FindNeighbors(immune.combined, reduction = "pca", dims = 1:30)
immune.combined <- FindClusters(immune.combined, resolution = 0.5)
# Visualization
immune.combined@meta.data$stim = append( rep( 'CTRL', each = meta_dim[[1]][2]), rep( 'stim', each = meta_dim[[2]][2]))
p1 <- DimPlot(immune.combined, reduction = "umap", group.by = "stim")
p2 <- DimPlot(immune.combined, reduction = "umap", label = TRUE, repel = TRUE)
p1 + p2
DimPlot(immune.combined, reduction = "umap", split.by = "stim")

p1 <- DimPlot(immune.combined, reduction = "pca", group.by = "stim")
p2 <- DimPlot(immune.combined, reduction = "pca", label = TRUE, repel = TRUE)
p1 + p2
DimPlot(immune.combined, reduction = "pca", split.by = "stim")

p1 <- DimPlot(immune.combined, reduction = "tsne", group.by = "stim")
p2 <- DimPlot(immune.combined, reduction = "tsne", label = TRUE, repel = TRUE)
p1 + p2
DimPlot(immune.combined, reduction = "tsne", split.by = "stim")
dev.off()
saveRDS(immune.combined, file = rdsOutputfile )





















