#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'tab gene invaild')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



with open( args.tab ) as f :
    print ( next(f) )
    for line in f:
        line_arr = line.strip().split('\t')
        #m = re.search(r'\d+\t.*copy', line)
        #arr = m.group(0).split('\t')
        if len(line_arr) != 6:
            print ( line_arr, len(line_arr))



























