#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import re
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def string2dit(string):
    lst = []
    pn = re.compile(r'\d+')
    ps = re.compile(r'[A-Z]')
    seps = [i for i in pn.split(string) if i ]
    nums = [i for i in ps.split(string) if i ]
    for key,value in zip(seps,nums):
        if key == 'M':
            lst.append(value)
    lst = [int(i) for i in lst ]
    lst.sort(reverse = True )
    return lst[0]



bfh = open(args.bed)
for line in bfh:
    line_arr = line.strip().split('\t')
    start = int(line_arr[1])
    end = int(line_arr[2])
    chain = line_arr[5]
    match_len = string2dit(line_arr[-1])
    if chain == '+' :
        start = end - match_len
    else :
        end = start + match_len
    line_arr[1] = str(start)
    line_arr[2] = str(end)
    print(('\t'.join(line_arr)))























