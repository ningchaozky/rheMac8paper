#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help ='dir for insert ')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

print('''ls | grep sql | perl -ane 'print "mysql -uroot -D go < $_"' |xargs -0 bash -c''')
fls = system.dir('.').fls(pattern = 'txt')
for fl in fls:
    fl = fl.strip('./')
    table = fl.replace('.txt','')
    print('''db_maintain.pl --dbtype mysql --tname %s --dbname go --flatFile %s --sep '\\t' --action all''' % ( table, fl ))




























