zebrafish_hicup_matrix
ICEnorm.Test.r
zebrafish_DI.sh
zebreafish_HMM.calls.m
zebrafish.3post.hmm.domaincaller.sh
