

import os
import sys
import ConfigParser
root_dir = os.getcwd()
cf = ConfigParser.ConfigParser()
conf = sys.argv[1]
cf.read(conf)
project = cf.get('basic','test')
print cf.__dict__
