'''
'''
import re
import os
import os.path
import glob
import sys
import gzip
import linecache
import ConfigParser
reload(sys)
sys.setdefaultencoding('utf-8')
from django.template import Template, Context, loader
from django.conf import settings
settings.configure(DEBUG=True, TEMPLATE_DEBUG=True,TEMPLATE_DIRS=('/allwegene3/pipeline/no_refTR/report_result/modules',))

root_dir = os.getcwd()
cf = ConfigParser.ConfigParser()
conf = '%s/project.ini' % (root_dir)
if not os.path.exists(conf):
    exit("Project configure file not exists!")
cf.read(conf)

## get all analysis steps includes set
includes = cf.get('para','includes')
all_content = set([1,2,3,4,5,6,7,8,9,10,11,12])
includes = set([int(each) for each in includes.split(',')])
project = cf.get('basic','project')
pro_dir = cf.get('basic','pro_dir')
se_pe = cf.get('basic','stype')
species = cf.get('basic','species')
tax = cf.get('basic','tax')
sample = cf.get('para','sample')
group = cf.get('para','group')
groupname = cf.get('para','groupname')
ss = cf.get('para','ss')
replicates = cf.get('para', 'replicates')
#flag_tf = cf.getboolean('para','flag_tf')
#flag_uniform = cf.getboolean('para','flag_uniform')
flag_saturation = cf.getboolean('para','flag_saturation')

##for other flags
flag_qc = False
flag_assem = False
flag_anno = False
flag_cds = False
flag_ssr = False
flag_snp = False
flag_cds = False
flag_exp = False
flag_diff = False
flag_qual = False
flag_go = False
flag_kegg = False
flag_ppi = False

if (set([1]).issubset(includes)):
    flag_qc = True

if (set([2]).issubset(includes)):
    flag_assem = True
   
if (set([3]).issubset(includes)):
    flag_anno = True

if (set([4]).issubset(includes)):
    flag_cds = True
	
if (set([5]).issubset(includes)):
    flag_snp = True

if (set([6]).issubset(includes)):
    flag_ssr = True

if (set([7]).issubset(includes)):
    flag_exp = True

if (set([8]).issubset(includes)):
    flag_quan = True
    flag_diff = True
    compare = cf.get('para','compare')
    venn_cluster_name = cf.get('para','venn_cluster_name')
    union_for_cluster= cf.get('para','union')
    flag_cluster = False
    num_diff = sum(1 for line in open(union_for_cluster))
    if num_diff >50 and num_diff <=25000:
        flag_cluster = True
#    flag_density = True

## RNA_assessment
if (set([9]).issubset(includes)):
    flag_qual = True

if (set([10]).issubset(includes)):
    flag_go = True

if (set([11]).issubset(includes)):
    flag_kegg = True

if (set([12]).issubset(includes)):
    flag_ppi = True

##for strand-specific sequencing
flag_strand = False
if ss == 'reverse':
    flag_strand = True

##############################
samples=sample.split(',')
groupnames=groupname.split(',')
dict_group={}
for i in range(len(groupnames)):
    dict_group[i+1]=groupnames[i]

compares=compare.split(',')
compare_names=[]
for each in compares:
    temp=each.split(':')
    compare_names.append(groupnames[int(temp[0])-1]+'vs'+groupnames[int(temp[1])-1])

##for venn plots
venn_cluster_vs_names=[]
flag_venn = False
for each in venn_cluster_name.split(','):
    if each.count('vs') >= 2 and each.count('vs') <= 5:
        flag_venn = True
    venn_cluster_vs_names.append(each)

## what is the meanings
flag_seq = False
if (len(samples) > 1) and flag_qual:
    flag_seq = True

## report and results ======================================
report_dir = pro_dir + '/' + project +'_report/'
results_dir = pro_dir + '/' + project +'_results/'
assert not os.system('mkdir %s' %(report_dir))
assert not os.system('mkdir %s' %(results_dir))
os.chdir(results_dir)
methods_dir = '/allwegene3/pipeline/no_refTR/report_result/methods'
readme_dir = '/allwegene3/pipeline/no_refTR/report_result/result_readme'
result_order=0
###for example fq dir
if flag_qc:
    assert not os.system('mkdir '+str(result_order)+'.fastq_example')
    os.chdir(str(result_order)+'.fastq_example')
    for eachsample in samples:
        if se_pe != 'se':
            f_in=gzip.open(root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'_1.clean.fq.gz','rb')
        else:
            f_in=gzip.open(root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.clean.fq.gz','rb')
        f_out=[f_in.readline() for num in range(20)]
        open(eachsample+'example.fq.txt','w').writelines(f_out)
        f_in.close()
    assert not os.system('cp %s/0.fastq_example.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.fastq_example/'+str(result_order)+'.fastq_example.README.txt'))
    os.chdir(results_dir)

##for 1.QC
    result_order+=1
    rd_order=str(result_order)
    assert not os.system('mkdir %s' %(rd_order+'.QC'))
    os.chdir(rd_order+'.QC')
##for 1.1error rate
    assert not os.system('mkdir %s' %(rd_order + '.1.ErrorRate'))
    os.chdir(rd_order + '.1.ErrorRate')
    for eachsample in samples:
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.Error.png',eachsample+'.error_rate_distribution.png'))
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.Error.pdf',eachsample+'.error_rate_distribution.pdf'))
    assert not os.system('cp %s/1.1.ErrorRate.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.QC/'+str(result_order)+'.1.ErrorRate/'+str(result_order)+'.1ErrorRate.README.txt'))
    os.chdir('..')

## for 1.2 GC distribution
    assert not os.system('mkdir %s' %(rd_order + '.2.GC'))
    os.chdir(rd_order+'.2.GC')
    for eachsample in samples:
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.GC.png',eachsample+'.GC_content_distribution.png'))
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.GC.pdf',eachsample+'.GC_content_distribution.pdf'))
    assert not os.system('cp %s/1.2.GC.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.QC/'+str(result_order)+'.2.GC/'+str(result_order)+'.2GC.README.txt'))
    os.chdir('..')

##for 1.3 raw reads classfication
    assert not os.system('mkdir %s' %(rd_order + '.3.RawReadsClassfication'))
    os.chdir(rd_order + '.3.RawReadsClassfication')
    for eachsample in samples:
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.pie3d.png',eachsample+'.raw_reads_classification.png'))
        assert not os.system('cp %s %s' % (root_dir+'/QC/'+eachsample+'/clean_data/'+eachsample+'.pie3d.pdf',eachsample+'.raw_reads_classification.pdf'))
    assert not os.system('cp %s/1.3.Filter.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.QC/'+str(result_order)+'.3.RawReadsClassfication/'+str(result_order)+'.3ReadsClassification.README.txt'))
    os.chdir('..')

##for 1.4 qc data table
    assert not os.system('mkdir %s' %(rd_order + '.4.qcTable'))
    os.chdir(rd_order + '.4.qcTable')
    alldataTable = [ root_dir + '/QC/' + sample + '/clean_data/Table' for sample in samples]
    alldataTable = ' '.join(alldataTable)
    assert not os.system("cat %s|cut -f 1-9 > %s " % (alldataTable ,'dataTable.xls.tmp'))
    assert not os.system("cat %s dataTable.xls.tmp > dataTable.xls" %(readme_dir + '/dataTable_header'))
    assert not os.system('rm dataTable.xls.tmp')
    assert not os.system('cp %s/1.4.DataTable.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.QC/'+str(result_order)+'.4.qcTable/'+str(result_order)+'.4DataTable.README.txt'))
    os.chdir(results_dir)

##for 2.Assembly
if flag_assem:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.Assembly')
    os.chdir(''+str(result_order)+'.Assembly')
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'Trinity.fa','Trinity.fa'))
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'unigene.fasta','unigene.fasta'))
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'length.distribution.Stats','length.distribution.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'length.interval.Stats','length.interval.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'length.distribution.png','length.distribution.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Assembly/'+'length.distribution.pdf','length.distribution.pdf'))
    assert not os.system('cp %s/2.Assembly.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Assembly/'+str(result_order)+'.Assembly.README.txt'))
    os.chdir(results_dir)



##for 3.Annotation
if flag_anno:
    result_order+=1
    sub_order=0
    assert not os.system('mkdir '+str(result_order)+'.Annotation')
    os.chdir(''+str(result_order)+'.Annotation')

    ## for 3.1 Summary 
    #sub_order+=1
    #assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.Summary')
    #os.chdir(''+str(result_order)+'.'+str(sub_order)+'.Summary')
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'AnnotationSummary.xls','AnnotationSummary.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'Annotation_merged.xls','Annotation_merged.xls'))
	#assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'unannotated.fasta','unannotated.fasta'))
    assert not os.system('cp %s/3.Annotation.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.Annotation.README.txt'))
    #os.chdir('..')

    ## for 3.2 NR, NT and SwissProt
    #sub_order+=1
    #assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.NR')
    #os.chdir(''+str(result_order)+'.'+str(sub_order)+'.NR')
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'NRannotation.xls','NRannotation.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NT/'+'NTannotation.xls','NTannotation.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/SwissProt/'+'SwissProtAnnotation.xls','SwissProtAnnotation.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'species_classification.xls','species_classification.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'species_classification.png','species_classification.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'species_classification.pdf','species_classification.pdf'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Evalue_distribution.xls','Evalue_distribution.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Evalue_distribution.png','Evalue_distribution.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Evalue_distribution.pdf','Evalue_distribution.pdf'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Similarity_distribution.xls','Similarity_distribution.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Similarity_distribution.png','Similarity_distribution.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/NR/'+'Similarity_distribution.pdf','Similarity_distribution.pdf'))
    #assert not os.system('cp %s/3.2.Annotation.NR.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.'+str(sub_order)+'.NR/'+str(result_order)+'.'+str(sub_order)+'.Annotation.NR.README.txt'))
    #os.chdir('..')

    ## for 3.3 GO 
    #sub_order+=1
    #assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.GO')
    #os.chdir(''+str(result_order)+'.'+str(sub_order)+'.GO')
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/GO/'+'GOannotation.xls','GOannotation.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/GO/'+'complete_go.txt','complete_go.txt'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/GO/'+'GO_classification.png','GO_classification.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/GO/'+'GO_classification.pdf','GO_classification.pdf'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/GO/'+'GO_classification.xls','GO_classification.xls'))
    #assert not os.system('cp %s/3.3.Annotation.GO.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.'+str(sub_order)+'.GO/'+str(result_order)+'.'+str(sub_order)+'.Annotation.GO.README.txt'))
    #os.chdir('..')

    ## for 3.4 KEGG 
    #sub_order+=1
    #assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.KEGG')
    #os.chdir(''+str(result_order)+'.'+str(sub_order)+'.KEGG')
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/KO/'+'KOannotation.xls','KOannotation.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/KO/'+'KO_classification.png','KEGG_classification.png'))
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/KO/'+'KO_classification.pdf','KEGG_classification.pdf'))
    #assert not os.system('cp %s/3.4.Annotation.KEGG.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.'+str(sub_order)+'.KEGG/'+str(result_order)+'.'+str(sub_order)+'.Annotation.KEGG.README.txt'))
    #os.chdir('..')
	
    ## for 3.5 Pfam
    assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/Pfam/'+'pfamAnnotation.xls','pfamAnnotation.xls'))
	

    ## for 3.6 KOG 
    #sub_order+=1
    if tax == 'e':
	#assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.KOG')
	#os.chdir(''+str(result_order)+'.'+str(sub_order)+'.KOG')
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'KOGannotation.xls','KOGannotation.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'KOG.barplot.png','KOG.barplot.png'))
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'KOG.barplot.pdf','KOG.barplot.pdf'))
	#assert not os.system('cp %s/3.5.Annotation.KOG.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.'+str(sub_order)+'.KOG/'+str(result_order)+'.'+str(sub_order)+'.Annotation.KOG.README.txt'))
	#os.chdir('..')
	assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'KOGsummary.xls','KOGsummary.xls'))
    else:
        #assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.COG')
	#os.chdir(''+str(result_order)+'.'+str(sub_order)+'.COG')
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'COGannotation.xls','COGannotation.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'COG.barplot.png','COG.barplot.png'))
        assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'COG.barplot.pdf','COG.barplot.pdf'))
	assert not os.system('cp %s %s' % (root_dir+'/Annotation/'+'/COGKOG/'+'COGsummary.xls','COGsummary.xls'))
	#assert not os.system('cp %s/3.5.Annotation.COG.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Annotation/'+str(result_order)+'.'+str(sub_order)+'.COG/'+str(result_order)+'.'+str(sub_order)+'.Annotation.COG.README.txt'))
	#os.chdir('..')
    os.chdir(results_dir)



##for 4.CDS
if flag_cds:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.CDS')
    os.chdir(''+str(result_order)+'.CDS')
    assert not os.system('cp %s %s' % (root_dir+'/CDSprediction/'+'CDSprediction.results.fa.score','CDSprediction.fasta.txt'))
    assert not os.system('cp %s %s' % (root_dir+'/CDSprediction/'+'CDSprediction.results.protein.score','CDSprediction.protein.txt'))
    assert not os.system('cp %s/4.CDS.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.CDS/'+str(result_order)+'.CDS.README.txt'))
    os.chdir(results_dir)


##for 5. SNP_indel 
if flag_snp:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.SNP')
    snp_order=str(result_order)
    os.chdir(''+str(result_order)+'.SNP')
    assert not os.system('cp %s %s' % (root_dir+'/SNP_Indel/SNP/ResultsQ30/Indels.xls','Indels.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/SNP_Indel/SNP/ResultsQ30/SNPs.xls','SNPs.xls'))
    #assert not os.system('cp %s %s' % (root_dir+'/SNP_Indel/SNP/ResultsQ30/SNP_InDel.stat.xls','SNP_InDel.stat.xls'))
    #assert not os.system('cp %s .' % (root_dir+'/SNP_Indel/SNP/ResultsQ30/SNP_InDel.stat.png'))
    #assert not os.system('cp %s .' % (root_dir+'/SNP_Indel/SNP/ResultsQ30/SNP_InDel.stat.pdf'))
    assert not os.system('cp %s/5.SNP.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.SNP/'+str(result_order)+'.SNP.README.txt'))
    os.chdir(results_dir)


##for 6. SSR 
if flag_ssr:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.SSR')
    os.chdir(''+str(result_order)+'.SSR')
    assert not os.system('cp %s %s' % (root_dir+'/SSR/'+'SSR.results.misa','SSR_results.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/SSR/'+'SSR.results.ssh.primer.results','SSR_primer.xls'))
    assert not os.system('cp %s .' % (root_dir+'/SSR/SSR.motif.distribution.png'))
    assert not os.system('cp %s .' % (root_dir+'/SSR/SSR.motif.distribution.pdf'))
    assert not os.system('cp %s/6.SSR.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.SSR/'+str(result_order)+'.SSR.README.txt'))
    os.chdir(results_dir)



##for 7. Expression 
if flag_exp:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.Expression')
    os.chdir(''+str(result_order)+'.Expression')
    for eachsample in samples:
        assert not os.system('cp %s %s' % (root_dir+'/Expression/'+eachsample+'/'+eachsample+'_fpkm.txt',eachsample+'_fpkm.xls'))
    assert not os.system('cp %s/7.Expression.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.Expression/'+str(result_order)+'.Expression.README.txt'))
    assert not os.system('cp %s %s' % (root_dir+'/Diff/'+'fpkm_description.xls','fpkm.xls'))
    assert not os.system('cp %s %s' % (root_dir+'/Expression/'+'Map_Stats.txt','Map_Stats.xls'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_boxplot.png'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_boxplot.pdf'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_density.png'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_density.pdf'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_violin.png'))
    assert not os.system('cp %s .' % (root_dir+'/Diff/'+'fpkm_violin.pdf'))
    os.chdir(results_dir)
	
	
	
##for 8. diff analysis
if flag_diff:
    result_order+=1
    sub_order=0
    assert not os.system('mkdir '+str(result_order)+'.DiffExprAnalysis')
    os.chdir(''+str(result_order)+'.DiffExprAnalysis')
   ## for 8.1 DEGlist 
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEGsList')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEGsList')
    for each in compare_names:
        os.system('mkdir %s' %(each))
        os.chdir('' + each)
        assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgeneID.xls', each+'.DEG_list.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgeneID_up.xls', each+'.DEG_list_up.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgeneID_down.xls', each+'.DEG_list_down.xls'))
        os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgene.xls', each+'.DEG.xls'))
        os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgene_up.xls', each+'.DEG_up.xls'))
        os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.diffgene_down.xls', each+'.DEG_down.xls'))
	assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.ann.xls', each+'.DEG_ann.xls'))
	assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.ann_up.xls', each+'.DEG_ann_up.xls'))
	assert not os.system('cp %s %s' % (root_dir+'/Diff/' + each + '/' + each + '.ann_down.xls', each+'.DEG_ann_down.xls'))
        ## for DEG seq
        assert not os.system('cp %s %s' % (root_dir+'/Diff/Diff_Gene_Seq/'+ each+'.diffgene.seq',each+'.DEG.fa'))
        assert not os.system('cp %s %s' % (root_dir+'/Diff/Diff_Gene_Seq/'+ each+'.diffgene_up.seq',each+'.DEG.up.fa'))
        assert not os.system('cp %s %s' % (root_dir+'/Diff/Diff_Gene_Seq/'+ each+'.diffgene_down.seq',each+'.DEG.down.fa'))
        ## for Differential_analysis_results.xls
        assert not os.system('cp %s ./' % (root_dir+'/Diff/' + each + '/' + each + '.Differential_analysis_results.xls'))
        ##for vocalno plots
        assert not os.system('cp %s ./' % (root_dir+'/Diff/' + each + '/' + each + '.volcano.pdf'))
        assert not os.system('cp %s ./' % (root_dir+'/Diff/' + each + '/' + each + '.volcano.png'))
        os.chdir('../')
    assert not os.system('cp %s/8.1.DiffList.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.DiffExprAnalysis/'+str(result_order)+'.'+str(sub_order)+'.DEGsList/'+str(result_order)+'.'+str(sub_order)+'DEGsList.README.txt'))
    os.chdir('..')   ## return 8.DiffExprAnalysis
##### for 8.2 heatmap plots
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEGcluster')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEGcluster')
    assert not os.system('cp %s Union_for_cluster.xls' % ( root_dir+'/Diff/cluster/union_for_cluster' ))
    assert not os.system('cp %s .' % (root_dir+'/Diff/cluster/heatCluster.pdf'))
    os.system('cp %s .' % (root_dir+'/Diff/cluster/heatCluster.png'))
    os.system('cp %s .' % (root_dir+'/Diff/cluster/heatCluster.detail.pdf'))
    assert not os.system('cp %s/8.2.Cluster_fpkm.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.DiffExprAnalysis/'+str(result_order)+'.'+str(sub_order)+'.DEGcluster/'+str(result_order)+'.'+str(sub_order)+'DEGcluster.README.txt'))
    if flag_cluster:
        assert not os.system('cp %s %s' % (root_dir+'/Diff/cluster/union_for_cluster_hclust/h_subcluster_plots.pdf','h_cluster_plots.pdf'))
        assert not os.system('cp %s .' % (root_dir+'/Diff/cluster/union_for_cluster_kmeans/kmeans_cluster_plots.pdf'))
        assert not os.system('cp %s .' % (root_dir+'/Diff/cluster/union_for_cluster_som/som_cluster_plots.pdf'))
        assert not os.system('cp %s .' % (root_dir+'/Diff/cluster/union_for_cluster_hclust/h_show_plots.png'))
        assert not os.system('mkdir '+'Subcluster')
        assert not os.system('mkdir '+'Subcluster/kmeans')
        assert not os.system('mkdir '+'Subcluster/hclust')
        assert not os.system('mkdir '+'Subcluster/som')
        assert not os.system('ls %s|while read a;do cut -f 1 $a>%s${a##*/}.xls;done' % (root_dir+'/Diff/cluster/union_for_cluster_kmeans/subcluster*','Subcluster/kmeans/'))
        assert not os.system('ls %s|while read a;do cut -f 1 $a>%s${a##*/}.xls;done' % (root_dir+'/Diff/cluster/union_for_cluster_hclust/subcluster*','Subcluster/hclust/'))
        assert not os.system('ls %s|while read a;do cut -f 1 $a>%s${a##*/}.xls;done' % (root_dir+'/Diff/cluster/union_for_cluster_som/subcluster*','Subcluster/som/'))
    os.chdir('..')

##  for 8.3 Venn 
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.Venn')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.Venn')
    if flag_venn:
        for each in venn_cluster_vs_names:
            os.system('mkdir all up down')
            assert not os.system('cp -r %s ./all' % (root_dir+'/Diff/venn/all/'+each))
            assert not os.system('cp -r %s ./up' % (root_dir+'/Diff/venn/up/'+each))
            assert not os.system('cp -r %s ./down' % (root_dir+'/Diff/venn/down/'+each))
        assert not os.system('cp %s/8.3.Venn.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.DiffExprAnalysis/'+str(result_order)+'.'+str(sub_order)+'.Venn/'+str(result_order)+'.'+str(sub_order)+'VennDiagram.README.txt'))
    else:   ## only two groups/samples
        os.system('cp %s .' % (root_dir+'/Diff/co_exp_list/venn.png'))
        os.system('cp %s .' % (root_dir+'/Diff/co_exp_list/venn.pdf'))
        os.system('cp %s .' % (root_dir+'/Diff/co_exp_list/*co_exp.xls'))
        os.system('cp %s/8.3.two_groups_Venn_fpkm.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.DiffExprAnalysis/'+str(result_order)+'.'+str(sub_order)+'.Venn/'+str(result_order)+'.'+str(sub_order)+'VennDiagram.README.txt'))
    os.chdir(results_dir)
	

	
## for 9. RNA_Seq assessment 
if flag_qual:
    result_order+=1
    sub_order=0
    assert not os.system ('mkdir ' + str(result_order)+ '.RNA_seq_Assessment')
    os.chdir(''+str(result_order)+ '.RNA_seq_Assessment')
## for 6.1 Saturation Curves
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.SaturationCurve')
    os.chdir('' +str(result_order)+'.'+str(sub_order)+'.SaturationCurve')
    for eachsample in samples:
        assert not os.system('cp %s .' % (root_dir+'/RNA_assessment/'+eachsample+'/'+eachsample+'.saturation.pdf'))
        assert not os.system('cp %s .' % (root_dir+'/RNA_assessment/'+eachsample+'/'+eachsample+'.saturation.png'))
    assert not os.system('cp %s/9.1.SatCurve.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.RNA_seq_Assessment/'+str(result_order)+'.'+str(sub_order)+'.SaturationCurve/'+str(result_order)+'.'+str(sub_order)+'SaturationCurve.README.txt'))
    os.chdir('..')
##for 6.2 correlation plots
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.Correlation')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.Correlation')
    for png in glob.iglob(root_dir+'/Diff/corr_plot/*.png'):
        assert not os.system('cp %s .' % png)
    for pdf in glob.iglob(root_dir+'/Diff/corr_plot/*.pdf'):
        assert not os.system('cp %s .' % pdf)
    assert not os.system('cp %s .' % (root_dir+'/Diff/corr_plot/cor_pearson.xls') )
    assert not os.system('cp %s/9.2.DupCorr_fpkm.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.RNA_seq_Assessment/'+str(result_order)+'.'+str(sub_order)+'.Correlation/'+str(result_order)+'.'+str(sub_order)+'Correlation.README.txt'))
    os.chdir(results_dir)



## for 10.go analysis
if flag_go:
    result_order+=1
    sub_order=0
    assert not os.system('mkdir '+str(result_order)+'.DEG_GO')
    os.chdir(''+str(result_order)+'.DEG_GO')
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEG_GOList')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEG_GOList')
    assert not os.system('mkdir ALL')
    assert not os.system('mkdir UP')
    assert not os.system('mkdir DOWN')
    for each in compare_names:
        assert not os.system('cp %s %s' % (root_dir+'/GO/'+each+'/ALL/'+each+'.GO_enrichment_result_up_down.xls', './ALL/'+ each+'.DEG_GO_enrichment_result_all.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GO_enrichment_result.xls', './UP/' + each+'.DEG_GO_enrichment_result_up.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GO_enrichment_result.xls', './DOWN/' + each+'.DEG_GO_enrichment_result_down.xls'))
    assert not os.system('cp %s/10.1.GOList.README.txt %s' % (readme_dir, results_dir + str(result_order)+'.DEG_GO/'+str(result_order)+'.'+str(sub_order)+'.DEG_GOList/'+str(result_order)+'.'+str(sub_order)+'DEG_GOList.README.txt'))
    os.chdir('..')
### for GO plots
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DAG')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DAG')
    assert not os.system('mkdir ALL')
    assert not os.system('mkdir UP')
    assert not os.system('mkdir DOWN')
    for each in compare_names:
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each +'/ALL/'+each+'_ALL.GObp_DAG.png'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.GObp_DAG.pdf'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.GOmf_DAG.png'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.GOmf_DAG.pdf'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.GOcc_DAG.png'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.GOcc_DAG.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GObp_DAG.png', './UP/'+each+'.GObp_DAG_up.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GObp_DAG.pdf', './UP/'+each+'.GObp_DAG_up.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GOmf_DAG.png', './UP/'+each+'.GOmf_DAG_up.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GOmf_DAG.pdf', './UP/'+each+'.GOmf_DAG_up.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GOcc_DAG.png', './UP/'+each+'.GOcc_DAG_up.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.GOcc_DAG.pdf', './UP/'+each+'.GOcc_DAG_up.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GObp_DAG.png', './DOWN/'+each+'.GObp_DAG_down.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GObp_DAG.pdf', './DOWN/'+each+'.GObp_DAG_down.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GOmf_DAG.png', './DOWN/'+each+'.GOmf_DAG_down.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GOmf_DAG.pdf', './DOWN/'+each+'.GOmf_DAG_down.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GOcc_DAG.png', './DOWN/'+each+'.GOcc_DAG_down.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.GOcc_DAG.pdf','./DOWN/'+each+'.GOcc_DAG_down.pdf'))
    assert not os.system('cp %s/10.2.DAG.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.DEG_GO/'+str(result_order)+'.'+str(sub_order)+'.DAG/'+str(result_order)+'.'+str(sub_order)+'DAG.README.txt'))
    os.chdir('..')

## for GO bar plots
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.BAR')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.BAR')
    assert not os.system('mkdir ALL')
    assert not os.system('mkdir UP')
    assert not os.system('mkdir DOWN')
    for each in compare_names:
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.bar_graph.png'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.bar_graph.pdf'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.bar_graph_updown.png'))
        os.system('cp %s ./ALL' % (root_dir+'/GO/'+each+'/ALL/'+each+'_ALL.bar_graph_updown.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.bar_graph.png', './UP/'+each+'.bar_graph_up.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/UP/'+each+'_UP.bar_graph.pdf', './UP/'+each+'.bar_graph_up.pdf'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.bar_graph.png', './DOWN/'+each+'.bar_graph_down.png'))
        os.system('cp %s %s' % (root_dir+'/GO/'+each+'/DOWN/'+each+'_DOWN.bar_graph.pdf', './DOWN/'+each+'.bar_graph_down.pdf'))
    assert not os.system('cp %s/10.3.BAR.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.DEG_GO/'+str(result_order)+'.'+str(sub_order)+'.BAR/'+str(result_order)+'.'+str(sub_order)+'BAR.README.txt'))

os.chdir(results_dir)

##for 11. kegg
if flag_kegg:
    result_order+=1
    sub_order=0
    assert not os.system('mkdir '+str(result_order)+'.DEG_KEGG')
    os.chdir(''+str(result_order)+'.DEG_KEGG')
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGList')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGList')
    os.system('mkdir ALL')
    os.system('mkdir UP')
    os.system('mkdir DOWN')
    for each in compare_names:
        assert not os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/ALL/'+each+'_ALL.KEGG_pathway_enrichment_result.xls', './ALL/'+each+'_all.DEG_KEGG_pathway_enrichment_result.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/UP/'+each+'_UP.KEGG_pathway_enrichment_result.xls', './UP/' + each+'_up.DEG_KEGG_pathway_enrichment_result.xls'))
        assert not os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/DOWN/'+each+'_DOWN.KEGG_pathway_enrichment_result.xls', './DOWN/' + each+'_down.DEG_KEGG_pathway_enrichment_result.xls'))
    assert not os.system('cp %s/11.1.KEGGList.README.txt %s' % (readme_dir, results_dir+str(result_order)+'.DEG_KEGG/'+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGList/'+str(result_order)+'.'+str(sub_order)+'DEG_KEGGList.README.txt'))
    os.chdir('..')
    ## for KEGG scatter plots 
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGScatter')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGScatter')
    os.system('mkdir ALL')
    os.system ('mkdir UP')
    os.system('mkdir DOWN')
    for each in compare_names:
        os.system('cp %s ./ALL' % (root_dir+'/KEGG/'+each+'/ALL/'+each+'_ALL.KEGG_pathway_enrichment_scatterplot.png'))
        os.system('cp %s ./ALL' % (root_dir+'/KEGG/'+each+'/ALL/'+each+'_ALL.KEGG_pathway_enrichment_scatterplot.pdf'))
        os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/UP/'+each+'_UP.KEGG_pathway_enrichment_scatterplot.png' , './UP/' +each+'_up.DEG_enriched_KEGG_pathway_scatterplot.png'))
        os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/UP/'+each+'_UP.KEGG_pathway_enrichment_scatterplot.pdf', './UP/' + each+'_up.DEG_enriched_KEGG_pathway_scatterplot.pdf'))
        os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/DOWN/'+each+'_DOWN.KEGG_pathway_enrichment_scatterplot.png', './DOWN/' +each+'_down.DEG_enriched_KEGG_pathway_scatterplot.png'))
        os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/DOWN/'+each+'_DOWN.KEGG_pathway_enrichment_scatterplot.pdf', './DOWN/' +each+'_down.DEG_enriched_KEGG_pathway_scatterplot.pdf'))
    assert not os.system('cp %s/11.2.KEGGScat.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.DEG_KEGG/'+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGScatter/'+str(result_order)+'.'+str(sub_order)+'DEG_KEGGScatter.README.txt'))
    os.chdir('..')
    
    ## for kegg pathway plots
    sub_order+=1
    assert not os.system('mkdir '+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGPathway')
    os.chdir(''+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGPathway')
    os.system('mkdir ALL UP DOWN')
    os.chdir('ALL')
    for each in compare_names:
        assert not os.system('mkdir '+each)
        assert not os.system('cp %s %s' % (root_dir+'/KEGG/'+each+'/ALL/'+each+'_ALL.html',each))
        assert not os.system('cp -r %s %s' % (root_dir+'/KEGG/'+each+'/ALL/src',each))
    os.chdir('../UP')
    for each in compare_names:
        assert not os.system('mkdir '+each)
        assert not os.system('cp %s %s/' % (root_dir+'/KEGG/'+each+'/UP/'+each+'_UP.html',each))
        assert not os.system('cp -r %s %s/' % (root_dir+'/KEGG/'+each+'/UP/src',each))
    os.chdir('../DOWN')
    for each in compare_names:
        assert not os.system('mkdir '+each)
        assert not os.system('cp %s %s/' % (root_dir+'/KEGG/'+each+'/DOWN/'+each+'_DOWN.html',each))
        assert not os.system('cp -r %s %s/' % (root_dir+'/KEGG/'+each+'/DOWN/src',each))
    assert not os.system('cp %s/11.3.KEGGPath.README.txt %s' % (readme_dir,results_dir+str(result_order)+'.DEG_KEGG/'+str(result_order)+'.'+str(sub_order)+'.DEG_KEGGPathway/'+str(result_order)+'.'+str(sub_order)+'DEG_KEGGPathway.README.txt'))
    os.chdir(results_dir)

	
## for 12.PPI analysis
if flag_ppi:
    result_order+=1
    assert not os.system('mkdir '+str(result_order)+'.PPI')
    os.chdir(''+str(result_order)+'.PPI')
    for each in compare_names:
        assert not os.system('cp %s %s' %(root_dir + '/PPI/' + each + '/' + each +'.ppi',each+'.ppi.txt'))
        assert not os.system('cp %s/12.1.PPI.README.txt %s' %(readme_dir,results_dir+str(result_order)+'.PPI/' +str(result_order)+'.PPI.README.txt'))
    os.chdir(results_dir)




	
######### generate report ...
os.chdir(report_dir)
os.chdir(report_dir)
assert not os.system('mkdir src')
assert not os.system('mkdir src/html')
assert not os.system('mkdir src/pictures')
assert not os.system('cp -r /allwegene3/pipeline/no_refTR/report_result/modules/src/css ./src/')
assert not os.system('cp -r /allwegene3/pipeline/no_refTR/report_result/modules/src/images ./src/')
assert not os.system('cp -r /allwegene3/pipeline/no_refTR/report_result/modules/src/js ./src')
assert not os.system('cp /allwegene3/pipeline/no_refTR/report_result/modules/src/html/help.html ./src/html')
assert not os.system('cp /allwegene3/pipeline/no_refTR/report_result/methods/IGVQuickStart.pdf ./src/')
assert not os.system('cp /allwegene3/pipeline/no_refTR/report_result/modules/src/html/right.html ./src/html')
assert not os.system('cp /allwegene3/pipeline/no_refTR/report_result/modules/AWSxxx_no-refRT_report.html %s' %(project + '_report.html'))
render = {}
#assert not os.system('cp -r /allwegene/dat2/pipeline/no_refTR/report_result/modules/src/ ./')
#assert not os.system('cp -r /allwegene/dat2/pipeline/no_refTR/report_result/modules/AWSxxx_no-refRT_report.html %s' %(project + '_report.html'))
render = {}
render['flag_qc']= False
render['flag_assem']= False
render['flag_anno']= False
render['flag_cds'] = False
render['flag_ssr']= False
render['flag_snp']= False
render['flag_exp']= False
render['flag_diff'] = False
render['flag_qual'] = False
render['flag_go'] = False
render['flag_kegg'] = False
render['flag_ppi'] = False
render['flag_indel'] = False


html_order = 2
render['total_raw_read_pairs']=[]
render['total_clean_read_pairs']=[]
os.chdir(report_dir + '/src/pictures')
if set([1]).issubset(includes):
    render['flag_qc']= True
    html_order += 1
    render['html_order_qc'] = str(html_order)
    render['figure_qc']=[]
    render['qc_table1']=[]
    for eachsample in samples:
        assert not os.system('cp %s %s' %(pro_dir + '/QC/'+eachsample+'/clean_data/'+eachsample+'.Error.png', eachsample + '.error_rate_distribution.png'))
        assert not os.system ('cp %s %s' %(pro_dir + '/QC/'+eachsample+'/clean_data/'+eachsample+'.GC.png', eachsample + '.GC_content_distribution.png'))
        assert not os.system ('cp %s %s' %(pro_dir + '/QC/'+eachsample+'/clean_data/'+eachsample+'.pie3d.png', eachsample + '.raw_reads_classification.png'))
        render['figure_qc'].append([eachsample+'.error_rate_distribution.png',eachsample+'.GC_content_distribution.png',eachsample  + '.raw_reads_classification.png'])
    data=open(pro_dir + '/QC/' + project + '.QC_report/results/1dataTable/dataTable', 'r')
    tb1=data.readlines()
    data.close()
    for each in tb1[1:]:
        render['qc_table1'].append('</td><td>'.join(each.split('\t')))
        each=each.strip().split('\t')
        render['total_raw_read_pairs'].append(int(each[1]))
        render['total_clean_read_pairs'].append(int(each[3]))
    total_raw= sum(render['total_raw_read_pairs'])/2
    total_clean= sum(render['total_clean_read_pairs'])/2
     

tmp=project.split('_')
render['contract'] = tmp[0]
render['replicates_counts']= replicates
render['sample_counts'] = len(samples)
render['group_counts'] = len(groupnames)
render['total_raw'] = total_raw
render ['total_clean'] = total_clean

### for assemble analysis
if set([2]).issubset(includes):
    os.chdir(report_dir + '/src/pictures')
    render['flag_assem']= True
    html_order += 1
    render['html_order_assem'] = str(html_order)
    render['figure_assem']=[]
    render['assem_table1']=[]
    render['assem_table2']=[]
    for eachsample in samples:
        assert not os.system('cp %s %s' %(pro_dir +'/Assembly/'+'length.distribution.png','length.distribution.png'))
        #assert not os.system('cp %s %s' %(pro_dir +'/Map/'+eachsample+'/'+eachsample+'.density.png',eachsample +'.density.png'))
        
    render['figure_assem'].append('length.distribution.png')
    assem_summary1=open(pro_dir + '/Assembly/length.interval.Stats','r')
    tbassem1=assem_summary1.readlines()
    assem_summary1.close()
    for each in tbassem1[1:]:
        render['assem_table1'].append('</td><td>'.join(each.split('\t')))
    
    assem_summary2=open(pro_dir + '/Assembly/length.distribution.Stats','r')
    tbassem2=assem_summary2.readlines()
    assem_summary2.close()
    for each in tbassem2[1:]:
        render['assem_table2'].append('</td><td>'.join(each.split('\t')))

### for annotation
if set([3]).issubset(includes):
    os.chdir(report_dir + '/src/pictures')
    render['flag_anno']= True
    render['flag_exp'] = True
    html_order += 1
    render['html_order_anno'] = str(html_order)
    render['figure_anno1']=[]
    render['figure_anno2']=[]
    render['figure_anno3']=[]
    render['figure_anno4']=[]
    render['figure_fpkm']=[]
    render['figure_cor']=[]
    render['figure_scatter']=[]
    render['anno_table1']=[]
    render['anno_table2']=[]
    render['anno_table3']=[]
    render['anno_table4']=[]
    render['anno_table5']=[]
	
    ##for annotation summary  (remove header)    
    anno_table1 = open(pro_dir+'/Annotation/AnnotationSummary.xls','r')
    anno_table1_content = anno_table1.readlines()
    anno_table1.close()
    for line in anno_table1_content[1:]:
        render['anno_table1'].append('</td><td>'.join(line.strip().split('\t')))
        
    
    ## for nr part (remove header)
    k=5
    anno_table2 = open(pro_dir +'/Annotation/NR/NRpart.xls','r')
    anno_table2_content = anno_table2.readlines()
    anno_table2.close()
    for line in anno_table2_content[1:]:
        render['anno_table2'].append('</td><td>'.join(line.strip().split('\t')))
        k -=1
        if k<0:
            break

    ##for figure species_classification.png,Evalue_distribution.png and Similarity_distribution.png
    assert not os.system('cp %s %s' %(pro_dir + '/Annotation/NR/species_classification.png','species_classification.png'))
    assert not os.system('cp %s %s' %(pro_dir + '/Annotation/NR/Evalue_distribution.png','Evalue_distribution.png'))
    assert not os.system('cp %s %s' %(pro_dir + '/Annotation/NR/Similarity_distribution.png','Similarity_distribution.png'))
    render['figure_anno1'].append(['species_classification.png','Evalue_distribution.png','Similarity_distribution.png'])

    ### for figure go_classification.png
    assert not os.system('cp %s %s' %(pro_dir + '/Annotation/GO/GO_classification.png','GO_classification.png'))
    render['figure_anno2'].append('GO_classification.png')
    
    ### for figure KOG_classification.png
    if tax == 'e':
        assert not os.system('cp %s %s' %(pro_dir + '/Annotation/COGKOG/KOG.barplot.png','KOG_classification.png'))
        render['figure_anno3'].append('KOG_classification.png')
    else:
        assert not os.system('cp %s %s' %(pro_dir + '/Annotation/COGKOG/COG.barplot.png','COG_classification.png'))
        render['figure_anno3'].append('COG_classification.png')
		
    ## for fpkm distribution plots
    assert not os.system('cp %s %s' %(pro_dir +'/Diff/fpkm_boxplot.png','fpkm_boxplot.png'))
    assert not os.system('cp %s %s' %(pro_dir +'/Diff/fpkm_violin.png','fpkm_violin.png'))
    assert not os.system('cp %s %s' %(pro_dir +'/Diff/fpkm_density.png','fpkm_density.png'))
    render['figure_fpkm'].append(['fpkm_boxplot.png','fpkm_violin.png','fpkm_density.png'])
	
    assert not os.system('cp %s %s' %(pro_dir + '/Diff/corr_plot/cor_pearson.png','cor_pearson.png'))
    render['figure_cor'].append(['cor_pearson.png'])

    for png in glob.iglob(pro_dir + '/Diff/corr_plot/*png'):
        if png !=pro_dir+'/Diff/corr_plot/cor_pearson.png':
            name=re.search(r'(/.*/)(.*)\.png',png).group(2)
            assert not os.system('cp %s %s' %(png, name+'.png'))
            render['figure_scatter'].append([name+'.png'])
			
			
    ### for figure KEGG_classification.png
    assert not os.system('cp %s %s' %(pro_dir + '/Annotation/KO/KO_classification.png','KO_classification.png'))
    render['figure_anno4'].append('KO_classification.png')
    
    ## for table 5_3 (remove header)
   
    map_summary = open(pro_dir + '/Expression/'+'Map_Stats.txt','r')
    map_summary_content = map_summary.readlines()
    map_summary.close()
	
    for each in map_summary_content[1:]:
        render['anno_table3'].append('</td><td>'.join(each.split('\t')))
        
    
    ## for table 5_4 (remove header)
    fpkm_exam = open(pro_dir + '/Expression/' + samples[0] + '/' + samples[0] + '_fpkm.txt','r')
    fpkm_exam_content=fpkm_exam.readlines()
    fpkm_exam.close()
    k=5
    for each in fpkm_exam_content[1:]:
        #if line.startswith('#'):
            #line=line.replace('#','')
        render['anno_table4'].append('</td><td>'.join(each.split('\t')))
        k -=1
        if k <0:
            break

    ## for table 5_5 (with header)
    fpkm_stat = open(pro_dir +'/Diff/fpkm.stat.xls','r')
    fpkm_stat_content=fpkm_stat.readlines()
    fpkm_stat.close()
    for each in fpkm_stat_content:
        render['anno_table5'].append('</td><td>'.join(each.split('\t')))	
    #k=5
    #for line in open(pro_dir + '/Expression/fpkm.summary.xls','r'):
        #if line.startswith('#'):
            #line=line.replace('#','')
        #render['anno_table5'].append('</td><td>'.join(line.strip().split('\t')))
        #k -=1
        #if k <0:
            #break 			
	
### Diff 
render['DEG_counts']=''
if set([4,5,6]).issubset(includes):
    render['flag_cds'] = True
    render['flag_snp'] = True
    render['flag_ssr']= True
    render['DEG_counts']=int(num_diff-1)
    os.chdir(report_dir + '/src/pictures')
    html_order += 1
    render['html_order_cds'] = str(html_order)
    ## 6 figures
    render['figure_assessment']=[]
    render['figure_ssr']=[]
    render['snp_table1']=[]
    render['snp_table2']=[]
    render['ssr_table1']=[]
    render['ssr_table2']=[]
    ## for figure 6_1
    if render['flag_qual'] == True:
    	for eachsample in samples:
    		assert not os.system('cp %s %s' % (pro_dir+'/RNA_assessment/'+eachsample+'/'+eachsample+'.saturation.png',eachsample+'.saturation.png'))
    		render['figure_assessment'].append([eachsample+'.saturation.png'])
    
	
    ### ssr motif
    assert not os.system('cp %s %s' % (pro_dir + '/SSR/SSR.motif.distribution.png','SSR.motif.distribution.png'))
    render['figure_ssr'].append('SSR.motif.distribution.png')
    
    ## for SNP  stat table 
    k = 5
    for line in open(pro_dir +'/SNP_Indel/SNP/ResultsQ30/SNPs.xls','r'):
    	render['snp_table1'].append('</td><td>'.join(line.strip().split('\t')))
    	k -= 1
    	if k < 0:
    		break
    
    ### for Indel 
    k = 5
    indelRow = 0
    indel_fh = open(pro_dir + '/SNP_Indel/SNP/ResultsQ30/Indels.xls','r')
    indel_content = indel_fh.readlines()
    indel_fh.close()	
    indelRow = len(indel_content)
    if indelRow > 1:
        render['flag_indel'] = True
        for line in indel_content:
            render['snp_table2'].append('</td><td>'.join(line.strip().split('\t')))
	    k -= 1
	    if k < 0:
		break
	
	
    ### for ssr stat (no header)
    ssr_stat = open(pro_dir + '/SSR/SSR.results.misa','r')
    ssr_content = ssr_stat.readlines()
    ssr_stat.close()	
    k = 5
    for each in ssr_content[1:]:
    	render['ssr_table1'].append('</td><td>'.join(each.split('\t')))	
    	k -= 1
    	if k < 0:
    		break
    
    
    ### for primer (no header)
    ssr_primer = open(pro_dir + '/SSR/SSR.results.ssh.primer.temp','r')
    ssr_primer_content = ssr_primer.readlines()
    ssr_primer.close()
    k = 5
    for each in ssr_primer_content[1:]:
    	render['ssr_table2'].append('</td><td>'.join(each.split('\t')))
    	k -= 1
    	if k < 0:
    		break
    #for each in fpkm_stat_content:
     #   render['expression_table1'].append('</td><td>'.join(each.split('\t')))

    ## for fpkm table
    #k=5
    #for line in open(pro_dir +'/Diff/fpkm.xls','r'):
     #   render['expression_table2'].append('</td><td>'.join(line.strip().split('\t')))
     #   k -=1
     #   if k<0:
      #      break

    

    
## for Diff analysis
if set([8,10,11]).issubset(includes):
    render['flag_diff'] = True
    render['flag_go'] = True
    render['flag_kegg']= True
    os.chdir(report_dir + '/src/pictures')
    html_order += 1
    render['html_order_diff'] = str(html_order)
    ## 7 figures
    render['diff_table']=[]
    render['go_table']=[]
    render['kegg_table']=[]
    render['figure_volcano']=[]
    render['figure_hclust']=[]
    render['figure_venn']=[]
    render['figure_kegg_scatter']=[]
    render['figure_kegg_pathway']=[]
    render['figure_go']=[]
    render['figure_DAG_bp']=[]
    render['figure_DAG_mf']=[]
    render['figure_DAG_cc']=[]
	
	
	
	## for diff gene table
    k=5
    for line in open(pro_dir + '/Diff/' + compare_names[0] +'/' + compare_names[0]+ '.diffgene.xls'):
        array = line.strip().split('\t')
        if not line.startswith('Gene_id'):
            readcount_1 = '%0.2f' %(float(array[1]))
            readcount_2 = '%0.2f' %(float(array[2]))
            log2FC = '%0.2f' %(float(array[3]))
            pval = '%0.2e' %(float(array[4]))
            padj = '%0.2e' %(float(array[5]))
            render['diff_table'].append('</td><td>'.join([array[0],readcount_1,readcount_2,log2FC,pval,padj]))
        else:
            render['diff_table'].append('</td><td>'.join(array))
        k -=1
        if k<0:
            break
	
	
	## for volcano plots
    for each in compare_names:
        assert not os.system('cp %s %s' %(pro_dir + '/Diff/' + each +'/' + each+ '.volcano.png', each+ '.volcano.png'))
        render['figure_volcano'].append([each+ '.volcano.png'])


    ## for heat cluster plots
    assert not os.system('cp %s %s' %(pro_dir+'/Diff/cluster/heatCluster.png','heatCluster.png'))
    render['figure_hclust'].append(['heatCluster.png'])
    ## for venn diagram
    if flag_venn == True:
        render['flag_venn'] = True
        for each in venn_cluster_vs_names:
            assert not os.system('cp %s %s' %(pro_dir + '/Diff/venn/all/' + each + '/' + each + '.venn.png', each + '.venn.png'))
            render['figure_venn'].append([each + '.venn.png'])
    else:
        assert not os.system('cp %s %s' %(pro_dir + '/Diff/co_exp_list/venn.png','venn.png'))
        render['figure_venn'].append(['venn.png'])
		
	
    ## for GO
    k=5
    for line in open(pro_dir+'/GO/' + compare_names[0] + '/ALL/' + compare_names[0] + '_ALL.GO_enrichment_result.xls','r'):
        if line.startswith('GO_accession'):
            continue
        else:
            array=line.strip().split('\t')
            pval= '%0.2e' %(float(array[3]))
            padj='%0.2e' %(float(array[4]))
            render['go_table'].append('</td><td>'.join([array[0],array[1],array[2],pval,padj,array[5],array[6]]))        
        k -=1
        if k<0:
            break

   ## for GO bar graph
    for each in compare_names:
        os.system('cp %s %s' %(pro_dir + '/GO/' + each + '/ALL/' + each + '_ALL.bar_graph.png',each + '_ALL.bar_graph.png'))
        os.system('cp %s %s' %(pro_dir + '/GO/' + each + '/ALL/' + each + '_ALL.bar_graph_updown.png',each + '_ALL.bar_graph_updown.png'))
        
        render['figure_go'].append([each + '_ALL.bar_graph.png',each + '_ALL.bar_graph_updown.png'])

   ## for DAG plots 
    for each in compare_names:
        os.system('cp %s %s' %(pro_dir + '/GO/' + each + '/ALL/' + each + '_ALL.GObp_DAG.png',each + '_ALL.GObp_DAG.png'))
        os.system('cp %s %s' %(pro_dir + '/GO/' + each + '/ALL/' + each + '_ALL.GOmf_DAG.png',each + '_ALL.GOmf_DAG.png'))
        os.system('cp %s %s' %(pro_dir + '/GO/' + each + '/ALL/' + each + '_ALL.GOcc_DAG.png',each + '_ALL.GOcc_DAG.png'))
        render['figure_DAG_bp'].append([each + '_ALL.GObp_DAG.png'])
        render['figure_DAG_mf'].append([each + '_ALL.GOmf_DAG.png'])
        render['figure_DAG_cc'].append([each + '_ALL.GOcc_DAG.png'])

   ## for KEGG
    k=5
    for line in open(pro_dir+'/KEGG/' + compare_names[0] + '/ALL/' + compare_names[0] + '_ALL.KEGG_pathway_enrichment_result.xls','r'):
        if line.startswith('#Term'):
            continue
        else:
            array=line.strip().split('\t')
            if len(array)>1:
                pval = '%0.2f' %(float(array[5]))
                padj = '%0.2f' %(float(array[6]))
                render['kegg_table'].append('</td><td>'.join([array[0],array[1],array[2],array[3],array[4],pval,padj]))
        k -=1
        if k<0:
            break    

    ## for KEGG scatter plots
    for each in compare_names:
        os.system('cp %s %s' %(pro_dir + '/KEGG/' + each + '/ALL/' + each + '_ALL.KEGG_pathway_enrichment_scatterplot.png',each + '_ALL.KEGG_pathway_enrichment_scatterplot.png'))
        render['figure_kegg_scatter'].append([each + '_ALL.KEGG_pathway_enrichment_scatterplot.png'])

    ## for KEGG pathway plots
    os.chdir(pro_dir + '/KEGG/'+compare_names[0]+'/ALL/src/')
    for png in glob.iglob('*png'):
        if png!='bg_pink.png' and png!='bg_red.png' and png!='logo.png' and png!='bg_green.png' and  png!='bg_yellow.png':
            os.chdir(report_dir + '/src/pictures/')
            os.system('cp %s %s' %(pro_dir + '/KEGG/'+compare_names[0]+'/ALL/src/'+ png,report_dir + '/src/pictures/'))
#           name=re.search(r'(/.*/)(.*)\.png',png).group(2)
            render['figure_kegg_pathway'].append([png])
            
if set([12]).issubset(includes):
    render['flag_ppi'] = True

os.chdir(report_dir + '/src/pictures/')
os.chdir(report_dir)
###########
t= loader.get_template('/allwegene3/pipeline/no_refTR/report_result/modules/src/html/right.html')
c=Context(render)
html=t.render(c)
open(report_dir + '/src/html/right.html','w').write(html)
#assert not os.system ("wkhtmltopdf --page-width 350mm --page-height 495mm -n --print-media-type --footer-center '[page] / [topage]' " + report_dir + '/src/html/right.html ' + report_dir + project + '_report.pdf')

os.chdir(results_dir)
os.system('tree -d -v -L 4 -o DirectoryTree.html -H ./')
