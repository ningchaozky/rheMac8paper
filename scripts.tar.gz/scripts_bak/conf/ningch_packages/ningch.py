#!/usr/bin/env python
import sys
import os
import subprocess as sp
import magic
from Bio import SeqIO
import re
import gzip
import socket 
import fcntl
import struct
import json
import numpy as np
import pandas as pd
#from inspect import getmembers,isfunction

def usage_self():
	if len(sys.argv) <= 1:
		print sys.argv[0],'str:f_for_function'
		exit(1)
def usage(hs):
	'str retrun script name add usage string'
	if len(sys.argv) <= 1:
		print sys.argv[0],hs
		exit(1)

def line_num(file_In):
	'\n(file_In) retrun int (line_numer)'
	child = sp.Popen(['wc', '-l',file_In], stdout = sp.PIPE, stderr = sp.PIPE)
	return int(child.stdout.next().split(' ')[0])

def reads_num(bed_str,output):
	'\n(bed,read_nameCol), retrun int(reads_num which have deal paired and single),file_abs:dep paired to single read'
	bed = sp_args(bed_str)[0]
	cols = [int(i) - 1 for i in sp_args(bed_str)[1:]]
	read_col = cols.pop(0)
	work_dir = os.path.dirname(os.path.abspath(bed))
	out_bed = os.path.join(work_dir,output)
	out_bed_hd = open(out_bed,'w')
	reads_num,reads_dict = 0,{}
	bed_hd = open(bed)
	for line in bed_hd:
		line_arr = line.split('\t')
		key = line_arr[read_col].replace('/1','')
		key = key.replace('/2','')
		if key not in reads_dict:
			reads_num += 1
			out_bed_hd.write(line)
			reads_dict[key] = 1
	reads_num = len(reads_dict.keys())
	bed_hd.close()
	return (reads_num,out_bed)

	
def run_sys(cmd_str,wait = 'no'):
	'\n(cmd_str) retrun obj(stdout,stderr)'
	cmd_list = []
	cmd_arr = cmd_str.split(' ')
	for i in cmd_arr:
		if i == ' ':
			continue
		cmd_list.append(i)
	c = sp.Popen(cmd_list, stdout = sp.PIPE, stderr = sp.PIPE)
	if wait == 'yes':
		stdout,stderr = c.communicate()
		stdout_arr = stdout.split('\n')
		stderr_arr = stderr.split('\n')
		stdout_arr = iter([i+'\n' for i in stdout_arr])
		stderr_arr = iter([i+'\n' for i in stderr_arr])
		return stdout_arr,stderr_arr
	else:
		return c.stdout,c.stderr
def annot(input_string):
	'\n(cmd_str) retrun (#cmd_str)'
	input_arr = input_string.split('\n')
	output_string = ''
	for line in input_arr:
		if line == '':
			output_string += '\n'
		else:
			output_string += '#'+line
	return output_string

def check_trim(file_name_with_abs_path):
	'\n(file_name_with_abs_path), retrun (1|0)'
	if not os.path.exists(file_name_with_abs_path):
		return 0
        fh = open(file_name_with_abs_path)
        index = 0
        for line in fh:
                if 'TrimmomaticPE: Completed successfully' in line:
                        index = 1
                if 'TrimmomaticSE: Completed successfully' in line:
                        index = 1
        return index

def sp_args(s):
	'\nexcl,col, retrun list(str1,str2,...)'
	s_arr = s.split(',')
	return s_arr

class excl():
	def __init__(self,excl,header = 'T'):
		xls = {}
		stat = ['abspath','first_line','col_num','row_num','names','header']
		for each in stat:
			if each not in xls:
				xls[each] = []
		for i,each in enumerate(excl):
			File = os.path.abspath(each)
			xls['abspath'].append(File)
			excl_hd = open(File)
			first_line = excl_hd.next().strip()
			col_num = len(first_line.split('\t'))
			xls['first_line'].append(first_line)
			xls['col_num'].append(col_num)
			if header == 'T':
				xls['row_num'].append(line_num(File) - 1)
				xls['names'] = first_line.split('\t')
				xls['header'] = 'T'
			else:
				xls['header'] = 'F'
				xls['row_num'].append(line_num(File))
				xls['names'].append(range(0,col_num))
			excl_hd.close()
		self.xls = xls
	def status(self):
		return self.xls
	def pick_value_from_excl(self,xls,col,row):
		'\nfile:xls,str:name,int:line retrun str(value)'
		xls_hd = open(self.xls['abspath'][xls])
		value = ''
		for p,each in enumerate(xls_hd):
			if self.xls['header'] == 'T' and p + 1 == row:
				value = each.strip().split('\t')[col]
				break
			elif(p == row):
				value = each.strip().split('\t')[col]
				break 
		return value
	def excl_merger(self,s,out_put):
		'\nname,excl,col.... retrun file: excl col cat results'
		output = open(out_put,'w')
		files,values,s_arr_no_empty = [],[],[]
		s_arr_all = s.split(' ')
		for each in s_arr_all:
			if each == '':
				continue
			s_arr_no_empty.append(each)
		lines,arr_length = [],0
		for arr_length,each in enumerate(s_arr_no_empty):
			args = sp_args(each)
			lines.append(line_num(args[1]))
		max_line_num = max(lines)
		arr_length += 1
		init_str = []
		for e in range(arr_length):
			init_str.append('NA')
		values = [['NA' for col in range(arr_length)] for row in range(max_line_num + 1)]
		for p,each in enumerate(s_arr_no_empty):
			each_arr = each.split(',')
			name = each_arr[0]
			file_abs = each_arr[1]
			col = int(each_arr[2]) - 1
			xls_h = open(file_abs)
			values[0][p] = name
			for pos,line in enumerate(xls_h):
				line = line.rstrip()
				line_arr = line.split('\t')
				values[pos+1][p] = line_arr[col]
			xls_h.close()
		for pos,each in enumerate(values):
			each.insert(0,pos)
			if pos == 0:
				each[0] = 'line_num'
			output.write('\t'.join([str(i) for i in each])+'\n')
class excl_pandas():
	def __init__(self):
		pass
	def merge_excl(self,info,join = 'outer',header = 0,axis = 1):
		dfs = []
		for each in info:
			xls,name,index_col,pos_name = each
			df = pd.read_table(xls,sep = '\t',header = header,index_col = index_col)[pos_name]
			if isinstance(name,list):
				df.name = '.'.join(name)
			elif isinstance(name,basestring):
				df.name = name
			dfs.append(df)
		return pd.concat(dfs, axis = axis, join = join)


				
			
			
class nSys():
	'\nmimic system function'
	def __init__(self):
		pass
	def nRm(self,prefix,suffix):
		cmd = 'rm %s*%s' % (prefix,suffix)
		return cmd
	def arr_value(self,s,sep,pos,re = 'F'):
		s = s.strip()
		if re =='F':
			s_arr = s.split(sep)
			return s_arr[int(pos)]
		if re == 'T':
			p = re.compile(r'%s' % sep)
			s_arr = p.split(s)
			return s_arr[int(pos)]
def check_and_annot(cmd,input_file):
	'cmd string, file_name_with_abs_path, retrun (annot or not cmd string)'
	if os.path.exists(str(input_file)) and os.path.getsize(str(input_file)) > 0:
		cmd = annot(cmd)
	return cmd

def check_and_build_index(bam):
	'file:bam return cmd'
	bam = os.path.abspath(bam)
	cmd = ''
	if os.path.exists(bam+'.bai') and os.path.getsize(bam+'.bai'):
		cmd = '#samtools index %s' % bam
	else:
		cmd = 'samtools index %s' % bam
	return cmd


class chromosome():
	'mouse chromosome names 1-19,x,y,MT; human chromosome names 1-22,X,Y,MT; mmSizeFile();hsSizeFile();mmchr();hschr();mmsize();hpsize()'
	def __init__(self,sp):
		self.files = [soft().abspth('mm10.chrom.sizes.chr'),soft().abspth('hg38.chrom.sizes'),soft().abspth('rheMac3.genome')]
		self.chr,self.size,self.abspth = {},0,''
		for each in self.files:
			if os.path.basename(each).startswith(sp):
				self.abspth = each
		f = open(self.abspth)
		for line in f:
			line_arr = line.strip().split('\t')
			self.chr[line_arr[0]] = line_arr[1]
			try:
				self.size += int(line_arr[1])
			except:
				pass
		f.close()
	def size(self):
		return self.size
	def chr(self):
		return self.chr
	def abspth(self):
		return self.abspth
def file_type(In):
	'file:sam_or_bam return str:sam|bam'
	File = os.path.abspath(In)
	work_dir = os.path.dirname(File)
	file_type = magic.from_file(File)
	if 'gzip compressed' in file_type:
		file_type = 'bam'
	if 'ASCII text' in file_type:
		file_type = 'sam'
	return file_type

def insert_suff(name,suff,pos):
	'str:name str:suff int:pos =======> name.suff'
	p = -1
	if pos:
		p = int(pos)
	arr = name.split('.')
	arr.insert(p,suff)
	arr = '.'.join(arr)
	return arr


def check_mapping_status(sam,read1,read2):
	'sam,read1,read2 =========> 1|0'
	last_sam_seq,last_read_seq,index  = [],[],0
	work_file = os.path.abspath(sam)
	read1 = os.path.abspath(read1)
	if not os.path.exists(work_file):
		return 0
	if read2:
		read2 = os.path.abspath(read2)
	stdout,stderr = run_sys('tail -n 20 %s' % work_file)
	for last in stdout:
		if last == '':
			continue
		last_arr = last.split('\t')
		try :
			last_sam_seq.append(last_arr[9])
		except IndexError,e:
			return 0
	stdout,stderr = run_sys('tail -n 20 %s' % read1)
	for last in stdout:
		if last.strip() in last_sam_seq:          
			index = 1
	if read2:
		stdout,stderr = run_sys('tail -n 20 %s' % read2)
		for last in stdout:
			if last.strip() in last_sam_seq:
				index = 1
	return index

def change_suff(name,suff):
	'name,suff ======>name substitute with suff'
	p = re.compile(r'\.\w+$')
	if suff == '':
		name = p.subn(suff,name)[0]
	else:
		name = p.subn('.'+suff,name)[0]
	return name

class soft():
	'\nClass object,\nabspth(excuate function name)  return the abspath of the file\nall() return all file abspth'
	def __init__(self):
		self.path = {}
		self.dirs = []
		path = os.environ['PATH']+':'
		if 'DATA' in os.environ:
			path += os.environ['DATA']
		dirs = path.split(':')
		for d in dirs:
			if d == '':
				continue
			if os.path.exists(d):
				self.dirs.append(d)	
				for exe in os.listdir(d):
					exe = os.path.join(d,exe)
					if os.path.isdir(exe):
						continue
					if os.path.isfile(exe):
						x = os.path.basename(exe)
						self.path[x] = exe
	def abspth(self,In):	
		path = self.path
		if path[In].endswith('.jar'):
			path[In] = 'java -jar %s' % path[In]
		return path[In]
	def all(self):
		return self.path
	def paths(self):
		return self.dirs

class arr():
	'\nClass obj:(self,LIST)\n\tmake_string(self)\n\tmake_int(self)\n\tmake_float(self)'
	def __init__(self,LIST):
		self.arr = LIST
	def make_string(self):
		arr = [str(i) for i in self.arr]
		return arr
	def make_int(self):
		arr = [int(i) for i in self.arr]
		return arr
	def make_float(self):
		arr = [float(i) for i in self.arr]
		return arr

def lastline(File,num='10'):
	file_abs = os.path.abspath(File)
	if not os.path.exists(file_abs):
		file_abs = '-'
	stdout,stderr = run_sys('tail -n %s %s' % (num,file_abs))
	lines = []
	for each in stdout:
		lines.append(each.strip())
	return lines

class openFile():
	def __init__(self,File):
		self.File = os.path.abspath(File)
		self.file_type = magic.Magic().from_file(File)
	def nOpen(self):
		if 'gzip' in self.file_type and 'compressed' in self.file_type:
			return gzip.open(self.File, 'rb')
		if not os.path.exists(self.File) and self.File.endswith('-'):
			return nOpen('-')
		if 'ASCII' in self.file_type and 'CRLF' in self.file_type:
			return nOpen(self.File)

def nOpen(File,mode = 'r'):
	'check whether stdin or not; and return iter handle'
	handle = ''
	if File == '-':
		handle = sys.stdin
	else:	
		File_abspath = os.path.abspath(File)
		if os.path.exists(File_abspath):
			handle = open(File_abspath,mode)
	return handle

class seq_index():
	'fun get_name(ATCACG) return 1'
	def __init__(self):
		self.index = {}
		d = SeqIO.to_dict(SeqIO.parse('/home/ningch/soft/script/conf/index.fa', "fasta"))
		for each in d:
			self.index[str(d[each]._seq)] = each
			self.index[str(d[each].reverse_complement()._seq)] = each
	def get_name(self,s):
		s = s.strip()
		for each in self.index:
			s = s.replace('N','')
			s = s.replace('n','')
			if s in each:
				return each,s,self.index[each]

class bio(soft):
	'\nClass obj: bio(self)\n\ttrim(self,read_1[,read_2],Type = \'PE\')\n\tmapping(self,clean_1[,clean_2],sp,mapper = \'bwa\',Type = \'PE\')\n\
	merge_sams(self,args)\n\tsort(self,sam)\n\tsam2bam(self,sam)\n\tmarkDup(self,bam)\n\tcufflink_fpkm(self,bam,Type=\'fr-unstranded\')\n'
	def __init__(self):
		self.picard = soft().abspth('picard.jar')
		self.convert2bed = soft().abspth('convert2bed')
		self.samtools = soft().abspth('samtools')
	def trim(self,read_1,read_2,Type = 'PE'):
		self.trim_soft = soft().abspth('trimmomatic-0.33.jar')
		self.trim_adapter = soft().abspth('customed_adapter.fa')
		prefix,trim_cmd,log,clean_1,clean_2 = os.path.basename(change_suff(read_1,'').replace('_1','').replace('.fq','')),'','','',''
		if Type == 'PE':
			output = '%s.1P.fq %s.1U.fq %s.2P.fq %s.2U.fq' % (prefix,prefix,prefix,prefix)
			clean_1 = '%s.1P.fq' % prefix
			clean_2 = '%s.2P.fq' % prefix
			log = '%s.PE.cliped.txt' % prefix
			cmd_trim = '%s PE -threads 8 %s %s %s ILLUMINACLIP:%s:2:30:10  MINLEN:36 2>%s.PE.cliped.txt' % \
			(self.trim_soft,read_1,read_2,output,self.trim_adapter,prefix)
			return cmd_trim,clean_1,clean_2,log
		if Type == 'SE':
			output = '%s.se.fq' % prefix
			clean_1 = output
			log = '%s.SE.cliped.txt' % prefix
			cmd_trim = '%s SE -threads 8 %s %s ILLUMINACLIP:%s:2:30:10  MINLEN:36 2>%s.SE.cliped.txt' % \
			(self.trim_soft,read_1,output,self.trim_adapter,prefix)
			return cmd_trim,clean_1,log
	def mapping(self,clean_1,clean_2,sp='hs',mapper = 'bwa',Type = 'PE',other = ''):
		gtf,mappingIndex = '',''
		bwa = soft().abspth('bwa')
		if sp =='hs':
			gtf = soft().abspth('Homo_sapiens.GRCh38.87.chr.gtf')
			mappingIndex = soft().abspth('Homo_sapiens.GRCh38.chr.fa')
		if sp == 'mm':
			gtf = soft().abspth('Mus_musculus.GRCm38.87.chr.gtf')
			mappingIndex = soft().abspth('Mus_musculus.GRCm38.chr.fa')
		if Type == 'PE' and mapper == 'bwa':
			sam = change_suff(os.path.basename(change_suff(clean_1,'').replace('_1','').replace('.fq','')),'sam')
			bwa_cmd = '%s mem %s %s %s -t 8 %s > %s' % (bwa,mappingIndex,clean_1,clean_2,other,sam)
			return bwa_cmd,sam
		if Type == 'SE' and mapper == 'bwa':
			sam = change_suff(os.path.basename(change_suff(clean_1,'').replace('_1','').replace('.fq','')),'sam')
			bwa_cmd = '%s mem %s %s -t 8 %s > %s' % (bwa,mappingIndex,clean_1,other,sam)
			return bwa_cmd,sam
	def merge_sams(self,args):
		merge_In,merge_Out_arr,merge_cmd = '',[],''
		args = [str(i) for i in args]
		for each in args:
			merge_Out_arr.append(change_suff(each,''))
			merge_In += ' INPUT=%s ' % each
		merge_Out = '_'.join(merge_Out_arr)+'.merge.bam'
		merge_cmd = '%s MergeSamFiles %s OUTPUT=%s' % (self.picard,merge_In,merge_Out)
		return merge_cmd,merge_Out
	def sort(self,sam):
		'\n(sam) returr (cmd,out)'
		sam = os.path.basename(sam)
		out = insert_suff(sam,'sort',-1).replace('sam','bam')
		cmd = '%s SortSam SORT_ORDER=coordinate I=%s O=%s' % (self.picard,sam,out)
		return cmd,out
	def merge(self,bams,name):
		merge_in = ''
		merge_out = name+'.bam'
		for each in bams:
			merge_in += ' I='+each
		cmd = '%s MergeSamFiles %s O=%s' % (self.picard,merge_in,merge_out)
		return cmd,merge_out

	def sam2bed(self,sam):
		sam = os.path.basename(sam)
		output = change_suff(sam,'bed')
		cmd = '%s -i %s %s' % (self.convert2bed,sam,output)
		return cmd,output
	def sam2bam(self,sam):
		sam = os.path.basename(sam)
		output = change_suff(sam,'bam')
		cmd = '%s view -bhS %s > %s' % (self.samtools,sam,output)
		return cmd,output
	def markDup(self,bam):
		bam = os.path.basename(bam)
		out = insert_suff(bam,'dup',-1).replace('sam','bam')
		mat = change_suff(bam,'matrix')
		cmd = '%s MarkDuplicates REMOVE_DUPLICATES=TRUE METRICS_FILE=%s I=%s O=%s' % (self.picard,mat,bam,out)
		return cmd,out
	def cufflink_fpkm(self,label,In,Type='fr-unstranded',other = '',sp='hs'):
		cufflink = soft().abspth('cufflinks')
		out_dir = label
		if sp =='hs':
			gtf = soft().abspth('Homo_sapiens.GRCh38.87.chr.gtf')
			mappingIndex = soft().abspth('Homo_sapiens.GRCh38.chr.fa')
		if sp == 'mm':
			gtf = soft().abspth('Mus_musculus.GRCm38.87.chr.gtf')
			mappingIndex = soft().abspth('Mus_musculus.GRCm38.chr.fa')
		cmd = '%s -G %s --label %s %s -p 3 --library-type %s -o %s %s' % (cufflink,gtf,label,other,Type,out_dir,In)
		return cmd,out_dir
	def cuffmerge(self):
		pass
	def macs(self,Input,treat,sp,name,pvalue,other = '',other_out = ''):
		self.macs2 = soft().abspth('macs2')
		output = '%s_peaks.xls' % name
		if treat == Input:
			cmd = '%s callpeak -t %s -n %s -f BAM -g %s -m 5 50 -p %s --broad -B  %s --SPMR' % (self.macs2,treat,name,sp,pvalue,other)
			cmd = cmd.replace(other_out,'')
		else:
			cmd = '%s callpeak -t %s -c %s -n %s -f BAM -g %s -m 5 50 -p %s --broad --SPMR -B %s' % (self.macs2,treat,Input,name,sp,pvalue,other)
			cmd = cmd.replace(other_out,'')
		return cmd,output
	def fastq_dump(self,sra,Type = 'PE'):
		sf= soft().abspth('fastq-dump')
		sra = os.path.basename(sra)
		read_1 = sra.split('.')[0]+'_1.fastq'
		cmd = '%s --split-files %s' % (sf,sra)
		if Type == "PE":
			read_2 = sra.split('.')[0]+'_2.fastq'
			return cmd,read_1,read_2
		if Type == "SE":
			return cmd,read_1
	def bedGraphToBigWig(self,bdg,sp = 'hs'):
		sf = soft().abspth('bedGraphToBigWig.py')
		bw = change_suff(bdg,'bw')
		cmd = '%s %s %s %s' % (sf,bdg,bw,sp)
		return cmd,bw
	def seq(self,seq):
		from Bio.Seq import Seq
		from Bio.Alphabet import generic_dna
		my_dna = Seq(seq, generic_dna)
		return my_dna
	def seq_find(self,raw_dir):
		fs = os.listdir(raw_dir)
		read_1,read_2 = '',''
		for each in fs:
			if each.endswith('_1.fq.gz')  or each.endswith('_1.fq'):
				read_1 = os.path.join(raw_dir,each)
			if each.endswith('_2.fq.gz')  or each.endswith('_2.fq'):
				read_2 = os.path.join(raw_dir,each)
		return read_1,read_2
	def deq(self,input_bam,q='10'):
		out = insert_suff(input_bam,'q10',-1)
		cmd = 'samtools view -bh -q %s %s > %s' % (q,input_bam,out)
		return cmd,out
def get_ip_address(ifname):
	'\nget_ip_address(\'eth0\')'
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	return socket.inet_ntoa(fcntl.ioctl(
		s.fileno(),
		0x8915,  # SIOCGIFADDR
		struct.pack('256s', ifname[:15])
		)[20:24])


class parse_ini():
	'\n__init__(self,ini)\nraw(self)\nripe(self): sample,group key must be given'
	def __init__(self,ini):
		self.ini = os.path.abspath(ini)
		self.d = SeqIO.to_dict(SeqIO.parse(ini, "fasta"))
	def raw(self):
		samples = ''
		if 'sample' in self.d:
			samples = str(self.d['sample']._seq).split(',')
		return self.d,samples
	def ripe(self):
		ini = self.ini
		sample,group,make_up = [],{},{}
		d = SeqIO.to_dict(SeqIO.parse(ini, "fasta"))
		sample = str(d['sample']._seq).split(',')
		group = str(d['group']._seq).split(',')
		return (d,sample,group,make_up)
	def par_json(self):
		with open(self.ini) as json_file:
			json_data = json.load(json_file, object_hook=convert)
			return json_data


def convert(input):
	if isinstance(input, dict):
		return {convert(key): convert(value) for key, value in input.iteritems()}
	elif isinstance(input, list):
		return [convert(element) for element in input]
	elif isinstance(input, unicode):
		return input.encode('ascii')
	else:
		return input



class pbs():
	'\n(self,cpu=1,mem=2)\nheader()\nsplit(self,prefix,bash,num = -1)'
	def __init__(self,soft='bwa',cpu=1,mem=2):
		self.header = '\
#PBS -N default\n\
#PBS -q core24\n\
#PBS -l nodes=1:ppn=%s,mem=%sgb,walltime=1000:00:00\n\
#PBS -j oe\n\
#HSCHED -s lj+%s+human\n' % (soft,cpu,mem)
	def header():
		return self.header
	def split(self,prefix,bash,num = -1):
		num = int(num)
		p = re.compile(r'\n\n+',re.M)
		bs = os.path.abspath(bash)
		work_dir = os.path.dirname(bash)
		bs_h = nOpen(bs)
		cmd,nameList = '',[]
		for line in bs_h:
			cmd += line
		if num == -1:
			cmd_arr = p.split(cmd)
		else:
			cmd_arr = p.split(cmd,num)
		for i,e in enumerate(cmd_arr):
			e = e.strip()
			if e == '':
				continue
			i += 1
			name = '%s.split%d.pbs' % (prefix,i)
			header = self.header.replace('-N default','-N %s' % name)
			name = os.path.join(work_dir,name)
			nameList.append(name)
			output = open(name,'w')
			output.write(header)
			output.write(e)
			output.close()
		return nameList

		
	
def fun_usage(u = 'f'):
	fun,cls = {},{}
	possibles = globals().copy()
	i = 0
	for each in possibles:
		if each in ['pos','socket','re','SeqIO','magic','usage_self','sp','sys','os','subprocess'] or '__' in each:
			continue
		i += 1
		if each not in fun:
			fun[each] = ''
		fun[each] += 'function %s:' % str(i)
		if possibles[each].__doc__:
			fun[each] += possibles[each].__doc__
		else:
			fun[each] += 'None'
		fun[each] += '\n'
	if u == 'f':
		for each in fun:
			print each,fun[each]
	else:
		for each in fun:
			if u in each:
				print each,fun[each]
def ningch_line_num(st):
	stdout,stderr = run_sys('which ningch.py')
	ningch_abspth = stdout.next().strip()
	fh = open(ningch_abspth)
	line_num = []
	for i,e in enumerate(fh):
		i += 1
		if st in e:
			if 'class' in e:
				line_num.append('class line_num: '+str(i))
			if 'def' in e:
				line_num.append('class line_num: '+str(i))

	line_num = arr(line_num).make_string()
	return line_num


if __name__ == '__main__':
	usage_self()
	for each in ningch_line_num(sys.argv[1]):
		print each
	fun_usage(sys.argv[1])
