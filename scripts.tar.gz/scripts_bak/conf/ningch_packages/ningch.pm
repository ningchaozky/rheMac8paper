#!/usr/bin/env perl
package ningch;

sub sp_args {
	@args = split /,/,shift;
	return @args;
}

sub blat { 
	   print "World $_[0]\n" 
}

1;
