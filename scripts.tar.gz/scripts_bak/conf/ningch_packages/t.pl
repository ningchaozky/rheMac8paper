use ningch;
print sp_args('fdfad,2');
