import ningch as nc 
import sys

File = nc.nOpen(sys.argv[1])

for each in File:
	print each
