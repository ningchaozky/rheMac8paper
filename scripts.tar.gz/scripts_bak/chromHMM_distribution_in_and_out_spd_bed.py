#!/usr/bin/env python3
import os
import re
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#sns.barplot( palette="Set3" )
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#fig,ax = plt.subplots(figsize=(10,30))
#plt.style.use('ggplot')
#import seaborn as sns;sns.set(color_codes=True)
import argparse
from ningchao.nSys import trick, fix
from ningchao.nBio import bedKit
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'ini', nargs = '?', help = 'bed ini')
parser.add_argument( '-fc', nargs = '?', help = 'extend fold', type = float)
parser.add_argument( '-up','-u', nargs = '?', help = 'up stream', type = int)
parser.add_argument( '-down','-d', nargs = '?', help = 'down stream', type = int )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



with open( args.ini ) as f:
    for line in f:
        peirod, bed = re.split( r'\s+', line.strip())
        extend = bedKit.bed( bed ).extend( **vars( args ) )
        #cmd = '''bedtools makewindows -b {} -n 200 -i srcwinnum'''.format(bed)
































