#!/usr/bin/env python3
import os
import sys
import sqlite3
import argparse
import ningchao
from ningchao.nSys import trick
example = '''data_sync_check.py output data'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'data', nargs = '?', help = 'data output from data_sync_check.py')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( fl ):
    with open( fl ) as fh:
        for line in fh:
            line_arr = line.strip().split('\t')
            filename = line_arr[0]
            num = line_arr[1]
            for each in line_arr[2:]:
                abspath, ctime, size , timeHuamnReadable, sortOrderBySystem, diskWithID = each.split('|')
                yield filename, abspath, diskWithID, ctime, size , timeHuamnReadable, sortOrderBySystem



if __name__ == '__main__':
    '''CREATE TABLE IF NOT EXISTS sequenceFiles (
	fileName TEXT,
    fileAbsPath TEXT,
    diskWithID TEXT,
    ctime NUMERIC, 
    size INTEGER,
    timeHuamnReadable TEXT,
	sortOrderBySystem INTEGER,
    PRIMARY KEY ( fileName, fileAbsPath, diskWithID));
    '''
    con = sqlite3.connect( os.path.join( ningchao.__path__[0], 'nData/sequence.sqlite3.db') )
    cur = con.cursor()
    for each in parse( args.data  ):
        #print ( each, file = sys.stderr )
        cur.execute('INSERT OR IGNORE INTO sequenceFiles VALUES (?,?,?,?,?,?,?)', each )
    con.commit()
    con.close






























