#!/usr/bin/perl -w

#Use the title delete the fasta

unless(@ARGV){
print "Usage:\n\tcut.pl title fasta model\n";
print "title\tYou want to extract\nfasta\tThe file include the sequene\nmodel\t1 for arry slowly but can extrant all\n\t2 for fast extract, but the sequence should have no repeat. default\n"; 
}
else{

	if(! $ARGV[2] || $ARGV[2]==2){
		open TI,"$ARGV[0]";
		open FA,"$ARGV[1]";

	#made hash for extract	
		my %seq;
		while(<FA>){
			if(/>(.*)/){
			$name = $1;
			$allName .= $1."\n";
			}
			else{
			$seq{$name} .= $_;
			}
		}
		$allName .= "\n";
	#print $allName;
	#extrat seq form hash	
	while(<TI>){
	chomp;
	$_ =~ quotemeta;
		if($allName =~ /$_\n/){
		print ">$_\n";
		print $seq{$_};
		print "\n";			
		}
	}
}
	# arry 
	elsif($ARGV[2] == 1){
	open TITLE,"$ARGV[0]";
	open FASTA,"$ARGV[1]";

	my $title;
	@titles = <TITLE>;
	@titles = map{s///g,$_} @titles;

	# Build fasta file
	$/ = '>';
	while(<FASTA>){
	chomp;
		if(/\S+/){
		push @fasta,$_;
		}
	}

	$/ = "\n";
	for my $title(@titles){
	chomp $title;
		for(@fasta){
		chomp;
		s///g;
		($name,$seq) = split /\n/,$_,2;
		$name = quotemeta $name;
		 	if($title =~ /^$name$/){
			$name =~ s/\\//g;
			print ">$name\n$seq\n";
			last;
			}
		}
	}
	}
}
