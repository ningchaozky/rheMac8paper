#!/usr/bin/env perl 
use warnings;
use strict;
use ningch;

@ARGV || die "$0 xls,col1,col2,.. xls,col1,col2\n";


my @arg1 = ningch::sp_args($ARGV[0]);
my @arg2 = ningch::sp_args($ARGV[1]);



my %xls;
open XLS2, shift @arg2;
while(<XLS2>){
	chomp;
	my @line_arr = split /\t/,$_;
	my @key;
	for my $pos (@arg2){
		push @key,$line_arr[$pos-1];
	}
	my $k = join('\t',@key);
	$xls{$k} += 1;
}
close XLS2;

open XLS1,shift @arg1;
while(<XLS1>){
	chomp;
	my @line_arr = split /\t/;
	my (@key,$key);
	for my $pos (@arg1){
		push @key,$line_arr[$pos-1];
	}
	$key = join('\t',@key);
	unless ($xls{$key}) {
		print "$_\n";
	}
}




