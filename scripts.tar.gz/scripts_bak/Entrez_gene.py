#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import entrez
example = ''' id|gene '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-tab', nargs='+', help ='tab 2(column)')
parser.add_argument('-c', choices=['mm10','hg38'], help ='genome version', required = True )
parser.add_argument('-t', choices=['id2gene','gene2alias','gene2id'], help ='infor you want to get', required = True )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

entrez_class = entrez.entrez(args.c)
dit = eval('entrez_class.%s()' % args.t)
def pt(key,dit):
    key = key.upper()
    if key in dit:
        print(key +'\t' + ','.join(dit[key]))
    else :
        print(key +'\t' + 'none')

if not os.path.exists(args.tab[0]):
    gene = args.tab[0]
    pt(gene,dit)
else :
    tab,col = args.tab
    col = int(col) - 1
    fh = open(tab)
    for line in fh:
        line_arr = line.strip().split('\t')
        key = line_arr[col]
        pt(key,dit)


























