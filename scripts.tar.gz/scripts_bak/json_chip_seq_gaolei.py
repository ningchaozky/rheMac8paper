#!/usr/bin/env python
import os 
import sys
import ningch as nc 

nc.usage('work.json start')

sf = nc.soft()

d = nc.parse_ini(sys.argv[1]).par_json()
root = d['work_dir']
raw_dir = d['raw_data']
readme = d['readme']
leigao_data_dir = os.path.dirname(readme)
leigao_data_dir_2 = d['gaolei_data2_dir']

if 0 :
	z = 0
	with open('trim_and_mapping.sh','w') as fh:
		for marker in d['Marker']:
			marker_dir = os.path.join(root,marker)
			if isinstance(d['Marker'][marker], str):
				continue
			for period in d['Marker'][marker]:
				period_dir = os.path.join(marker_dir,period)
				for e in d['Marker'][marker][period]:
					work_dir = os.path.join(raw_dir,d['Marker'][marker][period][e])
					read_1 =  os.path.join(leigao_data_dir,period,d['Marker'][marker][period][e].split('.')[2]+'_1.fq.gz')
					if not os.path.exists(read_1):
						read_1 = os.path.join(leigao_data_dir_2,d['Marker'][marker][period][e].split('.')[2]+'_1.fq.gz')
					read_2 = read_1.replace('_1.','_2.')

					mkdir_cmd = 'mkdir -p %s' % work_dir
					mkdir_cmd = nc.check_and_annot(mkdir_cmd,work_dir)
					trim_cmd,clean_1,clean_2,log = nc.bio().trim(read_1,read_2)
					clean_1,clean_2,log = [os.path.join(work_dir,i) for i in (clean_1,clean_2,log)]
					log = os.path.join(work_dir,log)
					if os.path.exists(log) and nc.check_trim(log):
						trim_cmd = nc.annot(trim_cmd)
					
					map_cmd,map_out = nc.bio().mapping(clean_1,clean_2,sp='hs',mapper = 'bwa',Type = 'PE')
					map_out = os.path.join(work_dir,map_out)
					if nc.check_mapping_status(map_out,clean_1,clean_2):
						map_cmd = nc.annot(map_cmd)
			
					sort_cmd,sort_out = nc.bio().sort(map_out)
					sort_out = os.path.join(work_dir,sort_out)
					sort_cmd = nc.check_and_annot(sort_cmd,sort_out)

					dup_cmd,dup_out = nc.bio().markDup(sort_out)
					dup_out = os.path.join(work_dir,dup_out)
					dup_cmd = nc.check_and_annot(dup_cmd,os.path.join(work_dir,dup_out))
					

					map_cmd = nc.check_and_annot(map_cmd,dup_out)
					map_cmd = nc.check_and_annot(map_cmd,sort_out)
					sort_cmd = nc.check_and_annot(sort_cmd,dup_out)
					trim_cmd = nc.check_and_annot(trim_cmd,sort_out)
					fh.write(mkdir_cmd+'\n')
					z += 1
					fh.write('#seq %s\ncd %s\n' % (str(z),work_dir))
					fh.write(trim_cmd+'\n')
					fh.write(map_cmd+'\n')
					fh.write(sort_cmd+'\n')
					fh.write(dup_cmd+'\n')
					fh.write('\n\n')			
#					print 'ssh ningch@192.168.76.34 mkdir -p /home/ningch/data/chip-seq/human/raw_data/%s' % (os.path.basename(work_dir))
#					print 'scp.py %s /home/ningch/data/chip-seq/human/raw_data/%s' % (os.path.join(work_dir,dup_out),os.path.basename(work_dir))

if 0 :
	z = 0
	with open('callpeak.sh','w') as fh:
		for marker in d['Marker']:
			marker_dir = os.path.join(root,marker)
			for period in d['Marker'][marker]:
				period_dir = os.path.join(marker_dir,period)
				if 'Input' in d['Marker'][marker]:
					continue 
				for e in d['Marker'][marker][period]:
					work_dir = os.path.join(raw_dir,d['Marker'][marker][period][e])
					sample_dir = d['Marker'][marker][period][e]
					treat = os.path.join(raw_dir,sample_dir,sample_dir.split('.')[2]+'.sort.dup.bam')
					if os.path.exists(treat):
						input_key = sample_dir.split('.')[1]+'.Input.rep1'
						Input_dir = d['Marker'][input_key]
						Input = os.path.join(raw_dir,Input_dir,Input_dir.split('.')[2]+'.sort.dup.bam')
						if os.path.exists(Input):
							z += 1
							fh.write('#seq %s\ncd %s\n' % (str(z),os.path.dirname(treat)))
							macs_cmd,macs_out = nc.bio().macs(Input,treat,sp='hs',name = sample_dir.split('.')[2],pvalue='1e-3' )
							macs_out = os.path.join(os.path.dirname(treat),macs_out)
							macs_cmd = nc.check_and_annot(macs_cmd,macs_out)
							fh.write(macs_cmd+'\n')

							bdg =os.path.join(os.path.dirname(treat), macs_out.replace('_peaks.xls','_treat_pileup.bdg'))
							bdgBw_cmd,bw = nc.bio().bedGraphToBigWig(bdg)
							bdgBw_cmd = nc.check_and_annot(bdgBw_cmd,bw)
							fh.write(bdgBw_cmd+'\n')


							macs_cmd,macs_out = nc.bio().macs(Input,treat,sp='hs',name = sample_dir.split('.')[2]+'.vBroad',pvalue='1e-3',other_out ='--broad' )
							macs_out = os.path.join(os.path.dirname(treat),macs_out)
							macs_cmd = nc.check_and_annot(macs_cmd,macs_out)
							fh.write(macs_cmd+'\n')
							
							bdg =os.path.join(os.path.dirname(treat), macs_out.replace('_peaks.xls','_treat_pileup.bdg'))
							bdgBw_cmd,bw = nc.bio().bedGraphToBigWig(bdg)
							bdgBw_cmd = nc.check_and_annot(bdgBw_cmd,bw)
							fh.write(bdgBw_cmd+'\n')
							
							bdg =os.path.join(work_dir, macs_out.replace('_peaks.xls','_control_lambda.bdg'))
							bdgBw_cmd,bw = nc.bio().bedGraphToBigWig(bdg)
							bdgBw_cmd = nc.check_and_annot(bdgBw_cmd,bw)
							fh.write(bdgBw_cmd+'\n')
							
							fh.write('\n\n')

if 0 :
	z = 0
	with open('Repeatability.sh','w') as fh:
		for marker in d['Marker']:
			marker_dir = os.path.join(root,marker)
			for period in d['Marker'][marker]:
				period_dir = os.path.join(marker_dir,period)
				if isinstance(d['Marker'][marker], str):
					continue
				work_dir = os.path.join(d['work_dir'],marker,period)
				ven,cor = [],[]
				for rep in d['Marker'][marker][period]:
					sample = d['Marker'][marker][period][rep]
					source_dir = os.path.join(d['raw_data'],d['Marker'][marker][period][rep])
					broad_rep_peaks = os.path.join(source_dir,d['Marker'][marker][period][rep].split('.')[2]+'_peaks.xls')
					rep_vbroad_peaks = os.path.join(source_dir,d['Marker'][marker][period][rep].split('.')[2]+'.vBroad_peaks.xls')
					bw = os.path.join(source_dir,d['Marker'][marker][period][rep].split('.')[2]+'_treat_pileup.bw')
					
					fh.write('cd %s\n' % work_dir)
					fh.write('cp %s %s\n' % (broad_rep_peaks,work_dir))
					fh.write('cp %s %s\n' % (rep_vbroad_peaks,work_dir))
					fh.write('cp %s %s\n' % (bw,work_dir))
					broad_rep_peaks = os.path.basename(broad_rep_peaks)
					rep_vbroad_peaks = os.path.basename(rep_vbroad_peaks)
					fh.write('clean_no_chr_line.py %s hs\n' % broad_rep_peaks)
					fh.write('clean_no_chr_line.py %s hs\n' % rep_vbroad_peaks)
					broad_rep_peaks_chr = nc.insert_suff(broad_rep_peaks,'chr',-1)
					rep_vbroad_peaks_chr = nc.insert_suff(rep_vbroad_peaks,'chr',-1)
					broad_rep_peaks_chr_hist_data = nc.change_suff(broad_rep_peaks_chr,'histdata')
					rep_vbroad_peaks_chr_hist_data = nc.change_suff(rep_vbroad_peaks_chr,'histdata')
					fh.write('prepare_bin_for_length_distribution.py %s > %s\n' % (broad_rep_peaks_chr,broad_rep_peaks_chr_hist_data))
					fh.write('prepare_bin_for_length_distribution.py %s > %s\n' % (rep_vbroad_peaks_chr,rep_vbroad_peaks_chr_hist_data))
					fh.write('draw_histogram.R %s %s\n' % (broad_rep_peaks_chr_hist_data,broad_rep_peaks_chr_hist_data))
					fh.write('draw_histogram.R %s %s\n' % (rep_vbroad_peaks_chr_hist_data,rep_vbroad_peaks_chr_hist_data))
					pie_data = nc.change_suff(broad_rep_peaks_chr,'pie_data')
					fh.write('peaks_cover_precent.py %s,4 hs > %s\n' % (broad_rep_peaks_chr,pie_data))
					fh.write('draw_pie.R %s %s\n' % (pie_data,nc.change_suff(pie_data,'')))
					pie_data = nc.change_suff(rep_vbroad_peaks_chr,'pie_data')
					fh.write('peaks_cover_precent.py %s,4 hs > %s\n' % (rep_vbroad_peaks_chr,pie_data))
					fh.write('draw_pie.R %s %s\n' % (pie_data,nc.change_suff(pie_data,'')))
					broad_peaks_bed = os.path.join(work_dir,d['Marker'][marker][period][rep].split('.')[2]+'.bed')
					vbroad_peaks_bed = os.path.join(work_dir,d['Marker'][marker][period][rep].split('.')[2]+'.vbroad.bed')
					fh.write('grep -v \'#\'  %s | grep -v chr |cut -f1,2,3 |sed /^$/d > %s\n' % (broad_rep_peaks,broad_peaks_bed))
					fh.write('grep -v \'#\'  %s | grep -v chr |cut -f1,2,3 |sed /^$/d > %s\n' % (rep_vbroad_peaks,vbroad_peaks_bed))
					ven.append(vbroad_peaks_bed)
					rep_bam = os.path.join(d["raw_data"],'%s/%s.sort.dup.bam' % (sample,sample.split('.')[-2]))
					rep_bed = nc.change_suff(rep_bam,'bed')
					fh.write('bedtools bamtobed -i %s > %s\n' % (rep_bam,rep_bed))
					bin_bed_name = os.path.basename(d['bin'])
					intersect_out = nc.change_suff(rep_bed,'intersect.bin')
					fh.write('bedtools intersect -a %s -b %s -wo > %s\n' % (rep_bed,d['bin'],intersect_out))
					cor_rpkm_out = os.path.basename(nc.change_suff(intersect_out,'cor.rpkm'))
					fh.write('cd %s\n' % os.path.dirname(intersect_out))
					fh.write('get_fpkm_from_intersect_bed.py %s %s %s %s\n' % (rep_bed,intersect_out,d['bin'],cor_rpkm_out))
					rpkm_out = cor_rpkm_out.replace('.cor','')
					fh.write('get_rpkm_from_intersect_bed.py %s,7,8,9 %s\n' % (intersect_out,rpkm_out))
					fh.write('cp %s %s\n' % (cor_rpkm_out,work_dir))

					cor.append(cor_rpkm_out)
				if len(cor) > 1:
					cor_string = ''
					for each in cor:
						cor_string += ','.join([each,each,'4'])+' '
					fh.write('cd %s\n' % work_dir)
					fh.write('excls_col_cat.py %s %s\n' % (cor_string,'rpkm.cor.xls'))
					fh.write('cor.R rpkm.cor.xls rpkm.cor')
				ven_bed = []
				in_bed = ' '.join(ven)
				if ven == []:
					continue
				merge_cmd = 'cat %s | sort -k1,1 -k2,2n | bedtools merge -i - | perl -pe \'$i++;chomp; $_ = $_.\"\\t\".$i."\\n"\'> merge_all_rep.bed' % in_bed
				fh.write('cd %s\n' % work_dir)
				fh.write(merge_cmd+'\n')
				for e in ven:
					file_name = os.path.basename(e)
					intersect_out = os.path.join(work_dir,file_name+'.intersect.merge.bed')
					ven_bed.append(','.join([file_name,intersect_out,'7']))
					fh.write('bedtools intersect -a %s -b %s -wb > %s' % (file_name,'merge_all_rep.bed',intersect_out) +'\n')
				if len(ven) > 1:
					fh.write('excls_col_cat.py %s %s' % (' '.join(ven_bed),os.path.join(work_dir,'ven.data'))+'\n')
					fh.write('draw_ven.R %s %s' % ('ven.data','ven')+'\n')
				fh.write('\n\n')

if 0 :
	z = 0
	with open('merge.sh','w') as fh:
		for marker in d['Marker']:
			if isinstance(d['Marker'][marker], dict):
				for peirod in d['Marker'][marker]:
					work_dir = os.path.join(root,marker,peirod)
					mkdir_cmd = 'mkdir -p %s' % work_dir
					mkdir_cmd = nc.check_and_annot(mkdir_cmd,work_dir)
					fh.write(mkdir_cmd+'\n')
					z += 1
					fh.write('#seq %s\ncd %s' % (str(z),work_dir)+'\n')
					if list(d['Marker'][marker][peirod].values()) == []:
						fh.write('\n\n')
						continue
					bams = [os.path.join(d['raw_data'],i,i.split('.')[-2]+'.sort.dup.bam') for i in  list(d['Marker'][marker][peirod].values())]
					merge_cmd,merge_out = nc.bio().merge(bams,'merge.sort.dup')
					merge_out = os.path.join(work_dir,'merge.sort.dup.bam')
					merge_cmd = nc.check_and_annot(merge_cmd,merge_out)
					fh.write(merge_cmd+'\n')
					fh.write('\n\n')
			elif isinstance(d['Marker'][marker], str):
				pass


if 1 :
	z = 0
	with open('call.merge.peaks.sh','w') as fh:
		for marker in d['Marker']:
			if isinstance(d['Marker'][marker], dict):
				for peirod in d['Marker'][marker]:
					work_dir = os.path.join(root,marker,peirod)
					if os.path.exists(os.path.join(work_dir,'merge.sort.dup.bam')):
						z += 1
						fh.write('#seq %s\ncd %s' % (str(z),work_dir)+'\n')
						Input = os.path.join(raw_dir,d['Marker']["%s.Input.rep1" % peirod],d['Marker']["%s.Input.rep1" % peirod].split('.')[-2]+'.sort.dup.bam')
						deq_input_cmd,dep_input_out = nc.bio().deq(Input,'10')
						Input = dep_input_out
						deq_input_cmd = nc.check_and_annot(deq_input_cmd,os.path.join(work_dir,dep_input_out))
						fh.write(deq_input_cmd+'\n')
						deq_treat_cmd,dep_treat_out = nc.bio().deq('merge.sort.dup.bam','10')
						deq_treat_cmd = nc.check_and_annot(deq_treat_cmd,os.path.join(work_dir,os.path.join(work_dir,dep_treat_out)))
						fh.write(deq_treat_cmd+'\n')

						macs_cmd, macs_out = nc.bio().macs(Input,'merge.sort.dup.q10.bam',sp= 'hs', name = '%s.%s' % (peirod,marker), pvalue = '1e-5', other_out = '--broad')
						macs_out = os.path.join(work_dir,macs_out)
						macs_cmd = nc.check_and_annot(macs_cmd,macs_out)
						fh.write(macs_cmd+'\n')

						chr_out = nc.insert_suff(macs_out,'chr','-1')
						chr_cmd = nc.check_and_annot('clean_no_chr_line.py %s hg ' % (macs_out),chr_out)
						fh.write(chr_cmd+'\n')
						
						peaks_chr_hist_data = nc.change_suff(chr_out,'histdata')
						len_pie_cmd = nc.check_and_annot('prepare_bin_for_length_distribution.py %s > %s\n' % (chr_out,peaks_chr_hist_data),peaks_chr_hist_data)
						fh.write(len_pie_cmd)

						histogram_cmd = nc.check_and_annot('draw_histogram.R %s %s\n' % (peaks_chr_hist_data,peaks_chr_hist_data),peaks_chr_hist_data+'.png')
						fh.write(histogram_cmd)

						pie_data = nc.change_suff(chr_out,'pie_data')
						fh.write(nc.check_and_annot('peaks_cover_precent.py %s,4 hg > %s\n' % (chr_out,pie_data),pie_data))
						png = nc.change_suff(pie_data,'pie')+'.png'
						prefix = nc.change_suff(os.path.basename(pie_data),'pie')
						fh.write(nc.check_and_annot('draw_pie.R %s %s\n' % (pie_data,prefix),png))
						
						
						intersect_promoter_out = nc.change_suff(chr_out,'intersect_promoter.bed')
						promoter_cmd = nc.check_and_annot('bedtools intersect -a %s -b %s -wo > %s' % (chr_out,d["promoter_1K"],intersect_promoter_out),intersect_promoter_out)
						fh.write(promoter_cmd+'\n')

						promoter_contain_peaks = nc.change_suff(intersect_promoter_out,'promoter_contain_peaks.bed')
						contain_peaks_cmd = nc.check_and_annot('cut -f1,2,3,10 %s | awk \'!x[$0]++\' > %s\n' % (intersect_promoter_out,promoter_contain_peaks),promoter_contain_peaks)
						fh.write(contain_peaks_cmd)

						precent_out = os.path.join(work_dir,'%s.promoter_info.data' % nc.change_suff(promoter_contain_peaks,''))
						promoter_contain_percent_prepare = nc.check_and_annot('prepare_promoter_contain_pie_data.py %s %s %s\n' % (promoter_contain_peaks,chr_out,precent_out),precent_out)
						fh.write(promoter_contain_percent_prepare)
						
						draw_pie_cmd = nc.check_and_annot('draw_pie_v2.R %s %s\n' % (precent_out,precent_out),precent_out+'.png')
						fh.write(draw_pie_cmd)



						bdg =os.path.join(work_dir, macs_out.replace('_peaks.xls','_treat_pileup.bdg'))
						bdgBw_cmd,bw = nc.bio().bedGraphToBigWig(bdg)
						bdgBw_cmd = nc.check_and_annot(bdgBw_cmd,bw)
						fh.write(bdgBw_cmd+'\n')
						
						bdg =os.path.join(work_dir, macs_out.replace('_peaks.xls','_control_lambda.bdg'))
						bdgBw_cmd,bw = nc.bio().bedGraphToBigWig(bdg)
						bdgBw_cmd = nc.check_and_annot(bdgBw_cmd,bw)
						fh.write(bdgBw_cmd+'\n')
						fh.write('\n\n')

#					if os.path.exists(os.path.join(work_dir,'bwa_merge_treat.bam')):
#						z += 1
#						treat = os.path.join(work_dir,'bwa_merge_treat.bam')
#						Input = os.path.join(work_dir,'bwa_merge_input.bam')
#						fh.write('#seq %s\ncd %s\n' % (str(z),work_dir))
#						macs_cmd, macs_out = nc.bio().macs(Input,treat,sp= 'hs', name = '%s.%s' % (peirod,marker), pvalue = '1e-3', other_out = '--broad')
#						macs_out = os.path.join(work_dir,macs_out)
#						macs_cmd = nc.check_and_annot(macs_cmd,macs_out)
#						fh.write(macs_cmd+'\n')
						

						fh.write('\n\n')
