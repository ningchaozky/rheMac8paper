#!/usr/bin/env Rscript
#first
alen <- commandArgs()
suppressMessages(library(argparser))
p <- arg_parser('melt pos period stat')
p <- add_argument(p, "tab",help = "tab for plot sankey plot [alluvial]" )
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))
suppressMessages(library( ggalluvial ))
suppressMessages(library( forcats ))
suppressMessages(library( dplyr ))
suppressMessages(library( alluvial ))

#data(vaccinations)
#fct_reorder
#levels(vaccinations$response) <- rev(levels(vaccinations$response))
#df = read.table( 'chr1.e6.xls', check.names = FALSE, header = TRUE)
#method one
df = read.table( args$tab, check.names = FALSE, header = TRUE)
#alluvial( df[,2:8], freq = df$freq )
#dev.off()
#stop()

plevels = c("E50", "E90", "E120", "P0", "4M", "45Y", "20Y")
#slevels = paste('E', seq(12), sep="")
slevels = c('biv','active','repress')
#df$p <- factor( df$period, levels = c("E50", "E90", "E120", "0M", "4M", "45Y", "20Y"))
df %>% mutate( period = factor( period, levels = plevels)) %>%
mutate( stat = factor( stat, levels = slevels)) %>%
#ggplot( aes(x = period, stratum = stat, alluvium = pos, y = num, fill = stat, label = stat)) +
ggplot( aes(x = period, stratum = stat, alluvium = pos, fill = stat, label = stat)) +
  scale_x_discrete(expand = c(.1, .1)) +
  geom_flow() +
  geom_stratum(alpha = .5) +
  geom_text(stat = "stratum", size = 3) +
  theme(legend.position = "none") +
  ggtitle("stat dynamic development")
ggsave(paste( args$tab, "alluvialSankeyStackPlot.pdf", sep = '.'))
