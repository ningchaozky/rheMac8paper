#!/usr/bin/env python3
import os
import sys
import math
import argparse
import pandas as pd
import numpy as np
from scipy import stats
from collections import defaultdict
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'peirod', nargs = '?', help = 'peirod for RNA extract')
parser.add_argument( 'order', nargs = '?', help = 'order file output from match_epigenitics_order.py')
parser.add_argument( '-trans_exp', nargs = '?', help = 'transcript file for exp', default = '/farangism/ningch/earyly_embryo/RNA/transcripts.exp.tpm')
parser.add_argument( '-t2g', nargs = '?', help = 'transcript to gene file', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.geneTransPromoterMean')
parser.add_argument( '-kt', choices = ['gene', 'transcript_id'], help = 'merge transcript to gene or not')
parser.add_argument( '-normal', choices = [ 'zscore', 'hardCut','raw','n1','qcut', '+1log2'], help = 'normal method if hardCut set value', default = 'raw')
parser.add_argument( '-value', nargs = '?', help = 'value for hard cut', default = 2 )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def tginfor( fl ):
    infor = defaultdict( dict )
    with open( fl ) as f :
        for line in f:
            line_arr = line.strip().split('\t')
            tid, gid = line_arr[3], line_arr[6]
            infor[tid] = gid
    return infor

def get_normal( **kwargs ):
    orderFile, transExpFile, peirod, normal, value = [ kwargs.get(i) for i in ['order','trans_exp','peirod','normal','value']]
    vals, index = [], []
    with open( transExpFile ) as f :
        pindex = next(f).strip().split('\t').index( peirod )
        print ('#Peirod is {}, select {}'.format(peirod, pindex), file = sys.stderr)
        for line in f:
            line_arr = line.strip().split('\t')
            vals.append( float( line_arr[pindex] ) )
            index.append( line_arr[0] )
    if normal == 'hardCut':
        vals = [ i > value and 1 or 0 for i in vals ]
    elif normal == 'zscore':
        vals = stats.zscore( vals, ddof = 1 )
    elif normal == 'n1':
        vals = [ i > 30 and 30 or i for i in vals ]
        vmin, vmax = min( vals ), max(vals)
        vals = [ (i - vmin) / (vmax - vmin) for i in vals ]
    elif normal == 'qcut':
        tmp = pd.qcut( vals, 6, labels = None, duplicates = 'drop' )
    elif normal == '+1log2':
        vals = [ math.log2(i+1) or i for i in vals  ]
    fh = open( '{}.{}.exp.xls'.format( peirod, normal), 'w' )
    print ( 'transcript_id', peirod, sep = '\t', file = fh )
    for trans_id, val in zip(index, vals):
        print ( trans_id, val, sep = '\t', file = fh)
    fh.close()
    return fh.name


def format( lst ):
    out = []
    for each in lst:
        try :
            out.append( float(each) )
        except :
            out.append( each )
    return out


if __name__ == '__main__':
    #infor = pd.read_csv( args.trans_exp, sep = '\t', index_col = 0, header = 0).T.to_dict()
    if args.kt == 'gene':
        tinfor = tginfor( args.t2g )
    normal_xls = get_normal( **vars( args ))
    cmd = 'excel_extract_v2.py {} -b {}'.format( args.order, normal_xls)
    lst = []
    for line in system.run( cmd, shell = True ):
        if args.kt == 'gene':
            line_arr = line.strip().split('\t')
            line_arr[0] = tinfor.get(line_arr[0])
            lst.append( format( line_arr ) )
        elif args.kt == 'transcript_id' :
            lst.append( format( line.strip().split('\t') ) )
    header = lst.pop(0)
    header[0] = 'symbol'
    df = pd.DataFrame( lst, columns = header )
    df.to_csv( 'transcript_id.gene.xls' )
    grouped = df.groupby([ 'symbol','group' ], sort=False).mean().reset_index()
    grouped.to_csv( sys.stdout, sep = '\t', index = False )





