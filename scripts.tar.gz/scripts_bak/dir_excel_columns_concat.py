#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick, system
example = '''pattern excel concat'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help ='dir for find excl')
parser.add_argument('-p', nargs='?', help ='pattern for excle')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def parse( args ):
    fls = list (system.dir( args.dir ).fls( args.p, abspath = False ) )
    return fls


fls = parse( args )
index = 0

for fl in fls:
    fh = open( fl )
    for line in fh:
        line_arr = line.strip().split('\t')
        if 'AC' in line_arr and 'pol2' in line_arr and 'K4' in line_arr :
            if index == 0 :
                print(line, end=' ')
            index += 1
            continue
        if len( [ i for i in line_arr if i.strip() ]) < 5 :
            continue
        print(line)

#cmd = 'excel_concat.py -xls ' + ' '.join([ i+',index_col,1,header,1' for i in fls ] ) + ' -axis 0 -o test'
#print cmd



























