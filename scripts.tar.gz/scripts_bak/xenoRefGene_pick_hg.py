#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='use hg infor pick the xeon', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-bed', nargs='?', help ='xenoRefGene.gsGend.bed')
parser.add_argument('-hg', nargs='*', help ='hg tabs')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

bed = args.bed
hg = args.hg
lst = []
for each in hg:
    ofh = open(each)
    for line in ofh:
        line_arr = line.strip().split('\t')
        if line_arr[1] not in hg:
            lst.append(line_arr[1])

bfh = open(bed)
for line in bfh:
    line_arr = line.strip().split('\t')
    gene = line_arr[3].split('.')[1]
    if gene in lst:
        print(line, end=' ')











