#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'matrix', nargs = '?', help = 'matrix you want to append' )
parser.add_argument( '-goid', nargs = '?', help = 'goid include all the go in the matrix. u can use root goid. neu is GO:0007399', default = 'GO:0007399' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ) :
    return args.matrix, args.goid
def infor( goid ):
    std, err, rcode = system.run('gene_ontology_parse.py %s' % goid)
    dit = {}
    for line in std:
        line = line.strip()
        if not line:
            continue
        line_arr = line.strip().split('\t')
        goid,desc =  line_arr
        trick.dinit( dit, goid, desc )
    return dit
if __name__ == '__main__':
    matrix, goid = parse( args )
    dit = infor( goid )
    for line in open( matrix ):
        line_arr = line.strip().split(' ')
        index = trick.lst(line_arr).index('GO', regular = True )[0]
        goid = trick.lst(line_arr).get( index )
        line_arr.append( dit[goid] )
        print('\t'.join( line_arr ))
























