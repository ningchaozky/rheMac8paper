#!/usr/bin/env Rscript
#first
alen <- commandArgs()
suppressMessages(library(argparser))
suppressMessages(library(Seurat))
p <- arg_parser('script description')
p <- add_argument(p, "mat", help= "matrix")
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))


pdfout = paste( args$mat,'pdf', sep = '.')
rds = paste( args$mat, "rds", sep = '.')
if (file.exists(rds)){
    print (paste('Already exists', rds, 'Loading... it'))
    pbmc = readRDS( rds )
    print (paste('Already loaded it'))
}else{
    df <- read.table( args$mat, sep = '\t', header = 1, check.names = 0, row.names = 1 )
    df = t(df)
    pbmc <- CreateSeuratObject(counts = df)
    #plot1 <- FeatureScatter(pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt")
    pbmc <- NormalizeData(pbmc, normalization.method = "RC", scale.factor = 1000000)
    pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 2000)
    all.genes <- rownames(pbmc)
    pbmc <- ScaleData(pbmc, features = all.genes)
    saveRDS(pbmc, file = rds)
}
    pbmc <- RunPCA(pbmc, features = VariableFeatures(object = pbmc))
    pbmc <- FindNeighbors(pbmc, dims = 1:10)
    pbmc <- FindClusters(pbmc, resolution = 0.5)
    pbmc <- RunUMAP(pbmc, dims = 1:10)
pdf(file = pdfout)
VlnPlot(pbmc, features = c("nFeature_RNA", "nCount_RNA"), ncol = 2)
DimPlot(pbmc, reduction = "umap")
dev.off()























