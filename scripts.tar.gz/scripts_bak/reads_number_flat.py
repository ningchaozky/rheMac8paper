#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
import argparse
import multiprocessing as mp
from collections import defaultdict
from ningchao.nSys import trick, parse, system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'js', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def name_get( reads ):
    lst = []
    cmd = 'data_sync_check_v3.py {}_1.fq.gz'.format( reads )
    for line in system.run( cmd, shell = True ):
        if '(' not in line:
            continue
        line_arr = eval( line )
        fl = line_arr[1]
        if os.path.exists( fl ):
            size = os.path.getsize( fl )
            fl_base_name = os.path.basename( fl )
            lst.append( [fl_base_name, fl, size] )
    return lst



ini = parse.ini( args.js ).to_dict()
raw = ini['period']
uniqs = defaultdict( lambda : defaultdict( list ) )
for p in raw:
    if p not in ['20Y']:
        continue
    for r in raw[p]:
        if r not in ['prefrontal']:
            continue
        for m in raw[p][r]:
            for rep in raw[p][r][m]:
                key = '_'.join([p,m,rep])
                reads = raw[p][r][m][rep]
                if isinstance( reads, str ):
                    for f, fl, size in name_get( reads ):
                        uniqs[key][ f ].append( [ fl, size] )
                elif isinstance( reads, list ):
                    for read in reads:
                        for f, fl, size in name_get( read ):
                            uniqs[key][f].append([fl, size])


def get_reads(fl):
    if not os.path.exists(fl):
        return 0
    try :
        with open( fl ) as f :
            num = next(f).strip().split(' ')[-1]
            return int(num) / 4
    except :
        return 0
for e in uniqs:
    gz_map = []
    for gz in uniqs[e]:
        gzs = uniqs[e][gz]
        gzs = sorted( uniqs[e][gz], key = lambda x: x[1])
        gz = gzs[-1][0]
        #gz_map.append(gz)
        gz_map.append( get_reads(os.path.basename(gz) + '.reads'))
    print (e, int(sum(gz_map)))

#print ( gz_map )


def calculate_reads_num( gz ):
	cmd = 'fq_reads_num.py {}'.format( gz )
	system.run( cmd, shell = True )

if 0 :
    with mp.Pool(6) as p:
	    p.map( calculate_reads_num, gz_map )
    p.close()
    p.join()
























