#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick, excel
example = ''' use pandas, header, index'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'a', nargs = '?', help = 'excel a source for output ')
parser.add_argument( '-b', nargs = '?', help = 'excel b, like rowname for extract')
parser.add_argument( '-ipos','-i', nargs = '?', help = 'output index_col pos, default 1', default = 1, type = int)
parser.add_argument( '-ics', action = 'store_true', help = ' ignore the case senstive')
parser.add_argument( '-c', choices = ['left','right','outer','inner','AnoInB','AnoInBappendB','pick'], help = 'excel b ', default = 'inner')
parser.add_argument( '-v', nargs ='+', help = 'value for choices')
parser.add_argument( '-onlyName', nargs = '?', help = 'only name join 1 1 ', type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def tab_parse( tab, **kwargs ):
    tab, targs = excel.xls( tab ).parse( simple = True )
    df = pd.read_csv( tab, **targs )
    if args.ics:
        df['source_index'] = df.index
        df.index = df.index.str.lower()
    if args.onlyName :
        df['onlyName_index'] = df.index.map( lambda x: x.split('.')[args.onlyName-1] )
    return df


def main():
    dfA = tab_parse( args.a, **kwargs )
    if args.b:
        dfB = tab_parse( args.b, **kwargs )
        if args.c == 'AnoInB':
            df = dfA[ ~dfA.index.isin(dfB.index) ]
        elif args.c == 'AnoInBappendB':
            dfAnotInB = dfA[ ~dfA.index.isin(dfB.index)  ]
            df = dfB.append(dfAnotInB)
        else :
            if args.onlyName:
                df = dfA.join( dfB, on = ['onlyName_index'], lsuffix='_caller', rsuffix='_other', how = args.c)
            else :
                df = dfA.join( dfB, lsuffix='_caller', rsuffix='_other', how = args.c )
            #df = pd.merge( dfA, dfB, how = args.c, validate='many_to_many')
    else :
        if args.c == 'pick':
            if not args.v :
                print ('#Required set args.v for pick all row with value')
            #chek column of row if row will use as float if coulumn will pick the header column value
            else :
                try :
                    df = dfA[dfA.eq( float( args.v[0] ) ).all(1)]
                except :
                    df = dfA[dfA[args.v[0]].eq(float(args.v[1])).all(1)]
    df.insert( args.ipos - 1, 'geneId', df.index)
    df.to_csv( sys.stdout, sep = '\t', index = False)


if __name__ == '__main__':
    kwargs = vars( args )
    main()



























