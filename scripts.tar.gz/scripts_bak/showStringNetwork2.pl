#!/usr/bin/perl -w

use strict;
use File::Basename;
use Getopt::Long;
use DBI;
use Cwd;
my $cwd = getcwd();


### Usage: perl showStringNetwork.pl ... ###
sub Usage {
  print STDERR << "USAGE";
  Description: This script is used to retrieve protein pairs which are known to interact 
  with each other, or they are linked to each other in a manner described as in STRING 
  database, such as neighborhood,fusion,cooccurence,coexpression,experimental,database,
  textmining,etc.
  Author: Longsheng.xing\@allwegene.com
  Version: 1.0
=========================================================================================
Options:
		-i  --in         <s>   input file containing protein names
		-s  --species    <s>   sample species info
		-o  --out        <s>   output file
		-h  --help             print this help info


=========================================================================================
USAGE

}

my ($in,$out,$species,$help);

GetOptions("in|i=s" => \$in,
	   "out|o=s" => \$out,
	   "species|s=s" => \$species,
	   "help|h" => \$help);

if( !defined($in) || !defined($out) ||
    !defined($species) || $help ) {
  &Usage();
  exit(0);
}

my $name = $species;

my $taxon = &queryTaxonIdBySpeciesName($name);

print $taxon,"\n";

my $alias;
$alias = &readProteinName($in);


### get string_protein_id based on input protein alias name
my $ids = &getStringProteinId($taxon,$alias);

my @links_detailed = ();

foreach my $i(0 .. $#$alias) {
  print "$alias->[$i]:";
  foreach my $j(0 .. $#{$ids->[$i]}) {
    print "\t$ids->[$i][$j]";
    
    my $tmp_id = $ids->[$i][$j];

    $links_detailed[$i][$j] = &queryLinksByStringProteinId('protein_links_detailed',$tmp_id);


  }
  print "\n";
}

### print matched protein_links_detailed in fixed format
open OUT,">$out" || die "Cannot write to this file!$!";

my @entries = ("node1","node2","neighborhood","fusion","cooccurence","coexpression","experimental","database_score","textmining","combined_score");
my $delim = "";
foreach my $i(0..$#entries) {
  print OUT "$delim$entries[$i]";
  $delim = "\t";
}
print OUT "\n";

&outputMatchLinksDetailed(\@links_detailed,*OUT);


close OUT;



#&queryStringProteinIdByAlias('Cact');
my $protein_id = "394.NGR_c00010";


### protein_actions
#my $actions = &queryActionsByStringProteinId($protein_id);



### protein_links
#&queryLinksByStringProteinId('protein_links',$protein_id);

### protein_links_detailed
#&queryLinksByStringProteinId('protein_links_detailed',$protein_id);

### subroutin for outputing links_detailed
### in fixed format
sub outputMatchLinksDetailed($$) {
  my $links_detailed = shift;
  my $ofh = shift;
  
  my @links_detailed_fields = ('protein1','protein2','neighborhood','fusion','cooccurence','coexpression','experimental','database_score','textmining','combined_score');

  foreach my $i(0 .. $#$links_detailed) {
    foreach my $j(0 .. $#{$links_detailed->[$i]}) {
      foreach my $k(0 .. $#{$links_detailed->[$i][$j]}) {
        my $temp_links_detailed_hash = $links_detailed->[$i][$j][$k];
        my $delim = "";
	### simple filter
	next if($temp_lins_detailed_hash->{'combined_score'} < 400);
        foreach my $p(0 .. $#links_detailed_fields) {
          printf $ofh "$delim%s",$temp_links_detailed_hash->{$links_detailed_fields[$p]};
          $delim = "\t";
        }
        print $ofh "\n";
      }
    }
  }

}



### read in input protein name 'alias'
sub readProteinName {
  my $infile = shift;
  open IN,"<$infile" || die "Cannot open this file!$!";
  
  my @alias = ();
  while(<IN>) {
    chomp;
	push @alias,$_;  
  }
  
  close IN;  
  
  return \@alias;
}

### get string_protein_id based on input file
sub getStringProteinId {
  my $taxon_id = shift;
  my $alias = shift;
  
  
  my @rawProteinIds;
  foreach my $i(0 .. $#$alias) {
    my $tmp = $alias->[$i];
	$rawProteinIds[$i] = &queryStringProteinIdByAlias($tmp);
	
  }
  
  my @proteinIds = ();
  foreach my $i(0 .. $#$alias) {
    foreach my $j(0 .. $#{$rawProteinIds[$i]}) {
	  print $rawProteinIds[$i] ->[$j][0];
	  
	  $rawProteinIds[$i]->[$j][0] =~ /^(\d+)\./;
	  if($taxon_id == $1) {
	    push @{$proteinIds[$i]}, $rawProteinIds[$i]->[$j][0];
		
	  }
	}
  }
  
  
  return \@proteinIds;
}

### connecting database 
sub connectDatabase {
  my $database = "STRING";
  my $passwd = "auwigeneroot";
  my $user = "root";
  my $host = "localhost";

  my $dsn = "DBI:mysql:database=$database;host=$host";

  my $dbh = DBI->connect($dsn,$user,$passwd,{RaiseError=>0, PrintError => 1})
    or die "Could not connect to mysql server: $DBI::err($DBI::errstr)\n";

  return $dbh;

}

### scan taxonomy_id by species official name ###
sub queryTaxonIdBySpeciesName($) {
  my $species = shift;
  
  my $dbh = &connectDatabase();
    my $table = "species";

  print ">>>>>> Testing query taxon_id based on species name >>>>>>\n";
  my $sth = $dbh->prepare("SELECT taxon_id from $table where compact_name = '$species'");

  $sth->execute();
  #if(!$sth) {
  #  print "$species not existed in database!\n";
  #}
### fetchrow_arrayref to fetch record reference and print ###
  my $taxon_id = &fetchRowArrayRef($sth);
  $sth->finish();

  $dbh->disconnect();

  return $taxon_id->[0][0];
}

### fetch record and print
sub fetchRowArray($){
  my $sth = shift;
  
  while( my @row = $sth->fetchrow_array() ) {
    print join("\t",@row),"\n";
  }
  
}


### fetch record reference and print one field by one using fetchrow_arrayref
sub fetchRowArrayRef($) {
  my $sth = shift;

  my @arr = ();
  my $cnt = 0;
  while(my $rowref = $sth->fetchrow_arrayref()) {
    my $delim = "";
	
	$arr[$cnt] = $rowref;
	$cnt++;
	
    for(my $i = 0; $i < @{$rowref}; $i++) {
      print $delim . $rowref->[$i];
	  #push @arr,$rowref->[$i];
	  
      $delim = ',';
    }
    print "\n";
  }
  
  return \@arr;

}


### fetch record hash table reference and print one by one
sub fetchRowHashRef($) {
  my $sth = shift;
  
  my $labels = $sth->{NAME};
  my $cols = $sth->{NUM_OF_FIELDS};
  
  print ">>>>>> field count $cols\n";
  #my %returnHash = ();
  
  my @returnHash = ();
  my $cnt = 0;
  while( my $rowref = $sth->fetchrow_hashref() ) {
    my $delim = "";
    $returnHash[$cnt] = $rowref;
    $cnt++;
	
    #for(my $i = 0; $i < $cols; $i++) {
     # print $delim . $labels->[$i] . " = " . $rowref->{$labels->[$i]};
	  
     # $delim = ",";
    #}
    #print "\n";
  }
  
  return \@returnHash;
}

### query standard string_protein_id based on alias name provided by user ###
sub queryStringProteinIdByAlias {
  my $alias = shift;
  
  my $table = "protein_aliases";
  my $dbh = &connectDatabase();

  #my $sth = $dbh->prepare("SELECT string_protein_id from $table where alias = '$alias'");
  my $sth = $dbh->prepare("SELECT string_protein_id from $table where alias = '$alias'");
  $sth->execute();

  my $protein_id = &fetchRowArrayRef($sth);
  #&fetchRowHashRef($sth);
  
  $sth->finish();  
  $dbh->disconnect();
  
  return $protein_id;
}

### query actions based on input string_protein_id
### protein_actions schema:
### item_id_a
### item_id_b
### mode
### action
### aIsActing
### score
sub queryActionsByStringProteinId($) {
  my $string_protein_id = shift;
  
  my $table = "protein_actions";
  my $dbh = &connectDatabase();
  
  my $sth = $dbh->prepare("SELECT * from $table where item_id_a = '$string_protein_id' OR item_id_b = '$string_protein_id'");
  $sth->execute(); 
  
  my $actions = &fetchRowHashRef($sth);
  
  $sth->finish();
  $dbh->disconnect();
  
  return $actions;
}

### query links based on input string_protein_id
### protein_links schema:
### protein1
### protein2
### combined_score
sub queryLinksByStringProteinId($$) {
  my $table = shift;
  my $string_protein_id = shift;
  
  my $dbh = &connectDatabase();
  
  my $sth = $dbh->prepare("SELECT * from $table where protein1 = '$string_protein_id' OR protein2 = '$string_protein_id'");
  $sth->execute();
  
  my $links = &fetchRowHashRef($sth);
  
  $sth->finish();  
  $dbh->disconnect();
  
  return $links;
}

### main subroutine
sub main {
 
 print "MAIN function!\n";
 
 
}
