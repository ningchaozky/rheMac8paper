#!/usr/bin/env perl
use warnings ;

unless (@ARGV){
	die "$0 hg19 name\n";
}

$db = $ARGV[0];
$name = $ARGV[1];

print  "wget http://egg.wustl.edu/d/$db/$name\n";
print  "wget http://egg.wustl.edu/d/$db/$name.tbi\n";
print   "mv $name /srv/epgg/data/data/subtleKnife/$db\n";
print   "mv $name.tbi /srv/epgg/data/data/subtleKnife/$db\n";

