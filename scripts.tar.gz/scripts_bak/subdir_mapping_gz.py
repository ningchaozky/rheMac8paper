#!/usr/bin/env python3
import os
import re
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'dir', nargs = '?', help = 'dir for subdir fq.gzs mapping')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

template = '''STAR --twopassMode Basic --quantMode TranscriptomeSAM GeneCounts --readFilesCommand gunzip -c --outFilterScoreMinOverLread  0.2 --outFilterMatchNminOverLread  0.2 --runThreadN 6 --genomeDir /home/soft/data/genome/hg19/fasta/start_index --alignIntronMin 20 --alignIntronMax 50000 --outSAMtype BAM SortedByCoordinate --sjdbOverhang 146 --outSAMattrRGline ID:sample SM:sample PL:ILLUMINA --outFilterMismatchNmax 2 --outSJfilterReads Unique --outSAMmultNmax 1 --outFileNamePrefix {} --outSAMmapqUnique 0 --readFilesIn {} {}\n\n'''


def paired( directory ):
    nest = lambda : defaultdict( nest )
    dit = nest()
    fls = system.dir( directory ).fls('fq.gz', depth = 1, fpattern = '^clean')
    for each in fls:
        wd, name = os.path.split( each )
        sample, suffix = re.split( r'_1.|_2.', name ) 
        if '_1.' in name:
            dit[ wd ][ sample ]['r1'] = each 
        elif '_2.' in name:
            dit[ wd ][ sample ]['r2'] = each 
    return ( dit )



if __name__ == '__main__':
    dit = paired( args.dir )
    for wd in dit:
        for sample in dit[wd]:
            r1, r2 = dit[wd][sample]['r1'], dit[wd][sample]['r2']
            print ('cd {}'.format( wd ))
            print ( template.format( sample, r1, r2))
            



























