#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import neuron,geneKit
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-tab', nargs='*', help ='input file and gene col')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
neuron_genes = neuron.neu().genes()
col = 0
if len(args.tab) > 1 :
    col = int(args.tab[1]) - 1
fh = open(args.tab[0])
for line in fh:
    index = False 
    line_arr = line.strip().split('\t')
    for each in geneKit.arr2name(line_arr[col]):
        if each.split('.')[0].upper() in neuron_genes:
            index = True
            break
    if index :
        print(line, end=' ')




























