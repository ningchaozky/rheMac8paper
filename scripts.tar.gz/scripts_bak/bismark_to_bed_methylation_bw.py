#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, system, fix
desc = '''bismark_to_bed output bed'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bismark_to_bed_output', nargs='?', help ='output bed from bismark_to_bed')
parser.add_argument('-c', nargs='?', help ='depth for cut off', default = 5, type = int)
parser.add_argument('-gs', nargs='?', help = 'genome size', default = '/home/soft/data/genome/rheMac8/rheMac8.genome')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def cut_to_bdg():
    bdg = fix.fix( args.bismark_to_bed_output ).append('bdg')
    bfh = open( bdg, 'w' )
    with open( args.bismark_to_bed_output ) as f :
        for line in f :
            line_arr = line.strip().split('\t')
            depth = int(line_arr[-2]) + int(line_arr[-1])
            if depth >= args.c:
                print ( *line_arr[0:4], file = bfh )
    bfh.close()
    return bdg


if __name__ == '__main__':
    bdg = cut_to_bdg()
    cmd = 'bedGraphToBigWig {} {} {}'.format( bdg, args.gs, fix.fix(bdg).change('bw'))
    stdout,stderr,returncode = system.run( cmd )
    for line in [returncode, *stdout,*stderr] :
        print ( line )























