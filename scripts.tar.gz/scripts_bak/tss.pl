#!/usr/bin/perl -w

#data input example

#chr1    gene    ENSMUSG00000102693      +       3068253 3078253
#10      3110111 C       +       1       1       0       1       CTA     CHH

if(!@ARGV){
    print "\nUsage:\t./$0 gene_file met_file\n\n";
}
else{
open $gene,"$ARGV[0]";
open $met, "$ARGV[1]";


# seq hash
my %gene;
while(<$gene>){
    my($chr,$af) = split /\s+/,$_,2;
        push(@$chr,"$chr\t$af");
        $gene{$chr} = \@$chr;
}

#map to met
if(0){
while(my($k,$v) = each %gene){
    print "$k=>$v";
    for(@{$v}){
        print;
    }
}
}


while(<$met>){
    my ($chr,$pos,$af) = split /\s+/,$_,3;
    for(@{$gene{$chr}}){
        my($gene_chr,$gene_type,$gene_id,$gene_strand,$start,$end) = split /\s+/,$_;
        if( $pos >= $start && $pos <= $end){
            print "$gene_chr\t$gene_type\t$gene_id\t$gene_strand\t$start\t$end\t$pos\t$af"
        }    
    }
}
}
