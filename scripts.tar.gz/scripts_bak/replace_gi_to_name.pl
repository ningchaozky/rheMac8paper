#!/usr/bin/perl 
use strict;

unless(@ARGV){
	die "Usage: $0 xls[fasta|txt]\n\txls should have gi| after '\\t'\n";
}

my $in;
open $in,"$ARGV[0]";
while(<$in>){
	chomp;
	my ($out,@tmp);
	my @tmp = split /\t/,$_;
	for(@tmp){
		if(/^gi\|(\d+)/i){
			my $tmp = $_;
			$_ = `blastdbcmd -db /data/Database/nr/nr -entry $1  -target_only -outfmt '%i=>%t=>%g=>%a=>%l=>%T'`;
			unless($_){
				$_ = $tmp;
			}
			chomp;
		}
		$out .= "$_\t";
	}
	$out =~ s/\t$//;
	print "$out\n";
}
