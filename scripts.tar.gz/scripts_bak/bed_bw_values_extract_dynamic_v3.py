#!/usr/bin/env python
import os
import sys
import argparse
import pandas as pd
import numpy as np
from pybedtools import BedTool
from collections import defaultdict
from ningchao.nSys import trick,system
from ningchao.nBio import bw,chromosome
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='use the point intersect the peaks and pick peaks sum vlaues', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bw', nargs='?', help ='bw file for extract' )
parser.add_argument( 'peaks', nargs = '?', help ='macs2 callpeaks results' )
parser.add_argument( '-t', nargs='?', help= ''' 'tss3k','tss1k','gb5k','gene','enhancer','exons' or bed input ''', default = 'tss3k' )
parser.add_argument( '-c', choices = ['sum','max','median','mean'], help ='', default = 'sum' )
parser.add_argument( '-nt', choices = ['normal','no_normal'] )
parser.add_argument( '-n', nargs = '?', help = 'name for the column' )
parser.add_argument( '-o', nargs = '?', help = 'ouput file' )
parser.add_argument( '-m', nargs = '?', help = 'match file record how the num get' )
parser.add_argument( '-s', nargs = '?', type = int, default = 0, help = 'max span for the peaks. Note this is bigger than points smaller than peaks. default up and down 2000' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def get_annot_bed( **kwargs ):
    annot = {
            'gene':'/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.bed',
            'tss3k': '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.bed',
            'tss1k': '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown1K.bed',
            'enhancer':'/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown1K.bed',
            #'tss3k': '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.wangxiaoqun.bed',
            'gb5k' : '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.bodyUpDown5K.bed',
            'exons': '/home/soft/data/genome/rheMac8/transcripts/Ensembl.exons.5K.bed'
    }
    print ( 'choose bed is {}'.format(args.t) )
    if args.t in annot:
        return annot.get(kwargs.get('t'))
    else :
        return args.t

def intersect( region, **kwargs):
    infor, peaks = defaultdict( list ), kwargs.get('peaks')
    cmd = 'bedtools intersect -a %s -b %s -wo' % ( region, peaks )
    #if enhancer will delete the tss region results
    if kwargs.get('t') in ['enhancer']:
        cmd = 'bedtools subtract -a {} -b {} -f 0.5'.format( peaks, region )
    #sys.stderr.write(cmd + '\n')
    #stdout, stderr, returncode = system.run( cmd, shell = True)
    stdout = system.run( cmd, shell = True)
    slist = [ i.strip() for i in stdout ]
    if not slist:
        return {}
    stdout = iter(slist)
    fline = next( stdout )
    posA, posB, line_arr = check( fline )
    key = trick.lst( trick.lst(line_arr).get(posA) ).toStr(sep = '\t')
    value = trick.lst(trick.lst(line_arr).get(posB)).toStr(sep = '\t')
    infor[key].append( value )
    for line in stdout:
        line = line.strip()
        if not line :
            continue
        line_arr = line.split('\t')
        key = trick.lst(trick.lst(line_arr).get(posA)).toStr(sep = '\t')
        value = trick.lst(trick.lst(line_arr).get(posB)).toStr(sep = '\t')
        if value not in infor[key]:
            infor[key].append( value )
    return infor

def check( line ):
    line_arr = line.strip().split('\t')
    index = [ i for i,v in enumerate(line_arr) if v.startswith('chr') ]
    if len( index ) == 1 :
        posA = posB = [ (i,i+1,i+2) for i in index ][0]
    elif len( index ) == 2 :
        posA, posB = [ (i,i+1,i+2) for i in index ]
    return posA, posB, line_arr

def respan(line_arr, rstart, rend, mspan):
    line_arr[1] = int(line_arr[1])
    line_arr[2] = int(line_arr[2])
    if line_arr[2] - line_arr[1] > mspan * 2 :
        line_arr[1] = (int(rstart) + int(rend))/2 - mspan
        line_arr[2] = (int(rstart) + int(rend))/2 + mspan
    return [ str(i) for i in line_arr ]


def sedeal( key, start, end, chroms, mspan):
    chrom, raw_start, raw_end = key.split('\t')
    raw_start, raw_end = int(raw_start) - mspan, int(raw_end) + mspan
    start, end = int( start ), int(end)
    start = start < 0 and 0 or start
    end = end > chroms[chrom] and chroms[chrom] or end
    raw_start = raw_start < 0 and 0 or raw_start
    raw_end = raw_end > chroms[chrom] and chroms[chrom] or raw_end
    end = end > raw_end and raw_end or end
    start = start < raw_start and raw_start or start
    return chrom, start, end

def calculate( bwfh, chrom, start, end, **kwargs):
    start, end, values = int( start ), int( end ), [0]
    if kwargs.get('c') == 'sum':
        try :
            values = [  np.nansum( bwfh.raw().values( chrom, start, end  ) )  ]
        except :
            print ( 'Wrong: ', chrom, start, end, file = sys.stderr )
            values = [ 0 ]
            #np.nansum( bwfh.raw().values( chrom, start, end )  )
    elif kwargs.get('c') == 'max':
        values = [ bwfh.raw().stats( chrom, start, end, type = 'max' )[0] ]
    elif kwargs.get('c') == 'median':
        #span_bins_for_median = ( end - start ) // 20
        span_bins_for_median = 1
        try :
            values = [ np.nanmedian( bwfh.raw().stats( chrom, start, end, nBins = span_bins_for_median ) ) ]
        except :
            print ( 'Wrong: ', chrom, start, end, file = sys.stderr )
            values = [0]
    elif kwargs.get('c') == 'mean':
        values = [ bwfh.raw().stats( chrom, start, end, type = 'mean' )[0] ]
    if len( values ) == 1 and None in values:
        values = [ 0 ]
    if kwargs.get('nt') == 'normal':
        return values[0] * 1000 / ( end - start )
    return values[0]

def writ_dict_to_bed( dit ):
    with open( 'tmp.file.bed', 'w' ) as f :
        for key in dit:
            print ( key, file = f)
    return f.name

def bed_header_check():
    peaks = kwargs.get('peaks')
    with open( peaks ) as f:
        header = f.readline()
        if 'bw' in header or 'v1' in header:
            kwargs.update({'peaks_header': header })
            peaks_no_header = open( peaks + '.noheader', 'w')
            print ( *f.readlines(), sep = '', end = '', file = peaks_no_header )
            peaks_no_header.close()
        kwargs.update({'peaks': peaks_no_header.name })


if __name__ == '__main__':
    name, mspan = os.path.basename( args.bw ) , args.s
    bw, chroms = bw.bw(args.bw), chromosome.chr('rh8').kwargs.get('size')
    kwargs = vars(args)
    annot_bed = get_annot_bed( **kwargs )
    bed_header_check()
    infor = intersect( annot_bed, **vars( args ) )
    #enhancer will not concern the gene so write the bed for calculate is enough
    if args.t in ['enhancer']:
        pfh = open( writ_dict_to_bed( infor ) )
    else :
        pfh = open( annot_bed )
    if args.n:
        name = args.n
    ofh = sys.stdout
    if args.o:
        ofh = open(args.o,'w')
    err = open( os.path.basename(args.o) +'.err', 'w')
    header = [ 'chrom', 'start', 'end' ]
    if args.t not in [ 'enhancer']:
        header.extend([ 'symbol', 'placeHolder', 'chain'] )
    header.append( name )
    print ( *header, sep = '\t', file = ofh )
    print ( *header, sep = '\t', file = err )
    for line in pfh:
        if 'track' in line :
            continue
        line_arr = line.strip().split('\t')
        chrom, rstart, rend = line_arr[0:3]
        key = trick.lst(line_arr[0:3]).toStr('\t')
        value = 0.1
        if key in infor:
            length = 0
            for i, each in enumerate( infor[ key ] ):
                chrom, start, end = each.split('\t')
                start, end = int( start ), int( end )
                #chrom, start, end = sedeal( key, start, end, chroms, mspan)
                length += abs( end - start )
                #value += bw.sum( chrom, start, end )
                each_vale = calculate( bw, chrom, start, end, **vars(args) )
                #bw.max( chrom, start, end  )
                value += each_vale
                print ( 'match', key, 'raw', chrom, start, end, i, each_vale, value, file = err)
                #line_arr = respan(infor[key].split('\t'), rstart, rend, mspan)
            #normal length
            #value = value * 1000 / length
        else :
            #normal length
            #value = bw.sum( chrom, int(rstart), int(rend) ) * 1000/ abs( int(rstart) - int(rend) )
            #not normal length
            #value = bw.sum( chrom, int(rstart), int(rend) )
            value = calculate( bw, chrom, rstart, rend, **vars(args)  )
            #value = bw.max( chrom, int(rstart), int(rend) )
            print ( 'raw', chrom, rstart, rend, 'match', key, value, file = err)
        line_arr = [ *line_arr, value ]
        print ( *line_arr, sep = '\t', file = ofh )


















