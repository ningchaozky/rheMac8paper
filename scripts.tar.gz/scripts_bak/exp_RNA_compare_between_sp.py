#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = '''only colunm for comapre'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-e1', nargs='?', help ='express 1')
parser.add_argument('-e2', nargs='?', help ='express 2')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def fl2dit( fl ):
    fh, dit = open( fl ), {}
    for line in fh:
        if 'gene' in line:
            continue
        name, val = line.strip().split('\t')
        alias = name.split('.')[0].upper()
        trick.dinit( dit, alias, [] )
        dit[alias].append( float( val ) )
    return dit

def mean_val( lst ):
    return sum( lst )/ len( lst )

if __name__ == '__main__':
    exp1 = fl2dit(args.e1)
    exp2 = fl2dit(args.e2)
    for alias in exp2:
        if alias in exp1:
            v2 = mean_val( exp2[alias] )
            v1 = mean_val( exp1[alias] )
            if v1 < 1 and v2 < 1 :
                continue
            if v1 == 0 or v2 == 0 :
                if v1 or v2 > 1 :
                    print(alias, v1, v2, 'None')
            elif v1 / v2 > 2 :
                print(alias, v1, v2, v1 / v2)
            elif v2 / v1 > 2 :
                print(alias, v1, v2, v2 / v1)




























