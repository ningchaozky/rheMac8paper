#!/usr/bin/perl -w 


open File,"< $ARGV[0]";
while(<File>){
my ($a,$b,$c,$d,$e,$f,$g) = split '\t',$_,7;
if(($b >=$d && ($e >=90) && ($f*3)/$d >2/4)|($b <= $d && $e >=90 &&
($f*3)/$b>2/4)){
print;
}
}
