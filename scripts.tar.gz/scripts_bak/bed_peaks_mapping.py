#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome,geneKit,bedKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='this script already concert the chain\nbed_peaks_mapping.py -bed /home/ningch/data/genome/rheMac8/neuron/neuron.bed  -peak K4.bed.bw.tab', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-bed', nargs='?', help ='bed file you want to extract peaks', required = True )
parser.add_argument('-peak', nargs = '?', help ='peak file for the mapping', required = True )
parser.add_argument('-s', '-span', help = 'span for the mapping', nargs = '?', type = int , default = 2500 )
parser.add_argument('-onlyMapping', '-om', help = 'only output mapping peak', action='store_false')
parser.add_argument('-o', nargs = '?', help =' output file' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

bed = open(args.bed)
peak = open(args.peak)
out = sys.stdout
span = args.s
debug = False
if args.o :
    out = open(args.o,'w')
onlyMapping = args.onlyMapping



def get_bin(pos, span):
    pos = float(pos)
    span = float(span)
    float_return = pos/span
    int_return = int(pos)/ int(span)
    if float_return == int_return :
        return int_return
    else :
        return int_return + 1


def gene_in_span(region,start, span):
    lst = list(range(region[0],region[1]))
    lst.append(region[1])
    for i in lst:
        if abs(i - start) <= span :
            return True
    return False



infor = {}
bed_infor = {}
chroms = chromosome.chr('rh8').chr
gene_infor = {}
for line in bed:
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    if chrom not in chroms:
        continue
    if len(line_arr) >= 5 :
        chain = line_arr[5]
        gene = geneKit.name(line_arr[3])
    else :
        print('should be the bed6')
    start = int(line_arr[1])
    end = int(line_arr[2])
    if chain == '+':
        pos_bin = get_bin(start, span)
    else :   
        pos_bin = get_bin(end, span)

    trick.set2dict(infor,chrom,pos_bin,[])
    key = ','.join([chrom,gene,chain,str(pos_bin)])
    infor[chrom][pos_bin].append(key)
    trick.set3dict(gene_infor,chrom,key,'start',start)
    trick.set3dict(gene_infor,chrom,key,'end',end)
    trick.set3dict(gene_infor,chrom,key,'chain',chain)


for line in peak:
    if 'track' in line :
        continue
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    if chrom == 'chr' :
        header = line_arr
        header.insert(3,'gene')
        print('\t'.join(header))
    if chrom not in chroms:
        continue
    start = int(line_arr[1])
    end = int(line_arr[2])
    out_line = []
    last = line_arr[0:3]
    pick_gene = []
    pos_bin_start = get_bin(start,span)
    pos_bin_end = get_bin(end,span)
    lst = list(range(pos_bin_start,pos_bin_end))
    lst.append(pos_bin_end)
    for i in range(1,3):
        lst.append(pos_bin_start - i)
        lst.append(pos_bin_end + i)
    lst = set(lst)
    #if '\t'.join(line_arr[0:3]) == 'chr11\t54735607\t54737821':
    if 1 :
        for i in lst :
            if i in infor[chrom]:
                keys = infor[chrom][i]
                for key in keys:
                    chain = gene_infor[chrom][key]['chain']
                    gene_start = gene_infor[chrom][key]['start']
                    gene_end = gene_infor[chrom][key]['end']
                    if chain == '+':
                        if gene_in_span([start,end],gene_start,span):
                            pick_gene.append(key)
                    elif chain == '-' :
                        if gene_in_span([start,end],gene_end,span):
                            pick_gene.append(key)
                    if debug:
                        print(keys)
                        print(start,end,gene_start,gene_end)
                        print(pick_gene)
    else :
        continue
    pick_gene = set(pick_gene)
    if 1 and len(pick_gene) >= 1:
            out_line.extend(last)
            out_line.append(','.join(pick_gene))
            out_line.extend(line_arr[3:])
            out.write('\t'.join(out_line) + '\n')
