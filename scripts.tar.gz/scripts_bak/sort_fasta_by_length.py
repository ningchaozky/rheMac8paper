#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nBio.fasta as faKit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-f','-fasta', nargs='?', help ='fasta file for sort', required = True )
parser.add_argument('-o', nargs='?', help ='reference')
parser.set_defaults(bar=42, baz='badger')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
out = sys.stdout
if args.o:
	out = open(args.o,'w')


dit = faKit.fa2dict(args.f)
length = {}
for each in dit:
	trKit.set1dict(length,each,len(dit[each].seq))

for name,seq_len in sorted(list(length.items()), lambda x, y: cmp(x[1], y[1]), reverse=False):
	out.write('>'+name + '\n')
	out.write(str(dit[name].seq).replace('_','') + '\n')



