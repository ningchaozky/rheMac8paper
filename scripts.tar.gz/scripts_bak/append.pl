#!/usr/bin/perl
use strict;

unless(@ARGV == 2){
	die "Usage: $0 xls,col fasta\n";
}

my ($col, @par_xls,%seq, $input_fa, $input_xls,  $name);
@par_xls = split /,/,$ARGV[0];
if(@par_xls == 2){
	$col =  $par_xls[1] - 1;
}

open $input_fa,$ARGV[1];
while(<$input_fa>){
	chomp ;
	if(/^>/){
		s/>//;
		$name = $_;
	} else {
		$seq{$name} .= $_;
	}
}

open $input_xls,$par_xls[0];
while(<$input_xls>){
	chomp ;
	print "$_\t";
	$name = (split /\t/,$_)[$col];
	if (length $seq{$name} == 0 ){
		print STDERR "Warning: $name length is 0\n";
	}
	print length $seq{$name};
	print "\t$seq{$name}\n";
}
