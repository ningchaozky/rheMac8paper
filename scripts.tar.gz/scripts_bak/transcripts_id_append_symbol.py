#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from gtfparse import read_gtf
from ningchao.nSys import trick
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tab', nargs='?', help = 'tab')
parser.add_argument( '-gtf', nargs='?', help = 'gtf for symbol get', default = '/home/soft/data/genome/rheMac8/Macaca_mulatta.Mmul_8.0.1.97.gtf')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def symbol_dict():
    symbols = defaultdict( str )
    df = read_gtf( args.gtf )
    df = df[['gene_id', 'gene_name', 'transcript_id']]
    for gene_id,gene_name,transcript_id in df.iterrows():
        if transcript_id:
            if gene_name:
                symbols[transcript_id] = '.'.join([ transcript_id, gene_name ])
            elif gene_id:
                symbols[transcript_id] = '.'.join([ transcript_id, gene_id])
            else :
                print ( transcript_id, 'no gene_name, no gene_id', file = sys.stderr)
        else :
            print ( gene_id,gene_name,transcript_id, file = sys.stderr )
    return symbols


if __name__ == '__main__':
    symbols = symbol_dict()
    with open( args.tab ) as f :
        print ( next(f).rstrip() )
        for line in f:
            line_arr = line.rstrip().split('\t')
            line_arr[0] = symbols.get( line_arr[0] )
            print ( *line_arr, sep = '\t' )




















