#!/usr/bin/env python
import sys
import os

if len(sys.argv) <= 1:
	print(sys.argv[0],'str:name,xls:fpkm.xls count by intersect bed,col ...')
	exit()


files = sys.argv[1:]
fpkms = []
for each in files:
	i = 0
	fpkms.append('')
	each_arr = each.split(',')
	name = each_arr[0]
	file_abs = each_arr[1]
	col = int(each_arr[2]) - 1
	xls_h = open(file_abs)
	fpkms[i] = fpkms[i]+'\t'+name
	for line in xls_h:
		i += 1
		if len(fpkms) < i + 1:
			fpkms.append('')
		line = line.rstrip()
		line_arr = line.split('\t')
		fpkms[i] = fpkms[i]+'\t'+line_arr[col]
	xls_h.close()
for each in fpkms:
	each = each.strip()
	if each:
		sys.stdout.write(each+'\n')










