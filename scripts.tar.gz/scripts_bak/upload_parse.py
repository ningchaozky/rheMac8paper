#!/usr/bin/env python3
import os
import re
import sys
import matplotlib as mpl
import argparse
from collections import defaultdict
from ningchao.nSys import trick, parse, system, status
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('js', nargs='?', help = 'upload parse from js file')
parser.add_argument('-t', nargs='?', help = 'md5|upload|bioSample|run|rename|mvGSA', required = True )
parser.add_argument('-d', nargs='?', help = 'B##|', default = 'B##' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_age( name ):
    lst = []
    age_unit = 'Day'
    if 'E' in name :
        age_unit = 'Day'
    elif 'M' in name or 'month' in name :
        age_unit = 'Month'
    elif 'Y' in name :
        age_unit = 'Year'
    age = trick.string.replace( name.split('_')[0], ['E','Y','M','month'] )
    for p in [ '0M', 'P0' ]:
        if p in name:
            lst = [ 0, 'Day', 'birth' ]
            break
    else :
        lst.extend([age, age_unit, ''])
    lst.append('not collected')
    lst.append( tissue )
    lst.append( 'BIG' )
    return lst

def get_uniq_data():
    uniq = set()
    for p in data:
        for r in data[p]:
            if r not in ['prefrontal','PFC','enhKOdBN1']:
                continue
            for m in data[p][r]:
                for rep in data[p][r][m]:
                    sample_name = status.cmd.print( p, r, m, rep, sep = '_', end = '')
                    age = get_age( sample_name )
                    sample_name = system.dir.str_map_period( sample_name, sep = '_', replace = True )
                    if m in ['dnase']:
                        Strategy = 'DNase-Hypersensitivity'
                    elif m in 'hic' :
                        Strategy = 'Hi-C'
                    elif m in ['RNA']:
                        Strategy = 'RNA-Seq'
                    else :
                        Strategy = 'ChIP-Seq'
                    if isinstance( data[p][r][m][rep], list ):
                        for i,each in enumerate(data[p][r][m][rep]):
                            each_name = '{}_addSeq{}'.format( sample_name, i+1)
                            pstr = status.cmd.print( each_name, public_description, project_accession, each_name, organism, *holder, *age, each, Strategy, sep = '|' )
                            uniq.add( pstr )
                    else :
                        pstr = status.cmd.print ( sample_name, public_description, project_accession, sample_name, organism, *holder, *age, data[p][r][m][rep], Strategy, sep = '|')
                        uniq.add(pstr)
    return uniq
def need_transfer( fl, **kwargs ):
    already = kwargs.get('already')
    if not os.path.exists( fl ) :
        print ('Not exists: {}'.format(fl))
        return False
    fl_size = os.path.getsize( fl )
    fl = os.path.basename( fl )
    if fl not in already :
        print ( fl, 'not in already, transfer it' )
        return True
    else :
        if already[fl] == fl_size:
            print ( fl, 'in ', 'size same: {} {}, ignore it'.format(fl_size, already[fl]) )
            return False
        elif already[fl] > fl_size :
            print ( fl, 'small than remote', 'size: local {}, remote {}, ignore it'.format(fl_size, already[fl]) )
            return False
        else :
            print ( fl, 'big than remote', 'size: local {}, remote {}, ignore it'.format(fl_size, already[fl]) )
            return True


def md5_file( fl, **kwargs ):
    md5output_file = '{}.md5.txt'.format( os.path.basename(fl) )
    md5 = []
    if os.path.exists( md5output_file ):
        with open( md5output_file ) as f:
            md5 = [ i for i in f.readlines() if i.strip() ]
    if not md5:
        print ( md5output_file, 'not exists')
        cmd = 'md5sum {} > {}'.format( fl, md5output_file )
        print ( cmd, file = kwargs.get('file'))
    else :
        print ('Already exist: {}'.format(md5output_file))


def check_trim( fl ):
    for each in [ '_2U.', '_1U.', '_1P.', '_2P.', 'split.log']:
        if each in fl:
            print ( fl, 'include {}, ignore'.format(each))
            return True


def upload_trans( uniq ):
    uploadcmd, notFound = open('upload.{}.sh'.format(args.d), 'w'), open('NotFoundInNowDisk.{}.txt'.format(args.d), 'w')
    if args.t in ['md5']:
        omd5fh = open('md5.{}.sh'.format(args.d), 'w')
    uploadcmds, notFounds, check_in = defaultdict( list ), set(), defaultdict( str )
    for each in system.dir.sort( uniq ):
        earr = each.strip().split('|')
        expect_reads = [ '{}_1.fq.gz'.format(earr[-2]),'{}_2.fq.gz'.format(earr[-2]) ]
        #if 'E80' in earr[0]:
        #    continue
        cmd = '''data_sync_check_v3.py '{}%fq.gz' '''.format( earr[-2] )
        for each in system.run( cmd, shell = True ):
            if '(' in each and 'fq.gz' in each and args.d in each:
                each = eval(each)
                infor[each[2]] += 1
                file_abspath = each[1]
                fl_name = os.path.basename( file_abspath )
                if check_trim( file_abspath ) :
                    continue
                print ( earr[0], each[1:3] )
                check_in[fl_name] = each[1]
                if args.t in ['upload']:
                    if not need_transfer( each[1], already = already ) :
                        continue
                    #cmd = '''echo 'binary\nput {} {} | ftp submit.big.ac.cn'''.format( each[1], fl_name )
                    cmd = '''ftp submit.big.ac.cn << END
binary
put {} {}
END'''.format( each[1], fl_name )
                    uploadcmds[fl_name].append([ already[fl_name], os.path.getsize(each[1]), cmd ] )
                elif args.t in ['md5']:
                    md5_file( file_abspath, file = omd5fh )
        for read in expect_reads:
            if read not in check_in:
                if read in already:
                    notFounds.add('found for remote: {}'.format( read ))
                else :
                    notFounds.add( 'Not found for: {},{}'.format( earr[0], earr[-2] ) )
    for fl in uploadcmds:
        fl_cmd_arr = uploadcmds[fl]
        fl_uploadcmds = sorted( fl_cmd_arr, key = lambda x : x[1] )
        print ( '#remote: {}, local: {}\n{}'.format( *fl_uploadcmds[ -1 ] ), file = uploadcmd)
    for each in notFounds:
        print ( each, file = notFound )
    uploadcmd.close()
    notFound.close()
    print ( sorted( infor.items(), key = lambda x: x[1], reverse = True) )

def bioSample( uniq ):
    for each in uniq:
        eprint = each.split('|')[:-1]
        print ( *eprint, sep = '|' )
def runExp( uniq ):
    design = { 'ChIP-Seq': ''' The crosslinked sample were incubated in lysis buffer (50 mM Tris-HCl pH 8.0, 10 mM EDTA pH8.0, 0.2% SDS, 1mM PMSF, 1x proteinase inhibitor cocktail, 20 mM Na-butyrate) for 20min on ice, then sonicated using Diagenode Bioruptor for 10 cycles by 30s ON and 30s OFF. The chromatin solution was incubated with antibody-coated Protein A beads overnight at 4. The beads were washed by RIPA buffer with 300 mM NaCl for three times, TE buffer (10 mM Tris-HCl pH 8.0, 1mM EDTA) for once, then incubated in 100ul ChIP elution buffer (10mM Tris-HCl pH8.0, 5mM EDTA, 300mM NaCl, 0.5% SDS) with 2.5 uL proteinase K (Qiagen) at 55C for 6 hrs. The eluted DNA was purified by 2x SPRI beads. NEBNext Ultra II DNA Library Prep Kit for Illumina was used for ChIP-seq DNA library construction. The libraries were sequenced on NovaSeq with paired-end 150 bp (Illumina). ''',
            'RNA-Seq': '''SMART-Seq v4 Ultra Low Input RNA Kit for Sequencing (Takara, 634888) was used for RNA-seq library preparation according to manufacturers' instructions.''',
            'DNase-Hypersensitivity': '''the frozen tissue was put in 37oC water bath for 10 seconds to unfreeze, then using a scalpel to cut up the tissue on ice. After dissociate the tissue, add 200uL 0.1% BSA/PBS to resuspend and transferred into 1.7 mL tubes. Centrifuge at 800rpm for 5 minutes at 4oC, then remove supernatant. Add 180uL cold lysis buffer (10mM Tris-HCL pH 7.5, 10mM NaCl, 3mM MgCl2, 0.1% Triton X-100) to resuspend the pellet by gentle pipetting , and then kept on ice for 30 min. 20ul diluted DNaseI (Roche, 04716728001) was add to final concentration of 80 U/mL and incubated at 37oC for exactly 5 min. Reaction was stopped by adding 400ul of stop buffer (10mM Tris-HCL pH 7.5, 10mM NaCl, 0.15% SDS, 10mM EDTA) containing 200ug Proteinase K (QIAGEN, 19133) followed by incubation at 55oC for 3 hr. The DNA was extracted by phenol-chloroform (Amresco, 0883) and precipitated by ethanol with 20ug glycogen (Thermo Fisher, R0551) and 1/10 volume 3M NaOAc (Thermo Fisher, R1181) at -80oC overnight. Following centrifugation at max speed for 15 min, DNA precipitation was washed with 800ul ice-cold 70% ethanol, then dissolved in 50ul TE (2.5mM Tris-HCL pH 7.5, 0.05 mM EDTA) after air-dry. Run DNA on a 2% agarose gel and cut the gel to select 50-100 bp DNA fragments. Purify size selected DNA using Zymoclean Gel DNA Recovery Kit (ZYMO RESEARCH, D4008). NEBNext Ultra II DNA Library Prep Kit for Illumina (NEB, E7645S) was used to construct library. DNA was end repaired and A-tailed by adding 7ul NEBNext Ultra II End Prep Reaction Buffer and 3ul NEBNext Ultra II End Prep Enzyme Mix''',
	'Hi-C': ''' The generation of Hi-C libraries with was optimized according to a previous protocol (Rao et al., 2014). Samples were fixed with 100 mL of freshly made 1% formaldehyde solution and incubated at room temperature for 10 min. To quench the reaction, 2.5 M glycine solution was added to a final concentration of 0.2 M. Samples were incubated at room temperature for 5 min and then centrifuged for 5 min at 3,000 g at 4 oC. Supernatants were discarded and samples were lysed in 100 mL of ice-cold Hi-C lysis buffer (10 mM Tris-HCl pH 8.0, 10 mM NaCl, 0.2% Igepal CA630) with a protease inhibitor cocktail on ice for 15 min. Samples were then centrifuged at 3000 g for 5 min and the supernatants carefully discarded. Pelleted nuclei were washed once with 100 mL of 1x NEBuffer 2. Discard the supernatant and remain 4.5 mL, and add 0.5 mL of 5% sodium dodecyl sulfate (SDS). Tubes were gently tapped to mix the pellet and were incubated at 62C for 5 min. After incubating, 14.5 mL of water
    and 2.5 mL of 10% Triton X-100 were added to quench the SDS. Tubes were gently tapped to mix well, avoiding excessive foaming and then incubated at 37 oC for 15 min. 2.5 mL of 10X NEBuffer 2 and 10 U of MboI restriction enzyme (NEB, R0147) were added and chromatin was digested at 37 oC for 5 hr. Samples were incubated at 62 oC for 20 min to inactivate MboI and then cooled to room temperature. To fill in the restriction fragment overhangs and mark the DNA ends with biotin, 5 mL of fill-in master mix (3.75 mL of 0.4 mM biotin-14-dATP, 0.45 mL of 10 mM dCTP/ dGTP/ dTTP mix, 0.8 mL of 5 U/mL DNA polymerase I, large) was added. Samples were mixed by pipetting and incubated at 37 oC for 30 min. Ligation master mix (66.3 mL of water, 12 mL of 10X NEB T4 DNA ligase buffer, 10 mL of 10% Triton X-100, 1.2 mL of 10 mg/ml bovine serum albumin, 1 mL of 400 U/mL T4 DNA ligase) was added and samples were incubated at 16 oC for 18 hr. Nuclei were pelleted by centrifugation for 5 min at 3000 g and
    were washed with 100 mL of 10 mM Tris buffer, pH 8.0. Pellets were then resuspended 50 mL of 10 mM Tris buffer with 2 mL of 20 mg/ml proteinase K and incubated at 65 oC for 18 hr. Proteinase K was inactivated by incubation at 75 oC for 30 min. To make biotinylated DNA suitable for high-throughput sequencing using Illumina sequencers, DNA samples were sheared to a length of 400 bp. Fifty 50 ng of carrier RNA was added and sheared DNA was transferred to a fresh PCR tube, then treated with the End Repair/dA-Tailing Module (NEB, E7442L) and Ligation Module (NEB, E7445L) following the operation manual. Samples were prepared for biotin pull-down by washing with 50 mL of 10 mg/ml Dynabeads MyOne Streptavidin T1 beads (Life technologies, 65602) in 100 mL of 1X Tween Washing Buffer (1X TWB: 5 mM Tris-HCl, pH7.5; 0.5 mM EDTA; 1 M NaCl; 0.05% Tween 20). Samples were separated on a magnet and the solution was discarded. Ligation products were mixed with 83.5 mL of 2X Binding Buffer (2X BB: 10
        mM Tris-HCl DNA was then quantified and sequenced using an Illumina sequencing platform.'''}
    design = { i: v[:1999] for i,v in design.items() }
    expFh, runFh = open('experiment.xls', 'w'), open('run.xls', 'w')
    for i,each in enumerate(uniq):
        earr = each.strip().split('|')
        Strategy = earr[-1]
        selection = 'ChIP'
        if 'Hi-C' in Strategy:
            selection = 'Restriction Digest'
        elif 'DNase-Hypersensitivity' in Strategy:
            selection = 'DNAse'
        elif 'RNA' in Strategy:
            selection = 'size fractionation'
        elif 'methylation' in Strategy:
            selection = 'size fractionation'
        desi = ' '.join( design.get(Strategy).split('\n') )
        ID = 'E{}'.format(i+1)
        #lst = ['R{}'.format(i+1), earr[0], project_accession, bioSampleName, '', 'Illumina HiSeq X Ten']
        elst = [ ID, earr[0], project_accession, bioSampleName, '', 'Illumina NovaSeq 6000']
        library_type = 'TRANSCRIPTOMIC' if 'RNA' in Strategy else 'GENOMIC'
        elst.extend([ desi, earr[0], Strategy, library_type, selection, 'PAIRED', '150' ] )
        #*earr, sep = '|' )
        print ( *elst, sep = '|', file = expFh)
        read_1, read_2 = earr[-2] +'_1.fq.gz', earr[-2] +'_2.fq.gz'
        pread_1, pread_2 = earr[0] +'_1.fq.gz', earr[0] +'_2.fq.gz'
        if not md5_read(read_1):
            continue
        rlst = [ ID, earr[0], project_accession, earr[0], 'fastq', pread_1, md5_read(read_1), pread_2, md5_read( read_2) ]
        print ( *rlst, sep = '|', file = runFh )

def md5_read( fl ):
    md5_file = fl + '.md5.txt'
    #print ( md5_file )
    if os.path.exists( md5_file ) and os.path.getsize( md5_file) > 0:
        with open( md5_file ) as f:
            return [ i for i in f.readlines() if i.strip()][0].split(' ')[0]

def rename( uniq ):
    for line in uniq:
        line_arr = line.strip().split('|')
        raw_name, name = line_arr[-2], line_arr[0]
        raw_read_1, raw_read_2 = raw_name + '_1.fq.gz', raw_name + '_2.fq.gz'
        read_1, read_2 = name + '_1.fq.gz', name + '_2.fq.gz'
        cmd = 'echo rename {} {} | ftp submit.big.ac.cn'.format( raw_read_1, read_1 )
        print ( cmd )
        cmd = 'echo rename {} {} | ftp submit.big.ac.cn'.format( raw_read_2, read_2 )
        print ( cmd )

def get_already():
    already = defaultdict( int )
    cmd = '''echo dir | ftp submit.big.ac.cn'''
    for line in system.run( cmd, shell = True ):
        line_arr = re.split('\s+', line )
        already[line_arr[-1]] = int(line_arr[4])
    return already
def mvGSA( ):
    already = get_already()
    for each in already:
        if '_' in each:
            print ( 'echo rename {} GSA/{} | ftp submit.big.ac.cn'.format(each,each))
if __name__ == '__main__':
    public_description = ''' The prefrontal cortex development and aging in rhesus monkey '''
    organism = '''Macaca mulatta'''
    project_accession = '''PRJCA018217'''
    bioSampleName = 'New'
    holder=['','']
    tissue = 'prefrontal cortex'
    infor = parse.ini( args.js ).to_dict()
    data = infor['period']
    infor = defaultdict( int )
    already = get_already()
    uniq = system.dir.sort( get_uniq_data(), sep = '_' )
    if args.t in ['bioSample']:
        bioSample( uniq )
    elif args.t in ['run']:
        runExp( uniq )
    elif args.t in ['rename']:
        rename( uniq )
    elif args.t in ['upload', 'md5'] :
        upload_trans( uniq )
    elif args.t in ['mvGSA']:
        mvGSA( )





