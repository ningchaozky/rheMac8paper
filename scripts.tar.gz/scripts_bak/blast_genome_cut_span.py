#!/usr/bin/env python3
import os
import re
import sys
import argparse
from Bio import SeqIO
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('blastoutput', nargs = '?', help = 'reference')
parser.add_argument('query', nargs = '?', help = 'query fasta')
parser.add_argument('genome', nargs = '?', help = 'genome')
parser.add_argument('-s', nargs = '?', help = 'span from match region', default = 2000, type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


header = '6 qlen slen qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore'.split(' ')
header.pop(0)


def pick( start, end, seq, span = 0):
    if start < end :
        ostart, oend = start - span, end + 1
        if oend > len( seq ):
            oend = len( seq )
        out = seq[ ostart : oend].seq
    if start > end :
        ostart, oend = end, start + span + 1
        if oend > len( seq ):
            oend = len( seq )
        out = seq[ ostart : oend ].seq.reverse_complement()
    return out

def sub( string ):
    return re.sub( string, '_forward_frame.*','')


fh = open( args.blastoutput )
query = SeqIO.to_dict( SeqIO.parse( args.query, 'fasta' ))
seq = SeqIO.to_dict( SeqIO.parse( args.genome, "fasta") )
for line in fh:
    line_arr = line.strip().split('\t')
    dit = dict(zip(header, line_arr ))
    #sseqid, qseqid = sub(dit['sseqid']), sub(dit['qseqid'])
    sseqid, qseqid = dit['sseqid'], dit['qseqid']
    pident, qstart, qend, sstart, send = map( int, map( float, [ dit[i] for i in ['pident', 'qstart', 'qend', 'sstart', 'send']]))
    qlen = len(query[qseqid].seq)
    if  pident > 60  and qstart < 20 :
        print ( line.strip() )
        sseq = pick( sstart, send, seq[ sseqid ], args.s )
        qseq = pick( qstart, qend, query[ qseqid ] )
        print ('>' + '-'.join( [ sseqid, qseqid ] ), 'span{}'.format( args.s ))
        print ( qlen, 'qlen-qstart', qlen - qstart, 'qstart', qstart, qend, sstart, send, qseqid, sseqid, pident )
        print ( 'genome seq', sseq ) 
        print ( 'query seq', qseq )
        print ('cap sequence' , sseq + query[qseqid].seq[ qend + 1 : ] )
        #print ( qlen, qstart, qend, sstart, send, pident )
        #print ( 'query source seq', query[qseqid].seq)
        #print ( 'query reverse complement seq', query[qseqid].seq.reverse_complement() )
    else :
        print ( line )
#print ( seq['group1'].seq )




























