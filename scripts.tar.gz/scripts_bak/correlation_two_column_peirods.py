#!/usr/bin/env python3
import os
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
fig = plt.figure( figsize=( 18, 24) )
import argparse
import pandas as pd
import itertools
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'columns scatter plot')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


df = pd.read_csv(args.tab, header = 0, sep = '\t', index_col=[0])
df[df > 400] = 400
for p1,p2 in itertools.combinations(df.columns, 2 ):
    df.plot(x=p1, y=p2, style='o')
    plt.savefig( '{}.{}-vs-{}.pdf'.format( args.tab, p1, p2), dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
































