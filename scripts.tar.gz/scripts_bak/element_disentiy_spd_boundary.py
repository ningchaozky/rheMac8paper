#!/usr/bin/env python3
import os
import re
import sys
import copy
import matplotlib
import numpy as np
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#subplot define, also polar plot
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.barplot( palette="Set2" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import pandas as pd
from munch import DefaultMunch
from ningchao.nSys import trick, system, fix
from collections import defaultdict

example = '''element density on boundary'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'element', nargs = '?', help = 'element bed ini' )
parser.add_argument( '-spdini', nargs = '?', help = 'spd bed ini', default = '/farangism/ningch/earyly_embryo/SPD/dynamic/bed/spd.20220121.ini' )
parser.add_argument( '-bs', nargs = '?', help = 'bin size', default = 10000, type = int )
parser.add_argument( '-bodyLength','-bl', nargs = '?', help = 'body length for plot', default = 1000000, type = int )
parser.add_argument( '-up', nargs = '?', help = 'up spd', default = 500000, type = int )
parser.add_argument( '-down', nargs = '?', help = 'down spd', default = 500000, type = int )
parser.add_argument( '-force','-f', action = 'store_true', help = 'fource calculate of use loal file')
parser.add_argument( '-boundaryOnly','-bo', action = 'store_true', help = 'fold plot boundary')
parser.add_argument( '-removeLegend','-r', action = 'store_true', help = 'removeLegend')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def spd_to_bin( **kwargs):
    kwargs = DefaultMunch.fromDict( kwargs )
    bodysplit_times = kwargs.bodyLength / kwargs.bs
    infor = defaultdict( lambda : defaultdict( lambda : defaultdict( lambda : defaultdict( int ) ) ) )
    with open( kwargs.spdini ) as f:
        for line in f:
            peirod, pbed = re.split(r'\s+', line.strip())
            #up and down deal 
            with open (pbed) as fh:
                for line_num, line in enumerate( fh ):
                    chrom, start, end = line.strip().split('\t')[0:3]
                    chrom = chrom.replace('chr','')
                    chrom , start, end = chrom.replace('chr',''), int( start ), int( end )
                    inside_bs = int( (int(end) - int( start )) / bodysplit_times )
                    for i, pos in enumerate( range(start, end, inside_bs)):
                        relative_pos = int( pos / inside_bs )
                        infor[peirod][chrom]['l{}.i{}'.format( line_num, inside_bs)][ relative_pos ] = 0

                    #abs up and down
                    up_boundary, down_boundary = start - kwargs.get('up'), end + kwargs.get('down')
                    for i, step in enumerate( range(*[ up_boundary, start, kwargs.bs])):
                        relative_pos = int( step / kwargs.bs )
                        infor[peirod][chrom]['l{}.u{}'.format( line_num, kwargs.bs)][ relative_pos ] = 0
                    for i, step in enumerate( range( *[ end, down_boundary, kwargs.bs])):
                        relative_pos = int( step / kwargs.bs )
                        infor[peirod][chrom]['l{}.d{}'.format( line_num, kwargs.bs)][ relative_pos ] = 0
    return infor


def bed_math_pos( element, useful_pos ):
    #split bed to elements files
    fls, out, peirods = defaultdict( str ), defaultdict( dict ), useful_pos.keys()
    with open( element ) as f:
        for line in f:
            line_arr = line.strip().split('\t')
            typ = line_arr[3]
            if typ not in fls:
                fls[typ] = open('/tmp/{}.tmp.bed'.format(typ), 'w')
            fls[typ].write( line )
    for typ in fls:
        fls[typ].close()

    #iter element 
    for element in fls:
        element_useful_pos, ebed = copy.deepcopy( useful_pos ), fls[ element ].name
        with open( ebed ) as f:
            for line_num, line in enumerate( f ):
                if not line_num % 5000 :
                    print ( element, line_num, file = sys.stderr )
                chrom, start, end = line.strip().split('\t')[0:3]
                chrom = chrom.replace('chr','')
                start, end = int( start ), int( end )
                for peirod in peirods:
                    for typ_bs in useful_pos[peirod][chrom].keys():
                        line, lpos = typ_bs.split('.')
                        bs = int( lpos[1:] )
                        for pos in range(start, end, bs):
                            relative_pos = int( pos / bs )
                            if relative_pos in useful_pos[peirod][chrom][typ_bs]:
                                element_useful_pos[peirod][chrom][typ_bs][ relative_pos ] += 1
        out.update( { element: element_useful_pos })
    return out


def plot_data_prepare( useful_pos, **kwargs ):
    dit, out_source = defaultdict( lambda : defaultdict( lambda : defaultdict(int))), []
    for element in useful_pos:
        peirods = useful_pos[element].keys()
        for peirod in peirods:
            if peirod in ['','']:
                continue
            up, inside, down = [], [], []
            for chrom in useful_pos[element][peirod]:
                for typ_bs in useful_pos[element][peirod][chrom]:
                    uid, values = typ_bs.split('.')[1][0],useful_pos[element][peirod][chrom][typ_bs]
                    if uid == 'i':
                        inside.append([ i[1] for i in sorted ( values.items(), key = lambda x: int( x[0] ), reverse = False )])
                    elif uid == 'u':
                        up.append([ i[1] for i in sorted ( values.items(), key = lambda x: int( x[0] ), reverse = False )])
                    elif uid == 'd':
                        down.append([ i[1] for i in sorted ( values.items(), key = lambda x: int( x[0] ), reverse = False )])
                    else :
                        print ( '#Ignore', element, typ_bs, values, 'check', file = sys.stderr)
            up, inside, down = [ np.sum( x  ) for x in zip(*up)  ], [ np.sum( x  ) for x in zip(*inside)  ], [ np.sum( x  ) for x in zip(*down)  ]
            line_values = [ *up, *inside, *down  ]
            for i, v in enumerate( line_values ):
                out_source.append( [ element, peirod, i, v ])
    return pd.DataFrame( out_source, columns = ['element','peirod','pos','num'] )


if __name__ == '__main__':
    xls, pdf = fix.fix(args.element, basename = True).append('plot.Data.xls'), fix.fix(args.element, basename = True).append('plot.Data.pdf')
    if not os.path.exists(xls) or args.force:
        print ( '#START calculate ...', file = sys.stderr)
        useful_pos = spd_to_bin( **vars( args ))
        useful_pos = bed_math_pos( args.element, useful_pos  )
        df = plot_data_prepare( useful_pos )
        df.to_csv( xls, sep = '\t', index = False )
    df = pd.read_csv(xls, header = 0, sep = '\t')
    if args.boundaryOnly:
        df['pos'] = df['pos'].apply(lambda x: abs( x - 199 ) if x >= 100 else x )
        df = df.groupby(['element','peirod','pos'])['num'].agg('sum').reset_index()
    elements = df.element.unique()
    fig,axs = plt.subplots( len(elements), figsize=(10,30), sharex=True, sharey=False, subplot_kw=dict(projection= None));
    if len(elements) == 1:
        fig,axs = plt.subplots( len(elements), figsize=(16,8), sharex=True, sharey=False, subplot_kw=dict(projection= None));
    if len(elements) == 1 :
        axs = [axs]
    for i,element in enumerate( elements ):
        print ( element )
        element_df = df[df.element == element]
        ymax = element_df.num.max()
        sns.lineplot( data = element_df, x = 'pos', y = 'num', hue = 'peirod', err_style="bars", ci=0, ax = axs[i], palette="Set2")
        sns.despine()
        axs[i].set_ylim(auto = True)
        axs[i].set_title( element )
        axs[i].grid(True, which='both')
        axs[i].axvline( 50, ls='--', linewidth= 0.5, color ='grey'  )
        axs[i].spines['top'].set_visible(True)
        axs[i].get_legend().remove()
    if not args.removeLegend:
        handles, labels = axs[ len(elements) - 1].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper left', bbox_to_anchor=(0.2, .5, 0.5, 0.5), ncol = 1, framealpha = 0 )
    axs[len(elements) - 1].spines['right'].set_visible(False)
    sns.despine(fig=fig, ax= axs[len(elements) - 1], top=True, right=True, left=True, bottom=True, offset=None, trim=False)
    plt.savefig( pdf, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')




























