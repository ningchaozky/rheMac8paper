#!/usr/bin/env python
import os,sys


if len(sys.argv) <= 1:
	print(sys.argv[0],'file:sam','read_1 read_2')
	exit()



def lastline():
	global pos
	while True:  
		pos = pos - 1
		try:  
			f.seek(pos, 2)
			if f.read(1) == '\n':  
				break  
		except:
			f.seek(0, 0)          
			return f.readline().strip()
	return f.readline().strip()
  
  
if __name__ == "__main__":
	last_sam_seq,last_read_seq = [],[]
	work_file = os.path.abspath(sys.argv[1])
#	print 'Dealing with: %s ' % work_file
	f = open(work_file,'rb')
	pos = 0
	for line in range(11):
		last = lastline()
		if last == '':
			continue
		last_arr = last.split('\t')
		last_sam_seq.append(last_arr[9])
	f.close()  
	index = 0
	f = open(sys.argv[2],'rb')
	pos = 0
	for line in range(20):
		lastline()
		lastline()
		lastline()
		if lastline() in last_sam_seq:		
			index = 1
	f.close()
	f = open(sys.argv[3],'rb')
	pos = 0
	for line in range(20):
		lastline()
		lastline()
		lastline()
		if lastline() in last_sam_seq:
			index = 1
	if index == 1:
		print('Can look the end of: %s \tsuccess' % work_file)
	else:
		print('\n\nCa\'n look the end of: %s \tfailure' % work_file)
	f.close()
					




