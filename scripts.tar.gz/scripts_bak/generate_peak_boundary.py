#!/usr/bin/env python
import os
import sys




if len(sys.argv) <= 1:
	print(sys.argv[0],'file:bed','int:length')
	exit()


bed = open(sys.argv[1])

for line in bed:
	line_arr = line.split('\t')
	boundary = int(line_arr[1])
	print(line_arr[1],line_arr[2])
	line_arr[1] = boundary - int(sys.argv[2]) - 1
	line_arr[2] = boundary + int(sys.argv[2])
	line_arr = [str(i) for i in line_arr]
	print('\t'.join(line_arr[0:3]))




