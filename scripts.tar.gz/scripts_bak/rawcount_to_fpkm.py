#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nBio.rheMac as rhKit
import ningchao.nSys.trick as trKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( '-i', nargs='?', help ='input file for deal')
parser.add_argument('-o', nargs='?', help ='output file if not sys.std')
parser.add_argument( '-reads', nargs='?',type = float, help ='output file if not sys.std', default = 35 )
args = parser.parse_args()
if len(sys.argv) == 1:
        parser.print_help().__str__
        sys.exit(2)

ofh = sys.stdout
fh = sys.stdin
if args.i != '-':
	fh = open(args.i)
if args.o:
	ofh = open(args.o,'w')

header = fh.next().strip().replace('\'','').replace('#','')
header_arr = header.split('\t')
header_arr[3] = rhKit.short(header_arr[3])
ofh.write('\t'.join(header_arr) + '\n')


for each in fh:
	each = each.strip()
	each_arr = each.split('\t')
	fpkm = float(each_arr[3])/args.reads
	each_arr[3] = str(round(fpkm,3))
	ofh.write('\t'.join(each_arr) + '\n')
	


















