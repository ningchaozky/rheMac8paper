#!/usr/bin/env perl
use strict;
use warnings;

@ARGV or die "#Usage: $0 gonumber[,col] tablename\n";

my ($in,@arg,$col);
@arg = split /,/,$ARGV[0];
if(@arg == 2){
	$col = $arg[1] - 1;
}else{
	$col = 0;
}

open $in,$arg[0];

while(<$in>){
	chomp;
	my @line = split /\t/,$_,-1;
	my $annot = `go_query.pl $line[$col] $ARGV[1]`;
	print "$_\t$annot" if $annot;
}
