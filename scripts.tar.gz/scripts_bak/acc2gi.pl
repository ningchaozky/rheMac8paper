#!/usr/bin/perl -w
#
# This script extract title through gi number, you should put only one 
# gi number in each line thank you for use ningchao 2014.10.15
#
use Getopt::Long;

my $out;
my $blastresult;
my $help;

GetOptions ("accession|a=s" => \$accession,
			"out|o=s" => \$out,
			"help|h" => \$help,
			"gi|g=s" => \$gi);

if($help){
print STDOUT << "EOF";
Usage:
print $0
		-accession|a	
		-gi|g 			gi number
		-out|o 			other number  eg: ebi pdb ... and so on 
		-help|h			 help for your use
	Thanks for your use!~~ ningchao
EOF
		exit();
}

open ACCESSION, "< $accession";
open OUT, "> $out";
open GI, "> $gi";

my $output;
while (<ACCESSION>){
chomp;
if(/gi\|(\d+)\|\w+\|(.*)$/){
print GI "$1\n";
print OUT  "$2\n";
}
}
