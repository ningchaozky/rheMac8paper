#!/usr/bin/perl -w


unless(@ARGV){
	print "\nUsage:\t$0 file.fa file.sam breaks\n\n\tbreaks is you want to split\n\tbam should samtools sort coord\n\toutput\n\n\n";
}
else{

	open $fa,"$ARGV[0]";
	$breaks = $ARGV[2];
	chomp $breaks;
	my $seq_name = '';
	my %fa_length;
	my $fasta_bases = 0;

#get length 

	while(<$fa>){
		chomp;
		if(/>/){
			s/>//;
			$seq_name = $_;
		}
		else{
			$fasta_bases += length;
			$fa_length{$seq_name} += length;
		}
	}
	#get read length
	sub get_read_length(){
		my @cigar = split /[MIS=X]/,shift;
		$len = 0;
		for(@cigar){
			s/.*[DNHP]//g;
			$len += $_;
		}
		return $len;
		$len = 0;
	}
	open $sam, "$ARGV[1]";
	my %words;
	while(<$sam>){
		@tmp = split /\t/,$_;
		if(@tmp > 9 && $tmp[5] =~ /\d+/){
			$read_length = &get_read_length($tmp[5]);
#			print $read_length;
			$big = int ((($tmp[3]+$read_length)*$breaks)/$fa_length{$tmp[2]});
			$small = int ($tmp[3]*$breaks/$fa_length{$tmp[2]});
			unless($small){
#you can split out which reads more than cds here in 5'
				$small = 1;
			}
			if($big > $breaks){
				$big = $breaks;
#you can split out which reads more than cds here in 3'
#				print "$tmp[3]\t$breaks\t$fa_length{$tmp[2]}\t$tmp[2]\t$read_length\t$big\n";
			}
#			print "$tmp[3]\t$read_length\t$fa_length{$tmp[2]}\t\t\t$small\t$big\n";
			for($small..$big){
				$words{$_}++;
			}
		}
	}
	print "position\treads\n"; 
	for(sort{$a<=>$b} keys %words){
		print "$_\t$words{$_}\n";
}
close $sam;
}
