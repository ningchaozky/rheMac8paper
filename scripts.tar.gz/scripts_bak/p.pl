open $file,"$ARGV[0]";
while(<$file>){
#print;
}
print $ARGV[0];
$pwd = `pwd`;
print $pwd;
print $file;
