#!/usr/bin/env sh
### Usage:
###   start
###
help() {
        awk -F '###' '/^###/ { print $2 }' "$0"
}
if [[ $# == 0 ]] || [[ "$1" == "-h" ]]; then
        realpath $0
        help
        exit 1
fi
#project_beds_bws_bams_andSoOn_pos.py ppois H3K4me3 -u 2>/dev/null| while read line; do
read -p "Pol2 H3K27me3, Enter marker: " marker
read -p "gb5k tss3k, Enter type: " type
#type=gb5k
#marker=H3K27me3
>&2 echo !!!use $marker
>&2 echo !!!use $type
>&2 echo sleep 10s for check
>&2 sleep 1
all_xls=()
for ctype in max median sum; do
    normal_array=()
    no_normal_array=()
    for peirod in E50 E90 E120 0M 4M 45Y 20Y; do
        bed=`project_beds_bws_bams_andSoOn_pos.py $marker bed $peirod -u 2>/dev/null`
        #bw=`project_beds_bws_bams_andSoOn_pos.py $marker bw $peirod -u 2>/dev/null`
        bw=`project_beds_bws_bams_andSoOn_pos.py ppois $marker bw $peirod -u 2>/dev/null`
        if [[ $marker == *"nase"* ]]; then
            bw=`project_beds_bws_bams_andSoOn_pos.py $marker bw $peirod -u 2>/dev/null`
        fi
        for normal_type in no_normal normal; do
            out="$marker.$peirod.$type.$normal_type.$ctype.signal"
            if [ "$normal_type" = "normal" ]; then 
    			normal_array+=( "$out,index_col,1,2,3,4,5,6" )
			else
				no_normal_array+=( "$out,index_col,1,2,3,4,5,6")
			fi;
            show bed_bw_values_extract_dynamic_v2.py $bw $bed -t $type -nt $normal_type -o $out -c $ctype
        done
    done
    normal=`join_by ' ' ${normal_array[*]}`
    no_normal=`join_by ' ' ${no_normal_array[*]}`
    normal_merge="normal.${marker}.$ctype.signal.xls"
    show "excel_concat.py $normal > $normal_merge"
    show "tss_geneBody_mini.py $normal_merge > $normal_merge.mini"
    no_normal_merge="no_normal.${marker}.$ctype.signal.xls"
    show "excel_concat.py $no_normal > $no_normal_merge"
    show "tss_geneBody_mini.py $no_normal_merge > $no_normal_merge.mini"
    all_xls+=( $normal_merge.mini )
    all_xls+=( $no_normal_merge.mini )
    #run `pwd` "bed_bw_values_extract_dynamic_v2.py $bw $bed -t $type -no_normal -o $no_normal_out"
    #run `pwd` "bed_bw_values_extract_dynamic_v2.py $bw $bed -t $type -o $normal_out"
done
#excel_concat.py `find.py ppois.signal$ -s ' ' -sort peirod -f 'E80|xls' -x "{},index_col,1,2,3,4,5,6,header,1"` > $type.signal.xls
#find.py ppois.signal$ -s ' ' -sort peirod / . -f 'E80|xls' -x "{},index_col,1,2,3,4,5,6,header,1"
#excel_concat.py

all_xls=`join_by ' ' ${all_xls[*]}`
#match 1 is ok for output
show pick_match_signal_excels_v4.py $all_xls /dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.de80 -t match 1
#all show match for RNA
show pick_match_signal_excels_v4.py $all_xls /dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.de80 -t match all
#one peirod prime
show pick_match_signal_excels_v4.py $all_xls /dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.de80 -t prime 1
#three peirod prime
show pick_match_signal_excels_v4.py $all_xls /dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.de80 -t prime 3
#all peirod prime
show pick_match_signal_excels_v4.py $all_xls /dataB/ftp/pub/rheMac3/analysis/RNA/RNA.tpm.mini.de80 -t prime 7




