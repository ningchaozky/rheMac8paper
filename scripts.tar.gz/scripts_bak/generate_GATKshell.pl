#!/usr/bin/perl -w

use strict;
use File::Basename;
use Getopt::Long;
use Cwd;
my $cwd = getcwd;

sub Usage {
	print STDERR << "EOF";
=====================================================================================
Description      Generate a shell script to run GATK and extract SNP and Indel info
Version: 1.0
2015-11-25       xinglongsheng\@auwigene.com

Options
		-r --ref      <s>   :   the directory of reference genome
		-s --stype    <s>   :   sequencing type: PE(paired-end) or SE(single end)
		-o --organism <s>   :   organsim name
		-c --contract <s>   :   contract No.
		--indels      <s>   :   known Indels info
		--SNP         <s>   :   known SNP info
		-f --fq       <s>   :   the directory of clean fastq files
		--out         <s>   :   output directory
		-b --bwaIdx   <s>   :   bwa index for reference genome
		-n --names    <s>   :   sample names
		-t --thread   <i>   :   number of CPU to use
		-h --help           :   print this help info

=====================================================================================
EOF

}

my ($ref, $stype, $species, $contract, @Indels, $SNP, $fq_dir, $out_dir, $bwaRef, @name, $thread, $help);


GetOptions("ref|r=s" => \$ref,
	   "stype|s=s" => \$stype,
	   "organism|o=s" => \$species,
	   "contract|c=s" => \$contract,
	   "indels=s" => \@Indels,
	   "SNP=s" => \$SNP,
	   "bwaIdx|b=s" => \$bwaRef,
	   "fq|f=s" => \$fq_dir,
	   "out=s" => \$out_dir,
	   "names|n=s" => \@name,
	   "thread|t=i" => \$thread,
	   "help|h" => \$help
);

if( !defined($ref) ||  !defined($stype) || !defined($species) || 
    !defined($contract) || !defined($fq_dir) || !defined($out_dir) || 
    scalar @name == 0 || !defined($bwaRef) || $help ) {
	&Usage();
	exit 0;
}

$thread ||= 8;


$fq_dir =~ s/\/$//;
$out_dir =~ s/\/$//;

$ref =~ s/\/$//;


### priciple of project name based on contract number
my $project_name = "AWG-" . $contract . "-$species" . "-RefTR";

### running directory
#my $run_dir = "$out_dir/$project_name/SNP_Indel";
my $run_dir = $out_dir;

#my $run_dir = "$SNP_Indel_dir/$name";

if( ! -e $run_dir ) {
  mkdir $run_dir;
}
my $run_script = $contract . "_runGATK.sh";

### gatk and picard full path
my $gatk = "/awg/users/ningch/software/calling/gatk/GenomeAnalysisTK.jar";
my $picard = "/awg/users/ningch/software/share/picard-tools-1.119";

#print $run_dir,"\n";

open OUT,">$run_dir/$run_script" || die "Cannot write to $run_script!$!";

print OUT "#!/bin/bash\n\n";

print OUT "mkdir $run_dir/bwa\n";
print OUT "cd $run_dir/bwa\n";

### Known Indel information
my $Mills1000G = "Mills_and_1000G_gold_standard.indels.hg19.vcf";
my $Phase1000G = "1000G_phase1.indels.hg19.vcf";
my $knownIndels = "";

if( scalar @Indels > 0 ) {
  my $cnt = scalar @Indels;
  for (my $i = 0; $i < $cnt; $i++) {
    $knownIndels .= " -known $ref/$Indels[$i] \\\n";
  }
}

### Known SNP information
my $dbsnp = "dbsnp_138.hg19.reordered.vcf";
my $knownSNP = "";

if( defined($SNP) ) {
  $knownSNP .= " -knownSites $ref/$SNP \\\n";
}
if( scalar @Indels > 0 ) {
  my $cnt = scalar @Indels;
  for(my $i = 0; $i < $cnt; $i++) {
    $knownSNP .= " -knownSites $ref/$Indels[$i] \\\n";
  }
}

### fastq postfix
my $post_fix = "";
foreach my $n(0 .. $#name) {
  my $tmp;
  if($stype eq 'PE') {
    $name[$n] =~ /(\S+)_1\.(\S+)/;
    $tmp = $1;
    $post_fix = $2;
  } else {
    $name[$n] =~ /(\S+)\.(\S+)/;
    $tmp = $1;
    $post_fix = $2;
  }
  $name[$n] = $tmp;
}

### core
### print GATK shell for each sample in order
foreach my $i(0 .. $#name) {
  print OUT "################## $name[$i] #################\n\n";

  my $bwa_dir = "$run_dir/bwa";

  my $met_dir = $bwa_dir;
  my $other_dir = $bwa_dir;
  my $vcf_dir = $bwa_dir;

  &print_bwaAlignment($stype,$name[$i],$ref,$bwa_dir,*OUT);
  &print_DupMark($name[$i],$ref,$bwa_dir,$met_dir,*OUT);
  &print_LocalRealign($name[$i],$ref,$bwa_dir,$other_dir,*OUT);
  &print_BQSR($name[$i],$ref,$bwa_dir,$other_dir,*OUT);
  &print_VariantCall($name[$i],$ref,$bwa_dir,*OUT);
  &print_ManualFilter($name[$i],$ref,$vcf_dir,*OUT);
}

print OUT "echo 'SNP Indel analysis completed.'\n";
print OUT "date";

close OUT;


### subroutine for bwa alignment shell
sub print_bwaAlignment {
  my($type, $sample, $ref_dir, $bwa_dir,$ofh) = @_;
  
  my ($sample_forward,$sample_reverse,$sample_read);
  
  my $sai_dir = $bwa_dir;
  my $sam_dir = $bwa_dir;
  my $bam_dir = $bwa_dir;

  my $bwa_cmd = "";
  
  if($type eq 'PE') {
    $sample_forward = "$fq_dir/$sample\_1." . "$post_fix";
    $sample_reverse = "$fq_dir/$sample\_2." . "$post_fix";
	
    $bwa_cmd .= "echo 'bwa aln $ref_dir/$bwaRef -t $thread $sample_forward >$sai_dir/$sample\\_1.sai'\n";
    $bwa_cmd .= "bwa aln $ref_dir/$bwaRef -t $thread $sample_forward >$sai_dir/$sample\\_1.sai\n";

    $bwa_cmd .= "echo 'bwa aln $ref_dir/$bwaRef -t $thread $sample_reverse >$sai_dir/$sample\\_2.sai'\n";
    $bwa_cmd .= "bwa aln $ref_dir/$bwaRef -t $thread $sample_reverse >$sai_dir/$sample\\_2.sai\n";

    ########################### bwa paired-end sam #############################
    $bwa_cmd .= "echo 'bwa sampe -r '\@RG\\tID:$sample\\tLB:$sample\\tSM:$sample\\tPL:ILLUMINA' $ref_dir/$bwaRef $sai_dir/$sample\\_1.sai $sai_dir/$sample\\_2.sai $sample_forward $sample_reverse | gzip > $sai_dir/$sample.sam.gz'\n";
    $bwa_cmd .= "bwa sampe -r '\@RG\\tID:$sample\\tLB:$sample\\tSM:$sample\\tPL:ILLUMINA' $ref_dir/$bwaRef $sai_dir/$sample\\_1.sai $sai_dir/$sample\\_2.sai $sample_forward $sample_reverse | gzip > $sai_dir/$sample.sam.gz\n";

	
  } else {
    $sample_read = "$fq_dir/$sample." . "$post_fix";
	
    $bwa_cmd .= "echo 'bwa aln $ref_dir/$bwaRef -t $thread $sample_read >$sai_dir/$sample.sai'\n";
    $bwa_cmd .= "bwa aln $ref_dir/$bwaRef -t $thread $sample_read >$sai_dir/$sample.sai\n";
    $bwa_cmd .= "echo 'bwa samse -r '\@RG\\tID:$sample\\tLB:$sample\\tSM:$sample\\tPL:ILLUMINA' -f $sample.sam $ref_dir/$bwaRef $sample.sai $sample_read | gzip > $sai_dir/$sample.sam.gz'\n";
    $bwa_cmd .= "bwa samse -r '\@RG\\tID:$sample\\tLB:$sample\\tSM:$sample\\tPL:ILLUMINA' -f $sample.sam $ref_dir/$bwaRef $sample.sai $sample_read | gzip > $sai_dir/$sample.sam.gz\n";
	
  }
  
######################## BWA alignment ########################
  my $bwa_shell = <<BWA_SHELL;

echo "================== bwa alignment ==================="
echo "Start time"
date

########################### bwa alignment ########################

$bwa_cmd


########################### sorting sam file ###########################
echo "Sorting bam file"

echo "java -Xmx10g -Djava.io.tmpdir=/tmp \\
 -jar $picard/SortSam.jar \\
 INPUT=$sam_dir/$sample.sam.gz \\
 OUTPUT=$bam_dir/$sample.bam \\
 SORT_ORDER=coordinate \\
 VALIDATION_STRINGENCY=LENIENT \\
 CREATE_INDEX=true"

java -Xmx10g -Djava.io.tmpdir=/tmp \\
 -jar $picard/SortSam.jar \\
 INPUT=$sam_dir/$sample.sam.gz \\
 OUTPUT=$bam_dir/$sample.bam \\
 SORT_ORDER=coordinate \\
 VALIDATION_STRINGENCY=LENIENT \\
 CREATE_INDEX=true

echo "================== bwa alignment over =================="
echo "End time"
date

BWA_SHELL

  print $ofh $bwa_shell;

}

################################# Duplicate marking ################################
### subroutine for Duplicate marking shell
sub print_DupMark {
  
  my ($sample, $ref_dir, $bam_dir, $met_dir, $ofh) = @_;  

  
  my $Dup_mark = <<DUPMARK_SHELL;

####################### Duplicate marking #######################

echo "================= Duplicate marking =================="

echo "Start time"
date


echo "java -Xmx15g -Djava.io.tmpdir=/tmp \\
 -jar $picard/MarkDuplicates.jar \\
 INPUT= $bam_dir/$sample.bam \\
 OUTPUT= $bam_dir/$sample.dedupped.bam \\
 METRICS_FILE= $met_dir/$sample.dedupped.metrics \\
 CREATE_INDEX=true \\
 VALIDATION_STRINGENCY=LENIENT"

java -Xmx15g -Djava.io.tmpdir=/tmp \\
 -jar $picard/MarkDuplicates.jar \\
 INPUT= $bam_dir/$sample.bam \\
 OUTPUT= $bam_dir/$sample.dedupped.bam \\
 METRICS_FILE= $met_dir/$sample.dedupped.metrics \\
 CREATE_INDEX=true \\
 VALIDATION_STRINGENCY=LENIENT

######################## reorder sam file ##########################

echo "java -Xmx15g -Djava.io.tmpdir=tmp/ \\
 -jar $picard/ReorderSam.jar \\
 I=$bam_dir/$sample.dedupped.bam \\
 O=$bam_dir/$sample.Reorder.bam \\
 R=$ref_dir/$bwaRef \\
 CREATE_INDEX=true \\
 TMP_DIR=tmp/ \\
 VALIDATION_STRINGENCY=LENIENT"

java -Xmx15g -Djava.io.tmpdir=tmp/ \\
 -jar $picard/ReorderSam.jar \\
 I=$bam_dir/$sample.dedupped.bam \\
 O=$bam_dir/$sample.Reorder.bam \\
 R=$ref_dir/$bwaRef \\
 CREATE_INDEX=true \\
 TMP_DIR=tmp/ \\
 VALIDATION_STRINGENCY=LENIENT

echo "================== Duplicate marking over =================="
echo "End time"
date

DUPMARK_SHELL

  print $ofh $Dup_mark;

}

########################## Local realignment #######################
### subroutine for Local realignment shell

sub print_LocalRealign {
  my ($sample, $ref_dir, $bam_dir, $other_dir, $ofh) = @_;
  	

  my $LocalRealignment = <<LR_SHELL;

echo "================== Local realignment =================="

echo "Start time"
date


echo "================== RealignerTargetCreator =================="
echo "java -Xmx15g -jar $gatk \\
 -T RealignerTargetCreator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.bam \\
$knownIndels -o $other_dir/$sample.realigner.intervals"
  

java -Xmx15g -jar $gatk \\
 -T RealignerTargetCreator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.bam \\
$knownIndels -o $other_dir/$sample.realigner.intervals


echo "================== IndelRealigner =================="
echo "java -Xmx15g -jar $gatk \\
 -T IndelRealigner \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.bam \\
 -targetIntervals $other_dir/$sample.realigner.intervals \\
$knownIndels -o $bam_dir/$sample.dedupped.realigned.bam"


java -Xmx15g -jar $gatk \\
 -T IndelRealigner \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.bam \\
 -targetIntervals $other_dir/$sample.realigner.intervals \\
$knownIndels -o $bam_dir/$sample.dedupped.realigned.bam


echo "================== Local realignment over =================="

echo "End time"
date

LR_SHELL

  print $ofh $LocalRealignment;

}

############################ Base quality score recalibration ############################


### subroutine for Base quality score recalibration shell
sub print_BQSR {
  my($sample, $ref_dir, $bam_dir, $other_dir, $ofh) = @_;

  my $BaseQualityScoreRecal = <<BQSR_SHELL;

echo "================== Base quality score recalibration =================="

echo "Start time"
date

### Analyze patterns of covariation in the sequence dataset ###
echo "java -Xmx15g -jar $gatk \\
 -T BaseRecalibrator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
$knownSNP -o $other_dir/$sample.recal.grp"

java -Xmx15g -jar $gatk \\
 -T BaseRecalibrator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
$knownSNP -o $other_dir/$sample.recal.grp

### Do a second pass to analyze covariation remaining after recalibration ###
echo "java -Xmx15g -jar $gatk \\
 -T BaseRecalibrator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
 -BQSR $other_dir/$sample.recal.grp \\
$knownSNP -o $other_dir/$sample.post_recal.grp"

java -Xmx15g -jar $gatk \\
 -T BaseRecalibrator \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
 -BQSR $other_dir/$sample.recal.grp \\
$knownSNP -o $other_dir/$sample.post_recal.grp



### Generate before/after plots ###
echo "java -Xmx15g -jar $gatk \\
 -T AnalyzeCovariates \\
 -R $ref_dir/$bwaRef \\
 -before $other_dir/$sample.recal.grp \\
 -after $other_dir/$sample.post_recal.grp \\
 -plots $other_dir/recalibration_plots.pdf"

java -Xmx15g -jar $gatk \\
 -T AnalyzeCovariates \\
 -R $ref_dir/$bwaRef \\
 -before $other_dir/$sample.recal.grp \\
 -after $other_dir/$sample.post_recal.grp \\
 -plots $other_dir/recalibration_plots.pdf

### Apply the recalibration to your sequence data ###
echo "java -Xmx15g -jar $gatk \\
 -T PrintReads \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
 -BQSR $other_dir/$sample.recal.grp \\
 -o $bam_dir/$sample.dedupped.realigned.recal.bam"

java -Xmx15g -jar $gatk \\
 -T PrintReads \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.bam \\
 -BQSR $other_dir/$sample.recal.grp \\
 -o $bam_dir/$sample.dedupped.realigned.recal.bam


echo "================== Base quality score recalibration over =================="
echo "End time"
date

BQSR_SHELL

  print $ofh $BaseQualityScoreRecal;

}

################################ Variant calling using HaplotypeCaller ################################
### subroutine for Variant calling shell
sub print_VariantCall {
  my ($sample, $ref_dir, $bam_dir, $ofh) = @_;

  my $variants = $sample . "_raw_variants.vcf";

  my $Variant_calling = <<VARCALL_SHELL;

echo "================== Variant calling =================="

echo "Start time"
date
echo "java -Xmx15g -jar $gatk \\
 -T HaplotypeCaller \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.recal.bam \\
 -L 20 \\
 --genotyping_mode DISCOVERY \\
 -stand_emit_conf 10 \\
 -stand_call_conf 30 \\
 -o $bam_dir/$variants"

java -Xmx15g -jar $gatk \\
 -T HaplotypeCaller \\
 -R $ref_dir/$bwaRef \\
 -I $bam_dir/$sample.dedupped.realigned.recal.bam \\
 -L 20 \\
 --genotyping_mode DISCOVERY \\
 -stand_emit_conf 10 \\
 -stand_call_conf 30 \\
 -o $bam_dir/$variants


echo "================== Variant calling over =================="
echo "End time"
date

VARCALL_SHELL

  print $ofh $Variant_calling;

}
############################ Manual filtering #############################
### subroutine for Manual filtering shell
sub print_ManualFilter {
  my ($sample, $ref_dir, $vcf_dir, $ofh) = @_;

  my $variant = $sample . "_raw_variants.vcf";
  my $snp = $sample . "_raw_snps.vcf";
  my $indel = $sample . "_raw_indels.vcf";
  my $filteredSNP = $sample . "_filtered_snps.vcf";
  my $filteredIndel = $sample . "_filtered_indels.vcf";

  my $Manual_filtering = <<MANUALFILTER_SHELL;


echo "================== Manual filtering =================="
echo "Start time"
date

### 1. Extraction of SNPs from call set ###
echo "java -Xmx15g -jar $gatk \\
 -T SelectVariants \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$variant \\
 -selectType SNP \\
 -o $vcf_dir/$snp"

java -Xmx15g -jar $gatk \\
 -T SelectVariants \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$variant \\
 -selectType SNP \\
 -o $vcf_dir/$snp

### 2. Determination of parameters for filtering SNPs ###
###   QualByDepth (QD) 2.0
###   FisherStrand (FS) 60.0
###   RMSMappingQuality (MQ) 40.0
###   MappingQualityRankSumTest (MQRankSum) 12.5
###   ReadPosRankSumTest (ReadPosRankSum) 8.0

### 3. Application of filters to the SNP call set ###
echo "java -Xmx15g -jar $gatk \\
 -T VariantFiltration \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$snp \\
 --filterExpression "QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \\
 --filterName "my_snp_filter" \\
 -o $vcf_dir/$filteredSNP"

java -Xmx15g -jar $gatk \\
 -T VariantFiltration \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$snp \\
 --filterExpression "QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \\
 --filterName "my_snp_filter" \\
 -o $vcf_dir/$filteredSNP


### 4. Extraction of Indels from the call set ###
echo "java -Xmx15g -jar $gatk \\
 -T SelectVariants \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$variant \\
 -selectType INDEL \\
 -o $vcf_dir/$indel"

java -Xmx15g -jar $gatk \\
 -T SelectVariants \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$variant \\
 -selectType INDEL \\
 -o $vcf_dir/$indel

### 5. Determination of parameters for filtering Indels ###
###    QualByDepth(QD) 2.0
###    FisherStrand(FS) 200.0
###    ReadPosRankSumTest(ReadPosRankSum) 20.0

### 6. Application of filters to the Indel call set ###
echo "java -Xmx15g -jar $gatk \\
 -T VariantFiltration \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$indel \\
 --filterExpression "QD < 2.0 || FS > 200.0 || ReadPosRankSum < -20.0" \\
 --filterName "my_indel_filter" \\
 -o $vcf_dir/$filteredIndel"

java -Xmx15g -jar $gatk \\
 -T VariantFiltration \\
 -R $ref_dir/$bwaRef \\
 -V $vcf_dir/$indel \\
 --filterExpression "QD < 2.0 || FS > 200.0 || ReadPosRankSum < -20.0" \\
 --filterName "my_indel_filter" \\
 -o $vcf_dir/$filteredIndel


echo "================== Manual filtering over =================="
echo "End time"
date

MANUALFILTER_SHELL

  print $ofh $Manual_filtering;

}


