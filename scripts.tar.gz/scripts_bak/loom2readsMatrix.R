#!/usr/bin/env Rscript
#first
alen <- commandArgs()
suppressMessages(library(SeuratDisk))
suppressMessages(library(SeuratObject))
suppressMessages(library(Seurat))
suppressMessages(library(argparser))
p <- arg_parser('script description')
p <- add_argument( p, "loom", short = '-l',help="loom file download from internet" )
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))

ds <- Connect( filename = args$loom, mode = "r")
fca_head_mat <- ds[["/matrix"]][,]
fca_head_geneid <- ds[["/row_attrs/Gene"]][]
fca_head_cellid <- ds[["/col_attrs/CellID"]][]
colnames(fca_head_mat) <- fca_head_geneid
rownames(fca_head_mat) <- fca_head_cellid
write.table( fca_head_mat, file = paste(args$loom, 'tab', sep="."), append = FALSE, quote = TRUE, sep = "\t", col.names=NA )




























