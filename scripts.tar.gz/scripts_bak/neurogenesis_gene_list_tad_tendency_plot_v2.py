#!/usr/bin/env python3
import os
import sys
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
import math
plt.tight_layout()
import pandas as pd
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system, excel
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs='+', help ='excel you want to mini')
parser.add_argument( '-tads', nargs='+', help ='tads for calculate the tendency', default = ['/dataB/ftp/pub/rheMac3/analysis/hic/hic/10K/E50.merge.chrall.ICE.domain.bed', '/dataB/ftp/pub/rheMac3/analysis/hic/hic/10K/E90.merge.chrall.ICE.domain.bed'])
parser.add_argument( '-ref', nargs = '?', help = 'gene annot', default = '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.bed')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def tad_calculate_tendency():
    infor = defaultdict( lambda : defaultdict( list ) )
    for tad in args.tads:
        period = system.dir.str_map_period( tad )
        cmd = 'bedtools intersect -a {} -b {} -wo'.format( tad, args.ref )
        for line in system.run( cmd, shell = True ):
            line_arr = line.rstrip().split('\t')
            tad_start, tad_end = map( int, line_arr[1:3] )
            symbol_start, symbol_end = map( int, line_arr[4:6] )
            symol_mid = (symbol_end - symbol_start) / 2
            tad_mid = (tad_end - tad_start) / 2
            #distance_to_boundary = min( [ abs(symol_mid - tad_start), abs(tad_start - tad_end) ] )
            distance_to_boundary = min( [ abs(symol_mid - tad_start), abs(symol_mid - tad_end) ] )
            y = abs ( symol_mid - tad_mid )
            #y = y / (y + distance_to_boundary)
            x = distance_to_boundary
            symbol = line_arr[6].split('.')[0].upper()
            if y/x < 2 :
                continue
            infor[ symbol ][ period].append( y/x )
    tendency_output_dit = defaultdict( lambda : defaultdict( list ) )
    for symbol in infor.keys():
        for period in infor[symbol].keys():
            tendency_output_dit[symbol][period] = sum( infor[symbol][period] )
    df1 = pd.DataFrame( tendency_output_dit ).T
    df1_max = np.nanmax( df1.to_numpy() )
    df1 = df1.fillna( df1_max )
    df1.to_csv( 'tad_calculate_tendency.data', sep = '\t', header = True, index = True, index_label = 'symbol' )
    return infor

def tabs_parse():
    infor = defaultdict( list )
    tabs =  excel.parse( args.tabs )
    for tab, tpara in tabs:
        index_col = tpara.get('index_col')
        with open( tab ) as f :
            for line in f :
                if 'modProbes' in line :
                    continue
                line_arr = line.strip().split('\t')
                symbol = line_arr[index_col].split('.')[0].upper()
                infor[ symbol ].append( tab )
    return infor


def pick_data( tabs_symbols, symbol_period_tendency ):
    infor = defaultdict( lambda : defaultdict( list ) )
    for symbol in tabs_symbols:
        tabs = tabs_symbols[symbol]
        for tab in tabs:
            if symbol in symbol_period_tendency:
                infor[tab][symbol] = symbol_period_tendency[symbol]
    lst = []
    for tab in infor:
        for symbol in infor[tab]:
            #for p in ['E90','E50']:
            for p in [system.dir.str_map_period(i) for i in args.tads ]:
            #for p in infor[tab][symbol]:
                for val in infor[tab][symbol][p]:
                    val = math.log( 1 + val)
                    lst.append([tab, symbol, p, val])
    df = pd.DataFrame( lst, columns = ['tab','symbol','period','val'])
    return df

def plot( df ):
    ax = sns.violinplot( x='tab', y='val', hue = 'period', data = df)
    #ax = sns.boxplot( x='tab', y='val', hue = 'period', data = df)
    #ax.set_ylim([ 0,  0.4])
    plt.savefig(('prefix.tendency' + '.pdf'), format='pdf',  bbox_inches='tight', pad_inches=+1 )


if __name__ == '__main__':
    tabs_symbols = tabs_parse()
    symbol_period_tendency = tad_calculate_tendency()
    df = pick_data( tabs_symbols, symbol_period_tendency )
    plot( df )


























