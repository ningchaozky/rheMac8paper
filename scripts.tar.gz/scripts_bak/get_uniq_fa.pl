#!/usr/bin/perl 
use strict;

unless(@ARGV){
	die "Usage: $0 fa\n";
}

my ($fa,$str);
open $fa,"$ARGV[0]";
	while(<$fa>){
		chomp;
		if(/>/){
			s/>//;
			$_ = quotemeta;
			if($str =~ /$_\n/){
				print "$_\n";
				$str =~ s/\\//g;
			}
			$str .= "$_\n";
		}
	}

