#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s bed' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed for the gff')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

bfh = open(args.bed)
fLine = bfh.next().strip().split('\t')
fGene = fLine[3]
exons = []
for line in bfh:
    line_arr = line.strip().split('\t')
    gene = line_arr[3]
    exons.append(line_arr)
    if gene != fGene:
        print(exons)
        fGene = gene
        exons = []





























