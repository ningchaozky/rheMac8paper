#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs = '?', help = 'bed')
parser.add_argument('-span', nargs = '?', help = 'bed for span. 10000', default = 10000, type = int )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fh = open( args.bed )
chroms = chromosome.chr('rh8', sexX = True, sexY = True).chr
for line in fh:
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    line_arr[1], line_arr[2] = int ( line_arr[1] ), int ( line_arr[2] )
    chrom_max = int( chroms[chrom] )
    line_arr[1] = line_arr[1] - args.span 
    line_arr[2] = line_arr[2] + args.span
    if line_arr[1] < 0 :
        continue
    if line_arr[2] > chrom_max:
        continue
    trick.write( line_arr )






























