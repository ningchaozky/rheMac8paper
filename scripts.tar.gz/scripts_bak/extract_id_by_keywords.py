#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = '''file keywordsFile '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('f', nargs='?', help ='file for extract')
parser.add_argument('k', nargs='?', help ='key words file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
kf = args.k
kfh = open(kf)
keys = []
for line in kfh:
    line_arr = [ i.strip() for i in line.split(';') if i.strip() ]
    keys.extend(line_arr)

kfh.close()
fh = open(args.f)
for line in fh:
    index = False
    for each in keys:
        if trick.lstInStr(each,line):
            index = True
            break 
    if index :
        print(line, end=' ')


























