#!/usr/bin/perl -w

######################################################
#      This script is aimed at extracting diff       #         
######################################################
use strict;
use Getopt::Long;


my $fileA;
my $fileB;
my $out;
my $help;
my $out2;

GetOptions("fileA|a=s" => \$fileA,
           "fileB|b=s" => \$fileB,
           "out|o=s" => \$out,
           "help|h" => \$help,
			"moreThanOneTime|m=s" => \$out2);
           
           
           
if( $help ) {
  print STDERR << "EOF";
Usage:
  perl $0
          -fileA|a	  	file A (the big one)
          -fileB|b	  	file B (the little one)
          -out|o		output file contain the big one have no in the little one
          -help|h 		print help info
		  -m			more than one title
EOF
  exit();
          	
}


open A,"< $fileA";
open B,"< $fileB";
open OUT, "> $out";
my @b = <B>;
chomp @b;

my %hash;
while(<A>){
s/\s+//;
s///;
chomp;
my $a=$_;
my $cn;
$_ = quotemeta;
foreach $b(@b){
$b =~ s/\s+//;
$b =~ s///;
if($b =~ /^($_)$/){
$cn++;
}
}
$hash{$a} = $cn;
}

while(my ($key,$value) = each %hash){
unless( defined $value){
print	OUT "$key\n";
}
}

open OUT2, "> $out2";
while(my ($key,$value) = each %hash){
if( defined $value && $value >1){
print OUT2 "$key\n";
}
}
