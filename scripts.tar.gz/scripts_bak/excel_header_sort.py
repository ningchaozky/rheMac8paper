#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick, excel
from ningchao.nBio import rheMac
example = '''excel header sort'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('xls', nargs='?', help = 'xls header sort')
parser.add_argument('-rep', action='store_false', help = 'del replicate')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


class parse():
    def __init__(self, args):
        self.excel = args.xls
        self.rep = args.rep
    def xls(self):
        return self.excel
    def rep(self):
        return self.rep

if __name__ == '__main__':
    args = parse(args)
    inputFile, rep = args.xls(), args.rep
    header = excel.xls(inputFile).header()
    keys = rheMac.trick().sort(header)
    if  rep :
        keys = [ i for i in keys if 'rep' not in i ]
    reheader = ' '.join(keys)
    cmd = 'excel_mini_col.py %s -c skey -v %s' % (inputFile, reheader)
    sys.stderr.write(cmd + '\n')
    os.system( cmd )

























