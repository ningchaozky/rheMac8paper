#!/usr/bin/env python3
import os
import re
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick, system
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'd', nargs='?', help = '.diff$ file for analysis')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fls = system.dir(args.d).fls('diff$', fpattern = 'vs')
infor = defaultdict( lambda : defaultdict ( list ) )

for fl in fls :
    with open(fl) as f :
        print ( fl, next(f), file = sys.stderr )
        for line in f :
            if 'Non-Differential' in line:
                continue
            line_arr = line.rstrip().split('\t')
            chrom = os.path.basename(fl).split('.')[0]
            infor[line_arr[-1]][chrom].append(line.rstrip())
num = defaultdict( int )
for chrom in infor.keys():
    for t in infor[chrom]:
        print ( chrom, t, len(infor[chrom][t]) )
        num[chrom] += len(infor[chrom][t])
print ( num )

























