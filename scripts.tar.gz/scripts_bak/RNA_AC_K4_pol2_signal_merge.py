#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('matrixs', nargs='*', help ='matrix merge ')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def parse( args ):
    matrixs = args.matrixs
    RNA_matrix = [ i for i in matrixs if 'RNA' in i ][0]
    others = [ i for i in matrixs if i != RNA_matrix ]
    return RNA_matrix, others

def pRNA( bed ):
    dit = {}
    fh = open ( bed )
    header = fh.next().strip().split('\t')
    for line in fh :
        line_arr = line.strip().split('\t')
        #line_dit = dict(zip(header, line_arr))
        gene = line_arr[4].split('.')[0].upper()
        trick.dinit( dit, 'header', header )
        chain, chrom = line_arr[3], line_arr[0]
        if chain == '+' :
            tss = line_arr[1]
        else :
            tss = line_arr[2]
        trick.dinit( dit, gene, chrom, tss, [])
        dit[ gene ][ chrom ][ tss ].append( line.strip() )
    fh.close()
    return dit

def pOthers( others ):
    dit = {}
    for each in others:
        fh = open( each )
        header = fh.next().strip().split('\t')
        trick.dinit( dit, each, 'header', header )
        for line in fh:
            line_arr = line.strip().split('\t')
            tss = str((int(line_arr[1]) + int(line_arr[2]))/2)
            gene = line_arr[4].split('.')[0].upper()
            chrom = line_arr[0]
            trick.dinit( dit, each, gene, chrom, tss, [])
            dit[each][gene][chrom][tss].append(line.strip())
        fh.close()
    return dit

def gene_extract_val( gene, typs, chip_dit ):
    line_arr = []
    for typ in typs :
        header = chip_dit[ typ ][ 'header' ]
        if gene in chip_dit[ typ ]:
            val = chip_dit[ typ ].pop( gene )
            line_arr.append( val )
        else :
            exit('check gene %s in %s\n' % (gene, typ))
    return line_arr

def compare_and_out_line( rdit, odit ):
    line_arr = []
    for chrom in rdit:
        for tss in rdit[chrom]:
            for sameTss_diff in rdit[chrom][tss]:
                line_arr.append( sameTss_diff )
                try :
                    for e in [ i[chrom][tss] for i in odit ]:
                        line_arr.extend(e)
                except :
                    print(chrom, tss, rdit, odit)
                    exit ()
    return '\t'.join( line_arr )
if __name__ == '__main__':
    RNA_matrix, others = parse ( args )
    RNA_dit = pRNA( RNA_matrix )
    chip_dit = pOthers( others )
    rheader = RNA_dit.pop('header')
    typs = list(chip_dit.keys())
    [ rheader.extend(chip_dit[i]['header']) for i in typs ]
    print('\t'.join(rheader))
    for gene in RNA_dit:
        print(compare_and_out_line(RNA_dit[gene], gene_extract_val(gene, typs, chip_dit )))
        


























