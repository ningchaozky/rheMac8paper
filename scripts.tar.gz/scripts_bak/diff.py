#!/usr/bin/env python3

import os
import sys
import argparse
from ningchao.nSys import trick,cmd,fileKit
example = ''' diff two matrix '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-m1', nargs = '+', help = ' matrix1 and column want to compare ')
parser.add_argument('-m2', nargs = '+', help = ' matrix2 and column want to compare ')
parser.add_argument('-s',  choices = ['1-2','2-1','1^2','1|2','1&2'], help = ' type of operate ', default = '1-2')
parser.add_argument('-igc',  action = 'store_true', help = ' upper ' )
parser.add_argument('-onlyGene',  action = 'store_true', help = ' only compare gene ' )
parser.add_argument('-wholeLine',  action = 'store_true', help = ' wholeLine ' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def write(lst):
    for each in lst:
        print(each)

def up( slst ):
    return set([ i.upper() for i in slst ])

def pick_gene(lst):
    out = []
    for each in lst:
        e_arr = each.split('.')
        out.append(e_arr[0].upper())
    return set(out)

if __name__ == '__main__':
    select, igc, onlyGene, wholeLine = args.s, args.igc, args.onlyGene, args.wholeLine
    m1, c1 = cmd.parse(args.m1).matrix()
    m2, c2 = cmd.parse(args.m2).matrix()
    gene1 = set ( list (fileKit.File(m1).lst(c1, case = True ) ) )
    gene2 = set (list (fileKit.File(m2).lst(c2, case = True ) ) )
    if onlyGene:
        gene1 = pick_gene( gene1 )
        gene2 = pick_gene( gene2 )
    if igc :
        gene1 = up( gene1 )
        gene2 = up( gene2 )
    if select == '1-2':
        write(gene1 - gene2)
    elif select == '1^2':
        write( gene1 ^ gene2 )
    elif select == '2-1':
        write(gene2 - gene1)
    elif select == '1&2':
        write( gene1 & gene2 )
    elif select == '1|2':
        write( gene1 | gene2 )


























