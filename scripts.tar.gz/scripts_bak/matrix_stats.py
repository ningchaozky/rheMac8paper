#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from pandas import read_table
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'matrix', nargs='?', help ='matrix' )
parser.add_argument( '-header', action='store_false', help = 'header?' )
parser.add_argument( '-index', nargs = '*', help = 'index col', default = [1], type = int )
parser.add_argument( '-usecols', nargs = '*', help = 'columns' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

matrix = args.matrix
header = int(args.header)
index = args.index
if len(index) == 1:
    index = int(index[0]) - 1
else :
    index = [ i -1 for i in index ]
usecols = args.usecols
df = read_table( matrix, sep = '\t', header = header, index_col = index, usecols = usecols )
print(df.quantile( [0.25, 0.5, 0.75 ], axis = 0 ))



























