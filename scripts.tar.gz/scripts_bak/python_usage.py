#!/usr/bin/env python
import sys
import copy
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='get env keys\' values')
parser.add_argument('-k', nargs='?', default = 'defaults', help ='key work for getitem from env dict')
parser.add_argument('-d', nargs='?', default = '/allwegene3/soft/public/env', help ='js dir')
parser.add_argument('-all', action='store_true', help ='print all keys for use')

exec(trickTookit.usage('parser'))

args = parser.parse_args()

dct = envTookit.to_dict(args.d,suffix='.js',exculde=['env.js'])
if args.all:
	print(list(dct.keys()))
	sys.exit(0)

if isinstance( args.k, list ):
	for each in args.k:
		print(dct[each])
elif isinstance( args.k, str ):
	print(dct[args.k])
