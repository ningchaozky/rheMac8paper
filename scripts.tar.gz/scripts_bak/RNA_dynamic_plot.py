#!/usr/bin/env python3
import os
import sys
import matplotlib
import pandas as pd
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
plt.tight_layout()
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
fig, ax = plt.subplots( 1, figsize=(10,40) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'RNA', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
parser.add_argument( '-c', nargs= '?', help = 'cut off for express, row col, 0.5 0.5 ', default = 0.5, type = float)
parser.add_argument( '-n1', nargs= 2, help = 'n1 cut off, row 0.8, col, top 0.2', default = [ 0.8, 0.2 ], type = float)
parser.add_argument( '-p', nargs='?', help = 'deal with method for transcripts: max median sum maxstd', default = 'sum')
parser.add_argument( '-o', nargs='?', help ='output results', default = sys.stdout, type = argparse.FileType('w'))
parser.add_argument( '-t', choices=['rowCut','colCut','allCut'], help = 'cut method for output', default = 'allCut')
parser.add_argument( '-a', action='store_true', help = 'append the not specify results')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse_exp():
    print ('parse_exp ...', file = sys.stderr)
    exp, exp_dict = defaultdict( list ), defaultdict( lambda : defaultdict( float ) )
    header = args.RNA.readline().rstrip().split('\t')
    header_match_period = [ system.dir.str_map_period(i) for i in header[1:] ]
    for line in args.RNA :
        line_arr = line.rstrip().split('\t')
        symbol = line_arr[0].split('.')[0]
        exp[symbol].append( line )
    with open( '.'.join( [ args.RNA.name, args.p, 'tab'] ), 'w') as f:
        print ( *header, sep = '\t', file = f )
        for symbol in exp:
            print ( *trick.lst( exp[symbol] ).pick( pt = args.p ), sep = '\t', file = f)
    with open( f.name ) as f:
        f.readline()
        for line in f:
            line_arr = line.rstrip().split('\t')
            #if max(map(float, line_arr[1:])) < args.c:
            #    continue
            dit = dict( zip( header[1:], line_arr[1:]) )
            exp_dict[line_arr[0]] = dit
    kwargs.update( { 'exp': f.name, 'header': header, 'header_match_period': header_match_period, 'exp_dict': exp_dict } )

def row_cut():
    print ('row_cut ...', file = sys.stderr)
    symbols = defaultdict( list )
    with open( kwargs.get('exp') ) as f:
        f.readline()
        header = kwargs.get('header')
        for line in f :
            line_arr = line.rstrip().split('\t')
            line_cut = trick.dit( header[1:], line_arr[1:], fun = float ).n1Cut( percent = args.n1[0], cut = args.c)
            for each in line_cut:
                if not each :
                    continue
                p,v,percent = each
                symbols[ p ].append( line_arr[0] )
    return symbols

def col_cut( symbols ):
    print ('col_cut ...', file = sys.stderr)
    symbols_share, exp_dict = defaultdict( list ), kwargs.get('exp_dict')
    for p in symbols.keys():
        psymbols = symbols[p]
        lst = [ ( symbol, exp_dict[symbol][p] ) for symbol in psymbols ]
        tmp = trick.dit( [i[0] for i in lst], [i[1] for i in lst], fun = float ).top( top = args.n1[1] )
        symbols[p] = [i[0] for i in tmp ]
    return symbols
def get_tab( symbols ):
    box_plot_data = defaultdict( int )
    print ('get_tab ...', file = sys.stderr)
    exp_dict = kwargs.get('exp_dict')
    symbols_uniq = set()
    rc = 'r' + str(int(args.n1[0]*100))+'c' + str(int(args.n1[1]*100)) if args.t != 'rowCut' else 'r' + str(int(args.n1[0]*100))
    with open( '.'.join( map( str, [ args.RNA.name, args.p, args.t, rc, 'tab']) ), 'w') as f:
        fh = open( fix.fix(f.name).insert('withPeriod'), 'w')
        print ( *kwargs.get('header'), sep = '\t', file = f)
        print ( *kwargs.get('header'), 'period', sep = '\t', file = fh)
        header = kwargs.get('header')[1:]
        if 0 :
            print ('change 45Y 20Y', file = sys.stderr)
            raw_2 = header[-2]
            header[-2] = header[-1]
            header[-1] = raw_2
        for p in header:
            for symbol in symbols[p]:
                if symbol not in symbols_uniq:
                    box_plot_data[p] += 1
                    pval = [ symbol, *[ exp_dict[symbol][p] for p in header ] ]
                    print ( *pval, sep = '\t', file = f )
                    print ( *pval, system.dir.str_map_period(p), sep = '\t', file = fh )
                symbols_uniq.add( symbol )
        #append not in specify
        if args.a :
            for symbol in exp_dict:
                if symbol not in symbols_uniq:
                    pval = [ symbol, *[ exp_dict[symbol][p] for p in header ] ]
                    print ( *pval, sep = '\t', file = f )
                    print ( *pval, system.dir.str_map_(period), sep = '\t', file = fh )
    plt.bar(*zip(*box_plot_data.items()))
    pdf = f.name + '.bar.pdf'
    for bars in ax.containers:
    	ax.bar_label(bars)
    plt.title('{}.genes'.format(sum(box_plot_data.values())))
    plt.savefig( pdf, dpi=250, transparent=True )
    os.system('heatmap_seaborn.py {}'.format(f.name))
    os.system('link_generate.py {}'.format( pdf ))
def main():
    print ( '#Parameters:', args.n1, args.c, file = sys.stderr )
    parse_exp()
    symbols = row_cut()
    if args.t in ['colCut','allCut']:
        symbols = col_cut( symbols )
    get_tab( symbols )
if __name__ == '__main__':
    kwargs = vars( args )
    main()

