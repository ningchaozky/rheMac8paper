#!/usr/bin/env Rscript
Args <- commandArgs()

library(DEGseq)
label1 <- Args[6]
label2 <- Args[7]
pValue <- as.numeric(Args[8])
foldChange <- as.numeric(Args[9])
geneExpFile <- Args[10]
output <- paste(label1,label2,sep = "-vs-")
file <- read.table(geneExpFile,header=T,sep="\t")


geneExpMatrix1 <- as.matrix(data.frame(file[1],file[[label1]]))
geneExpMatrix2 <- as.matrix(data.frame(file[1],file[[label2]]))
layout(matrix(c(1,2,3,4,5,6), 3, 2, byrow=TRUE))
par(mar=c(2, 2, 2, 2))
DEGexp(geneExpMatrix1=geneExpMatrix1, geneCol1=1, expCol1=c(2), groupLabel1=label1,
	geneExpMatrix2=geneExpMatrix2, geneCol2=1, expCol2=c(2), groupLabel2=label2,
	method="MARS",
	pValue=pValue,
	foldChange=foldChange,
	outputDir=output)
