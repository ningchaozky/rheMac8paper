#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import geneKit
example = '''html download results'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('files', nargs='+', help = 'files for anaysis')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()





infor = {}
for fl in args.files:
    fh = open( fl )
    for line in fh:
        if 'Gene' in line or 'gene' in line:
            continue
        line_arr = line.strip('\n').split('\t')
        name = (line_arr[-1] + '.' + line_arr[-2]).strip('.').replace(' ','')
        trick.dit(infor).set( name, [] )
        genes = [ line_arr[0] ]
        genes.extend( [ i.strip() for i in line_arr[1].split(',') ] )
        infor[name].extend( geneKit.name(genes).format() )
for name in infor:
    print(name +'\t', end=' ')
    print(','.join( infor[name] ))


























