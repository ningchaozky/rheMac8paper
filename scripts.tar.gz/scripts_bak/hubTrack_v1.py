#!/usr/bin/env python
import sys
import os
import copy
import argparse
from ningchao.nSys import system
import ningchao.usage as uTookit
import ningchao.nBio.hub as hubTookit
from ningchao.nData import data

parser = argparse.ArgumentParser(prog = sys.argv[0],description='generate trackHub.txt from patter file', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('k', nargs='+', help ='key words for filter file split by "."')
parser.add_argument('-g', nargs='?', default = 'rheMac8', help ='genome for bw| rheMac8|mm10|mm9|hg19|hg38')
parser.add_argument('-p', nargs='?', help ='file prefix should different with other track', required = True )
parser.add_argument('-f', nargs='+',default=[], help ='fit arry for name pattern')
parser.add_argument('-group', nargs='?', default = '3', help ='group 1:1 2:3 3:5. this options for washu only')
parser.add_argument('-w', nargs='?', default = '.',help ='which directory you want to find bw files')
parser.add_argument('-t', choices = ['ucsc','washu'], help ='ucsc|[washu]', default = 'ucsc')
parser.add_argument('-it', choices = ['bb','bw','hic'], help ='bigBed|bw format', default = 'bw')
parser.add_argument('-sameColor', choices = [0,1,2,3,4], help ='set same color for the bw. pos for the label. \n0,all diff 1,peirod 2,region 3,marker 4,rep', default = 0, type = int )
parser.add_argument('-sort', nargs = '*',type = int, help ='sort key beyond samColor', default = [ 0 ] )
parser.add_argument('-ymax', help ='max y axis. for ucsc', default = '10')
parser.add_argument('-ylimit', help ='max y axis limit. for ucsc', nargs = '+', default = [ 0, 0, 10 ])
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    pattern, genome, fiter, trackType = args.k, args.g, args.f, args.it
    sort = args.sort
    if trackType == 'bb':
        trackType = 'bigBed'
    elif trackType == 'bw':
        trackType = 'bigWig'
    elif trackType == 'hic':
        trackType = 'hic'
    prefix = 'p' in args and args.p or '.'.join(pattern)
    marker, work_dir, group = copy.copy(pattern), args.w, args.group
    #this marker is lst object not show in short name
    marker= []
    return pattern, genome, fiter, trackType, sort, prefix, marker, work_dir, group, args.t


def main( hubType, colors ):
    if hubType == 'ucsc':
        print('\n'.join(hubTookit.hub( genome, prefix, work_dir, recursion = 0, ylimit = args.ylimit, sameColor = args.sameColor, sort = sort, trackType = trackType ).db(pattern,marker,fiter, inColor = colors)))
    elif hubType == 'washu':
        hub = os.path.abspath( os.path.join(work_dir, prefix+'.washu.hub') )
        fh = open(hub,'w')
        fh.write(hubTookit.washu(work_dir,group,pattern,marker,genome))
        print(hub)
        huburl = system.fl( hub ).link( ) 
        print(huburl)
        url = 'http://washu.lab/browser/?genome=%s&datahub=%s' % ('w' + genome, huburl)
        print(url)


if __name__ == '__main__':
    pattern, genome, fiter, trackType, sort, prefix, marker, work_dir, group, hubType  = parse( args )
    colors = data.data().color()
    main( hubType, colors)


