#!/usr/bin/env python
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('-i', nargs='?', help ='input file', default = 'rowDendrogram.txt')
parser.add_argument('-o', nargs='?', help ='output for geneName')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()



fh = open(args.i)
out = open(args.o,'w')
for line in fh:
	line_arr = line.strip().split('\"')
	for each in line_arr:
		if 'ENS' in each and 'value' not in each:
			out.write(each+'\n')


