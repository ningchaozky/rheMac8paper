#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'compare_combin', nargs = '?', help = 'two complex output raw cluster compare combinations')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



with open(args.compare_combin) as f :
    for line in f:
        line_arr = re.split(r'\s+', line )
        cmd = '''complex_heatmap_cluster_match_complex_heatmap_cluster_groups.py fc.xls.ClustOrder.raw {} -rawB /uDiskE/data/early_embryo/RNA/refseq/normal/mini.len.tpm.mean.mini.s0.ClustOrder.raw {}'''.format(line_arr[1].replace(',',' '), line_arr[2].replace(',',' '))
        print ( cmd )



























