#!/usr/bin/env python
import sys
import os


if len(sys.argv) <= 1:
	print(sys.argv[0],'read_1:file','read_2:file','length_of_AA/TT:int')
	exit()


reads_1 = open(sys.argv[1])
reads_2 = open(sys.argv[2])
length_of = int(sys.argv[3])
aaa = 'A'*length_of
ttt = 'T'*length_of
rd_1 = open('%s.fq' % sys.argv[1].replace('.fq','_need'),'w')
rd_2 = open('%s.fq' % sys.argv[2].replace('.fq','_need'),'w')


arr = []
x,y,z = -1,0,0
while 1:
	arr_for = []
	arr_rev = []
    	line_read_1 = reads_1.readline()
    	line_read_2 = reads_2.readline()
	x += 1
	if not line_read_1 or not line_read_2:
		break
	arr_for.append(line_read_1)
	arr_rev.append(line_read_2)
	for i in range(0,3):
		arr_for.append(reads_1.readline())
		arr_rev.append(reads_2.readline())
	arr_for_a = len(arr_for[1].split(aaa))
	arr_for_t = len(arr_for[1].split(aaa))
	arr_rev_a = len(arr_rev[1].split(ttt))
	arr_rev_t = len(arr_rev[1].split(ttt))
	if arr_for_a > 1 or arr_rev_a > 1:
		y += 1
		for each in arr_for:
			rd_1.write(each)
		for each in arr_rev:
			rd_2.write(arr_rev[i])
	if arr_for_t > 1 or arr_rev_t >1:
		z += 1
		for each in arr_for:
			rd_1.write(each)
		for each in arr_rev:
			rd_2.write(arr_rev[i])
sys.stdout.write('%s precent is:' % aaa)
sys.stdout.write('%s\n' % str(float(y)/x*100))
sys.stdout.write('%s precent is:' % ttt)
sys.stdout.write('%s\n' % str(float(z)/x*100))
sys.stdout.write('%s and %s precent is:' % (aaa,ttt))
sys.stdout.write('%s\n' % str(float(z+y)/x*100))

