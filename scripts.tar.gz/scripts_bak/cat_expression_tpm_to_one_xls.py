#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.parse as p
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='cat excl to one excl and change the title name to you need')
parser.add_argument('-xls', nargs='*', default = 'xo 3 ...', help ='js dir')
parser.add_argument('-T', action = 'store_true', help = 'same col ?, default = True')
parser.add_argument('-f', nargs='*', default = '', help = 'arry for delete word in title sf ...')
parser.add_argument('-o', nargs='?', default = 'merge.xls', help = 'same col ?, default = True')
exec(trickTookit.usage('parser'))
args = parser.parse_args()

col = 0
isforms,Infor = [],{}
excls = iter(args.xls)
for xls in excls:
	fh = open(xls)
	col = int(next(excls)) - 1
	name,lst2 = trickTookit.delList(xls.split('.'),args.f)
	name = '.'.join(name)
	if args.T :
		next(fh)
	for line in fh:
		line_arr = line.split('\t')
		isforms.append(line_arr[0])
		trickTookit.set2dict(Infor,name,line_arr[0],line_arr[col])
	fh.close()


isforms = trickTookit.uList(isforms,dEmpty = 'no')
print(list(Infor.keys()))

out = open(args.o,'w')
out.write('isform'+'\t'+'\t'.join(list(Infor.keys()))+'\n')
for isfor in isforms:
	line = []
	for each in list(Infor.keys()):
		if isfor in Infor[each]:
			line.append(Infor[each][isfor])
		else :
			line.append('0')
	out.write(isfor+ '\t' + '\t'.join(line)+'\n')

out.close()


