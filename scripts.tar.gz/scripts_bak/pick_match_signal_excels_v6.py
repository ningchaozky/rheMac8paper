#!/usr/bin/env python3
import os
import re
import sys
import argparse
import numpy as np
from ningchao.nSys import trick, system, fix
from collections import defaultdict

desc = '''last tab pick before match before'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs='+', help = 'excels with only one header and one index column. last table should be RNA')
parser.add_argument( '-fc', nargs='?', help = 'fold change at least', default = 2, type = float)
parser.add_argument( '-pick_use_name', nargs='?', help = 'bw|bam', default = 'bw|bam')
parser.add_argument( '-t', nargs='+', help = 'match 1 max the max with same period |prime 2. match 1 meaning only one is ok, all meaning must all match RNA expression', default = [ 'match', '1' ])
parser.add_argument( '-p', nargs='?', help = 'last RNA and pick the before as one maxstd|max|correspondence', default = 'correspondence')
parser.add_argument( '-sm', choices = ['max','keep','sum','maxstd'], help = 'same symbol pick method', default = 'sum')
parser.add_argument( '-tt', nargs = '+', help = 'debug symbol IL1RAP')
parser.add_argument( '-n1Cut', nargs = '?', help = 'cutoff define in script body', default = 1.0, type = float)
parser.add_argument( '-merge', nargs = '?', help = 'merge each line by as symbols by any string')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_span( lst, **kwargs):
    stages = [ system.dir.str_map_period( lst[i][0], pub = False) for i in range( 2 )]
    smax, smin = max(stages), min(stages)
    span = smax - smin
    return span


def smooth():
    header_length, new_tabs, intersect = defaultdict( int ), defaultdict( list ), set()
    for aOrb in kwargs.get('tabs'):
        for tab in kwargs.get('tabs')[aOrb]:
            with open( tab ) as f :
                tab_header, tab_fh = system.dir.fl_infor( f )
                peirods = [ system.dir.str_map_period(i) for i in tab_header if 'Not' not in system.dir.str_map_period(i) ]
                if not peirods :
                    print('Err: empty header:', tab, tab_header)
                    exit()
                header_length[tab] = peirods
    intersect = set.intersection(*map(set, header_length.values()))
    for aOrb in kwargs.get('tabs'):
        for tab in kwargs.get('tabs')[aOrb]:
            with open( tab ) as f :
                tab_header, tab_fh = system.dir.fl_infor( f )
                tmptab = open( fix.fix( tab ).append('tmp'), 'w')
                new_tabs[aOrb].append( tmptab.name )
                pos = []
                for i,v in enumerate( tab_header[1:] ):
                    if system.dir.str_map_period( v ) in intersect :
                        pos.append( i + 1 )
                print ( tab_header[0], *[ tab_header[j] for j in pos ], file = tmptab, sep = '\t')
                for line in tab_fh :
                    line_arr = line.rstrip().split('\t')
                    print ( line_arr[0], *[ line_arr[i] for i in pos ], sep = '\t', file = tmptab )
                tmptab.close()
    kwargs.update({'tabs': new_tabs })


def symbols_get_overlap( dit ):
    rout, prime = defaultdict( set ), defaultdict( set )
    before, last = split_dit_by_last_tab( dit )
    if 'prime' in args.t:
        #for max_period in system.dir.periods( prefrontal_raw = True ):
        for max_period in system.dir.sort( list(last.keys()) ):
            if max_period == 'E50' :
                continue
            #last tab max_period symbols
            #max_period_symbols = list( last[max_period].values() )
            #last_tab_max_period_symbols, before_periods_symbols = max_period_symbols[-1], []
            before_periods_symbols = []
            last_tab_max_period_before_periods = [ i for i in system.dir.get_before_periods(max_period, span = int(args.t[1])) if i in before.keys()]
            last_tab_max_period_symbols = last[max_period][kwargs.get('tabs')[-1]]
            print ( 'last tab max_period:', max_period, 'before_periods', *last_tab_max_period_before_periods, file = sys.stderr)
            for p in last_tab_max_period_before_periods:
                #for max_period_symbols_before in before[p]:
                    before_p_values = []
                    for tab in before[p]:
                        values = list( before[p][tab] )
                        print ( 'prime:', tab, max_period, p, len(values))
                        #before_periods_symbols.extend( values )
                        before_p_values.extend( values )
                    rout[ p ].update( set.intersection( set(before_p_values), last_tab_max_period_symbols) )
                    before_periods_symbols.extend( rout[ p ] )
                    print ( '{} period {} select num'.format( max_period, p), len(rout[ p ]))
            symbols = set.intersection( set(before_periods_symbols), last_tab_max_period_symbols )
            prime[ max_period ] = symbols
            print ( 'select:', max_period, len(symbols) )
        #prime symbols
        kwargs.update({'prime': prime })
    elif 'match' in args.t :
        print ( 'Use', args.t, file = sys.stderr )
        for max_period in dit :
            #intersection
            if '1' in args.t:
                before_union, after_union = set.union( *before[max_period].values() ), set.union( *last[max_period].values() )
                symbols = set.intersection( before_union, after_union )
            elif 'all' in args.t:
                before_intersection = set.intersection( *before[max_period].values() )
                after_intersection = set.intersection( *last[max_period].values() )
                symbols = set.intersection( before_intersection, after_intersection )
            elif '2' in args.t :
                print ( 'not write function for match 2', file = sys.stderr )
                exit()
            rout[ max_period ] = symbols
            print ( max_period, 'n1 cut get :', kwargs.get('cutoff').get('n1Cut'), len(symbols), file = sys.stderr )
    #last_output_symbols
    kwargs.update({'symbols': rout })
    return rout


def split_dit_by_last_tab( dit ):
    before, last, periods = defaultdict( dict ), defaultdict( dict ), system.dir.periods( prefrontal_raw = True )
    for period in dit :
        for tab in dit[period]:
            if tab in kwargs.get('tabs')['a']:
                last[period][tab] = dit[period][tab]
            elif tab in kwargs.get('tabs')['b'] :
                before[period][tab] = dit[period][tab]
            else :
                print ('Check {}, for not in tabs a and tabs b\n')
                exit()
    return before, last



def get_cut( fl, **kwargs):
    for key in kwargs.get('cutoff'):
        if key in fl :
            cutoff = kwargs.get('cutoff')[key] 
            print ( fl, 'cutoff {}: '.format(key), cutoff, file = sys.stderr)
            return cutoff
    return 0
def data_parse():
    infor, periods = defaultdict( lambda : defaultdict( list) ), system.dir.periods( prefrontal_raw = True)
    tabs = kwargs.get('tabs')
    for aOrb in tabs:
        for tab in tabs[aOrb]:
            cutoff = get_cut( tab, **kwargs)
            with open( tab ) as f :
                header = next(f).rstrip().split('\t')
                header_mapped = [ system.dir.str_map_period(i, raw = i) for i in header ]
                need_periods = [ i for i in header_mapped if i in periods ]
                kwargs.update({'need_periods': need_periods})
                fnum, whole_num = 0,0
                for line in f :
                    whole_num += 1
                    arr = line.rstrip().split('\t')
                    arr_sorted = sorted( [ float(i) for i in arr[1:] ] )
                    if not arr_sorted[-1] :
                        fnum += 1
                        continue
                    if arr_sorted[-1] < cutoff and arr_sorted[-2] < cutoff:
                        fnum += 1
                        #print ( 'fiter data:', tab, line, arr_sorted[-1], 'cut off max is small than', cutoff, file = sys.stderr )
                        continue
                    symbol = arr[0].split('.')[0].upper() if kwargs.get('merge') else arr[0]
                    #keep raw data for enhancer or multi find function
                    line_arr = line.strip().split('\t')
                    infor[ tab ][ symbol ].append( [ line_arr[0], *[ float(i) for i in line_arr[1:]] ])
                print ( 'fiter data:', fnum, whole_num, round(fnum/whole_num,4), whole_num-fnum , tab, 'by', cutoff, file = sys.stderr )
    #infor = rawTab_same_symbols_pick( infor )
    kwargs.update({'infor':infor})
    return infor


def infor_get_express():
    pass


def normalto1( signal_ordered ):
    scale,dmin = (signal_ordered[0][-1] - signal_ordered[-1][-1]), signal_ordered[-1][-1]
    n1Cut = kwargs.get('cutoff').get('n1Cut')
    #zi = (xi – min(x)) / (max(x) – min(x))
    signal_ordered_n1Cut = [ (i, v) for i,v in signal_ordered if (v - dmin) / scale >= n1Cut ]
    return signal_ordered_n1Cut

def raw_infor_get_max_symbols( infor ):
    symbols = defaultdict( lambda : defaultdict( set ) )
    for tab in infor :
        for symbol in infor[tab]:
            #multi line for same symbol can be transcripts or enhancer information split to differect cluster
            for signal in infor[tab][symbol]:
                order = dict( zip(kwargs.get('need_periods'), signal[1:] ))
                order = sorted( order.items(), key = lambda x: float( x[1] ), reverse = True)
                order_n1Cut = normalto1( order )
                for each in order_n1Cut:
                    period = each[0]
                    symbols[ period ][ tab ].add( symbol )
                    if args.tt and symbol in args.tt:
                        print ( tab, max_period, symbol in symbols[ max_period ][ tab ], order)
    return symbols
def main():
    #smooth files
    smooth()
    #same symbol name pick method default keep same with input
    infor = data_parse()
    symbols = raw_infor_get_max_symbols( infor )
    symbols = symbols_get_overlap( symbols )
    if 'prime' in args.t :
        #prime split get results
        pick_keep_pace_symbols_from_tabs( )
    elif 'match' in args.t :
        #pick_at_least_match()
        pick_keep_pace_symbols_from_tabs( )
    else :
        print ('Wrong intpu:', args.t, file = sys.stderr )

def tabs_get_overlap_rawdata( infor ):
    symbols = defaultdict( lambda : defaultdict( set) )
    symbols[ max_period ][ tab ].add( symbol )
    return symbols

def rawTab_same_symbols_pick( infor ):
    rout = defaultdict( lambda : defaultdict( list ) )
    print ( 'symbol same pick method:', args.sm, file = sys.stderr)
    if args.sm == 'keep':
        return infor
    elif args.sm in [ 'sum', 'max', 'maxstd' ]:
        for tab in infor:
            for symbol in infor[tab]:
                symbol_lines_values = [ [ float(j) for j in i.rstrip().split('\t')[1:] ] for i in infor[tab][symbol] ]
                if len( infor[tab][symbol] ) >= 2 :
                    if args.sm == 'sum':
                        symbol_lines_values = [[ sum(col) for col in zip( *symbol_lines_values) ]]
                    elif args.sm == 'max':
                        symbol_lines_values = [[ max(col) for col in zip( *symbol_lines_values) ]]
                    elif args.sm == 'maxstd':
                        symbol_lines_values_sorted_std = sorted( symbol_lines_values, key = lambda x: np.std( x ), reverse=False)[-1]
                        symbol_lines_values = [ symbol_lines_values_sorted_std ]
                line_format = '\t'.join( [ str(i) for i in symbol_lines_values[0] ] )
                rout[tab][symbol] = ['\t'.join([ symbol, line_format ])]
                if args.tt and symbol in args.tt:
                    print ( tab, rout[tab][symbol])
    return rout


def pick_at_least_match():
    print ('use: {} {}'.format(*args.t), file = sys.stderr)
    symbols, infor = [ kwargs.get(i) for i in ('symbols','infor')]
    #print RNA results 
    tab_print( kwargs.get('tabs')[-1], symbols )
    #pick correspondence results for same period difference from prime method but can use same function sort_between_tab
    #sort_between_tab( period, symbol, data, output_all, output_mini)
    #for tab in args.tabs:
    #    tab_print( tab, symbols )

#def pick_keep_pace_symbols_from_tabs():
#    symbols, infor = kwargs.get('symbols'), kwargs.get('infor')


def pick_output( typ, tabs):
    symbols, infor = kwargs.get('symbols'), kwargs.get('infor')
    symbols_sorted_periods = system.dir.sort( list(symbols.keys()) )
    outputfile = open('{}_merge_files.{}{}'.format( typ, *args.t), 'w')
    outputfile_mini = open('{}_merge_files.{}{}.mini'.format( typ, *args.t), 'w')
    if 'before' in typ:
        print ( *kwargs.get('header_a'), file = outputfile_mini, sep = '\t')
    elif 'after' in typ :
        print ( *kwargs.get('header_b'), file = outputfile_mini, sep = '\t')
    for period in symbols_sorted_periods:
        for symbol in symbols[period]:
            symbol_datas = []
            for tab in tabs:
                    for each in infor[tab][symbol]:
                        symbol_datas.append( [ tab, each ] )
                    sort_output = sort_between_tab( period, symbol, symbol_datas, outputfile, outputfile_mini  )
    outputfile.close()
    outputfile_mini.close()
    system.run('''awk '!x[$1]++' {} > tmp1fa; mv tmp1fa {}'''.format(outputfile_mini.name, outputfile_mini.name), shell = True)

def pick_keep_pace_symbols_from_tabs():
    print ('pick_keep_pace_symbols_from_tabs', file = sys.stderr)
    before_tabs, after_tabs = kwargs.get('tabs')['a'], kwargs.get('tabs')['b']
    #if 'prime' in kwargs:
    #    tab_print( last_tab, kwargs.get('prime') )
    #    #tab_print( last_tab, symbols )
    #else :
    #    tab_print( last_tab, symbols )
    pick_output( 'before', before_tabs )
    pick_output( 'after', after_tabs )

def sort_between_tab( period, symbol, data, output_all, output_mini):
    if args.p == 'correspondence':
        header = kwargs.get('header')
        same_periods, symbol = [], ''
        for each in data :
            #symbol_name uniq for each tab, but maybe not bewteen period
            tab = each[0]
            tab_data = each[1]
            each_dit = dict( zip(header[1:], tab_data[1:]))
            #same_periods[tab].append( each[2:] )
            tab_sort_by_max_signal = sorted( each_dit.items(), key = lambda x: x[1], reverse=False)
            tab_max_period = system.dir.str_map_period( tab_sort_by_max_signal[-1][0] )
            if args.tt and symbol in args.tt :
                print ( arr, tab_max_period, period )
            if tab_max_period == period:
                print ( tab, *tab_data, tab_max_period, sep = '\t', file = output_all)
                same_periods.append( [ tab, *tab_data] )
        if len( same_periods ) >= 2 :
            same_periods_sorted = sorted( same_periods, key = lambda x: np.std( x[ 2 : -1 ] ) )
            print( *same_periods_sorted[ -1 ][1:], sep = '\t', file = output_mini )
        elif len(same_periods) == 1 :
            print ( *same_periods[0][1:], sep = '\t', file = output_mini )
        else :
            err_str = '\t'.join([ symbol, 'not file same with {}'.format(kwargs.get('tabs')[-1])]).strip()
            if err_str not in kwargs.get('err'):
                print ( err_str, file = sys.stderr)
                kwargs.get('err').add( err_str )
    elif args.p in [ 'maxstd', 'max' ]:
        if args.p == 'maxstd':
            arr = sorted( arr, key = lambda x: np.std( x[2:] ), reverse=False)
        elif args.p == 'max':
            arr = sorted( arr, key = lambda x: max( x[2:] ), reverse=False )
        return arr[-1]

def check_header():
    tabs_length = defaultdict( list )
    for aOrb in kwargs.get('tabs'):
        for fl in kwargs.get('tabs')[aOrb]:
            print ( fl, file = sys.stderr )
            with open( fl ) as f :
                header = next(f).rstrip().split('\t')
                kwargs.update({ 'header_{}'.format(aOrb): header })
                kwargs.update({ 'header': header })
                tabs_length[fl].extend( [ len(header), header ] )
    tabs_length_sorted = sorted( tabs_length.items(), key = lambda x: x[1][0], reverse=False)
    lengths = set([ i[1][0] for i in tabs_length_sorted ] )
    if len( lengths ) != 1 :
        print ( 'Must same length....', file = sys.stderr )
        print ( tabs_length_sorted, file = sys.stderr )
        exit()
    else :
        print ( '!!!chekc header pass: ', kwargs.get('header'), file = sys.stderr )
def tab_print( tab, symbols):
    #use symbols and infor in kwargs
    infor = kwargs.get('infor')
    symbols_sorted_periods = system.dir.sort( list(symbols.keys()) )
    with open( tab ) as f:
        keep_all = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_all'.format( args.t[0], args.sm, *args.t), 'w')
        keep_one_noCluster = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_one.noCluster'.format( args.t[0], args.sm, *args.t), 'w')
        keep_one = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_one'.format( args.t[0], args.sm, *args.t), 'w')
        header = next(f).rstrip().split('\t')
        print ( *header, 'cluster', sep = '\t', file = keep_all)
        print ( *header, 'cluster', sep = '\t', file = keep_one)
        print ( *header, sep = '\t', file = keep_one_noCluster)
        for period in symbols_sorted_periods:
            for symbol in symbols[period]:
                rna_tab = kwargs.get('tabs')[-1]
                multi_pick_period_match( period, infor[tab][symbol], keep_all, keep_one, keep_one_noCluster )
        keep_all.close()
        keep_one.close()
        keep_one_noCluster.close()
def multi_pick_period_match( period, data, keep_all, keep_one, keep_one_noCluster):
    header = kwargs.get('header')
    lst = []
    i = 0
    for each in data:
        edit = dict(zip(header[1:], each[1:]))
        esorted = sorted( edit.items(), key = lambda x:x[1] )
        emax_period = system.dir.str_map_period( esorted[-1][0] )
        if emax_period == period :
            #one is ok for go and another analysis
            e_no_cluster = '\t'.join( map(str, each) )
            e_str = '\t'.join( [ e_no_cluster, period ] )
            i += 1
            if i == 1 :
                print ( e_str, file = keep_one)
                print ( e_no_cluster, file = keep_one_noCluster)
            print ( e_str, file = keep_all)
            lst.append( e_str )

def get_two_groups():
    tabs = kwargs.get('tabs')
    a, b, marker = [], [], True
    if len( tabs ) == 1 :
        with open( tabs[0] ) as f :
            for line in f :
                line = line.rstrip()
                if line == 'split':
                    marker = not marker
                    continue
                a.append( line ) if marker else b.append( line )
        kwargs.update({'tabs': {'a': a, 'b': b }})
    if marker and not len(kwargs.get('tabs').get('b')) :
        kwargs['tabs']['b'] = kwargs['tabs']['a'].pop(-1)


if __name__ == '__main__':
    kwargs = vars( args )
    kwargs.update( {'log': False, 'periods_sorted': system.dir.periods( prefrontal_raw = True )} )
    #n1Cut set 1.0 for max pick default 0.8
    kwargs.update({'err':set(), 'cutoff':{'mean': 0.5, 'max': 3, 'median': 0.5, 'sum': 6, 'RNA': 0.5, 'n1Cut': args.n1Cut }})
    #file mode for tabs check 
    get_two_groups()
    check_header()
    main()





















