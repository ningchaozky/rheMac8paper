#!/usr/bin/env sh
if [ $# -lt 1 ]; then
	echo $0 'userhttpdirbind'
	exit
fi



mount /dev/sdg1 /home/
source /home/ningch/.bashrc
mount /dev/sdb3 /dataB/
mount /dev/sdf1 /dataE/
mount --bind /home/xiwu/wuxi/data /home/washU/pub/xiwu/
mount --bind /home/ningch /home/washU/pub/ningch_home
#mount --bind /home/yuanshl/ /home/washU/pub/yuanshl
#mount --bind	/home/ningch/yaoxl	/dataB/ftp/yaoxl
#mount --bind	/home/washU/pub/jsj	/dataB/ftp/jsj
#mount --bind	/home/washU/pub/wangjm	/dataB/ftp/wangjm
mount /dev/sdb3 /dataB
mount --bind /dataB/ftp/pub/ /home/washU/pub/pub
mount /dev/sdf1 /dataE
mount --bind /dataE/rawdata/rheMac/hic/ /home/washU/pub/hic
mount --bind /dataE /home/washU/pub/dataE
mount --bind /dataB/ftp/pub/rheMac3/ /home/washU/pub/ningch_dataB
systemctl restart httpd
systemctl restart mariadb
systemctl restart vsftpd
#mount --bind /dataE/rawdata/rheMac/hic/E80R1/prefrontal_corte /dataB/ftp/pub/rheMac3/E80/prefrontal/hic/R1
#mount --bind /dataE/rawdata/rheMac/hic/E80R2/prefrontal_corte /dataB/ftp/pub/rheMac3/E80/prefrontal/hic/R2

