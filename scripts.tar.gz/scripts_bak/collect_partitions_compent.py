#!/usr/bin/env python
import sys
import os

if len(sys.argv) <2:
	print('Usage:',sys.argv[0],'read_partitions', end=' ')
	exit(1)



dir_list = os.listdir(sys.argv[1])
file_abs = os.path.abspath(sys.argv[1])
dir_list = sorted(dir_list)
for dir in dir_list:
	abs_dir = os.path.join(file_abs,dir)
	os.chdir(abs_dir)
	part_dir_list = os.listdir(abs_dir)
	part_dir_list = sorted(part_dir_list)
	for trinity_out in part_dir_list:
		work_dir = os.path.join(abs_dir,trinity_out)
		os.chdir(work_dir)
		file_list = os.listdir(work_dir)
		file_list = sorted(file_list)
		for fasta in file_list:
			if fasta.endswith('trinity.reads.fa.out.Trinity.fasta'):
				fa = open(fasta)
				for line in fa:
					if line.startswith('>'):
						print('>'+fasta.replace('.trinity.reads.fa.out.Trinity.fasta','_')+line.replace('>c0_',''), end=' ')
					else:
						print(line, end=' ')
				fa.close()
	


