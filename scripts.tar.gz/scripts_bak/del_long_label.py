#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from tempfile import NamedTemporaryFile
from ningchao.nSys import trick, system

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help ='ucsc hubTrick with long lable')
parser.add_argument('-t', choices=[ 'del_long_label', 'addMarker'], help ='ucsc hubTrick with long label | addMarker name to the short')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    fdir = args.dir
    fls = system.dir(fdir).fls(pattern='Db.txt')
    return list(fls), args.t

def del_long_label( fls ):
    for fl in fls:
        ofh = open('/tmp/%s.tmp' % os.path.basename( fl ), 'w')
        fh = open( fl )
        for line in fh:
            if 'longLabel' in line and 'bw' in line:
                line_arr = line.split(' ')
                line = line_arr[0] + '     \n'
            ofh.write(line)
        ofh.close()
        cmd = 'mv %s %s' % (ofh.name, fl)
        print(cmd)

def addMarker( fls ):
    for fl in fls:
        fh = open( fl )
        ofh = NamedTemporaryFile(prefix=os.path.basename( fl ), suffix='.txt', dir='/tmp', delete = False )
        for line in fh:
            if 'shortLabel' in line and 'shortLabel separater' not in line and 'shortLabel multi' not in line:
                lst, lst2 = [], [ line ]
                name = ''
                for i in range( 3 ):
                    try :
                        iline = next(fh)
                        if 'bigDataUrl' in iline:
                            name = iline.split('/')[-1].replace('.ppois.bw','')
                        lst.append( iline )
                    except :
                        pass
                if name :
                    lst.insert( 0, '\tshortLabel %s' % name )
                else :
                    lst.insert( 0, line )
                if [ i for i in lst if 'bigDataUrl' in i ]:
                    ofh.write( ''.join( lst ) )
                else :
                    ofh.write( ''.join( lst2 ) )
            else :
                ofh.write( line )
        ofh.close()
        cmd = 'mv %s %s' % (ofh.name, fl)
        print(cmd)



if __name__ == '__main__':
    fls, typ = parse( args )
    if typ == 'del_long_label':
        del_long_label( fls )
    elif typ == 'addMarker':
        addMarker( fls )























