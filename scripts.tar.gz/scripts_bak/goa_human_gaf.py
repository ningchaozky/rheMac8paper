#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from Bio.UniProt.GOA import gafiterator, record_has
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('gaf', nargs='?', help = 'gaf file for parse')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

gfh, infor = open( args.gaf ), {}
for rec in gafiterator( gfh ):
    Synonym, GO_ID = rec['Synonym'], rec['GO_ID']
    trick.dinit( infor, GO_ID, Synonym )
for key in infor:
    print(key, infor[key])
#print trick.dit(infor).rev( valType = 'list' )





























