#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = '''name_rep1 name_rep2 will be mean'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help = 'matrix for use')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def parse( args ):
    return args.mat

def get_pos( matrix ):
    fh, pos = open( matrix ), {}
    header = fh.next().split('\t')
    name = [ i.split('rep')[0].strip('.') for i in header ]
    keys = trick.lst( name ).uniq()
    for key in keys:
        trick.dinit( pos, key, trick.lst( name ).index( key ))
    return pos, fh 

def main( ):
    pos, fh = get_pos( matrix )
    samples = list(pos.keys())
    samples.sort()
    trick.write( samples )
    for line in fh:
        line_arr = line.rstrip().split('\t')
        line_arr[1:] = [ float(i) for i in line_arr[1:] ]
        sample_vals = []
        for key in samples:
            vals = trick.lst( line_arr ).get( pos[key] )
            if len( vals ) == 1:
                sample_vals.append( vals[0] )
            else :
                sample_vals.append( sum( vals )/ len( vals ) )
        trick.write( sample_vals )
if __name__ == '__main__':
    matrix = parse( args )
    main( )
























