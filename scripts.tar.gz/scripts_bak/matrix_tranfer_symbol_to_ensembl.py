#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs='?', help = 'mat')
parser.add_argument('gtf', nargs='?', help = 'gtf')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def gtf_to_dict():
    infor = defaultdict( list )
    with open( args.gtf ) as f :
        for line in f :
            if line.startswith('#'):
                continue
            line_arr = line.strip().split('\t')
            if line_arr[2] == 'gene':
                attr = line_arr[8].strip().replace('\"','')
                dit = defaultdict( str )
                for each in attr.split(';'):
                    if not each.strip():
                        continue
                    arr = each.strip().split(' ')
                    if len(arr) == 2 :
                        k, v = each.strip().split(' ')
                        dit[k] = v
                    else :
                        print ( each )
                infor[dit['gene_name']].append( dit['gene_id'] )
    print ( 'gene_name number: ', len(infor ), file = sys.stderr)
    return infor

if __name__ == '__main__':
    infor = gtf_to_dict()
    omat = open( fix.fix( args.mat ).append('ensembl'), 'w')
    with open( args.mat ) as f :
        print ( 'gene_id', 'gene_name', next(f).strip(), sep = '\t', file = omat )
        for line in f:
            line_arr = line.strip().split('\t')
            if 'ENSMU' in line_arr[0]:
                line_arr[0] = '\t'.join([line_arr[0], line_arr[0]])
                print ( *line_arr, sep = '\t', file = omat)
                continue
            else :
                line_arr[0] = line_arr[0].replace('\"','')
                if line_arr[0] in infor:
                    ensembl_id = infor[line_arr[0]][0]
                    line_arr[0] = '\t'.join([ensembl_id, line_arr[0]])
                    print ( *line_arr, sep = '\t', file = omat)
                else :
                    print ( line_arr[0], infor.get(line_arr[0]), file = sys.stderr )






















