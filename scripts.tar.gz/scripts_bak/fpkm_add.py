#!/usr/bin/env python 
import sys
import os


if len(sys.argv) <= 1:
	print("Usage:",sys.argv[0],"Gr6,Gr20... 2-26 xls\n\tNote: Gr6 is your need")
	exit()

xls = open(sys.argv[-1])
names = sys.argv[1].split(',')
scope = sys.argv[2].split('-')



i,j = 0,0

for line in xls:
	tmp = line.split('\t')
	i += 1
	if i == 1:
		add = [0 for i in range(len(tmp))]
		add[0] = names[0]
	if tmp[0] == names[0]:
		add[int(scope[-1]):] = tmp[int(scope[-1]):]
	if tmp[0] in names:
		for j in range(int(scope[0])-1,int(scope[-1]),1):
			add[j] += float(tmp[j])
	else:
		print(line, end=' ')
for each in add:
	print(each, end=' ')
