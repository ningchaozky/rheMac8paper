#!/usr/bin/env python3
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
from ningchao.nBio import chromosome
from ningchao.nSys import trick, system, alluvial
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs='?', help = 'dir for deal the beds')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def out_put( ):
    chroms, fhs = chromosome.chr( 'rh8', sexX = True ).chr, {}
    for chrom in chroms:
        trick.dinit( fhs, chrom, open('.'.join([chrom, 'xls']), 'w') )
        join( [ 'period', 'pos', 'stat', 'num' ], fhs[ chrom ] )
    return fhs

def get_infor( directory, fhs):
    fls = list ( system.dir( directory ).fls('12_segments.bed') )
    for fl in fls:
        sys.stderr.write( fl +'\n')
        peirod = os.path.basename( fl ).split('_')[0]
        fh = open( fl )
        for line in fh:
            line_arr = line.strip().split('\t')
            chrom, start, end = line_arr[0], int( line_arr[1] ) // 200, int( line_arr[2] ) // 200
            typ = line_arr[-1]
            for i in range( start, end ):
               join( [ peirod, '.'.join( [chrom,str(i)] ), typ, '1'], fhs[chrom] )

def join( lst, fh ):
    fh.write( '\t'.join( lst ) + '\n' )

if __name__ == '__main__':
    fhs = out_put( )
    get_infor( args.dir,  fhs )
    

























