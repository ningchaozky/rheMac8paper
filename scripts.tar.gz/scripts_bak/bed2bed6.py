#!/usr/bin/env python3
import os
import sys
import importlib
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed to bed6')
parser.add_argument('-win', action='store_true', help ='write back to the source file')
parser.add_argument('-msep', nargs='?', help ='more than 3 columns paste together', default = '|')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

bed, win, msep = args.bed, args.win, args.msep
tfh = open( bed + '.bed6', 'w' )
for line in open( bed ):
    larr = []
    line_arr = line.strip('\n').split('\t')
    line_arr[3] = msep.join( line_arr[3:])
    larr = line_arr[0:4]
    larr.append( '0' )
    larr.append( '+' )
    trick.write( larr, tfh )
tfh.close()

if win :
    os.system('mv %s %s' % ( tfh.name, bed ) )




























