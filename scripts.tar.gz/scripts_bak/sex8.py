#!/usr/bin/env python
#-*- coding:UTF-8 -*-
import os
import sys
import ssl
import chardet
import argparse
import urllib2 as url
import urllib.request, urllib.parse, urllib.error
import base64
import requests
import ningchao
from ningchao.nSys import trick,html
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit
from bs4 import BeautifulSoup as bs
import importlib

importlib.reload(sys)  
sys.setdefaultencoding('utf8')   
ssl._create_default_https_context = ssl._create_unverified_context

parser = argparse.ArgumentParser(prog = sys.argv[0] + '\n' ,description='\n')
parser.add_argument( 'html', nargs='?', help ='www?' )
parser.add_argument( '-p', nargs='?', type = int, help ='pages', default = 5 )
parser.add_argument( '-t', choices = ['Boutique','EthnicChinese','Asian','EuropeAndAmerica'], nargs = '*', help ='download type' )

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def prepare( args ):
    package_path = ningchao.__path__[0]
    data = os.path.join(package_path,'nData','sex8.data')
    strings = open(data).readlines()
    for each in strings:
        exec(each.strip())
    typs = args.t
    if typs:
        fst = trick.dit(dit).get(typs)
    else :
        fst = list(dit.values())
        typs = list(dit.keys())

    html_obj = html.html( dynamic = False  )
    header = html_obj.header('ningchaozky', 'Lijing1011')
    pages = [ str(i+1) for i in range(int(args.p)) ]
    return fst, pages, typs, times, dit


def htmls( fst, pages, dit):
    for form in fst:
        for pg in pages:
            each = form.replace('-1','-' + pg) + '?&topicsubmit=yes'
            each = deal_id( each )
            sys.stderr.write( '#' + each +'\n' )
            yield trick.dit(dit).rev()[form], each


def deal_id( url_id ):
    submit_string = '&topicsubmit=yes'
    prefix = args.html.strip('/').split('/')[0:3]
    if 'https' not in url_id :
        prefix.append(url_id)
        url_id = '/'.join( prefix )
    if submit_string not in url_id:
        if '?' in url_id:
            url_id += submit_string
        else :
            url_id += '?' + submit_string
    return url_id

def hrefs( url_id ):
    url_id, name = deal_id( url_id ), ''
    sys.stderr.write('#deal link: %s\n' % url_id)
    request =  url.Request( url_id, headers = html.html( dynamic = False ).header() )
    bso = bs(url.urlopen( request ).read(), 'html.parser')
    print(url_id)
    #bso = bs( requests.get(url_id, verify = False ), 'html.parser')
    try :
        name = bso.title.text.split('-杏吧')[0].split('【')[0].strip()
        for link in bso.find_all('a'):
            yield link, name
    except :
        print(bso.title)
        yield '',''

def rank_normal( xml ):
    rk,nor = [], []
    for href, name in hrefs( xml ):
        txt = href.get('href')
        if txt != None and 'thread' in txt and href.parent.name in ['td','li'] and href.parent.get('width') == None :
            img = href.parent.find_all('img')
            if img and ( img[0].get('src').endswith('jpg') or img[0].get('src').endswith('png') ) :
                if href.get( 'target' ):
                    rk.append(txt)
                    sys.stderr.write('#deal top rank download: %s in %s\n' % (txt, xml) )
                else :
                    nor.append(txt)
                    sys.stderr.write('#deal normal download: %s in %s\n' % (txt, xml) )
    return nor,rk

def text_get( href ):
    finds = ['p','em']
    for find in finds:
        for each in href.parent.parent.parent.find_all( find ):
            text = each.text
            if '下载次数' in text:
                return each.text
    return False
def down_load_infor( href ):
    down_load_txt =  text_get( href )
    #down_load_txt = href.parent.em.text.decode(encoding='UTF-8', errors='strict')
    down_load_times = int( down_load_txt.strip().split(' ')[ -1 ].replace(')','') )
    return down_load_txt, down_load_times

def download( xmls, time):
    dit = {}
    for xml in xmls:
        for href, name in hrefs( xml ):
            if 'torrent' in href.text:
                down_load_txt, down_load_times = down_load_infor( href )
                sys.stderr.write('#pick file: %s %s\n' % (href.text.encode('utf-8'), down_load_txt.encode('utf-8')))
                download_times = int(down_load_txt.strip().split('下载次数:')[-1].strip().strip(')'))
                torrent_name = name.strip() + '.torrent'
                if os.path.exists(os.path.join(os.path.abspath('.'), torrent_name.encode('utf-8'))) :
                    sys.stderr.write( 'Exists %s, ignore it\n' % torrent_name.encode('utf-8') )
                    continue
                if download_times > time :
                    cmd = 'wget -O \"%s\" \'%s\' --no-check-certificate --timeout=20' % ( torrent_name, deal_id( href.get('href') ) )
                    sys.stderr.write( cmd.encode('utf-8') + '\n' )
                    os.system( cmd )
                else :
                    sys.stderr.write( '%d no more than %d, ignore it\n' % (download_times, time) )
         

if __name__ == '__main__':
    fst, pages, typs, times, dit = prepare( args )
    for typ,xml in htmls( fst, pages, dit):
        time = times[typ]
        nor, rk = rank_normal( xml )
        torrents = download( rk, time )
        download( nor, time)
    



