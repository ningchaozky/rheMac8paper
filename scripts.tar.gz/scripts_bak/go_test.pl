#!/usr/bin/perl
###############################################################################
# read in 
#   * (pmid gene GO) predicting results from file
#   * (pmid gene GO) golden standard results from file
# calculate Precision, Recall and F measure (hF measure) and write 
#   * (Precision, Recall, F1) to STDOUT
###############################################################################
use warnings;
use strict;
use Encode;
require 'Data/Dumper.pm';
require 'GO/Parser.pm';
use GO::Parser;

#------------------------------------------------------------------------------
# globals
#------------------------------------------------------------------------------
my $enc = 'utf-8';
my $evalFile;
my $resultFile;
my $metrics;
my $N_REC  = 1000;
my $N_EVAL = 20000000;

my %relevant = ();
my $totalgo = 0.0;

my $hit = 0;
my $totalpredict = 0.0;

#------------------------------------------------------------------------------
# main
#------------------------------------------------------------------------------

# get file names
if( $#ARGV != 2  ) {
    print STDERR "Usage: $0 <result file name> <test data file name> <0: using standard metrics or 1: using hierarchical metrics>\n";
    exit;
} else {
    $resultFile = $ARGV[0];
    $evalFile = $ARGV[1];
    $metrics = $ARGV[2];
}

my $parser = new GO::Parser({handler=>'obj'}); # create parser object
my $graph;
if($metrics==1){
    print "\rPlease wait, loading GO ontology file...\n";
    $parser->parse("gene_ontology_ext.obo"); # parse file -> objects
    $graph = $parser->handler->graph;  # get L<GO::Model::Graph> object
    print "\rThanks for waiting\n";
}

# read in evaluation data
open(EVALFILE, "$evalFile") or die "Could not open $evalFile\n";
my @alllines = ();
while(<EVALFILE>) {
    my $inputline = trim($_);
    $inputline = decode($enc, $inputline);   # utf-8 upper case 
    $inputline = encode($enc, uc($inputline));
    my $len = rindex $inputline."\$", "\$";
    if($len > 1){
        push(@alllines, $inputline);
    }
}
push(@alllines, "END N N");
close(EVALFILE);
my $pmidGene = "";
my @values = ();
foreach my $i (0..$#alllines){
    my @input = split(/ /, $alllines[$i]);
    if(@input!=3){
         print STDERR "INCORRECT FORMAT: at line $alllines[$i]\n";
    }
    my $pg = $input[0].$input[1];
    if($pmidGene eq $pg){
        push(@values, $input[2]);
    }
    else{
       if($metrics==1){
          my @allvalues = ();
          foreach my $value (@values) {
              push(@allvalues, $value);
              my $term = $graph->get_term($value);   # fetch a term by ID
              my $ancestor_terms = $graph->get_recursive_parent_terms($term->acc);
              foreach my $anc_term (@$ancestor_terms) {
                  push(@allvalues, $anc_term->acc);
              }
          }
	  my %seen = ();
	  my @unique = grep {! $seen{$_} ++} @allvalues;
	  $relevant{$pmidGene}=\@unique;
	  $totalgo += @unique;
       }
       else{
	  my @vs = @values;
	  $relevant{$pmidGene}=\@vs;
	  $totalgo += @values;
       }
       $pmidGene = $pg;
       @values = ();
       push(@values, $input[2]);
   }
}

# read in predicting results
open(RESULTFILE, "$resultFile") or die "Could not open $resultFile\n";
my @inputlines = ();
while(<RESULTFILE>) {
    my $inputline = trim($_);
    $inputline = decode($enc, $inputline);   # utf-8 upper case 
    $inputline = encode($enc, uc($inputline));
    my $len = rindex $inputline."\$", "\$";
    if($len > 1){
        push(@inputlines, $inputline);
    }
}
push(@inputlines, "END N N");
close(RESULTFILE);
my $ppmidGene = "";
my @pvalues = ();
my @extvalues = ();
my %duplCheck = ();                    # prevent duplicate predictions
foreach my $j (0..$#inputlines){
    my @input = split(/ /, $inputlines[$j]);
    if(@input!=3){
         print STDERR "INCORRECT FORMAT: at line $inputlines[$j]\n";
    }
    if($ppmidGene eq ($input[0].$input[1])){
         push(@pvalues, $input[2]);
    }
    else{
         # calculate average precision for relevant predicted GOs
         foreach my $i (0..min($#pvalues, $N_REC-1)) {
	    my $value = $pvalues[$i];
	    if($metrics==1){
                push(@extvalues, $value);
                my $term = $graph->get_term($value);   # fetch a term by ID
                if($term){
                my $ancestor_terms = $graph->get_recursive_parent_terms($term->acc);
                foreach my $anc_term (@$ancestor_terms) {
                    push(@extvalues, $anc_term->acc);
                }
                }
	    }
            else{ 
                $totalpredict += 1.0;
            }
        my $pmidgenevalue = $ppmidGene.$value;
	    if (defined($duplCheck{$pmidgenevalue})) {
	        print STDERR "DUPLICATE PREDICTION: $value at position ".($i+1)." (first occurrence at $duplCheck{$pmidgenevalue}) for pmid gene $ppmidGene\n";
	        next;
	    }
            if($metrics==0){
	        if (exists $relevant{$ppmidGene}){
                   foreach my $evalvalue (@{$relevant{$ppmidGene}}) {
                      if($evalvalue eq $value) {
	                  $duplCheck{$pmidgenevalue}=$i+1;
	                  $hit++;
	                  last;
                      }
                   }
                }
	    }
         }

         if($metrics==1){
	    my %seen = ();
	    my @uniquext = grep {! $seen{$_} ++} @extvalues;
            $totalpredict += @uniquext;
            foreach my $extvalue (@uniquext) {
	        if (exists $relevant{$ppmidGene}){
	                my $index = 0;
                    foreach my $evalvalue (@{$relevant{$ppmidGene}}) {
                       if($evalvalue eq $extvalue) {
                          $hit++;
                          splice(@{$relevant{$ppmidGene}},$index,1);
                          last;
                       }
                       $index++;
                    }
                }
            }
         }
         $ppmidGene = $input[0].$input[1];
         @pvalues = ();
         push(@pvalues, $input[2]);
         @extvalues = ();
    }
    # sanity check: no one should get more than N_EVAL hits!
    if ($hit>$N_EVAL) {
	die "ERROR IN EVALUATION: cnt=$hit > N_EVAL=$N_EVAL for user $pmidGene\n";
    }
}

my $Precision = 0.0;
if($totalpredict!=0){
    $Precision = $hit/$totalpredict;
}
my $Recall = 0.0;
if($totalgo!=0){
    $Recall = $hit/$totalgo;
}

my $F1 = 0.0;
if($Precision+$Recall>0){
    $F1 = 2*$Precision*$Recall/($Precision+$Recall);
}

printf "Precision: %5.3f \tRecall: %5.3f \tF1: %5.3f\n", $Precision, $Recall, $F1;

sub trim {
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}
sub min { $_[$_[0] > $_[1]] }
