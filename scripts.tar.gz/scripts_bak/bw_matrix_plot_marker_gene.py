#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import datetime
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns;sns.set(color_codes=True)
from ningchao.nSys import trick, excel
example = '''bw_matrix_insert_gene.py output and marker gene list plot boxplot'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('matrix', nargs='?', help = 'bw_matrix_insert_gene.py output matrix data' )
parser.add_argument('-marker', nargs='+', help = 'marker gene you want to plot' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def parse(args):
    matrix, marker = args.matrix, args.marker
    mtcol = excel.xls(matrix).header.index('gene')
    mrcol = 0
    return matrix,mtcol,marker[0],mrcol

def marker2dit(marker_file,mrcol):
    fh,infor = open(marker_file), {}
    for line in fh:
        line_arr = line.strip().split('\t')
        if len(line_arr) == 2:
            keys = line_arr[1].split(',')
            for key in keys:
                key_arr = key.split('-vs-')
                assert len(key_arr) == 2
                key = key_arr[0].capitalize()
                trick.dinit(infor,key,[])
                if line_arr[0] not in infor[key]:
                    infor[key].append(line_arr[0])
        else :
            sys.stderr.write('Ignore this line: %s' % line )
    return infor

def matrix2dit(matrix, mtcol):
    fh, infor = open( matrix ), {}
    for line in fh :
        line_arr = line.strip().split('\t')
        gene = line_arr[mtcol].split('.')[0].upper()
        trick.dit(infor).set(gene,[])
        infor[gene].append(line)
    return infor


def max_std(lst):
    header, out, std_dit, genes, out1 = [], [], {}, [], []
    for line in lst:
        line_arr = line.strip().split('\t')
        if 'gene' in line:
            header = line_arr
        else :
            gene = line_arr[3].split('.')[0]
            trick.dinit(std_dit, gene,[])
            std = round( np.std(np.array([ float(i) for i in line_arr[5:] ])), 3 )
            std_dit[gene].append( std )
    for line in lst:
        line_arr = line.strip().split('\t')
        if 'gene' in line:
            out = [line]
        else :
            std = round( np.std(np.array([ float(i) for i in line_arr[5:] ])), 3 )
            gene = line_arr[3].split('.')[0]
            if std == max(std_dit[gene]) and gene not in genes:
                out.append(line)
                genes.append( gene )
    for each in out:
        e_arr = each.split('\t')
        line = [ e_arr[3].split('.')[0]]
        line.extend(e_arr[5:])
        out1.append('\t'.join(line))
    return out1


def plot(tab, prefix):
    fh = open(tab)
    infor = {}
    header = fh.next().strip().split('\t')[5:]
    header.insert(0,'gene')
    for line in fh:
        line_arr = line.strip().split('\t')
        gene = line_arr[3].split('.')[0]
        values = [ round( float(i), 4 ) for i in line_arr[5:] ]
        dit = dict(list(zip(header, values)))
        for key in dit:
            trick.dit(infor).set(key,[])
            infor[key].append(dit[key])
            infor[key].insert(0, gene)
    fh.close()
    data = pd.DataFrame.from_dict(infor)
    id_vars = list(data.columns[[0]])
    melt = pd.melt(data,id_vars = id_vars)
    ax=sns.boxplot(x='variable',y='value',data = melt)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=30)
#    plt.ylim((0, args.y))
    plt.savefig((prefix + '.pdf'), format='pdf')


if __name__ == '__main__':
    matrix,mtcol,marker,mrcol = parse(args)
    nowTime = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M')
    markers = marker2dit(marker,mrcol)
    edit = matrix2dit(matrix,mtcol)
    matrix_header = excel.xls(matrix).header
    for typ in markers:
        fl = '.'.join([typ,nowTime,'tab'])
        prefix = '.'.join([typ,nowTime])
        fh = open( fl, 'w')
        lst = ['\t'.join(matrix_header) + '\n']
        for gene in markers[typ]:
            if gene in edit:
                lst.extend(edit[gene])
        lst = max_std( lst )
        fh.write(''.join( lst ))
        fh.close()















