#!/bin/bash
help()
{
    echo "Usage: $0 preDMS [ -n | --span ]
               [ -o | --outputdir ]
               [ -h | --help  ]"
    exit 2
}
SHORT=n:,o:,h
LONG=span:,outputdir:,help
OPTS=$(getopt -a -n weather --options $SHORT --longoptions $LONG -- "$@")
if [ "$#" -eq 0 ]; then
  help
fi
eval set -- "$OPTS"
while :
    do
        case "$1" in
            -n | --span )
            span="$2"
            shift 2
            ;;
            -o | --outputdir )
            outputdir="$2"
            shift 2
            ;;
            -h | --help)
            help
            ;;
            --)
            shift;
            break
            ;;
            *)
            echo "Unexpected option: $1"
            help
            ;;
        esac
    done

#Input=sperm.cov5.bed_VS_oocyte.cov5.bed.preDMS
Input=$1
#N=4000000
N=$span
#data_dir=/pnas/liujiang_group/zhanjh/meth_script_whole/test_data/sperm.cov5.bed_VS_oocyte.cov5.bed

#mkdir -p $data_dir
#cd $data_dir
split -l $N  --suffix-length=2 --numeric-suffixes ${Input} ${Input}_

cat >  pvalue.r   << EOF

args=commandArgs(T)
Input=args[1]
Output=args[2] #paste(Input,"qvalue.all.txt",sep="."
library(data.table)
Fish1=fread(header = FALSE,stringsAsFactors = FALSE,file =Input)
Fish1=as.data.frame(Fish1)

colnames(Fish1)=c("chr","start","end","bed2_meth_Level","bed2_meth_reads","bed2_unmeth_read","bed1_meth_Level","bed1_meth_reads","bed1_unmeth_read")
abs1=abs(Fish1\$bed2_meth_Level-Fish1\$bed1_meth_Level)
#Fish2=Fish1[(abs1>0.2),]
Fish2=Fish1
pvalue=0
for (i in 1:nrow(Fish2)){
  a=fisher.test(matrix(as.numeric(Fish2[i,][c(5,8,6,9)]),ncol=2))
  #t=a\$p.value
  pvalue[i]=a\$p.value
}

pva=data.frame(p=pvalue)
out_put=cbind(Fish2,pva)
write.table(out_put,file=Output,quote = F,sep="\t",col.names = T,row.names = F)
EOF

for i in `ls| grep -P "${Input}_\d*$"`
    do
        Rscript pvalue.r $i ${i}.DMS
    done






