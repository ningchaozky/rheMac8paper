#!/usr/bin/perl -w
#
# This script extract title through gi number, you should put only one 
# gi number in each line thank you for use ningchao 2014.10.15
#
use Getopt::Long;

my $out;
my $blastresult;
my $help;

GetOptions ("blastresult|b=s" => \$blastresult,
			"out|o=s" => \$out,
			"help|h" => \$help);

if($help){
print STDOUT << "EOF";
Usage:
print $0
		-blastresult|b 
		-out|o 
		-help|h help for your use
	Thanks for your use!~~ ningchao
EOF
		exit();
}

open BLASTRESULT, "< $blastresult";
open OUT, "> $out";

my $output;
while (<BLASTRESULT>){
chomp;
if(/^(.*)gi\|(\d+)\|\w+\|\S+\|(.*)$/){
my $blastWithTitle = `blastdbcmd -db /home/DataBase/ftp.ncbi.nlm.nih.gov/blast/db/nt/nt  -entry $2 -target_only -outfmt '%t|gi%g|'`;
chomp $blastWithTitle;
$output = "$1\t$blastWithTitle\t$3\n";
print OUT  "$output";
}
}
