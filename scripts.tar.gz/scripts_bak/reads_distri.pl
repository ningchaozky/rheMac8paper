#!/usr/bin/perl -w

unless(@ARGV){
	print "\nUsage:\t$0 acc.bam slip\nslip default 1000bp\n\n";
}
else{
$bam = shift;
chomp $bam;
	if(@ARGV){
		$breaks = shift;
	}
	else{
		$breaks = 1000;
	}

@header = `samtools view -H $bam`;
my %length;
for(@header){
    chomp;
    if(/SN\:(\d+)\s+LN\:(\d+)$/){
        $length{$1} = $2;
    }
}



for(keys %length){
	my $chr_len = $length{$_};
	for($i=1;$i< int($chr_len/$breaks)+1;$i++){
		$befor =  ($i-1)*$breaks;
		$after = $i*$breaks;
		$par = $_.':'.$befor.'-'.$after;
		$pos_num = `samtools view -c -F 0x10 $bam $par`;
		chomp $pos_num;
		$neg_num = `samtools view -c -f 0x10 $bam $par`;
		chomp $neg_num;
		$pos_out = sprintf "%.4f",($befor+$after)/2000000;
		if($neg_num == 0){
			print "$_\t$pos_out\t$pos_num\t0\n";
		}
		else{
			print "$_\t$pos_out\t$pos_num\t-$neg_num\n";
		}
		}
	}
}
