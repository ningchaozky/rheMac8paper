#!/usr/bin/env python3
import os
import sys
import copy
import argparse
import json
import re
from collections import defaultdict
from ningchao.nSys import trick, system, parse
from ningchao.nBio import hub
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('json', nargs='?', help = 'json template, color will use color nData, template give hic bigwig', default = sys.stdin, type = argparse.FileType('r'))
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def reset_genome( obj, genome = 'rheMac8'):
    if isinstance( obj, dict ):
        obj = [ obj ]
    for each in obj:
            if 'genome' in each:
                each['genome'] = genome
            elif 'metadata' in each:
                each['metadata']['genome'] = genome
    return copy.deepcopy(obj)



js = json.load( args.json )
genome = 'rheMac8'
js['genomeName'] = genome
tracks = js['tracks']
annot = reset_genome( tracks[:2] )
template = tracks[3]
js_out = js
acl='public-read'
bucket='bwsshare'
cf = '/home/soft/soft/packages/ningchao/nData/track.color.data'
colors = parse.ini( cf ).to_dict()
typ, displayMode = 'bigwig', 'full'
objects = system.run('aws s3 ls {} --recursive'.format(bucket), shell = True)


acl_sh = open('acl.sh', 'w')
fls = defaultdict( lambda : defaultdict( list ) )
for o in objects:
    o_arr = re.split( '\s+', o )
    o_file = os.path.basename(o_arr[-1])
    if 'bpm.bw ' in o_file:
        continue
    if o_file.split('.')[-1] in ['hic','bw']:
        marker = system.dir.str_map_marker( o_arr[-1] )
        fls[marker][o_file] = o_arr[-1]
        cmd = 'aws s3api put-object-acl --bucket {} --key {} --acl {}'.format( bucket, o_arr[-1], acl )
        print ( cmd, file = acl_sh )


def rgb2hex( rgb ):
    r,g,b = map( int, rgb.split(','))
    return "#{:02x}{:02x}{:02x}".format(r,g,b)

print_tracks = []
for m in fls:
    mfls = fls[ m ]
    for o_file, o_raw in system.dir.sort( mfls, period = True ):
        period = system.dir.str_map_period( o_file )
        if period == 1000 :
            print ('Wrong period match:', o_file, o_raw, file = sys.stderr )
            continue
        marker = system.dir.str_map_marker( o_file )
        color = rgb2hex(colors[ period ])
        url = 'https://bwsshare.s3.amazonaws.com/' + o_raw
        name = '_'.join([period, marker])
        if o_file.endswith('hic'):
            typ = 'hic'; displayMode = 'arc'
        print ( name, file = sys.stderr )
        template['name'] = name
        template['type'] = typ
        template['label'] = name
        template['options']['label'] = name
        template['options']['color'] = color
        template['url'] = url
        template['metadata']['genome'] = genome
        template['metadata']['Track type'] = typ
        print_tracks.append( copy.deepcopy(template) )
js['tracks'] = [ *annot, *print_tracks ]

js_output = open( 'rheMac.tracks.washU.js', 'w' )
js_output.write( json.dumps( js['tracks'], indent=4) )
acl_sh.close()
js_output.close()


cmd = 'aws s3 cp {} s3://{}'.format( js_output.name, bucket)
system.run( cmd, shell = True )
cmd = 'aws s3api put-object-acl --bucket {} --key {} --acl {}'.format( bucket, js_output.name, acl )
system.run( cmd, shell = True )

















