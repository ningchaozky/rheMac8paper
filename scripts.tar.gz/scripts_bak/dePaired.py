#!/usr/bin/env python
import os
import sys
import ningch as nc

nc.usage("file:bed file:bed.dePaired")


nc.reads_num('%s,4' % sys.argv[1],sys.argv[2])
