#!/usr/bin/env perl
use warnings ;


unless (@ARGV == 1){
	die "$0 hg19\n";
}

$db = $ARGV[0];
@list = `curl http://egg.wustl.edu/d/$db/`;

for(@list){
	if (/href=\"(.*gz)\"/){
		print "wget http://egg.wustl.edu/d/$db/$1\n";
	}
	if (/href=\"(.*gz.tbi)\"/){
		print "wget http://egg.wustl.edu/d/$db/$1\n";
	}
} 
