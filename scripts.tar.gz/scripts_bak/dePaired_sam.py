#!/usr/bin/env python
import os
import sys
import ningch as nc

nc.usage("file:sam file:sam.dePaired")

sam = open(sys.argv[1])

mmchr = nc.mmchr()
reads = {}
for line in sam:
	if line.startswith('@'):
		continue
	line_arr = line.strip().split('\t')
	if line_arr[0] not in reads:
		reads[line_arr[0]] = 0
	reads[line_arr[0]]  += 1

sam.close()
sam = open(sys.argv[1])
for line in sam:
	if line.startswith('@'):
		sys.stdout.write(line)
		continue
	line_arr = line.strip().split('\t')
	if reads[line_arr[0]] == 1:
		sys.stdout.write(line)
		continue
	if(reads[line_arr[0]] > 1 and (0x80 & int(line_arr[1])) == 0):
		sys.stdout.write(line)
sam.close()






