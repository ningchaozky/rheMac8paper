#!/usr/bin/env    python3
import os
import re
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot    as    plt
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
fig,ax = plt.subplots(figsize=(8,6))
plt.style.use('ggplot')
import seaborn    as    sns;sns.set(color_codes=True)
sns.barplot(    palette="Set3"    )
import argparse
import random
import pandas as pd
from scipy.stats import wilcoxon, levene, ttest_ind
from collections import defaultdict
from ningchao.nSys import trick, system
example = '''  '''
parser = argparse.ArgumentParser( prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'ini', nargs = '?', help = 'spd bed ini file')
parser.add_argument( '-annot', nargs = '?', help = 'annot file', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.geneTransPromoterMean.exonNum')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( lines, header, peirod_order):
    infor = defaultdict(lambda : defaultdict( list ))
    header = [ 'chrom','start','end',*header,'intersectLen']
    print ( header )
    for line in lines:
        tmp = dict(zip( header, line.strip().split('\t')))
        reads = [ int( v ) for k,v in tmp.items() if system.dir.str_map_peirod( k, up = '/', down = '/' ) == peirod_order ]
        lst = [ tmp['exonNum'], tmp['Rank'], tmp['symbol'], tmp['transcripts_id'], *reads ]
        infor[tmp['Rank']][tmp['symbol']].append(lst)
    return infor


def notInSPD( infor, annot):
    inSPD_genes, out, uniqGene = [], defaultdict( lambda : defaultdict ( int )), []
    for rank in infor:
        for gene in infor[rank]:
            #transcrips    =    infor[rank][gene]
            inSPD_genes.append( gene )
    with open( annot ) as f:
        for line in f:
            line_arr = line.strip().split('\t')
            gene = line_arr[7]
            if gene in inSPD_genes:
                continue
            if gene not in uniqGene:
                out[line_arr[-1]][gene] = int( line_arr[-2] )
                uniqGene.append( gene )
    return out

def plot_prepare(infor):
    rank_num_inSPD = defaultdict( lambda : defaultdict( int ))
    for rank in infor:
        for gene in infor[rank]:
            gene_exonNum = infor[rank][gene][0][0]
            rank_num_inSPD[rank][gene] = int(gene_exonNum)
    return rank_num_inSPD

if __name__ == '__main__':
    with open(args.annot +'.header') as f:
        header = next(f).strip().split('\t')
    with open(args.ini) as f:
        num = len([ i for i in f.readlines() if i.strip()])
        fig,ax = plt.subplots( 1, figsize=(8,6), sharex=True, sharey=True)
    dit = {'0-5': 0, '5-10': 1, '10-100':2 , '100-500':3}
    lst = []
    with open( args.ini ) as f:
        for plotNum,line in enumerate(    f    )    :
            peirod, bedfile = re.split(r'\s+', line.strip())
            peirod_order = system.dir.str_map_peirod( peirod, up = '', down = '', log = True)
            print ( peirod, bedfile, peirod_order, file = sys.stderr)
            cmd = 'bedtools intersect -a {} -b {} -wo'.format( bedfile, args.annot)
            lines = system.run( cmd, shell = True )
            infor = parse( lines, header, peirod_order)
            rank_num_inSPD = plot_prepare( infor )
            expect_num = notInSPD( infor, args.annot )
            in_spd_gene_num, not_spd_gene_num = 0,0
            for rank in rank_num_inSPD:
                for gene in rank_num_inSPD[rank]:
                    in_spd_gene_num += 1
                    lst.append([ rank, gene, peirod, rank_num_inSPD[rank][gene], 'inSPD'])
            for rank in expect_num:
                for gene in expect_num[rank]:
                    not_spd_gene_num += 1
                    lst.append([ rank, gene, peirod, expect_num[rank][gene],'NotinSPD'])
        df = pd.DataFrame( lst, columns = ['rank','gene', 'peirod','exonNum','typ'])
        print (df)
        df.to_csv('plot.data.xls',    sep    =    '\t')
        sns.boxplot( x='peirod',y='exonNum', hue = 'typ', data=df, showfliers=False )
        plt.savefig( 'rank.exonNum3.pdf'.format(peirod), dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')



















