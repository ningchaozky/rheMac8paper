#!/usr/bin/perl -w
# # comp100144_c0_seq1| Length: 286
# # comp100144_c0_seq1 Number of predicted TMHs:  5
# # comp100144_c0_seq1 Exp number of AAs in TMHs: 110.96214
# # comp100144_c0_seq1 Exp number, first 60 AAs:  15.20347
# # comp100144_c0_seq1 Total prob of N-in:        0.90710
# # comp100144_c0_seq1 POSSIBLE N-term signal sequence
# comp100144_c0_seq1|      TMHMM2.0        inside       1    42
# comp100144_c0_seq1      TMHMM2.0        TMhelix     43    65
# comp100144_c0_seq1      TMHMM2.0        outside     66    87
# comp100144_c0_seq1      TMHMM2.0        TMhelix     88   110
# comp100144_c0_seq1      TMHMM2.0        inside     111   171
# comp100144_c0_seq1      TMHMM2.0        TMhelix    172   194
# comp100144_c0_seq1      TMHMM2.0        outside    195   208
# comp100144_c0_seq1      TMHMM2.0        TMhelix    209   231
# comp100144_c0_seq1      TMHMM2.0        inside     232   232
# comp100144_c0_seq1      TMHMM2.0        TMhelix    233   252
# comp100144_c0_seq1      TMHMM2.0        outside    253   286
#
unless(@ARGV){
die "Usage:\ttmTrim.pl tmoutput fasta\n";
}
else{
open TM, "$ARGV[0]";
open FA, "$ARGV[1]";
# made hash
my %hash;

while(<FA>){
chomp;
	if(/>/){
	s/>//;
	$name = $_;
	}
	else{
	$hash{$name} .= $_;
	}
}


while(<TM>){
chomp;
	if(/^\#\s(.*)\sLength\:\ (\d+)$/){
	$nameLen = $name = $1;
	$len = $2;
	$nameLen =~ s/\|m\..*//;
	$seqLen = length $hash{$nameLen};
	}
	if(/\#\s(.*)\sNumber\ of\ predicted\ TMHs\:\s+(\d)/){
	$tm = $2;
	$name = quotemeta $name;
		if($1 =~ /^$name$/ && $tm > 0 && $len/$tm <78 && $len/$tm >40 && ($len*3)/$seqLen > 0.5){
		$name =~ s/\\//g;
		print "$name\t$len\t$seqLen\t$tm\t$hash{$nameLen}\n";
		}
	}
}
}
