#!/usr/bin/env python
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit
parser = argparse.ArgumentParser(prog=sys.argv[0],description='gtf to ucsc browser flat txt')
parser.add_argument('-a', nargs='?', help ='start')
parser.add_argument('-gtf', nargs='?', help ='gft file which download from ensemble')
if len(sys.argv) == 1:
        parser.print_help().__str__
        sys.exit(2)
args = parser.parse_args()

chrm = list(range(1,23))
chrm = [str(i) for i in chrm]
chrm.append('X')
Infor = {}
if args.a == 'start':
	fh = open(args.gtf)
	for line in fh:
		if line.startswith('#!'):
			continue
		line_arr = line.strip().split('\t')
		if str(line_arr[0]) not in chrm:
			continue
		desc_arr = iter(line_arr[8].split('\"'))
		gene_id,gene_name,transcript_id,transcript_name,gStart,gEnd,txStart,txEnd,cdsStart,cdsEnd,exStart,exEnd = '','','','','','','','','','','',''
		for each in desc_arr:
			if 'gene_id' in each:
				gene_id = next(desc_arr)
			if 'gene_name' in each:
				gene_name = next(desc_arr)
			if 'transcript_id' in each:
				transcript_id = next(desc_arr)
			if 'transcript_name' in each:
				transcript_name = next(desc_arr)
		trickTookit.set1dict(Infor,gene_id,{})
		if line_arr[2] == 'gene':
			gStart = line_arr[3]
			gend = line_arr[4]
		if line_arr[2] == 'transcript':
			txStart = line_arr[3]
			txEnd = line_arr[4]
		if line_arr[2] == 'CDS':
			cdsStart = line_arr[3]
			cdsEnd = line_arr[4]
		if line_arr[2] == 'exon':
			exStart = line_arr[3]
			exEnd = line_arr[4]
		trickTookit.set3dict(Infor,gene_id,transcript_id,'cdsStart',[])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'cdsEnd',[])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'txStart',txStart)
		trickTookit.set3dict(Infor,gene_id,transcript_id,'txEnd',txEnd)
		trickTookit.set3dict(Infor,gene_id,transcript_id,'exStart',[])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'exEnd',[])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'transcript_name',[])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'name',gene_name)
		trickTookit.set3dict(Infor,gene_id,transcript_id,'chr','chr' + str(line_arr[0]))
		trickTookit.set3dict(Infor,gene_id,transcript_id,'chain',line_arr[5])
		trickTookit.set3dict(Infor,gene_id,transcript_id,'chain',line_arr[5])
		Infor[gene_id][transcript_id]['cdsStart'].append(cdsStart)
		Infor[gene_id][transcript_id]['cdsEnd'].append(cdsEnd)
		Infor[gene_id][transcript_id]['exStart'].append(exStart)
		Infor[gene_id][transcript_id]['exEnd'].append(exEnd)
		Infor[gene_id][transcript_id]['transcript_name'].append(transcript_name)

times = {}
for gene_id in Infor:
	trickTookit.set1dict(times,gene_id,0)
	for transcript_id in Infor[gene_id]:
		transcript = Infor[gene_id][transcript_id]
		exStart = trickTookit.ulist(transcript['exStart'],dEmpty = 'yes')
		exEnd = trickTookit.ulist(transcript['exEnd'], dEmpty = 'yes')
		txStart = transcript['txStart']
		txEnd = transcript['txEnd']
		cdsStart = trickTookit.ulist(transcript['cdsStart'], dEmpty = 'yes')
		cdsEnd = trickTookit.ulist(transcript['cdsEnd'], dEmpty = 'yes')
		times[gene_id] += 1
		if len(cdsStart) < 1:
			sys.stderr.write(','.join(cdsStart))
			sys.stderr.write('\n')
			continue
		cdsStart = cdsStart[0]
		cdsEnd = cdsEnd[-1]
		exonNum = len(exStart)
		score,name = '0',transcript['name']
		print('\t'.join([str(i) for i in [times[gene_id],gene_id,transcript['chr'],transcript['chain'],txStart,txEnd,cdsStart,cdsEnd,exonNum,','.join(exStart),','.join(exEnd),score,name,'unk','unk','-1,'*exonNum]]))




