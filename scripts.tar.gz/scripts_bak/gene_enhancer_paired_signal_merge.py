#!/usr/bin/env python3
import os
import sys
import pickle
import dill
import timeit
import argparse
import pandas as pd
import multiprocessing as mp
from itertools import repeat
from functools import partial
from ningchao.nSys import trick, system, fix
from collections import defaultdict
desc = '''K27ac and hic interaction merge the signal togetor. files first line is index\nindex must uniq'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'files', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
parser.add_argument( '-d', nargs='?', help = 'dir for hic interaction calculate', default = '/dataB/ftp/pub/rheMac3/prefrontal/hic/whole_genome')
parser.add_argument( '-c', nargs='?', help = 'cut off for hic interaction', default = 5, type = float)
parser.add_argument( '-o', nargs='?', help = 'output prefix', required = True )
parser.add_argument( '-check_interaction', nargs='?', help = 'interaction check' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def index_parse():
    infor = defaultdict( list )
    lines = args.files.readlines()
    lines = [ i.rstrip() for i in lines if '#' not in i ]
    index_file = lines.pop(0)
    with open( index_file ) as f :
        for line in f :
            line_arr = line.rstrip().split('\t')
            key = '\t'.join( line_arr )
            chrom = line_arr[0]
            infor[chrom].append(key)
    kwargs.update({ 'signal': system.dir.sort(lines)})
    return infor

def merge_data_to_df():
    outputmerge_file = fix.fix(args.o).insert('hicItersection')
    kwargs.update( { 'df': outputmerge_file } )
    if os.path.exists(outputmerge_file) and os.path.getsize(outputmerge_file) > 10 :
        print ('Exists {}, and read it, you can delete by hand and generate new one...'.format( outputmerge_file ), file = sys.stderr )
        return outputmerge_file
    file_infor = defaultdict( lambda : defaultdict( float ) )
    for fl in kwargs.get('signal'):
        with open( fl ) as f :
            header = next(f).rstrip().split('\t')
            peirod = header[-1]
            for line in f :
                line_arr = line.rstrip().split('\t')
                #key = '\t'.join( line_arr[0:3] )
                file_infor[ peirod ] [ line_arr[3] ] = float( line_arr[-1] )
    df = pd.DataFrame(file_infor).fillna( 0 )
    df.to_csv( outputmerge_file, sep = '\t', index_label = 'gene_enhancer_pair')
    return outputmerge_file

def df_check_interaction( cutType = 'hicInteraction'):
    outputfile = open( fix.fix( kwargs.get('df') ).insert('hicCut'), 'w')
    interaction = kwargs.get('interaction')
    df = pd.read_csv( kwargs.get('df'), sep = '\t', header = 0, index_col = 0 )
    #header = [ system.dir.str_map_peirod(i) for i in colnames ]
    header = list(df.columns)
    print_header = [ 'gene_symbol_pair',]
    for each in header :
        print_header.append( each )
        print_header.append( each+ '.' + cutType )
    print ( *print_header, sep = '\t', file = outputfile)
    aleady_check_infor = defaultdict( lambda : defaultdict( float ) )
    print ('Start with multiprocessing cpu num is set 6....', file = sys.stderr )
    kwargs.update({'second_arg': [ header, interaction, outputfile ]})
    start = timeit.default_timer()
    arr = []
    with mp.Pool(6) as pool :
        for j, line_infor in enumerate( df.iterrows() ):
            if not j % 600 :
                for each in pool.map( line_check, arr ):
                    print ( *each, file = outputfile, sep = '\t')
                stop = timeit.default_timer()
                print ( line_infor[0], j, 'marker....Time usage: ', stop - start, file = sys.stderr)
                #init arr and starttime
                start = timeit.default_timer()
                arr = [line_infor]
            else :
                arr.append( line_infor )
        for each in pool.map( line_check, arr ):
            print ( *each, file = outputfile, sep = '\t')
        #pool.map( partial( line_check, check_infor = ''), rows )
        #pool.starmap( line_check, tuple([1,2,3]) )
    #for index, line in df.iterrows():
    if 0 :
            symbol_enhancer_pair = index
            symbol_enhancer_pair_infor = symbol_enhancer_pair.split('.')
            regions = symbol_enhancer_pair_infor[-1].split('|')
            pos = regions[-3:]
            pos_key = '|'.join( pos )
            symbol = symbol_enhancer_pair_infor[0].upper()
            outline = [symbol_enhancer_pair]
            for i,v in enumerate( line ):
                peirod = system.dir.str_map_peirod(header[i])
                #if pos_key in aleady_check_infor and peirod in aleady_check_infor.get(pos_key):
                #    outline.extend([v, aleady_check_infor[pos_key][peirod]])
                #    continue
                if symbol in interaction and peirod in interaction[symbol]:
                    regions = interaction[symbol][peirod]
                    whether_overlap = check_regions( pos, regions )
                    outline.extend([ v, whether_overlap])
                    #aleady_check_infor[pos_key][peirod] = whether_overlap
            print ( *outline, sep = '\t', file = outputfile)


def line_check( line_infor, check_infor = '' ):
    second_arg = kwargs.get('second_arg')
    header, interaction, outputfile = second_arg
    index, line = line_infor
    #print ( index, line, header, interaction, outputfile )
    symbol_enhancer_pair = index
    symbol_enhancer_pair_infor = symbol_enhancer_pair.split('.')
    regions = symbol_enhancer_pair_infor[-1].split('|')
    pos = regions[-3:]
    pos_key = '|'.join( pos )
    symbol = symbol_enhancer_pair_infor[0].upper()
    outline = [symbol_enhancer_pair]
    for i,v in enumerate( line ):
        peirod = system.dir.str_map_peirod(header[i])
        if symbol in interaction and peirod in interaction[symbol]:
            regions = interaction[symbol][peirod]
            whether_overlap = check_regions( pos, regions )
            outline.extend([ v, whether_overlap])
    return outline

def check_regions( pos, regions):
    chrom, start, end = pos
    for each in regions:
        interaction_chrom, interaction_start, interaction_end = each.rstrip().split('\t')
        if interaction_chrom != chrom:
            continue
        region_intersection = set.intersection( set( range(int(start), int(end)) ), set( range(int(interaction_start),int(interaction_end))) )
        if region_intersection :
            return 'yes'
    return 'no'



def symbol_set_no_interaction_to_default( symbol, peirod, pos, val):
    interaction = kwargs.get('interaction')
    if symbol in interaction and peirod in interaction.get( symbol ):
        bed = interaction.get( symbol ).get( peirod )
        for line in bed:
            line_arr = line.rtsrip().split('\t')
            print ( line_arr )

def get_usage_col(header):
    out = []
    for i,v in enumerate(header):
        peirod = system.dir.str_map_peirod( v )
        if 'NotFound' not in peirod :
            out.append( (i,peirod) )
    return out

def hic_parse_interaction():
    outputname = os.path.join(args.d, 'symbols.regions.{}.pickle'.format(args.c) )
    if os.path.exists( outputname ) and os.path.getsize( outputname ) > 10:
        print ( 'Exists', outputname, 'read it...', file = sys.stderr)
        with open( outputname, 'rb') as f :
            symbol_dit = dill.load( f )
            kwargs.update({'interaction': symbol_dit })
            return symbol_dit
    fls = system.dir( args.d ).fls( 'tab$', depth = 10, abspath = True )
    symbol_dit = defaultdict( lambda : defaultdict( set ))
    i = 0
    for fl in fls :
        i += 1
        with open( fl ) as f :
            header = next( f ).rstrip().split('\t')
            if 'H11WPL' in header :
                continue
            symbol = os.path.basename(fl).split('.')[0]
            need_pos = get_usage_col(header)
            #print ( symbol, need_pos )
            for line in f :
                line_arr = line.rstrip().split('\t')
                chrom,start,end = line_arr[0:3]
                #print ( chrom,start,end, *[ line_arr[i[0]] for i in need_pos ])
                #print ( line_arr, fl )
                for pos, peirod in need_pos:
                    if 'NA' in line_arr[pos]:
                        continue
                    val = float( line_arr[pos] )
                    if val > args.c:
                        symbol_dit[ symbol ][ peirod ].add('\t'.join([ chrom, start, end]))
        if not i % 1000 :
            print ( i, fl, symbol, file = sys.stderr )
    with open( outputname, 'wb') as handle:
        print ( 'Generate', outputname, '...', file = sys.stderr)
        dill.dump( symbol_dit, handle )
    kwargs.update({'interaction': symbol_dit })
    return symbol_dit

def main():
    index = index_parse()
    if args.check_interaction:
        interaction_dit = hic_parse_interaction()
    #kwargs update df for merge matrix
    merge_data_to_df()
    #def check interaction and set val 
    if args.check_interaction:
        df_check_interaction()


if __name__ == '__main__':
    kwargs = vars( args )
    main()































