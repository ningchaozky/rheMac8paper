#!/usr/bin/env python
import sys
import os

def help():
	print('#Usage:',sys.argv[0],'keyWord','dir')
	exit()

if len(sys.argv) != 3:
	help()

abs = os.path.abspath(sys.argv[2])
dirs = os.listdir(sys.argv[2])

dir_num = []
file_num = []

for tmp in dirs:
	filePath = os.path.join(abs,tmp)
	if os.path.isdir(filePath):
		if '%s' % sys.argv[1] in tmp:
			dir_num.append(tmp)
	if os.path.isfile(filePath):
		if '%s' % sys.argv[1] in tmp:
			file_num.append(tmp)
	
for dir in dir_num:
	print('dir\t',dir)
print('\nNumbers of Dirs is:',len(dir_num),'\n')
for file in file_num:
	print('file\t',file)
print('\nNumbers of Files is:',len(file_num),'\n')
