#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('name', nargs='?', help ='sample name')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
name = args.name
cwd = os.getcwd()

def cmd( input_cmd_string ):
    print('cd %s' % work_dir)
    print(input_cmd_string)
read_1 = name + '_R1.fq.gz'
read_2 = name + '_R2.fq.gz'
work_dir = os.path.join(cwd,name)
os.system( 'mkdir -p %s' % work_dir )
trim = 'java -jar /pnas/liujiang_group/ningch/soft/Trimmomatic-0.33/trimmomatic-0.36.jar PE -threads 8 %s_1.fq.gz %s_2.fq.gz %s_1.fq.gz %s_1U.fq.gz %s_2.fq.gz %s_2U.fq.gz ILLUMINACLIP:/pnas/liujiang_group/ningch/soft/Trimmomatic-0.33/adapters/customed_adapter.fa:2:30:10  MINLEN:36 HEADCROP:3 CROP:50 2>%s.PE.cliped.txt'
cmd(trim.replace('%s',name))


mapping = '/pnas/liujiang_group/ningch/soft/bwa/bwa mem /pnas/liujiang_group/ningch/data/genome/drosophlia/Drosophila_melanogaster.BDGP6.dna_sm.toplevel.fa %s_1.fq.gz %s_2.fq.gz -t 8  > %s.bwa.sam'
cmd(mapping.replace('%s',name))

sort = '/pnas/liujiang_group/ningch/soft/samtools-1.3.1/bin/samtools sort -m 6000000000 %s.bwa.sam -o %s.bwa.sort.bam'
cmd(sort.replace('%s',name))























