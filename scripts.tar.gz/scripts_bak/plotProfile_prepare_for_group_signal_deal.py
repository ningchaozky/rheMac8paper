#!/usr/bin/env python3
import os
import re
import sys
import gzip
import json
import random
import argparse
from ningchao.nSys import trick, fix, system
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs= '+', help = 'gzs file from plotProfile_prepare_for_group output gz files')
parser.add_argument( '-d', nargs= '?', help = 'period + period', default = '4M:P0-45Y')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def deal( line_arr, vd, s1, s2, **kwargs):
    line_arr[6:] = map( float, line_arr[6:] )
    line_arr[vd[0]:vd[1]] = [ x[0] - x[1] + random.uniform( 0.3, .8) for x in zip(line_arr[s1[0]:s1[1]], line_arr[s2[0]:s2[1]]) ]
    #line_arr[vd[0]:vd[1]] = [ sum(x) + random.uniform(0, 1) for x in zip(line_arr[s1[0]:s1[1]], line_arr[s2[0]:s2[1]]) ]
    return map( str, line_arr )


def parse():
    group_labels,group_boundaries = [], [0]
    data, relabel_num = [],0
    for tab in kwargs.get('tabs'):
        with gzip.open( tab ) as f :
            header = next(f).rstrip().replace(b'@', b'')
            tab_header_infor = json.loads( header )
            print ( tab_header_infor )
            group_boundaries_add = group_boundaries[-1] + tab_header_infor.get('group_boundaries')[1]
            group_boundaries.append( group_boundaries_add )
            group_labels.append( *tab_header_infor.get('group_labels') )
            sample_labels = tab_header_infor.get('sample_labels')
            vd,s1,s2 = re.split(r':|\+|\-', args.d)
            sample_labels, sample_boundaries = tab_header_infor.get('sample_labels'), tab_header_infor.get('sample_boundaries')
            sample_boundaries = [ i+6 for i in sample_boundaries ]
            match_periods = [ system.dir.str_map_period(i) for i in sample_labels ]
            sample_pos = dict(zip(match_periods, zip(sample_boundaries[:-1], sample_boundaries[1:])))
            for line in f :
                line = line.decode()
                line_arr = line.rstrip('\n').split('\t')
                #relabel
                line_arr[0:4] = map( str, [ 1, relabel_num, relabel_num+1, '{}:{}-{}'.format(1,relabel_num,relabel_num+1) ] )
                line_arr = deal( line_arr, sample_pos[vd], sample_pos[s1], sample_pos[s2], method = '+')
                relabel_num += 1
                data.append( '\t'.join( line_arr ) )
    tab_header_infor.update({'group_labels': group_labels, 'group_boundaries': group_boundaries })
    new_header = trick.string.replace( '@' + str(tab_header_infor), [ {'None': 'null', 'False': 'false', 'True': 'true'}, {'\'':'\"'}])
    with gzip.open( fix.fix(kwargs.get('tabs')[0]).append( *kwargs.get('tabs'), 'deal.gz'), 'wb') as f:
        f.write( new_header.encode() + b'\n')
        for line in data:
            f.write( line.encode() + b'\n' )
        #print ( *data, sep = '\n', file = f )




if __name__ == '__main__':
    kwargs = vars( args )
    parse()























