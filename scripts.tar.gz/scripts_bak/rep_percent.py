#!/usr/bin/env python
import os
import sys
import ningch as nc
import gzip

nc.usage('bam clean.fastq.gz')

stdout,stderr = nc.run_sys('samtools flagstat %s' % sys.argv[1],wait = 'yes')
map_num = stdout.next().split(' ')[0]

fh = gzip.open(sys.argv[2])
total = 0
for line in fh:
	total += 1
print(float(map_num)/total)
print(total,map_num)




