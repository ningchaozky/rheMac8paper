#!/usr/bin/env python3
import os
import re
import sys
import fanc
import argparse
import matplotlib
import numpy as np
import pandas as pd
import fanc.plotting
matplotlib.use('Agg')
from scipy.ndimage import zoom
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
import matplotlib.patches as patches
from ningchao.nSys import trick, system
from mpl_toolkits.axes_grid1 import make_axes_locatable

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('control', nargs='?', help = 'control')
parser.add_argument('case', nargs='?', help = 'case')
parser.add_argument('-rpd', nargs='?', help = 'chess pairs hg38 3000000 100000 hg38_chr2_3mb_win_100kb_step.bed --chromosome chr2', default = '/home/soft/data/genome/rheMac8/chess')
parser.add_argument('-w', nargs='?', help = 'window', default = 3000000, type = int )
parser.add_argument('-b', nargs='?', help = 'bin', default = 25000, type = int )
parser.add_argument('-hic_bin', nargs='?', help = 'window', default = 25000 )
parser.add_argument('-hic_norm', choices=['VC', 'VC_SQRT', 'KR'], help = 'bin', default = 'VC_SQRT' )
parser.add_argument('-sp', nargs='?', help = 'species', default = 'rh8')

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse():
    wdir, sim_field, sn_thr, zsim_thr = ".", "z_ssim", 0.5, -1
    win, span, ctr, case = args.w, args.b, args.control, args.case
    winsize = re.sub(r'000$','kb', str( win ).replace('000000','mb'))
    spansize = str(span//1000) + 'kb'
    result_file = "{}_vs_{}_{}_chess_results.tsv".format( get_name( case), get_name(ctr), winsize)
    step_fls = list( system.dir('/home/soft/data/genome/rheMac8/chess').fls( '%s.*%s' % ( winsize, spansize) ) )
    keys = [ i.split('_')[1] for i in step_fls ]
    step_fls = dict( zip( keys, step_fls ) )
    case, ctr = '%s@%s@%s' % (case, args.hic_bin, args.hic_norm), '%s@%s@%s' % ( ctr, args.hic_bin, args.hic_norm)
    return winsize, win, span, ctr, case, result_file, step_fls

def get_name( string ):
    return os.path.basename( string ).replace('.hic','')

def sim( ctr, case, step_fls):
    cmds, ofls = [], {}
    for chrom in step_fls:
        result = '%s.%s.%s.sim.csv' % (get_name( case), get_name(ctr),chrom)
        cmd = 'chess sim %s %s %s %s' % ( ctr, case, step_fls[chrom], result)
        cmds.append( cmd )
        #plot_ssim( result, step_fls[chrom], figname)
        trick.dinit( ofls, result, step_fls[chrom] )
    return (cmds, ofls)

def pick( fls, SN = 0.5, z_ssim = -1 ):
    cmds, ofls = [], []
    for fl in fls:
        chrom = fl.split('.')[2]
        ofls.append( '%s.pick' % fl )
        cmd = 'subset_chess_matrix.py %s %s -cut "SN,>%f" "z_ssim,<%f" > %s.pick' % ( fl, fls[fl], SN, z_ssim, fl)
        cmds.append( cmd )
    return cmds, ofls


def exact( fls, case, ctr):
    cmds = []
    for fl in fls:
        chrom = ( trick.lst( fl.split('.')).get( 'chr', regular = True) )[0]
        outdir = 'features.%s.%s.%s' % ( chrom, get_name( case), get_name(ctr) )
        cmd = 'mkdir %s\nchess extract %s %s %s %s' % ( outdir, fl, ctr, case, outdir)
        cmds.append( cmd )
    return cmds

def plot_ssim( similarities, regions, figname):
    similarities = pd.read_csv(wdir + chess_results_file, sep='\t', index_col=0)
    regions = pd.read_csv(wdir + region_pairs, sep='\t', header=None)
    sim_field = "z_ssim"
    sn_thr = 0.5
    zsim_thr = -1
    sub_sim = similarities[(similarities["SN"]>= sn_thr) & (similarities[sim_field]<= zsim_thr)]

    all_X = regions.loc[similarities.index, 1:2].mean(axis=1).values / 10 ** 6
    X = regions.loc[sub_sim.index, 1:2].mean(axis=1).values / 10 ** 6
    S = sub_sim[sim_field]
    SN = sub_sim["SN"]
    plt.figure(figsize=(10, 3))
    plt.plot(all_X, similarities[sim_field], ":", alpha=0.4)
    plt.hlines(zsim_thr, 0, max(all_X), linestyle=":", color="red")
    plt.scatter(all_X, similarities[sim_field], facecolors='none', edgecolors='grey', alpha=0.1, s=20)
    plt.scatter(X, S, c=SN, marker='.')
    plt.ylabel(sim_field.replace("_", "-"))
    plt.xlabel("window midpoint [Mb]")
    c = plt.colorbar()
    c.set_label("signal/noise")
    plt.tight_layout()
    plt.savefig( figname, dpi=250)


if __name__ == '__main__':
    winsize, win, span, ctr, case, result_file, step_fls = parse()
    sim_cmds, ofls = sim( ctr, case, step_fls)
    
    trick.pjoin( sim_cmds )

    pick_cmds, pfls = pick( ofls )
    trick.pjoin( pick_cmds )

    ecmds = exact( pfls, case, ctr)
    trick.pjoin( ecmds )



