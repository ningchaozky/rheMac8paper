#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,fix

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='use the  ac.distal.dnase and specify information get specify enh', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('enh', nargs='?', help ='enhancer')
parser.add_argument('sp', nargs='?', help ='specify ac get from entropy select')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

enh = args.enh
sp = args.sp
sp_obj = fix.fix(sp)
sp_simply = sp_obj.append('sp')
enh_obj = fix.fix(enh)
distal_enh_sp = enh_obj.append('sp')
print('grep -v track %s | grep -v start | cut -f1,2,3 > %s' % (sp,sp_simply))
print('bedtools intersect -a %s -b %s -wo | cut -f1,2,3 > %s' % (enh,sp_simply,distal_enh_sp))















