#!/usr/bin/perl -w

unless(@ARGV){
	print "\n\tUsage:\t$0 infor.txt\n\t\t1 for auto\n";
}
else{
	open $infor,"$ARGV[0]";
	while(<$infor>){
		if(/#/){
			s/#//;
			$each_client = $_;
		}
		else{
			$client{$each_client} .= $_;
		}
	}
	open $log,"> mapping.sh";
	while(my ($contract,$v) = each %client){
		$contract =~ s/contract=//;
		chomp $contract;
		@tmp = split /\n/,$v;
		chomp @tmp;
		$reference = shift @tmp;
		if($reference =~ /yes/){
			$bowtie_index = shift @tmp;
			$gff3 = shift @tmp;
			$in_data = shift @tmp;
			$out_data = shift @tmp;
			
			$gff3 =~ s/gff3=//;
			$bowtie_index =~ s/bowtie_index=//;
			$in_data =~ s/data_input_dir=//;
			$out_data =~ s/data_output_dir=//;
			for(@tmp){
				$for = (split /\s+/,$_)[0];
				$for =~ s/_[12]\..*//;
				`mkdir -p $out_data/$contract/mapping/$for`;
				$cmd_1 = "tophat -o $out_data/$contract/mapping/$for -p 20  --library-type fr-unstranded -G $gff3 $bowtie_index $out_data/$contract/trim/$for/for-paired.fq $out_data/$contract/trim/$for/rev-paired.fq";
				$cmd_2 = "samtools merge -h  $out_data/$contract/mapping/$for/accepted_hits.bam  $out_data/$contract/mapping/$for/merge.bam $out_data/$contract/mapping/$for/accepted_hits.bam $out_data/$contract/mapping/$for/unmapped.bam";
				$cmd_3 = "samtools view $out_data/$contract/mapping/$for/merge.bam > $out_data/$contract/mapping/$for/merge.sam";
				$cmd_4 = "perl /export/dat1/GROUP/ningchao/software/mapping/script/samstat.pl $out_data/$contract/mapping/$for/merge.sam > $out_data/$contract/mapping/$for/mapping.txt";
				print $log "$cmd_1\n$cmd_2\n$cmd_3\n$cmd_4\n\n";
				if(@ARGV >= 2){
					`$cmd_1`;
					`$cmd_2`;
					`$cmd_3`;
					`$cmd_4`;
					`cp $out_data/$contract/mapping/$for/mapping.txt /export/dat1/GROUP/ningchao/client_infor/$for-mapping.txt`;
				}
			}
		}
	}
}
