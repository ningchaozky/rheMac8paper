#!/usr/bin/env python3
import os
import sys
import random
import argparse
import subprocess as sp
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bam', nargs = '?', help = 'bam file for split')
parser.add_argument( '-n', nargs = '?', help = 'line num for each bam', default = 100000, type = int)
parser.add_argument( '-sn', choices = ['name','coordinate'], help = 'sort name or coordinate or null')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def extracter():
    pass


samtools_path = system.run( 'which samtools', shell = True )[0]
header = system.run( 'samtools view -H {}'.format(args.bam), shell = True )
proc = sp.Popen( ('samtools', 'view', args.bam), stdout = sp.PIPE )
i = 0
sams = []
fhs = []
while True :
    line = proc.stdout.readline().decode().strip()
    if not i % args.n :
        rname = ''.join( random.sample( [ chr(i) for i in range(65,91) ], k = 8))
        fl = '{}.{}.sam'.format( rname, i )
        fh = open( fl, 'w' )
        print ( *header, sep = '\n', file = fh )
        fhs.append( fh )
        if i >= 1 :
            fhs_nearest = fhs[ i// args.n -1 ]
            fhs_nearest.close()
            #cmds = [ '/home/soft/soft/samtools/v1.10/bin/samtools', 'ls', '-lrtn']
            if args.sn == 'name':
                sortname = fix.fix( fhs_nearest.name ).change('sortByName.bam')
                cmds = [ samtools_path, 'samtools', 'sort', '-n', fhs_nearest.name, '-o', sortname ]
            elif args.sn == 'coordinate' :
                sortname = fix.fix( fhs_nearest.name ).change('sortByCorr.bam')
                cmds = [ samtools_path, 'samtools', 'sort', fhs_nearest.name, '-o', sortname ]
            os.spawnlp( os.P_NOWAIT, *cmds )
            break
            sams.append( fhs_nearest.name )
    print ( line, file = fh )

    i += 1
    if not line:
        break


[os.system('rm {}'.format(i)) for i in sams]

























