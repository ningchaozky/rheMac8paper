#!/usr/bin/env python3
import os
import re
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'cmd', nargs = '?', help = 'cmd file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def pick_SRR( fh ):
    for line in fh:
        if 'prefetch' in line:
            srr = re.search(r'(SRR\d+)', line)[0]
            return srr
    pick_SRR( fh )


def paired( cmd_file ):
    dit = defaultdict( str )
    with open( cmd_file ) as fh :
        for line in fh:
            if not line.strip():
                continue
            if line.startswith('#GSE'):
                name = line.strip().split('\t')[-1].replace(' ','_').replace('/','.')
                SRR = pick_SRR( fh )
                if not SRR :
                    print ( line, name, SRR )
                dit[SRR] = 'mv source {}'.format( '.'.join([ SRR, name ] ))
    return dit

def check_and_rename( dit, search_root ):
    for srr in dit:
        stdout = system.run('''find.py '{}.sra$' -dir {} -d 10 -abspath'''.format(srr, search_root), shell = True)
        for line in stdout:
            if not line.strip():
                continue
            srr_dir = os.path.dirname( line )
            if '{}.'.format(srr) in os.path.basename(srr_dir):
                continue
            cmd = dit[srr].replace('source', srr_dir)
            target = [ i for i in cmd.split(' ') if i ][-1]
            if os.path.isdir( target ):
                sys.stderr.write('#Exits {} {}\nrm -rf {}\n'.format( srr_dir, target, srr_dir ))
            else :
                print ( cmd )
if __name__ == '__main__':
    dit = paired( args.cmd )
    check_and_rename( dit, '.' )






























