#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import pybedtools
from ningchao.nSys import trick
from ningchao.nBio import bed
from tempfile import NamedTemporaryFile
example = '''This scipt mainly deal with the gene exons overlap, redup the gene in the chroms. input file is the ouput of rheMac8_xenoRefGene_annot'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('exons', nargs='?', help = 'sorted and uniq exons' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
efh = open( args.exons )
gene = {}
for line in efh:
    dit = bed.parse(line)
    name = dit['name'].split('.')[0].upper()
    strand = dit['strand']
    chrom = dit['chrom']
    key = '.'.join([chrom,name,strand])
    trick.set1dict(gene, key, [])
    gene[key].append(line)

for key in gene:
    chrom,name,strand = key.split('.')
    tmp = NamedTemporaryFile('w+t', delete = False )
    for line in gene[key]:
        line_arr = line.strip().split('\t')
        tmp.write(line)
    tmp.flush()
    bedtool_obj = pybedtools.BedTool(tmp.name)
    for i,each in enumerate(bedtool_obj.sort().merge(d=0)):
        out_arr = str(each).strip().split('\t')
        out_arr.append('%s.exon_%s' % (name,str(i)))
        out_arr.append('')
        out_arr.append(strand)
        print('\t'.join(out_arr))
























