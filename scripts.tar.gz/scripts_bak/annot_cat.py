#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='cat seq from refGene,ensemble,own', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-beds', nargs='*', help ='input beds for merge')
parser.add_argument('-o', nargs='?', help ='output file')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


ofh = sys.stdout
if args.o :
    ofh = open(args.o,'w')

def parse(line_arr):
    infor = {}
    key = '\t'.join(line_arr[0:3])
    key = key +'\t'+line_arr[-1]
    trick.set2dict(infor,key,'raw',line)
    names = line_arr[3].split('.')
    trick.set2dict(infor,key,'ncbiId', names[1])
    trick.set2dict(infor,key,'name', names[0])
    trick.set2dict(infor,key,'chain', line_arr[-1])
    return infor


chroms = list(chromosome.chr('rh8').chr.keys())
upos = {}
beds = args.beds
for bed in beds:
    bfh = open(bed)
    for line in bfh:
        line_arr = line.strip().split('\t')
        if line_arr[0] not in chroms:
            continue
        infor = parse(line_arr)
        for key in infor:
            name = infor[key]['name']
            ncbiId = infor[key]['ncbiId']
            if key not in upos:
                ofh.write(infor[key]['raw'])
                trick.set1dict(upos,key,0)
                upos[key] += 1
                break
            else :
                #upos[key] += 1
                #ofh.write(key+ str(upos[key]) + '\n')
                break















