#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os
import sys
import obonet
import networkx
import argparse
example = '''obo file'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-obo', nargs='?', help = 'obo file download from: http://purl.obolibrary.org/obo/go-basic.obo', default = 'go-basic.obo')
parser.add_argument('goid', nargs='?', help = 'id you want to get genelist' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    obo = '/' in args.obo and args.obo or os.path.join('/home/ningch/data/GO/20190809', args.obo )
    sys.stderr.write( obo +'\n' )
    graph = obonet.read_obo( obo )
    id_to_name = { id_: data.get('name') for id_, data in graph.nodes(data=True) }
    name_to_id = { data['name']: id_ for id_, data in graph.nodes(data=True) if 'name' in data }
    return graph,id_to_name,name_to_id,args.goid


if __name__ == '__main__':
    graph,id_to_name,name_to_id,goid = parse( args )
    gos = (sorted( subterm for subterm in networkx.ancestors( graph, goid )) )
    des = (sorted( id_to_name[subterm] for subterm in networkx.ancestors( graph, goid )) )
    dit = dict(list(zip(gos,des)))
    dit.update({goid: id_to_name[ goid ] } )
    for each in dit:
        print(( '\t'.join([ each, dit[each] ]) ))

























