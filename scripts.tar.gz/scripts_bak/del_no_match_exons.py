#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import bed as Bed

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-exons', nargs = '?', help = 'exons bed', default = '/home/soft/data/genome/rheMac8/annot/exons/exons.bed')
parser.add_argument('err', nargs = '?', help = 'err match title')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def extractErrBed( fl, name ):
    nfh = open( name )
    lst = []
    for line in nfh:
        lst.append( line.strip() )
    nfh.close()
    efh = open( fl )
    sfh = open( fl + '.split', 'w')
    dfh = open( fl + '.err', 'w')
    for line in efh:
        line_arr = line.strip().split('\t')
        name = line_arr[3].split('_exon_')[0].split('.')[0]
        if name in lst:
            dfh.write( line )
        else :
            sfh.write( line )
    sfh.close()
    dfh.close()
    return sfh.name, dfh.name


if __name__ == '__main__':
    #split, err = extractErrBed( args.exons, args.err )
    err = 'exons.bed.err'
    split = 'exons.bed.split'
    bed = Bed.bed( split ).intersect( err, par = '-wo -f 0.8' )
    intersect, lst = open( 'intersect', 'w'), []
    IDs = []
    for line in bed:
        intersect.write( line )
        line_arr = line.strip().split('\t')
        index = trick.lst( line_arr ).index( 'exon.*chr', regular = True )[1]
        Id = line_arr[ index ].split('_exon_')[0].split('.')[0]
        if Id not in IDs:
            IDs.append( Id )
    intersect.close()
    for line in open(args.err):
        line = line.strip()
        if line in IDs:
            continue
        else :
            print ( line )

    























