#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import numpy as np
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s -a gene.K4.bed 4 -b gene.K27.bed 4 -v ia, intersect in a, vb, only in b' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-a', nargs='+', help ='tab a', required = True )
parser.add_argument('-b', nargs='+', help ='tab b', required = True )
parser.add_argument('-v', choices = ['ia','ib','va','vb'], help = 'output only in ia|ib(intersect)|va|vb|no(intersect)', default = 'ia')
parser.add_argument('-o', nargs='?', help ='outputfile')
parser.add_argument('-caseSense', '-c', action = 'store_false', help ='ignore the upper and lowcarse')
parser.add_argument('-neuron', '-n', nargs = '?', help ='only output neuron relation gene', default = 'neuron')
parser.add_argument('-onlyGene', action = 'store_true', help ='only output gene')
parser.add_argument('-cycle', nargs= '?', help ='only print the gene name', type = int, default = 2)
parser.add_argument('-genePos', nargs= '?', help ='only print the gene name', type = int, default = 0)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

afh = open(args.a[0])
bfh = open(args.b[0])
if len(args.a) > 1 :
    acol = int(args.a[1]) - 1
else :
    acol = 0
if len(args.b) > 1 :
    bcol = int(args.b[1]) - 1
else :
    bcol = 0
ofh = sys.stdout
if args.o:
    ofh = open(args.o,'w')

geneA = []
geneB = []
cycle = args.cycle
genePos = args.genePos
neuron = args.neuron
caseSense = args.caseSense
onlyGene = args.onlyGene

def split_genes(string, cycle, genePos, caseSense):
    out = []
    genes = string.split('.')
    split_length = len(genes)
    if split_length == 1:
        sys.stderr.write('warning: not with the same format for the name coloumn %s\n' % string)
    gene_name_index = np.arange(genePos, split_length, cycle)
    genes = [ genes[i] for i in gene_name_index ]
    for gene in genes:
        if not caseSense :
            gene = gene.upper()
        out.append(gene)
    return out



def lst_print(lst,afh,bfh, ofh, genePos, caseSense, col = 3, action = 'ia', onlyGene = True ):
    out = []
    if lst :
        if action == 'ia':
            for line in afh:
                if 'gene\t' in line or 'chr\t' in line:
                    out.append(line)
                line_arr = line.strip().split('\t')
                line_genes = split_genes(line_arr[col], cycle, genePos, caseSense)
                for each in line_genes:
                    if each in lst:
                        out.append(line)
                        break
        if action == 'ib':
            for line in bfh:
                if 'gene\t' in line or 'chr\t' in line:
                    out.append(line)
                line_arr = line.strip().split('\t')
                line_genes = split_genes(line_arr[col], cycle, genePos, caseSense)
                for each in line_genes:
                    if each in lst:
                        out.append(line)
                        break
        if action == 'va':
            for line in afh:
                if 'gene\t' in line or 'chr\t' in line:
                    out.append(line)
                line_arr = line.strip().split('\t')
                line_genes = split_genes(line_arr[col], cycle, genePos, caseSense)
                index = len(line_genes)
                for each in line_genes:
                    if each not in lst:
                        index -= 1
                if index == 0 :
                    out.append(line)
        if action == 'vb':
            for line in bfh:
                if 'gene\t' in line or 'chr\t' in line:
                    out.append(line)
                line_arr = line.strip().split('\t')
                line_genes = split_genes(line_arr[col], cycle, genePos, caseSense)
                index = len(line_genes)
                for each in line_genes:
                    if each not in lst:
                        index -= 1
                if index == 0 :
                    out.append(line)
        if onlyGene :
            uniq = []
            for line in out:
                line_arr = line.strip().split('\t')
                genes = split_genes(line_arr[col], cycle, genePos, caseSense)
                for each in genes:
                    if each not in uniq:
                        ofh.write(each + '\n')
                        uniq.append(each)
        else :
            for line in out:
                ofh.write(line.strip() + '\n')

for line in afh:
    line_arr = line.strip().split('\t')
    geneA.extend(split_genes(line_arr[acol], cycle, genePos, caseSense))


for line in bfh:
    line_arr = line.strip().split('\t')
    geneB.extend(split_genes(line_arr[acol], cycle, genePos, caseSense))

geneA = set(geneA)
geneB = set(geneB)

afh = open(args.a[0])
bfh = open(args.b[0])
lst = []

same = geneA & geneB
if neuron :
    nfh = open(neuron,'w')
    geneNeuron = []
    nfl = '/home/ningch/data/genome/rheMac8/neuron/neuron.gene'
    for line in open(nfl):
        geneNeuron.append(line.strip())
    geneNeuron = set(geneNeuron)
    same = same & geneNeuron
    sys.stderr.write('Intersect neuron gene number is %s, and output in the file: neuron\n' % str(len(same)))
    for each in same:
        nfh.write(each+'\n')
lst_print(same, afh, bfh, ofh, genePos, caseSense, col = acol, onlyGene = onlyGene, action = args.v)



