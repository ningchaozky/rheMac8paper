#!/usr/bin/perl -w
unless(@ARGV){
	print "\n\t$0 fasta sequence\n\n";
}
else{

open $fa,"$ARGV[0]";
open $title,"$ARGV[1]";

while(<$fa>){
	chomp;
	if(/>/){
		s/>//;
		$name = $_;
	}
	else{
		$seq{$name} .= $_;
	}
}
open $out,"> out.txt";

while(<$title>){
	chomp;
	$i++;
	print $out "$_\t";
	push @title,$_;
}
print $out "\n";

$j = $i;
while($i){
	$i--;
	$sequence_title = shift @title;
	print $out "$sequence_title\t";
	print $out "\t"x($j-$i-1);
	@title2 = @title;
	open $file_1,"> 1";
	print $file_1 ">$sequence_title\n".$seq{$sequence_title};
	$sequence_title = quotemeta $sequence_title;
	for(@title2){
		$name = $_;
		open $file_2,"> 2";
		print $file_2 ">$_\n".$seq{$_};
		`needle -asequence 1 -bsequence 2 -gapopen 10.0 -gapextend 0.5 -outfile one2two`;
		open $aln,"one2two";
		while(<$aln>){
			if(/^#\ Identity:\s+\d+\/\d+\s+\((.*)\%\)$/){
				print $out "$1\t";
			}
		}
	}
	print $out "\n";
}
}



