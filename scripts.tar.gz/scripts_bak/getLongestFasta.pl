#!/usr/bin/perl -w


if(! $ARGV[0]){
print "Usage:\n\t\tlongestOrf.pl fasta\n\n";
}
else{
open FA,"< $ARGV[0]";
$/='>';
@arry = <FA>;
chop @arry;
shift @arry;
@arry = map {">".$_}@arry;
@arry2 = @arry;


for(@arry){
my ($name1,$seq1);
my ($name2,$seq2);
my $len1 = length;
my $len2;
($name1,$seq1)  =  split /\n/,$_,2;
	for(@arry2){
	$len2 = length;
	($name2,$seq2) = split /\n/,$_,2;
		$name2 = quotemeta $name2;
		if($name1 =~ /^$name2$/){
			if($len1 >= $len2){
			$seq1 = $seq1;
			}
				else{
				$seq1 = $seq2;
				}
			}
		}
$hash{$name1} = $seq1;
}


while(my ($k,$v) = each %hash){
print "$k\n$v\n";
}

close FA;
}
