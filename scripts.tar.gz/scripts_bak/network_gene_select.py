#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('Cytoscape', nargs='?', help = 'Cytoscape file' )
parser.add_argument('geneListFile', nargs='?', help = 'gene List file' )
parser.add_argument( '-a', action='store_true', help = 'default or if -a then is and')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

check = args.a
def gg(string):
    return string.strip().split('.')[0]
def name(string):
    line_arr = string.strip().split('\t')
    line_arr = [i.split('.')[0] for i in line_arr]
    return '\t'.join(line_arr)

genes = []
gfh = open(args.geneListFile)
for line in gfh :
    genes.append(gg(line))
gfh.close()
cfh = open(args.Cytoscape)
print(cfh.next().strip())
for line in cfh:
    line_arr = line.strip().split('\t')
    start = gg(line_arr[0])
    end = gg(line_arr[1])
    if check:
        if start in genes or end in genes:
            print(name(line))
    else :
        if start in genes and end in genes:
            print(name(line))































