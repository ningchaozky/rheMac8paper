#!/usr/bin/env python
import os
import sys
#build index 

if len(sys.argv) <=3:
	print(sys.argv[0],'infor.ini','fasta','num_threads')
	exit()

num_threads = 8

if len(sys.argv) == 4:
	num_threads = sys.argv[-1]

bowtie_index = 0
rsem_index = 0
already_map = []
cwd = os.getcwd()
cwd_bam = os.listdir(cwd)
for bam in cwd_bam:
	if bam.endswith('.transcript.sorted.bam'):
		name = bam.replace('.transcript.sorted.bam','')
		already_map.append(name)

for line in os.listdir(cwd):
	if line.startswith('prepared.1'):
		bowtie_index = 1
	elif line.startswith('prepared'):
		rsem_index = 1
if not rsem_index:
	print('rsem-prepare-reference --no-polyA --bowtie %s prepared' % sys.argv[2])
infor = open(sys.argv[1])
for line in infor:
	line_array = line.strip('\n').split('\t')
	if line_array[0] not in already_map:
		print(('rsem-calculate-expression --calc-pme --calc-ci --ci-memory 4000 --bowtie-n 3 --time --paired-end %s %s prepared %s -p %s' % (line_array[1], line_array[2], line_array[0], num_threads)))
