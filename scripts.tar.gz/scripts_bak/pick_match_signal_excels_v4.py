#!/usr/bin/env python3
import os
import re
import sys
import argparse
import numpy as np
from ningchao.nSys import trick, system
from collections import defaultdict

desc = '''last tab pick before match before'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs='+', help = 'excels with only one header and one index column. last table should be RNA')
parser.add_argument( '-fc', nargs='?', help = 'fold change at least', default = 2, type = float)
parser.add_argument( '-pick_use_name', nargs='?', help = 'bw|bam', default = 'bw|bam')
parser.add_argument( '-t', nargs='+', help = 'match 1 max the max with same peirod |prime 2. match 1 meaning only one is ok, all meaning must all match RNA expression', default = [ 'match', 1 ])
parser.add_argument( '-p', nargs='?', help = 'last RNA and pick the before as one maxstd|max|correspondence', default = 'correspondence')
parser.add_argument( '-sm', choices = ['max','keep','sum','maxstd'], help = 'same symbol pick method', default = 'sum')
parser.add_argument( '-tt', nargs = '+', help = 'debug symbol IL1RAP')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_span( lst, **kwargs):
    stages = [ system.dir.str_map_peirod( lst[i][0], pub = False) for i in range( 2 )]
    smax, smin = max(stages), min(stages)
    span = smax - smin
    return span

def symbols_get_overlap( dit ):
    rout, prime = defaultdict( set ), defaultdict( set )
    before, last = split_dit_by_last_tab( dit )
    if 'prime' in args.t:
        #for max_peirod in system.dir.peirods( prefrontal_raw = True ):
        for max_peirod in system.dir.sort( list(last.keys()) ):
            if max_peirod == 'E50' :
                continue
            #last tab max_peirod symbols
            #max_peirod_symbols = list( last[max_peirod].values() )
            #last_tab_max_peirod_symbols, before_peirods_symbols = max_peirod_symbols[-1], []
            before_peirods_symbols = []
            last_tab_max_peirod_before_peirods = [ i for i in system.dir.get_before_peirods(max_peirod, span = int(args.t[1])) if i in before.keys()]
            last_tab_max_peirod_symbols = last[max_peirod][args.tabs[-1]]
            print ( 'last tab max_peirod:', max_peirod, 'before_peirods', *last_tab_max_peirod_before_peirods, file = sys.stderr)
            for p in last_tab_max_peirod_before_peirods:
                #for max_peirod_symbols_before in before[p]:
                    before_p_values = []
                    for tab in before[p]:
                        values = list( before[p][tab] )
                        print ( 'prime:', tab, p, len(values))
                        before_peirods_symbols.extend( values )
                        before_p_values.extend( values )
                    rout[ p ] = set.intersection( set(before_p_values), last_tab_max_peirod_symbols)
            symbols = set.intersection( set(before_peirods_symbols), last_tab_max_peirod_symbols )
            prime[ max_peirod ] = symbols
            print ( 'select:', max_peirod, len(symbols) )
        #prime symbols
        kwargs.update({'prime': prime })
    elif 'match' in args.t :
        for max_peirod in dit :
            #intersection
            if '1' in args.t:
                symbols = set.intersection( set.union( *before[max_peirod].values() ), *last[max_peirod].values() )
            elif 'all' in args.t:
                symbols = set.intersection( set.intersection( *before[max_peirod].values() ), *last[max_peirod].values() )
            rout[ max_peirod ] = symbols
            print ( 'max_peirod:', max_peirod, len(symbols), file = sys.stderr )
    #last_output_symbols
    kwargs.update({'symbols': rout })
    return rout


def split_dit_by_last_tab( dit ):
    before, last, peirods = defaultdict( dict ), defaultdict( dict ), system.dir.peirods( prefrontal_raw = True )
    for peirod in dit :
        for tab in dit[peirod]:
            if tab == args.tabs[-1]:
                last[peirod][tab] = dit[peirod][tab]
            else :
                before[peirod][tab] = dit[peirod][tab]
    return before, last

def data_parse():
    infor, peirods = defaultdict( lambda : defaultdict( list) ), system.dir.peirods( prefrontal_raw = True)
    for tab in args.tabs:
        with open( tab ) as f :
            header = next(f).rstrip().split('\t')
            header_mapped = [ system.dir.str_map_peirod(i, raw = i) for i in header ]
            need_peirods = [ i for i in header_mapped if i in peirods ]
            kwargs.update({'need_peirods': need_peirods})
            fnum = 0
            for line in f :
                arr = line.rstrip().split('\t')
                arr_sorted = sorted( [ float(i) for i in arr[1:] ] )
                if not arr_sorted[-1] :
                    fnum += 1
                    continue
                if arr_sorted[-1] == arr_sorted[-2] < 1 :
                    print ( 'fiter data:', tab, line, arr_sorted[-1], file = sys.stderr )
                    continue
                symbol = arr[0].split('.')[0].upper()
                #keep raw data for enhancer or multi find function
                line_arr = line.strip().split('\t')
                infor[ tab ][ symbol ].append( [ line_arr[0], *[ float(i) for i in line_arr[1:]] ])
            print ( 'fiter data:', fnum, tab, file = sys.stderr )
    #infor = rawTab_same_symbols_pick( infor )
    kwargs.update({'infor':infor})
    return infor

def raw_infor_get_max_symbols( infor ):
    symbols = defaultdict( lambda : defaultdict( set ) )
    for tab in infor :
        for symbol in infor[tab]:
            #multi line for same symbol can be transcripts or enhancer information split to differect cluster
            for signal in infor[tab][symbol]:
                order = dict( zip(kwargs.get('need_peirods'), signal[1:] ))
                order = sorted( order.items(), key = lambda x: float( x[1] ), reverse = True)
                max_peirod = order[0][0]
                symbols[ max_peirod ][ tab ].add( symbol )
                if args.tt and symbol in args.tt:
                    print ( tab, max_peirod, symbol in symbols[ max_peirod ][ tab ], order)
    return symbols
def main():
    #same symbol name pick method default keep same with input
    infor = data_parse()
    symbols = raw_infor_get_max_symbols( infor )
    symbols = symbols_get_overlap( symbols )
    if 'prime' in args.t :
        #prime split get results
        pick_keep_pace_symbols_from_tabs( )
    elif 'match' in args.t :
        #pick_at_least_match()
        pick_keep_pace_symbols_from_tabs( )
    else :
        print ('Wrong intpu:', args.t, file = sys.stderr )

def tabs_get_overlap_rawdata( infor ):
    symbols = defaultdict( lambda : defaultdict( set) )
    symbols[ max_peirod ][ tab ].add( symbol )
    return symbols

def rawTab_same_symbols_pick( infor ):
    rout = defaultdict( lambda : defaultdict( list ) )
    print ( 'symbol same pick method:', args.sm, file = sys.stderr)
    if args.sm == 'keep':
        return infor
    elif args.sm in [ 'sum', 'max', 'maxstd' ]:
        for tab in infor:
            for symbol in infor[tab]:
                symbol_lines_values = [ [ float(j) for j in i.rstrip().split('\t')[1:] ] for i in infor[tab][symbol] ]
                if len( infor[tab][symbol] ) >= 2 :
                    if args.sm == 'sum':
                        symbol_lines_values = [[ sum(col) for col in zip( *symbol_lines_values) ]]
                    elif args.sm == 'max':
                        symbol_lines_values = [[ max(col) for col in zip( *symbol_lines_values) ]]
                    elif args.sm == 'maxstd':
                        symbol_lines_values_sorted_std = sorted( symbol_lines_values, key = lambda x: np.std( x ), reverse=False)[-1]
                        symbol_lines_values = [ symbol_lines_values_sorted_std ]
                line_format = '\t'.join( [ str(i) for i in symbol_lines_values[0] ] )
                rout[tab][symbol] = ['\t'.join([ symbol, line_format ])]
                if args.tt and symbol in args.tt:
                    print ( tab, rout[tab][symbol])
    return rout


def pick_at_least_match():
    print ('use: {} {}'.format(*args.t), file = sys.stderr)
    symbols, infor = [ kwargs.get(i) for i in ('symbols','infor')]
    #print RNA results 
    tab_print( args.tabs[-1], symbols )
    #pick correspondence results for same peirod difference from prime method but can use same function sort_between_tab
    #sort_between_tab( peirod, symbol, data, output_all, output_mini)
    #for tab in args.tabs:
    #    tab_print( tab, symbols )

#def pick_keep_pace_symbols_from_tabs():
#    symbols, infor = kwargs.get('symbols'), kwargs.get('infor')
def pick_keep_pace_symbols_from_tabs():
    symbols, infor = kwargs.get('symbols'), kwargs.get('infor')
    print ('pick_keep_pace_symbols_from_tabs', file = sys.stderr)
    outputfile = open('before_merge_files.{}{}'.format( *args.t), 'w')
    outputfile_mini = open('before_merge_files.{}{}.mini'.format( *args.t), 'w')
    print ( *kwargs.get('header'), file = outputfile_mini, sep = '\t')
    symbols_sorted_peirods = system.dir.sort( list(symbols.keys()) )
    #for peirod in symbols_sorted_peirods:
    before_tabs, last_tab = args.tabs[:-1], args.tabs[-1]
    if 'prime' in kwargs:
        tab_print( last_tab, kwargs.get('prime') )
    else :
        tab_print( last_tab, symbols )

    for peirod in symbols_sorted_peirods:
        for symbol in symbols[peirod]:
            symbol_datas = []
            for tab in before_tabs:
                for each in infor[tab][symbol]:
                    symbol_datas.append( [ tab, each ] )
            sort_output = sort_between_tab( peirod, symbol, symbol_datas, outputfile, outputfile_mini  )
    outputfile.close()
    outputfile_mini.close()

def sort_between_tab( peirod, symbol, data, output_all, output_mini):
    if args.p == 'correspondence':
        header = kwargs.get('header')
        same_peirods, symbol = [], ''
        for each in data :
            #symbol_name uniq for each tab, but maybe not bewteen peirod
            tab = each[0]
            tab_data = each[1]
            each_dit = dict( zip(header[1:], tab_data[1:]))
            #same_peirods[tab].append( each[2:] )
            tab_sort_by_max_signal = sorted( each_dit.items(), key = lambda x: x[1], reverse=False)
            tab_max_peirod = system.dir.str_map_peirod( tab_sort_by_max_signal[-1][0] )
            if args.tt and symbol in args.tt :
                print ( arr, tab_max_peirod, peirod )
            if tab_max_peirod == peirod:
                print ( tab, *tab_data, tab_max_peirod, sep = '\t', file = output_all)
                same_peirods.append( [ tab, *tab_data] )
        if len( same_peirods ) >= 2 :
            same_peirods_sorted = sorted( same_peirods, key = lambda x: np.std( x[ 2 : -1 ] ) )
            print( *same_peirods_sorted[ -1 ][1:], sep = '\t', file = output_mini )
        elif len(same_peirods) == 1 :
            print ( *same_peirods[0][1:], sep = '\t', file = output_mini )
        else :
            err_str = '\t'.join([ symbol, 'not file same with {}'.format(args.tabs[-1])]).strip()
            if err_str not in kwargs.get('err'):
                print ( err_str, file = sys.stderr)
                kwargs.get('err').add( err_str )
    elif args.p in [ 'maxstd', 'max' ]:
        if args.p == 'maxstd':
            arr = sorted( arr, key = lambda x: np.std( x[2:] ), reverse=False)
        elif args.p == 'max':
            arr = sorted( arr, key = lambda x: max( x[2:] ), reverse=False )
        return arr[-1]

def check_header():
    tabs_length = defaultdict( list )
    for tab in args.tabs:
        with open( tab ) as f :
            print ( tab, file = sys.stderr )
            header = next(f).rstrip().split('\t')
            kwargs.update({ 'header': header })
            tabs_length[tab].extend( [ len(header), header ] )
        break
    tabs_length_sorted = sorted( tabs_length.items(), key = lambda x: x[1][0], reverse=False)
    lengths = set([ i[1][0] for i in tabs_length_sorted ] )
    if len( lengths ) != 1 :
        print ( 'Must same length....', file = sys.stderr )
        print ( tabs_length_sorted, file = sys.stderr )
        exit()
    else :
        print ( 'chekc_header: ', kwargs.get('header'), file = sys.stderr )

def tab_print( tab, symbols):
    #use symbols and infor in kwargs
    infor = kwargs.get('infor')
    symbols_sorted_peirods = system.dir.sort( list(symbols.keys()) )
    with open( tab ) as f:
        keep_all = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_all'.format( args.t[0], args.sm, *args.t), 'w')
        keep_one_noCluster = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_one.noCluster'.format( args.t[0], args.sm, *args.t), 'w')
        keep_one = open( os.path.basename(tab) + '.{}.{}.{}{}.keep_one'.format( args.t[0], args.sm, *args.t), 'w')
        header = next(f).rstrip().split('\t')
        print ( *header, 'cluster', sep = '\t', file = keep_all)
        print ( *header, 'cluster', sep = '\t', file = keep_one)
        print ( *header, sep = '\t', file = keep_one_noCluster)
        for peirod in symbols_sorted_peirods:
            for symbol in symbols[peirod]:
                rna_tab = args.tabs[-1]
                multi_pick_peirod_match( peirod, infor[tab][symbol], keep_all, keep_one, keep_one_noCluster )
        keep_all.close()
        keep_one.close()
        keep_one_noCluster.close()
def multi_pick_peirod_match( peirod, data, keep_all, keep_one, keep_one_noCluster):
    header = kwargs.get('header')
    lst = []
    i = 0
    for each in data:
        edit = dict(zip(header[1:], each[1:]))
        esorted = sorted( edit.items(), key = lambda x:x[1] )
        emax_peirod = system.dir.str_map_peirod( esorted[-1][0] )
        if emax_peirod == peirod :
            #one is ok for go and another analysis
            e_no_cluster = '\t'.join( map(str, each) )
            e_str = '\t'.join( [ e_no_cluster, peirod ] )
            i += 1
            if i == 1 :
                print ( e_str, file = keep_one)
                print ( e_no_cluster, file = keep_one_noCluster)
            print ( e_str, file = keep_all)
            lst.append( e_str )



if __name__ == '__main__':
    kwargs = vars( args )
    kwargs.update( {'log': False, 'peirods_sorted': system.dir.peirods( prefrontal_raw = True )} )
    kwargs.update({'err':set()})
    check_header()
    main()





















