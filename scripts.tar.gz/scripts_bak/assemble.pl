#!/usr/bin/perl -w

unless(@ARGV){
	print "\n\tUsage:\t$0 infor.txt\n\t\t1 for auto\n";
}
else{
	open $infor,"$ARGV[0]";
	open $log,"> assemble.sh";
	while(<$infor>){
		chomp;
		@tmp = split /\s+/,$_,2;
		$infor{$tmp[0]} = $tmp[1];
	}

	if($infor{'reference'} =~ /yes/){
		for(keys %infor){
			if(/sample/i){
				($forward,$reverse) = split /\s+/,$infor{$_};
				$dir = $forward;
				$reverse = $reverse;
				$dir =~ s/_[12]\..*//;
				`mkdir -p /$infor{'output_dir'}/$infor{'contract'}/assemble/$dir`;
				$cmd_1 = "cufflinks -p 8 -o /$infor{'output_dir'}/$infor{'contract'}/assemble/$dir /$infor{'output_dir'}/$infor{'contract'}/mapping/$dir/accepted_hits.bam";
				print $log "$cmd_1\n\n";
				if(@ARGV >= 2){
					`$cmd_1`;
				}
			}
		}
	}
}
