#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome,geneKit,bedKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='this script already concert the chain\nbed_peaks_mapping.py -bed /home/ningch/data/genome/rheMac8/exon/ref.ens.xeon.coding.gene -peak K4.bed.bw.tab', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'peak', nargs = '?', help ='peak file for the mapping' )
parser.add_argument( '-bed', nargs='?', help ='bed file you want to extract peaks', default = '/home/ningch/data/genome/rheMac8/exon/ref.ens.xeon.coding.gene' )
parser.add_argument( '-res', nargs = '?', help ='res for find gene', type = int, default = 40000 )
parser.add_argument( '-o', nargs = '?', help =' output file' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def get_bin( pos, span):
    pos = float(pos)
    span = float(span)
    float_return = pos / span
    int_return = int(pos) / int(span)
    if float_return == int_return :
        return int_return
    else :
        return int_return + 1

def parseGene2dict( annot, res ):
    infor,chroms = {},list(chromosome.chr('rh8').schr())
    with open(annot) as fh:
        for line in fh:
            line_arr = line.strip().split('\t')
            chrom,start,end = line_arr[0:3]
            if chrom not in chroms:
                continue
            gene,chain = line_arr[3],line_arr[5]
            start,end = int(start),int(end)
            if chain == '+':
                pos_bin = get_bin(start, res)
            else :
                pos_bin = get_bin(end, res)
            key = ','.join([chrom, gene, chain, str(pos_bin)])
            trick.set2dict(infor, chrom, pos_bin, [])
            infor[chrom][pos_bin].append(key)
    return infor

def peakGetInfor( peak, res, infor, ofh):
    with open( peak ) as fh:
        for line in fh:
            line_arr = line.strip().split('\t')
            chrom, start = line_arr[0:2]
            pos_bin = get_bin( start, res)
            for each in infor[chrom][pos_bin]:
                ofh.write(each + '\n')



if __name__ == '__main__':
    annot, peak, res = args.bed, args.peak, args.res
    ofh = sys.stdout
    if args.o :
        ofh = open(args.o,'w')
    infor = parseGene2dict( annot, res)
    peakGetInfor( peak, res, infor, ofh)




