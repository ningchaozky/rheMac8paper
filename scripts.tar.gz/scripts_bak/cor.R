#!/usr/bin/env Rscript
#first
#vegan can use for spider line
alen <- commandArgs()
library(argparser)
library(gridGraphics)
library(ggplot2)
p <- arg_parser('mds matrix data')
p <- add_argument(p, "--matrix", help="matrix for plot each with one col")
p <- add_argument(p, "--fiter", nargs = 'Inf', help="fiter coloum|coloums, chr,start,end", default = 'chr,start,end')
p <- add_argument(p, "--include", nargs = '?', help="last inclue you want to add. 20Y.PFC.CTCF.rep1,20Y.PFC.pol2.rep1", default = '')
p <- add_argument(p, "--dodge",short = '-d', nargs = '?', help="last inclue you want to add. 20Y.PFC.CTCF.rep1,20Y.PFC.pol2.rep1", default = 0)
p <- add_argument(p, "--fiterKey", nargs = '?', help="fiter key for not plot in the results", default = 'Input')
p <- add_argument(p, "--dmethod", nargs = '?', help="pearson|..", default = 'pearson')
p <- add_argument(p, "--dim", help="dimensions. 2(default)|3")
p <- add_argument(p, "--hclustMethod", help="dist method. euclidean(default)|maximum|manhattan|canberra|minkowski|binary|centroid|average|ward|mcquitty|median|complete|single", default = "ward")
p <- add_argument(p, "--out", help="output file", default="output")
p <- add_argument(p, "--cex", help = "cex size for front", default= '0.5')
p <- add_argument(p, "--shapePos", help = "pos for same", default= '1')
p <- add_argument(p, "--colorPos", help = "pos for same", default= '1')
if ( is.null(p$help) || length(alen) < 5) {
        print(p)
        quit(status=1)
}
args <- parse_args(p)
fiter <- args$fiter
width <- args$dodge
cex <- as.numeric(args$cex)
fiterKey <- unlist(strsplit(args$fiterKey,','))
shape <- as.numeric(args$shapePos)
color <- as.numeric(args$colorPos)
fiter <- unlist(strsplit(fiter,','))
data_frame <- read.table(args$matrix,header = T, check.names = F)
data_frame <- data_frame[complete.cases(data_frame),]
data_frame <- data_frame[,!names(data_frame) %in% fiter]
data_frame_col <- colnames(data_frame)

for(i in fiterKey){
    data_frame_col <- data_frame_col[!grepl(i, data_frame_col)]
}

if ( args$include != '') {
    include <- unlist(strsplit(args$include,','))
    data_frame_col <- c(data_frame_col,include)
}

data_frame <- data_frame[,data_frame_col]
colnames(data_frame)


dist <- function(x, ...){
    if (args$dmethod == "pearson"){
        as.dist(1-cor(x, method=args$dmethod))
    } else {
        dist(x,method=args$dmethod)
    }
}

dist <- dist(as.matrix(data_frame), method=args$dm)
mds <- as.data.frame(cmdscale(dist))
colnames(mds) <- c('dim1','dim2')
pdf(paste(args$out,".pdf",sep=''))
#plot(mds, type = 'n', axes = FALSE, xlab = 'dim1', ylab = 'dim2')
name <- names(data_frame)
namelst <- strsplit(rownames(mds),'\\.')
mds$shape <- sapply(namelst,function(x) x[shape])
mds$color <- sapply(namelst,function(x) x[color])
#pch <- sample(1:25,,replace=T)
#pch <- c(21,22,17,12,7)
#plot(mds, xaxt="n", yaxt="n", xlab = 'dim1', ylab = 'dim2', pch=shape, col=color)
#p <- ggplot(mds, aes(dim1,dim2, label = rownames(mds)))
p <- ggplot(mds, aes(dim1,dim2, label = shape))
p <- p + geom_point(aes(shape = shape, color = color)) + geom_text(check_overlap = TRUE, size = 2, aes(dim1,dim2+width,color = color), position=position_dodge(width=width))
p <- p + theme_bw()
p + theme(axis.line = element_line(colour = NA ),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    #panel.border = element_blank(),
    panel.background = element_blank())
dev.off()

pdf(paste(args$out,"hc.pdf",sep=''))
hc <- hclust(dist, method = args$hclustMethod)
plotfun <- function() plot(hc, cex = cex)
plotfun()




grab_grob <- function(){
      grid.echo()
        grid.grab()
}
#g <- grab_grob()
#grid.newpage()
#pushViewport(viewport(width=0.7,angle=30))
#grid.draw(g)
dev.off()












