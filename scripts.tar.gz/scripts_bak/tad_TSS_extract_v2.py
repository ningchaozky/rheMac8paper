#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tab', nargs='?', help = 'diff tad merge file')
parser.add_argument( '-tss', nargs='?', help = 'tss file', default = '/home/soft/data/genome/rheMac8/annot/ucsc/finally/gene.hg38.mm10.tssUpDown3K.bed')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



cmd = '''bedtools intersect -b {} -a {}  -wo| less'''.format( args.tab, args.tss)
stdout = system.run( cmd, shell = True )
lst = []
for line in stdout :
    line = line.replace('\"','')
    line_arr = line.rstrip().split('\t')
    key = [ line_arr[3], *line_arr[15:17] ]
    source = line_arr[-2]
    if '|' not in line :
        print ( line, file = sys.stderr )
        continue
    source_arr = source.split('|')
    typ = 'other' if 'NA' in source_arr[-2] else source_arr[-2]
    #lst.append( [ '|'.join( key ).replace(' ','_'), *line_arr[6:9] ] )
    lst.append( '|'.join( [ line_arr[3], typ.replace(' ','_') ] ) )

lst = sorted( lst, key = lambda x: x.split('|')[1], reverse = False)
print ( 'symbol', sep = '\t')
output = defaultdict( str )
for each in lst :
    typ = each.split('|')[1].replace(' ','_')
    if typ not in output:
        output[typ] = open( fix.fix( args.tab, abspath = True).append( typ ), 'w')
        print ( 'symbol', sep = '\t', file = output[typ])
    print ( each, sep = '\t', file = output[typ] )






















