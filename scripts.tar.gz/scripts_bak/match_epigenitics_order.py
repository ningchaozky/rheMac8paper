#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from scipy import stats
from itertools import product
from ningchao.nSys import trick, fix
from collections import defaultdict
from pandas.api.types import union_categoricals

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'signalFiles', nargs = '+', help = 'match_epigenitics.py output signal file')
parser.add_argument( '-peirod','-p', nargs = '?', help = 'peirod', required = True)
parser.add_argument( '-geneBed', nargs = '?', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.geneTransPromoterMean', help = 'geneBed file ')
parser.add_argument( '-normal', choices = ['zscore','hardCut'], help = 'zscore or hardCut to 0 and 1', default = 'zscore')
parser.add_argument( '-value', nargs = '?', help = 'cutoff for signal sort', default = 10, type = float)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def all_symbol_get( **kwargs ):
    infor = defaultdict( list )
    order = set()
    with open( kwargs.get('geneBed') ) as f:
        for line in f:
            line_arr = line.strip().split('\t')
            transcript_id, symbol = line_arr[3], line_arr[6]
            infor[symbol].append( transcript_id )
            order.add( transcript_id )
    return infor, order


def calculate( fl, order, **kwargs):
    infor, trans_length = defaultdict( float ), defaultdict( int )
    with open( fl ) as f :
        for line in f:
            line_arr = line.strip().split('\t')
            #transcript_id 3, symbo_id, 5
            trans_id, signal = line_arr[3], line_arr[-1]
            infor[ trans_id ] += float( signal )
            trans_length[ trans_id ] += int( line_arr[2] ) - int( line_arr[1] )
    for trans_id in order:
        if not infor.get(trans_id):
            infor[trans_id] = 0
        else :
            old = infor[trans_id]
            infor[trans_id] = ( infor[trans_id] * 1000.0) / trans_length[trans_id]
    return infor

def selfSort( dit, **kwargs):
    cutoff_dit = kwargs.get('cutoff')
    header = dit.pop('header')
    lst, out = list( dit.items() ), []
    for i, marker in enumerate( header ):
        lst = sorted( lst, key = lambda x: x[1][i], reverse = True )
        for j, val in enumerate( lst ):
            if marker in cutoff_dit:
                cutoff = cutoff_dit[ marker ]
            else :
                cutoff = cutoff_dit['default']
            lst[j] = list( lst[j] )
            #if marker == 'lad':
            #    print (marker, cutoff, lst[j][1][i] )
            lst[j][1][i] = lst[j][1][i] > cutoff and 1 or 0
            #if marker == 'lad':
            #    print (marker, cutoff, lst[j][1][i] )
    for each in lst:
        trans_id, vals = each
        out.append( [ trans_id, *vals ] )
    df = pd.DataFrame( out, columns = ['trans_id', *header ])
    return df



def signal_order( fls, order, **kwargs):
    raw_file, raw_infor, zscore_infor = defaultdict( str ), defaultdict( lambda : defaultdict ( float ) ), defaultdict( lambda : defaultdict(float))
    fls, infor = iter(fls), defaultdict( list )
    for name in fls:
        raw_file[ name ] = next( fls  )
        signal = calculate( raw_file[ name ], order, **kwargs)
        with open( raw_file[ name  ] ) as f :
            for line in f :
                line_arr = line.strip().split('\t')
                #raw_infor[name][line_arr[3]] = float( line_arr[-1] )
                raw_infor[name][line_arr[3]] = float( signal[line_arr[3]] )
        infor['header'].append( name )
        for trans_id in signal:
            infor[ trans_id ].append( signal[ trans_id ])
    df = selfSort( infor, **kwargs)
    df['hic'] = df['hic'].astype("str")
    df['spd'] = df['spd'].astype("str")
    df['lad'] = df['lad'].astype("str")
    df['group'] = 'c' + df['hic'] + df['spd'] + df['lad']
    xls = '{}.{}.order.xls'.format( args.peirod, 'hardCut{}'.format(args.value) )
    df.to_csv( xls, sep = '\t', index_label = 'gene_id', index = None )
    transId_group = dict( zip( df['trans_id'], df['group'] ) )

    for marker in raw_infor:
        trans_ids = [ k for k,v in raw_infor[marker].items() ]
        vals = [ raw_infor[marker].get(k) for k in trans_ids ]
        zscore_infor[marker] = dict( zip( trans_ids, stats.zscore( vals, ddof=1 )))
        raw_infor[marker] = dict( zip( trans_ids, vals))
    fh = open( fix.fix(xls).insert('zscore'),'w' )
    rfh = open( fix.fix(xls).insert('raw'),'w' )
    with open( xls ) as f:
        header = next(f).strip().split('\t')
        print ( *header, 'chic', 'slad', 'cspd', sep = '\t', file = fh)
        print ( *header, 'chic', 'slad', 'cspd', sep = '\t', file = rfh)
        for line in f:
            line_arr = line.strip().split('\t')
            line_arr[1:-1] = [ zscore_infor[marker].get(line_arr[0]) for marker in header[1:-1] ]
            line_arr[1:-1] = [ i and i or 0 for i in line_arr[1:-1] ]
            hic, spd, lad = list( line_arr[-1].replace('c','') )
            print ( *line_arr, hic, lad, spd, sep = '\t', file = fh )
            line_arr[1:-1] = [ raw_infor[marker].get(line_arr[0]) for marker in header[1:-1] ]
            line_arr[1:-1] = [ i and i or 0 for i in line_arr[1:-1] ]
            print ( *line_arr, hic, lad, spd, sep = '\t', file = rfh )
    fh.close()
    rfh.close()
if __name__ == '__main__':
    symbols, order = all_symbol_get( ** vars(args) )
    cutoff= {'lad': 500, 'default': args.value, 'spd': 500, 'RNA': 20, 'H3K9me3': 20, 'AC': 10, 'hic': 50}
    signal_order( args.signalFiles, order, cutoff = cutoff)




























