#!/usr/bin/env python3
import os
import sys
import gzip
import argparse
from ningchao.nSys import system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('gz', nargs='?', help ='fq.gz')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



cwd = os.getcwd()

cmd = 'unpigz -p 8 -c {} | wc -l'.format( args.gz )
outfile = os.path.join(cwd, fix.fix( args.gz ).append( 'reads' ) )

calculate = [ False ]
if os.path.exists( outfile ) and os.path.getsize(outfile) == 0 :
    calculate = [ True, outfile, os.path.getsize(outfile), 'exists' ]
elif not os.path.exists( outfile ) :
    calculate = [ True, outfile, 'not exists' ]

if calculate[0] :
    print ( calculate, file = sys.stderr )
    ofh = open( outfile, 'w')
    for line in system.run( cmd, shell = True):
        print ( os.path.basename(args.gz), args.gz, line, file = ofh )
    ofh.close()
else :
    size = os.path.getsize(outfile)
    print ('Already got!!', calculate, 'size:', size, file = sys.stderr )
























