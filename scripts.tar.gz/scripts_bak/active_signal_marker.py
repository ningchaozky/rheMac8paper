#!/usr/bin/env python
import os
import sys
import argparse
import numpy as np
from ningchao.nSys import trick, system, fix
from ningchao.nBio import chromosome,bw
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'p', nargs='?', help = 'pattern for find file' )
parser.add_argument( '-s', nargs='?', type = int, help = 'bin for noraml', default = 50 )
parser.add_argument( '-c', nargs='?', type = float, help = 'float cut for peak', default = 5 )
parser.add_argument( '-r', action='store_true', help = 'reverse for K27' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def init( args ):
    fls = list( system.dir().fls( args.p, fpattern = 'norm') )
    sys.stderr.write( str( len(fls)) + '\t' + ','.join( fls ) + '\n' )
    chroms = bw.bw(fls[0]).chroms( typ = 'sorted' )
    outfls = [ open(fix.fix(i).change('norm.bdg'),'w') for i in fls ]
    return fls, chroms, outfls

def lst_norm( lst, cut ):
    index = False 
    for each in lst:
        if max( each ) > cut:
            index = True
            break
    if index :
        lst = [ np.mean(i) for i in lst ]
        scale, min_val = max( lst ) - min( lst ), min(lst)
        val = [ (i-min_val)/scale for i in lst ]
        val = args.r and [ -i for i in val ] or val
    else :
        val = [ 0 for i in lst ]
    return val

def write( region, vals, outfls ):
    dit = dict(zip(outfls, vals))
    for fh in dit:
        fh.write( '\t'.join( [ region, str(dit[fh]) ] ) +'\n' )


def normal( fls, chroms, cut, span):
    fls = [ bw.bw(i).raw() for i in fls ]
    for chrom, clen in chroms:
        sys.stderr.write( '#%s' % chrom +'\n')
        for start in range(0, clen, span ):
            end = start + span
            if end > clen:
                continue
            lst = [ i.values( chrom, start, end ) for i in fls ]
            yield '\t'.join([chrom, str(start), str(end)]), lst_norm(lst, cut)


def main( ):
    fls, chroms, outfls = init( args )
    for region, vals in normal( fls, chroms, args.c, args.s):
        write( region, vals, outfls )
    [ i.close() for i in outfls ]

if __name__ == '__main__':
    main()

























