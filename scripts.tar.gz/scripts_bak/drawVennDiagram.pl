#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Basename;
use Cwd;
my $cwd = getcwd();


sub Usage{
  print STDERR << "USAGE";
  Description: Draw Venn diagram script
  Author: ningchao\@ioz.ac.cn
  Version: 1.0
======================================================================================
Options:
  
			-i  --in   <s>  input file
			-o  --out  <s>  output directory
			-h  --help      print this help info
		  
======================================================================================		  
USAGE

}



my ($infile,$outdir,$help);

GetOptions("in|i=s" => \$infile,
	   "out|o=s" => \$outdir,
	   "help|h" => \$help);
		   
if( !defined($infile) ||
    $help ) {
  &Usage();
  
  exit(0);
}

$outdir |= "./";

open IN,"<$infile" || die "Cannot open this file!$!";
my $header = <IN>;
chomp $header;
my @groups = split /\t/,$header;

shift @groups;
my $groupNum = scalar @groups;
my @deg = ();

while(<IN>) {
  chomp;
  my @line = split /\t/,$_;
  foreach my $i(0 .. $groupNum - 1) {
    if($line[$i + 1] > 0) {
	  push @{$deg[$i]},$line[0];
	}
  }
}

close IN;

chdir $outdir || die "Cannot chdir to this directory!$!";

### output DEGlist
foreach my $i(0 .. $#groups) {
  &outputDEGlist($groups[$i],$deg[$i]);
}

### Draw Venn diagram based on the number of data sets
if($groupNum == 2) {
  &implementTwoSets(\@groups);
  system("echo 'Rscript venn.r $groups[0] $groups[1]' >venn.sh");
  
} elsif($groupNum == 3) {
  &implementThreeSets(\@groups);
  system("echo 'Rscript venn.r $groups[0] $groups[1] $groups[2]' >venn.sh");
} elsif($groupNum == 4) {
  &implementFourSets(\@groups);
  system("echo 'Rscript venn.r $groups[0] $groups[1] $groups[2] $groups[3]' >venn.sh");
} elsif($groupNum == 5) {
  &implementFiveSets(\@groups);
  system("echo 'Rscript venn.r $groups[0] $groups[1] $groups[2] $groups[3] $groups[4]' >venn.sh");
} else {
  print STDERR "groups too many!\n Draw venn diagram for top 5 groups\n";
  my @tmpGroups = ();
  foreach my $i(0 .. 4) {
    push @tmpGroups,$groups[$i];
  }
  &implementFiveSets(\@tmpGroups);
  system("echo 'Rscript venn.r $tmpGroups[0] $tmpGroups[1] $tmpGroups[2] $tmpGroups[3] $tmpGroups[4]' >venn.sh")
}




### subroutine input files for venn.r
sub outputDEGlist($$) {
  my $out = shift;
  my $arr = shift;
  open OUT,">$out" || die "Cannot write to this file!$!";
  foreach my $i(0 .. $#$arr) {
    print OUT "$arr->[$i]\n";

  }
  close OUT;

}

### 2-sets
sub implementTwoSets {
  my $group = shift;
  
  open SCRIPT,">venn.r" || die "Cannot write to this file!$!";
  my $script =<<"EOF";
library(Vennerable)

Args <- commandArgs()
file1 <- Args[6]
file2 <- Args[7]

pdf('venn.pdf')
png('venn.png')
  
first <- read.table(file1,sep="\\t")
second <- read.table(file2,sep="\\t") 

first_arr <- as.vector(first\$V1)
second_arr <- as.vector(second\$V1) 
  
VennObject <- list($group->[0]=first_arr,$group->[1]=second_arr)  

VennFigure <- Venn(VennObject)

plot(VennFigure,doWeights = FALSE)
dev.off()

plot(VennFigure,doWeights = FALSE)
dev.off()

EOF
  
  print SCRIPT $script;
  
  close SCRIPT;
}


### 3-sets
sub implementThreeSets {
  my $group = shift;
  open SCRIPT,">venn.r" || die "Cannot write to this file!$!";
  my $script =<<"EOF";
library(Vennerable)

Args <- commandArgs()
file1 <- Args[6]
file2 <- Args[7]
file3 <- Args[8]

pdf('venn.pdf')
png('venn.png')
  
first <- read.table(file1,sep="\\t")
second <- read.table(file2,sep="\\t")  
third <- read.table(file3,sep="\\t")

first_arr <- as.vector(first\$V1)
second_arr <- as.vector(second\$V1) 
third_arr <- as.vector(third\$V1) 
  
VennObject <- list($group->[0]=first_arr,$group->[1]=second_arr,$group->[2]=third_arr)  

VennFigure <- Venn(VennObject)

plot(VennFigure,doWeights = FALSE)
dev.off()

plot(VennFigure,doWeights = FALSE)
dev.off()

EOF
  
  print SCRIPT $script;
  
  close SCRIPT;
}


### 4-sets
sub implementFourSets {
  my $group = shift;
  open SCRIPT,">venn.r" || die "Cannot write to this file!$!";
  my $script =<<"EOF";
library(Vennerable)

Args <- commandArgs()
file1 <- Args[6]
file2 <- Args[7]
file3 <- Args[8]
file4 <- Args[9]

pdf('venn.pdf')
png('venn.png')
  
first <- read.table(file1,sep="\\t")
second <- read.table(file2,sep="\\t")  
third <- read.table(file3,sep="\\t")
fourth <- read.table(file4,sep="\\t")

first_arr <- as.vector(first\$V1)
second_arr <- as.vector(second\$V1) 
third_arr <- as.vector(third\$V1) 
fourth_arr <- as.vector(fourth\$V1) 
  
VennObject <- list($group->[0]=first_arr,$group->[1]=second_arr,$group->[2]=third_arr,$group->[3]=fourth_arr)  

VennFigure <- Venn(VennObject)

plot(VennFigure,doWeights = FALSE,type="ellipses")
dev.off()

plot(VennFigure,doWeights = FALSE,type="ellipses")
dev.off()

EOF
  
  print SCRIPT $script;
  
  close SCRIPT;
}


### 5-sets
sub implementFiveSets {
  my $group = shift;
  open SCRIPT,">venn.r" || die "Cannot write to this file!$!";
  my $script =<<"EOF";
library(gplots)

Args <- commandArgs()
file1 <- Args[6]
file2 <- Args[7]
file3 <- Args[8]
file4 <- Args[9]
file5 <- Args[10]

pdf('venn.pdf')
png('venn.png')

first <- read.table(file1,sep="\\t")
second <- read.table(file2,sep="\\t")  
third <- read.table(file3,sep="\\t")
fourth <- read.table(file4,sep="\\t")
fifth <- read.table(file5,sep="\\t")

first_arr <- as.vector(first\$V1)
second_arr <- as.vector(second\$V1) 
third_arr <- as.vector(third\$V1) 
fourth_arr <- as.vector(fourth\$V1) 
fifth_arr <- as.vector(fifth\$V1)

VennObject <- list($group->[0]=first_arr,$group->[1]=second_arr,$group->[2]=third_arr,$group->[3]=fourth_arr,$group->[4]=fifth_arr)  

venn(VennObject)

dev.off()

venn(VennObject)
dev.off()

EOF

  print SCRIPT $script;
  
  close SCRIPT;
}
