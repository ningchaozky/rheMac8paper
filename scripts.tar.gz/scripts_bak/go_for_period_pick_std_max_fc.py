#!/usr/bin/env python3
import os
import sys
import argparse
import numpy as np
from ningchao.nSys import trick, system
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
parser.add_argument('-t', nargs='+', help = ''' ['max','fcNear','fcAll','std']''', default = ['max','fcNear','fcAll','std'])
parser.add_argument('-n', nargs = '?', help = 'num or percent for each period if <=1 is percent cut', default = 0.2, type = float)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def parse_data():
    infor = defaultdict( list )
    header, fh = system.dir.fl_infor( args.tab )
    kwargs.update( { 'header': header } )
    now_pos = fh.tell()
    with_period_on_line = system.dir.line_period_check( next(fh) )
    fh.seek( now_pos )
    if with_period_on_line :
        for v, line in enumerate( fh ) :
            if not v % 1000 :
                print ( v, line, file = sys.stderr )
            line_arr = line.rstrip().split('\t')
            with_period_on_line = system.dir.line_period_check( line_arr )
            if with_period_on_line :
                for pos, period in with_period_on_line.items():
                    period = line_arr[ pos ]
                    line_arr_without_period = [ i for i,v in enumerate( line_arr ) if i not in with_period_on_line ]
                    line_arr_del_period = list(map( line_arr.__getitem__, line_arr_without_period ))
                    line_arr_del_period[1:] = list( map( float, line_arr_del_period[1:] ) )
                    infor[ period ].append( line_arr_del_period )
    else :
        for v, line in enumerate( fh ) :
            if not v % 1000 :
                print ( v, line, file = sys.stderr )
            line_arr = line.rstrip().split('\t')
            gene = line_arr[0]
            d = dict( zip( header[1:], map( float, line_arr[1:] )) )
            d_sorted = sorted( d.items(), key = lambda x: x[1] )
            period = system.dir.str_map_period( d_sorted[ -1 ][0] )
            line_arr[1:] = list( map( float, line_arr[1:] ))
            infor[ period ].append( line_arr )
    for period in infor :
    #    print ( [ str(i) + period for i in infor[period] ])
        print ( 'Log:', period, len(infor[period]), file = sys.stderr )
    return infor



def cal_fc( line_arr, pos ):
    line_arr[1:] = [ i + 0.1 for i in line_arr[1:] ]
    if args.t == 'fcNear':
        if pos == 1 :
            return line_arr[1]/line_arr[2]
        elif pos == len( kwargs.get('header') ) - 1 :
            return line_arr[-1]/ line_arr[-2]
        else :
            return max([ line_arr[pos] / line_arr[pos-1], line_arr[pos]/ line_arr[pos+1]])
    else :
        return max([ line_arr[ pos ] / i for i in line_arr[1:] ])

def sort( d ):
    for period in d :
        with open( 'split.{}.{}-{}.run_kobas'.format( period, '_'.join(args.t), args.n ), 'w') as f:
            data = d[period]
            period_length = len( d[period] )
            if args.n <= 1 :
                cut = period_length * args.n
                print ( 'Choose percent: {}, {} gene for {}'.format(args.n, int(cut), period), file = sys.stderr)
            else :
                print ( 'Choose num: {}'.format(args.n), file = sys.stderr)
                cut = args.n
            pos = [ i for i,v in enumerate( [ system.dir.str_map_period(j) for j in kwargs.get('header') ] ) if period in v ]
            if not pos or len(pos) != 1 :
                print ( period, 'not find in', kwargs.get('header'), sep = '\t', file = sys.stderr)
            else :
                pos = pos[0]
            print ( period, pos )
            print ( *kwargs.get('header'), sep = '\t', file = f)
            for t in args.t:
                if t == 'max':
                    dsort = sorted( data, key = lambda x: x[ pos ], reverse = True )
                elif t == 'std' :
                    dsort = sorted( data, key = lambda x: np.std(x[1:]), reverse = True )
                elif t in [ 'fcNear', 'fcAll']:
                    dsort = sorted( data, key = lambda x: cal_fc( x, pos ), reverse = True )
                for i, line in enumerate( dsort ) :
                    if i < cut :
                        print ( *line, sep = '\t', file = f )
            f.close()
            cmd = '''awk '!x[$1]++' {} >1fadfasd; mv 1fadfasd {}'''.format( f.name, f.name )
            system.run( cmd, shell = True, noReturn = True )



def main():
    infor = parse_data()
    sort( infor )

if __name__ == '__main__':
    kwargs = vars( args )
    main()



























