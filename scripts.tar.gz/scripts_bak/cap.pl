#!/usr/bin/perl -w

unless(@ARGV){
print "Usage:\n\tcap.pl dir\n";
print "Give the dir and i will give you the cap squence you want.\nSeq should have two files with zip as suffix\n\n";
}
else{

opendir DIR,"$ARGV[0]";
@zips = grep /\d+\.zip/, readdir DIR;

for(@zips){
`unzip -o $ARGV[0]/$_`;
}

opendir DIR,".";
@seq2 = @seq1 = grep /seq$/,readdir DIR;
for(@seq1){
open TEM,"> temp.fa";
print TEM ">$_\n";
open SEQ,"$_";
my $name = quotemeta $_;
my $seq;
	while(<SEQ>){
	s///g;
	s/\n//g;
	$seq .= $_;
	}
print TEM substr($seq,0,860)."\n";
close TEM;
`mv temp.fa $name.860.txt`;
}

my %count;
@seq2 = grep{++$count{$_} <2} map{(split /\(/,$_)[0]} @seq2;

for(@seq2){
$_ = quotemeta;
`cat $_*860.txt > temp.fa;cap3 temp.fa -p 85; mv temp.fa.cap.contigs $ARGV[0]/$_.cap.fa`;
}

`rm *ab1 *seq temp*`;

close DIR;
}
