#!/usr/bin/env python
import os
import sys
import random
import argparse
import matplotlib
from functools import reduce
from  itertools import chain, combinations
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib_venn import venn2,venn3
from ningchao.nSys import trick, fix, excel
from collections import defaultdict
import pandas as pd
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='45Yh20Y.xls.nfc5.symbol,1,h /home/soft/data/genome/rheMac8/ageing/ageing.genes', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('mat', nargs = '+', help ='matrix for venn')
parser.add_argument('-must', nargs = '?', help ='symbols for must in the list calculate')
parser.add_argument('-pdf', nargs = '?', help ='pdf name')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

def printIntersections( dit ):
    order = dit.keys()
    outputfile = open( fix.fix( args.pdf ).append('tab'), 'w')
    combs = list(chain(*map(lambda x: combinations(order, x), range(0, len(order)+1))))
    for comb in combs:
        comb = list( comb )
        if len( comb ) >= 2 :
            print ( comb )
            a = set(dit[comb.pop(0)])
            for e in comb :
                a = a.intersection( set( dit[e] ) )
            for each in a:
                print ( each, file = outputfile )
    #out = reduce( set.intersection , [ set(val) for val in dit.values() ] )


def getSet():
    infor = defaultdict( set )
    mats = excel.parse( args.mat )
    if args.must:
        must_excel, must_para = excel.parse( args.must )
        mdf = pd.read_csv( must_excel, **must_para )
        must_symbols = [ i.upper() for i in mdf.index ]
    for m, m_kwargs in mats :
        df = pd.read_csv( m, **m_kwargs )
        for each in df.index :
            if isinstance( each, float ):
                continue
            symbol = each.split('.')[0].upper()
            if args.must:
                if symbol not in must_symbols:
                    print ( symbol, 'fitered')
                    continue
            infor[ m ].add( symbol )
            #for line in f :
            #    line_arr = line.strip().split('\t')
            #    infor[each].add( line_arr[0].split('.')[0].upper() )
            #    infor[each].add( line_arr[0] )
    return infor
infor = getSet()
for each in infor :
    print ( each, len( infor[each] ) )
h = '''venn%d( subsets = infor.values(), set_labels = infor.keys() )''' % len( infor )
v = eval( h )

printIntersections( infor )
if not args.pdf:
    name = ''.join(chr(random.randrange(65,90)) for i in range(6))
else :
    name = fix.fix( args.pdf ).append('pdf')
#venn2(subsets = (3, 2, 1))
#venn3([set(['A', 'B', 'C', 'D']), set(['D', 'E', 'F']), set(['D', 'E', 'F'])])
#venn3(subsets = ( 3247, 2153, 500, 898, 300, 200, 79 ), set_labels = ('Set1', 'Set2', 'Set3'))
plt.savefig( '{}.venn.pdf'.format(name),format = 'pdf')

os.system('link_generate.py {}.venn.pdf'.format(name))




