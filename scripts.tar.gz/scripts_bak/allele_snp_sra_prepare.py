#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
#plt.style.use('ggplot')
import argparse
from ningchao.nSys import trick, system, status
from ningchao.nBio import rheMac
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'ini', nargs = '?', help = 'ini from 82')
parser.add_argument( '-specify', nargs = '+', help = 'specify for select srr', required = True )
parser.add_argument( '-rutine', nargs = '?', help = 'rutine for analysis')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

infor = rheMac.infor( **vars( args) )
add, dit = infor.mergeAdds()
wds = {}
for wd in infor.work_dirs():
    if 'SRR' not in wd :
        continue
    rlpath = os.path.dirname(wd).replace('/pnas/liujiang_group/ningch/data/chipseq/neuro/rawdata/','')
    outputdir = '/uDiskE/data/early_embryo/{}/{}'.format( args.specify[0], rlpath )
    wds.update( {os.path.basename(wd): outputdir } )
trims = infor.TM()
already = []
outputdir = '/uDiskE/data/early_embryo/{}'.format(args.specify[0])
system.dir( outputdir ).check()
for srr in trims:
    wd = trims[srr]['work_dir'].replace('/pnas/liujiang_group/ningch/data/chipseq/neuro/rawdata/', wds[srr])
    srra = srr +'.sra'
    stdout = system.run('data_sync_check.py {}'.format(srra), shell = True)
    for each in stdout:
        if '#' in each :
            continue
        each_arr = each.split('\t')
        pos = each_arr[0]
        already.append(srr)
        ln = 'ln -s {} {}'.format( pos, wds[srr] )
        ln = status.cmd(wds[srr]).accessory( ln, flag = 'ln-s')
        print (ln)
    if srr not in already:
        cmd = 'prefetch {} --max-size 100G  --output-directory {}'.format( srr, wds[srr])
        print ( cmd )























