#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system, fix, status
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('macsdir', nargs = '?', help = 'bdg')
parser.add_argument('-gs', nargs = '?', help = 'genome size file', required = True)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def scale_factor( wd, **kwargs):
        dit, treatment, control = defaultdict( float ), 0, 0
        for xls in system.dir(wd).fls('xls$'):
            if '_peaks.xls' not in xls :
                continue
            macs_name = os.path.basename(xls).replace('_peaks.xls', '')
            with open ( xls ) as f :
                for line in f :
                    if '# total tags in treatment:' in line:
                        treatment = int( line.strip().replace('# total tags in treatment:', '')) / 1000000
                    if '# total tags in control:' in line :
                        control = int( line.strip().replace('# total tags in control:', '')) / 1000000
                dit[macs_name] = max([treatment,control])
        return dit

def bdg2w( bdg ):
    sort_bdg = fix.fix(bdg).insert('sort')
    bw = fix.fix(sort_bdg).change('bw')
    cmd = 'sort -k1,1 -k2,2n {} > {}'.format( bdg, sort_bdg)
    print (status.cmd_accessory(cmd, wd = wd, flag = 'sortbdg.{}'.format(name)) )
    cmd = 'bedGraphToBigWig {} {} {}'.format( sort_bdg, args.gs, bw )
    print (status.cmd_accessory(cmd, wd = wd, flag = 'bedGraphToBigWig.{}'.format(name)) )



for xls in system.dir(args.macsdir).fls('xls$'):
    bam = list(system.dir(args.macsdir).fls('bam$'))[0]
    wd,xls = os.path.split(xls)
    name = xls.replace('_peaks.xls','')
    bdg = name + '_treat_pileup.bdg'
    bdg2w( bdg )
    #sf = scale_factor( args.macsdir )
    #print ( sf )
    cmd = 'macs2 bdgcmp -t {} -c {} -o {} -m ppois'.format(bdg, bdg.replace( '_treat_pileup.bdg', '_control_lambda.bdg'), fix.fix(bdg).insert('ppois'))
    print ( cmd )
    bdg2w( fix.fix(bdg).insert('ppois') )
    cmd = 'samtools index {}\nbamCoverage --normalizeUsing BPM --numberOfProcessors 2 --outFileFormat bigwig  --minMappingQuality 1   --bam {} --binSize 50 --outFileName {}.bpm.bw'.format( bam, bam, name)
    print (status.cmd_accessory(cmd, wd = wd, flag = 'bedGraphToBigWig.bpm.{}'.format(name)) )
























