#!/usr/bin/env python
import sys
import argparse
from ningchao.nSys import ip,env,trick
from ningchao.nBio import rheMac
parser = argparse.ArgumentParser( prog=sys.argv[0], description='gtf infor parse' )
parser.add_argument( 'gtf', nargs='?', help ='gtf file ' ) 
parser.add_argument( '-a', choices = ['protein_coding'] )
parser.add_argument( '-o', nargs = '?', help = 'output file' )
if len(sys.argv) == 1:
        parser.print_help().__str__
        sys.exit(2)
args = parser.parse_args()

def parse ( args ):
    gtf = args.gtf
    ofh = args.o and open(args.o, 'w') or sys.stdout
    sys.stderr.write(gtf + '\n')
    chroms = list(range(1,24))
    chroms = ['chr' + str(i) for i in chroms]
    chroms.append('chrX')
    return open(gtf), ofh, chroms

if __name__ == '__main__':
    gfh, ofh, chroms = parse ( args )
    for line in gfh:
        if line.startswith('#'):
            continue
        line_arr = line.strip().split('\t')
        if line_arr[2] == 'gene':
            line_infor = trick.str2dict(line_arr[8])
            if line_infor['gene_biotype'] == 'protein_coding':
                key = '.'.join( [line_infor['gene_name'], line_infor['gene_id']] )
                print(key.upper())
