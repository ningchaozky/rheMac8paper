#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bed', nargs='?', help ='ac bed' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

bed = os.path.realpath(args.bed)
work_dir = os.path.dirname(bed)
bed_name = '.'.join(os.path.basename(bed).split('.')[0:2]) + '.dnase.rep1.bed'
dnase = os.path.join(os.path.dirname(work_dir), 'dnase', bed_name)
enh_dir = os.path.join(work_dir,'enh')
if not os.path.exists(enh_dir):
    os.mkdir(enh_dir)
print('grep -v track %s | cut -f1,2,3 > %s/ac' % (bed,enh_dir))
print('bed_peaks_mapping.py -bed /home/ningch/data/genome/rheMac8/exon/ref_ensemble_xeonRefGene.bed  -peak %s -o %s/ac.mapping' % (bed,enh_dir))
print('bedtools intersect -a %s/ac -b %s/ac.mapping -v > %s/ac.distal' % (enh_dir,enh_dir,enh_dir))
print('grep -v track %s | cut -f1,2,3 > %s/dnase' % (dnase,enh_dir))
print('bedtools intersect -a %s/ac.distal -b %s/dnase -wo | cut -f1,2,3 | awk \'!x[$0]++\' > %s/ac.distal.dnase' % (enh_dir,enh_dir,enh_dir))



















