#!/bin/env perl 
open FILE1,$ARGV[0]; ####GTF is ID_strand file ,NOT the real GTF file
open FILE2,$ARGV[1];  ####ID is the split.bed form split.pl!!!!!
foreach (<FILE1>){
    chomp;
    @yuan=split /\t/,$_;
    $hash{"$yuan[0]\t$yuan[1]\t$yuan[2]"}=$_;#"$yuan[1]\t$yuan[2]"
    #$hash{$yuan[3]}="$yuan[4]\t$yuan[5]";
}
foreach (<FILE2>) {
    chomp;
    @id=split /\t/,$_;
    if (exists $hash{"$id[0]\t$id[1]\t$id[2]"}){
        #print $hash{"$id[0]\t$id[1]\t$id[2]"},"\n";
        #print join("\t",@id),"\t",$hash{"$id[0]\t$id[1]\t$id[2]"},"\n";
        print join("\t",@id),"\t",$hash{"$id[0]\t$id[1]\t$id[2]"},"\n";

        #print "\n";
    }else {
    #print "$id[0]\t$id[1]\t$id[2]","\t","NA\tNA\tNA","\n";
    }
}



