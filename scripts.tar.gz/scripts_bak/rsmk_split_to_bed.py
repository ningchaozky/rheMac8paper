#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
#plt.tight_layout()
mpl.use('Agg')
#mpl.rcParams['pdf.fonttype'] = 42
#mpl.rcParams['ps.fonttype'] = 42
#mpl.rcParams['svg.fonttype'] = 'none'
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
import gzip
from collections import defaultdict
from ningchao.nSys import trick
desc = '''/gbdb/rheMac8/rmsk.txt.gz'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'rsmk download from http://hgdownload.cse.ucsc.edu/goldenPath/rheMac8/database/')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fls = defaultdict( str )
with gzip.open( args.tab ) as f :
    for line in f :
        line = line.decode()
        line_arr = line.rstrip().split('\t')
        chrom, start, end = line_arr[5:8]
        repName, repClass, repFamily = [ i.replace('?','WH') for i in line_arr[10:13] ]
        out_file_name = '.'.join([repFamily,repClass, 'bed'])
        if out_file_name not in fls :
            fls[out_file_name] = open( out_file_name, 'w')
        try :
            print ( chrom, start, end, repName, repClass, repFamily, sep = '\t', file = fls[out_file_name])
        except :
            print ( repName, repClass, repFamily, fls[out_file_name] )

























