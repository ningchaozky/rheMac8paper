#!/usr/bin/perl
use strict;
use warnings;

my ($pre,$start,$title);


unless(@ARGV){
	die "Usage: $0 pre start file\n\tEg: $0 HassGr 18 file\n";
}

$pre = $ARGV[0];
$start = $ARGV[1];
my $file;
open $file,"$ARGV[2]";

while(<$file>){
	if(/>/){
		chomp;
		if(/$pre(\d+)$/){
			if($1 <= $start){
				print "$_\n";
			}else{
				$start++;
				print '>'.$pre.$start."\n";
			}
		}else{
			$start++;
			print '>'.$pre.$start."\n";
		}
	}else{
		print;
	}

}
