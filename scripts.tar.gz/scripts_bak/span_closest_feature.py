#!/usr/bin/env python3
import os
import sys
import argparse
import subprocess as sp
from ningchao.nSys import trick
from collections import defaultdict

example = ''' use bed a extend span closest find b'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'a', nargs = '?', help = 'bed a')
parser.add_argument( 'b', nargs = '?', help = 'bed b')
parser.add_argument( '-include_ab_overlap','-iab', action = 'store_true', help = 'include_ab_overlap')
parser.add_argument( '-only_ab_overlap','-oab', action = 'store_true', help = 'only_ab_overlap')
parser.add_argument( '-s', nargs = '?', help = 'span extend for a', default = 1000000, type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def chrom_start_ends( arr ):
    lst = []
    for i,v in enumerate( arr ):
        try :
            if int( v ) > 1000 :
                lst.append( i )
                if len(lst) in [ 2, 5 ] :
                    lst.append( i + 1 )
                if len( lst ) == 6 :
                    break 
        except :
            continue
    if len( lst ) not in [ 3, 6 ]:
        print ( 'Start ends not right, len {}: '.format( len(lst) ), lst, *arr, sep = '\t', file = sys.stderr )
    return [ i-1 for i in lst ]

def check_start_end_pos(bed):
    if os.path.exists( bed ):
        with open( bed ) as f :
            return chrom_start_ends( next( f ).rstrip().split('\t') )
    elif isinstance( bed, str ):
        return chrom_start_ends( bed.rstrip().split('\t') )

def extend_bed( bed, span ):
    ebed = bed+'.extend'
    chrom, start, end = check_start_end_pos(bed)
    with open( bed ) as f :
        fh = open( ebed, 'w' )
        for line in f:
            line_arr = line.strip().split('\t')
            line_arr[start] = int( line_arr[start] ) - span
            line_arr[end] = int( line_arr[end] ) + span
            print ( *line_arr, sep = '\t', file = fh )
        fh.close()
        return fh.name

def ab_overlap( a, b):
    infor = defaultdict( list )
    achrom, astart, aend = check_start_end_pos(a)
    cmd = '''bedtools intersect -a {} -b {} -wo'''.format( a, b )
    print ( cmd, file = sys.stderr )
    p = sp.Popen( cmd, shell = True, stdout = sp.PIPE, stderr = sp.PIPE )
    stdout, stderr = p.stdout, p.stderr
    for line in stdout:
        line_arr = line.decode().split('\t')
        key = '\t'.join( [ line_arr[i] for i in [achrom, astart, aend] ] )
        infor[ key ].append( line.decode() )
    return infor


def pick_overlap_b( ebed, b):
    infor = defaultdict( list )
    achrom, astart, aend = check_start_end_pos( ebed )
    cmd = '''bedtools intersect -a {} -b {} -wo'''.format(ebed, b) 
    print ( cmd, file = sys.stderr )
    p = sp.Popen( cmd, shell = True, stdout = sp.PIPE, stderr = sp.PIPE )
    stdout, stderr = p.stdout, p.stderr
    for line in stdout:
        line_arr = line.decode().strip().split('\t')
        key = '\t'.join( [ line_arr[i] for i in [achrom, astart, aend]  ]  )
        infor[ key ].append( line.decode() )
    return infor


if __name__ == '__main__':
    #a extend
    ebed = extend_bed( args.a, args.s)
    #a b overlap; dict key is chrom,start,end
    ab_actually_intersect = ab_overlap( args.a, args.b )
    #b overlap a extended bed, key is chrom,start-span,end + span
    b_overlap_extene_a = pick_overlap_b( ebed, args.b)
    #find peak in a extend not in ab actually overlap
    for peak in b_overlap_extene_a:
        key = peak.split('\t')
        key[1],key[2] = str( int( key[1] ) + args.s), str( int( key[2]  ) - args.s )
        key = '\t'.join( key )
        if key not in ab_actually_intersect and not args.only_ab_overlap:
            pos = check_start_end_pos( b_overlap_extene_a[ peak ][0] )
            for each in b_overlap_extene_a[ peak ] :
                e_arr = each.strip().split('\t')
                e_arr[1] = int( e_arr[1] ) + args.s
                e_arr[2] = int( e_arr[2] ) - args.s
                length_sorted = sorted( [ int(e_arr[pos[i]]) for i in [1,2,4,5] ] )
                length = ( length_sorted[2] - length_sorted[1] )
                e_arr.pop(-1)
                if length > args.s :
                    continue
                print ( *e_arr, length, sep = '\t')
        elif args.include_ab_overlap or args.only_ab_overlap:
            for each in ab_actually_intersect[key]:
                print ( each.strip(), sep = '\t' )
























