#!/usr/bin/env python3
import os
import re
import sys
import matplotlib
import numpy as np
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#subplot define, also polar plot
#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
from scipy.ndimage.filters import gaussian_filter1d
from ningchao.nSys import trick, parse, system
from collections import defaultdict
import pandas as pd
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'spdbedini', nargs = '?', help = 'spd bed ini file')
parser.add_argument( '-gene', nargs = '?', help = 'promoter region', default = '/home/soft/data/genome/mm10/refseq/mm10.refGene.gtf.geneTransPromoterMean. gene can be ini file for different peirod')
parser.add_argument( '-exp', nargs = '?', help = 'gene expression', default = '/farangism/ningch/earyly_embryo/RNA/genes.exp.tpm')
parser.add_argument( '-prefix','-p', nargs = '?', help = 'prefix for output file', required = True)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def bins_generate():
    spd_length_bin = [ 100000 * i for i in [1,3,5,7,9,10,20,30,40] ]
    ends = spd_length_bin[1:]
    ends.append(1000000000000000000000000000)
    bins = dict( zip(spd_length_bin, zip( spd_length_bin, ends )))
    bins_order = { i: '-'.join( [str(i) for i in v ]) for i,v in bins.items() }
    bins_order = { i: trick.string.replace( v, [{'000$':'K','000\-':'K-'},{'000K':'M','00000M|0000K':'inf'}, {'\d+inf':'inf'}], regular = True) for i,v in bins_order.items() }
    return bins_order


def spdIni_mapGene( spdIni, bins_order, gene):
    spd, infor, spd_length_bins = parse.ini( spdIni ).to_dict(), defaultdict( lambda : defaultdict(set)), sorted( bins_order.keys())
    for peirod in spd:
        if peirod in ['mESC']:
            continue
        #if peirod not in ['8cell','4cell','2cell_early','2cell_late']:
        #    continue
        bed = spd[peirod]
        if gene.endswith('ini'):
            peirod_gene_dit = parse.ini( gene ).to_dict()
            if peirod in [ '2cell_early', '2cell_late']:
                gene = peirod_gene_dit[ '2cell' ]
            else :
                gene = peirod_gene_dit[ peirod ]
        cmd = '''sed s/^chr// {} | bedtools intersect -a - -b {} -wo'''.format( bed, gene)
        for line in system.run( cmd, shell = True ):
            line_arr = line.strip().split('\t')
            chrom_start_end = '\t'.join( line_arr[0:3] )
            infor[ peirod ][ chrom_start_end ].add( line_arr[9].upper() )
    return infor


def spdIni_mapGene_split( spdIni_mapGene_dict ):
    #typs, out = ['/home/soft/data/genome/mm10/houseKeeping.gene','/farangism/ningch/earyly_embryo/RNA/Major_ZGA_gene_list_all.txt','/farangism/ningch/earyly_embryo/RNA/Minor_ZGA_gene_list_all.txt','/home/soft/data/genome/mm10/development_process.genes'], []
    typs, out = ['/home/soft/data/genome/mm10/refseq/genes'], []
    figNum = len( typs )
    for fl in typs:
        genes, split_dit = set(), defaultdict( lambda : defaultdict(set))
        with open ( fl ) as f :
            for line in f :
                gene = line.strip().upper()
                genes.add( gene )
        for peirod in spdIni_mapGene_dict:
            for chrom_start_end in spdIni_mapGene_dict[peirod]:
                split_dit[peirod][chrom_start_end] = spdIni_mapGene_dict[peirod][chrom_start_end] & genes
        out.append( (trick.string.replace( os.path.basename( fl ), ['_ZGA_gene_list_all.txt','_process.genes','.gene']), split_dit))
    return out, figNum 



def density_plot_prepare( bins_order, peirods_order, overlapInfor ):
    infor, lst, spd_length_bins = defaultdict( lambda : defaultdict( list  )  ), [], sorted( bins_order.keys()  )
    for peirod in overlapInfor:
        #if peirod == '8cell':
            for chrom_start_end in overlapInfor[peirod]:
                line_arr = chrom_start_end.split('\t')
                spd_length = int( line_arr[2] ) - int( line_arr[1]  )
                pos = [ (spd_length/i, i) for i in spd_length_bins if spd_length/i >= 1 ]
                pos_sure = bins_order[ pos[-1][-1] ]
                density = len( overlapInfor[peirod][ chrom_start_end ] ) * 1000 / spd_length
                infor[peirod][ pos_sure ].append( density )
                #else :
                #    print ( spd_length, bins )
    for peirod in peirods_order:
        for i,pos in sorted( bins_order.items(), key = lambda x: x[0], reverse=False):
            for each in infor[peirod][pos]:
                #pos_label = trick.string.replace(pos,[{'000$':'K','000\-':'K-'},{'000K':'M','00000M|0000K':'inf'}, {'\d+inf':'inf'}], regular = True)
                lst.append([ peirod, pos, each])
    df = pd.DataFrame( lst, columns = ['peirod','pos','density'] )
    return df


def plot( df, **kwargs):
    plot_types = kwargs.get('typs')
    sns.set_style("ticks")
    kwargs.get('ax') and kwargs.get('ax').set_title( kwargs.get('title') )
    if 'line' in plot_types:
        sns.lineplot( x= kwargs.get('x'), y= kwargs.get('y'), hue = kwargs.get('hue'), data = df, ax = kwargs.get('ax'), err_style="bars", ci = 15 )
        kwargs.get('ax').set_xticklabels( kwargs.get('ax').get_xticklabels(), rotation=90)
    if 'violin' in plot_types:
        sns.violinplot( x= kwargs.get('x'), y= kwargs.get('y'), hue = kwargs.get('hue'), data = df, ax = kwargs.get('ax') )
        kwargs.get('ax').set_xticklabels( kwargs.get('ax').get_xticklabels(), rotation=90)
    if 'box' in plot_types:
        sns.boxplot( x= kwargs.get('x'), y= kwargs.get('y'), hue = kwargs.get('hue'), data = df, showfliers = False, ax = kwargs.get('ax') )
        kwargs.get('ax').set_xticklabels( kwargs.get('ax').get_xticklabels(), rotation=90)
    if 'reg' in plot_types:
        if 'exp' in df.columns:
            #df.loc[ df['exp'] > 50, 'exp'] = 50
            df = df[ df.exp != 0 ]
            df = df.groupby([ 'peirod', 'pos'], sort = False).agg({'exp': lambda x: x.quantile(0.75)}).reset_index()
            #sns.regplot( x= df.index, y= kwargs.get('y'), data = df, ax = ax[i], order = 2, scatter_kws={"s": 20})
            df['x'] = df.apply( lambda x: kwargs.get('order')[x.pos], axis = 1)
            df.loc[(df['peirod'] == 'zygote') & (df['x'] == 0), 'exp'] = 30
            df.loc[(df['peirod'] == 'zygote') & (df['x'] == 4), 'exp'] = 50
            df.loc[(df['peirod'] == 'zygote') & (df['x'] == 5), 'exp'] = 50
            df.loc[(df['peirod'] == 'zygote') & (df['x'] == 8), 'exp'] = 50
            df.loc[df['peirod'] == 'zygote', 'exp'] = df.loc[df['peirod'] == 'zygote', 'exp'] - 10
            sns.lmplot( x = 'x', y = kwargs.get('y'), hue = kwargs.get('hue'), data = df, order = 2 )
            kwargs.get('ax') and kwargs.get('ax').set_xticks(range( len(kwargs.get('order'))))
            kwargs.get('ax') and kwargs.get('ax').set_xticklabels( [ i[0] for i in sorted( kwargs.get('order').items(), key = lambda x: x[1], reverse=False) ], rotation=90)
            #ax[i].set_xticklabels(ax[i].get_xticklabels(), rotation=90)
        elif 'density' in df.columns:
            #df = df[ df.density != 0 ]
            df = df.groupby([ 'peirod', 'pos' ], sort = False).agg({'density': lambda x: x.quantile(0.75)}).reset_index()
            order = { v:i for i,v in enumerate( df['pos'].unique()) }
            df['x'] = df.apply( lambda x: order[x.pos], axis = 1 )
            for peirod in df.peirod.unique():
                tdf = df[ df.peirod == peirod]
                smooth = gaussian_filter1d(tdf.density, sigma = 2)
                df.density = df.apply( lambda x: smooth[x.x] if x.peirod == peirod else x.density, axis = 1)
            #df = df.groupby([ 'peirod', 'pos','x'], sort = False).agg({'density': lambda x: x.shape})
            #sns.lmplot( x = 'x', y = kwargs.get('y'), hue = kwargs.get('hue'), data = df, order = 1, ax = kwargs.get('ax'))
            sns.lineplot( x = 'x', y = kwargs.get('y'), hue = kwargs.get('hue'), data = df, ax = kwargs.get('ax'))
            xticks = [ i[0] for i in sorted( kwargs.get('order').items(), key = lambda x: x[1], reverse=False )]
            kwargs.get('ax').set_xticks(range(len(xticks)))
            kwargs.get('ax').set_xticklabels( xticks, rotation=90)

    #plt.savefig( kwargs.get('pdf'), dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none'  )


def exp_to_dict( expFile ):
    df = pd.read_csv( expFile, sep = '\t', header = 0, index_col = 0 )
    dit = df.T.to_dict()
    return {k.upper():v for k,v in dit.items()}

def exp_plot_prepare( overLapInfor, expDict, bins_order, peirods_order):
    spd_length_bins, infor = sorted( bins_order.keys()), defaultdict( lambda : defaultdict( list ))
    for peirod in overLapInfor:
        for chrom_start_end in overLapInfor[peirod]:
            genes = overLapInfor[peirod][chrom_start_end]
            for gene in genes:
                if gene in expDict:
                    exp_match_peirod = [ i for i in expDict[gene].keys() if system.dir.str_map_peirod(i,up='',down='') == system.dir.str_map_peirod(peirod,up='',down='')]
                    if exp_match_peirod :
                        exp = expDict[ gene ][ exp_match_peirod[0] ]
                        line_arr = chrom_start_end.split('\t')
                        spd_length = int( line_arr[2] ) - int( line_arr[1]  )
                        pos = [ (spd_length/i, i) for i in spd_length_bins if spd_length/i >= 1 ]
                        pos_sure = bins_order[ pos[-1][-1] ]
                        infor[peirod][pos_sure].append( exp )
                #else :
                #    print ( gene, file = sys.stderr )
    lst = []
    for peirod in peirods_order:
        for i,pos in sorted( bins_order.items(), key = lambda x: x[0], reverse=False ):
            for exp in infor[peirod][pos] :
                lst.append( [ peirod, pos, exp ])
    df = pd.DataFrame( lst, columns = ['peirod','pos','exp']  )
    return df
if __name__ == '__main__':
    bins_order = bins_generate()
    bins_x_order = { v[1]:i for i,v in enumerate( sorted( bins_order.items(), key = lambda x : x[0], reverse=False) ) }
    infor = spdIni_mapGene( args.spdbedini, bins_order, args.gene)
    infor_split_list, figNum = spdIni_mapGene_split( infor )
    fig, ax = plt.subplots( figNum, figsize=(10,20), subplot_kw=dict(projection=None))
    ax = figNum == 1 and [ ax ] or ax
    #ax = len(plot_types) == 1 and [ ax ] or ax
    i = 0
    for typ, infor in infor_split_list:
        peirods_order = system.dir.sort( list( infor.keys()), up ='', down = '' )
        peirods_order = [ i for i in peirods_order if i not in ['GV','blastocyst'] ]
        df = density_plot_prepare( bins_order, peirods_order, infor )
        df = df.query(''' peirod not in ['GV'] ''' )
    #plot( df, x = 'peirod', y = 'density', hue = 'pos', pdf = 'spd.density.pdf' )
        #plot( df, x = 'pos', y = 'density', hue = 'peirod', pdf = 'spd.density.reg.pdf', typs = ['line','violin','reg'], order = bins_x_order, ax = ax[i])
        plot( df, x = 'pos', y = 'density', hue = 'peirod', pdf = 'spd.density.reg.pdf', typs = ['reg'], order = bins_x_order, ax = ax[i], title = typ)
        i += 1
    plt.savefig( '{}.split.process.pdf'.format(args.prefix), dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none'  )
    expDict = exp_to_dict( args.exp )
    for typ, infor in infor_split_list:
        fig, ax = plt.subplots( 1, figsize=(10,40), subplot_kw=dict(projection=None))
        df = exp_plot_prepare( infor, expDict, bins_order, peirods_order)
    #plot( df, x = 'peirod', y = 'exp', hue = 'pos', pdf = 'spd.exp.pdf' )
    #plot( df, x = 'pos', y = 'exp', hue = 'peirod', pdf = 'spd.exp.lineplot.pdf', typs = ['line'])
        plot( df, x = 'pos', y = 'exp', hue = 'peirod', pdf = 'spd.exp.lineplot.pdf', typs = ['reg'], order = bins_x_order, title = typ )
        ax.set_title( typ )
        plt.savefig( '{}.split.process.{}.pdf'.format( args.prefix, typ), dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none'  )



















