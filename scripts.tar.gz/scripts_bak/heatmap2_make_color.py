#!/usr/bin/env python
import sys
import os

def help():
	print('#Usage',sys.argv[0],'color.txt','fpkm.xls')
	print('\tColor file like: blue\tHarmGr1,HarmGr2,HarmGr3')
	print('\tfpkm.xls should has the header')
	exit()

if len(sys.argv) <= 1:
	help()


map = {}
color = open(sys.argv[1])
for line in color:
	if line.startswith('#'):
		continue
	line = line.rstrip()
	line_arr = line.split('\t')
	genes = line_arr[1].split(',')
	for gene in genes:
		map[gene] = line_arr[0]



color_file = open('%s_heatmap_color_file.txt' % sys.argv[-1],'w')
print('id\tcolor\tneed', file=color_file)
#ordered gene
diff = open(sys.argv[-1])
next(diff)
for line in diff:
	line_array = line.rstrip('\n').split('\t')
	if line_array[0] in map:
		print(line_array[0]+'\t'+map[line_array[0]]+'\t'+line_array[0], file=color_file)
	else:
		print(line_array[0]+'\t'+'white'+'\t'+'NA', file=color_file)
