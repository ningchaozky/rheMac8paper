#!/usr/bin/env python
import os
import sys
import xlrd  
import ningchao.nSys.parse as parseTookit
import ningchao.usage as uTookit

uTookit.usage("infor.ini")

d = parseTookit.parse_ini(sys.argv[1],typ ='json').to_dict()
folds = list(range(1,100))

def shrink(num):
	if num < 5:
		return num
	num = num/2
	return amplify(num)
def amplify(num):
	if num >= 1:
		return num
	num = num * 2
	return amplify(num)
		
def dict_shrink(dit,fold):
	for k in dit:
		dit[k][0] = dit[k][0]/fold
	return dit


title = ['index', 'sample', 'library type', '7500', '2100', 'bases/GB', '450', 'dilution.times', 'sampling volume', 'sample quantity', 'final concentration','last']
keys = list(d.keys())
keys.sort()
for library in keys:
	tmp_450 = {}
	big_volume = {}
	for sample in d[library]:
		tmp_450[sample] = []
		data_450 = round(float((450.0/float(d[library][sample]['2100']))*float(d[library][sample]['7500'])),2)
		raw_volume = float(d[library][sample]['bases'])/data_450
		tmp_450[sample].append(raw_volume)
		if raw_volume > 10 :
			big_volume[sample] = raw_volume
	
	shrink_fold,shrink_num = {},0
	for sample in big_volume:
		raw = big_volume[sample]
		real = shrink(raw)
		shrink_fold[sample] = raw/real
	if shrink_fold :
		shrink_num = max(shrink_fold.values())
	else :
		shrink_num = 1
	
	shrink_dit = dict_shrink(tmp_450,shrink_num)
	for sample in shrink_dit:
		real = amplify(shrink_dit[sample][0])
		fold = real/shrink_dit[sample][0]
		tmp_450[sample].append(real)
		tmp_450[sample].append(fold)
	for sample in tmp_450:
		if tmp_450[sample][2]/tmp_450[sample][1] > 2 :
			tmp_450[sample][2] = tmp_450[sample][2] - 1
			tmp_450[sample][1] = tmp_450[sample][0] * tmp_450[sample][2]
	
	total_volume = sum([i[1] for i in list(tmp_450.values())])
	amp = 0
	last_volume = 10
	if int(total_volume/last_volume) == 0:
		amp = last_volume/total_volume
	else : 
		amp = 1
	for key in tmp_450:
		tmp_450[key][1] = tmp_450[key][1] * amp
	total_input = 0
	for sample in tmp_450:
		total_input = total_input +  float(d[library][sample]['7500']) * tmp_450[sample][1]/tmp_450[sample][2]
	concentration = round(total_input/last_volume,2)
	libType = ''
	print(library)
	print('\t'.join(title))
	for sample in d[library]:
		data_450 = round(float((450.0/float(d[library][sample]['2100']))*float(d[library][sample]['7500'])),2)
		sample_molecular_number = round(tmp_450[sample][1] * data_450 / tmp_450[sample][2],2)
		line = [d[library][sample]['index'],sample,libType,d[library][sample]['7500'],d[library][sample]['2100'],d[library][sample]['bases'],data_450,tmp_450[sample][2],round(tmp_450[sample][1],2),sample_molecular_number,concentration,last_volume]
		line = [str(i) for i in line]
		print('\t'.join(line))
	print('\n\n')





