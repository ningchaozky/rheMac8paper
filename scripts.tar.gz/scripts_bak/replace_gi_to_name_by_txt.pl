#!/usr/bin/perl 
use strict;

unless(@ARGV){
	die "Usage: $0 xls txt[fasta]\n";
}

my ($xls,$txt,%hash);
open $txt,"$ARGV[1]";
while(<$txt>){
	s/>//g;
	if(/gi\|(\d+)/i){
		$hash{$1} = $_;
	}
}


open $xls,"$ARGV[0]";
while(<$xls>){
	chomp;
	my ($out,@tmp);
	my @tmp = split /\t/,$_;
	for(@tmp){
		if(/^gi\|(\d+)/i){
			my $tmp = $_;
			$_ = $hash{$1};
			unless($_){
				$_ = $tmp;
			}
			chomp;
		}
		$out .= "$_\t";
	}
	$out =~ s/\t$//;
	print "$out\n";
}
