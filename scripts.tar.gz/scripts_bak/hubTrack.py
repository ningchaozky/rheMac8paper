#!/usr/bin/env python
import sys
import os
import copy
import argparse
from ningchao.nSys import system
import ningchao.usage as uTookit
import ningchao.nBio.hub as hubTookit
from ningchao.nData import data

parser = argparse.ArgumentParser(prog = sys.argv[0],description='generate trackHub.txt from patter file', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('k', nargs='?', help ='pattern for find file')
parser.add_argument('-genome','-g', nargs='?', help ='genome for bw| rheMac8|mm10|mm9|hg19|hg38|rh10', required = True)
parser.add_argument('-prefix','-p', nargs='?', help ='file prefix should different with other track hub', required = True )
parser.add_argument('-f', nargs='?', help = 'fiter pattern', default = 'fdfdafadfadsfsdfdsafererdfa22')
parser.add_argument('-group', nargs='?', default = '3', help ='group 1:1 2:3 3:5. this options for washu only')
parser.add_argument('-work_dir','-wd', nargs='?', default = '.',help ='which directory you want to find bw files')
parser.add_argument('-t', choices = ['ucsc','washu'], help ='ucsc|[washu]', default = 'ucsc')
parser.add_argument('-trackType','-it', choices = ['bb','bw','hic'], help ='bigBed|bw format', default = 'bw')
parser.add_argument('-sameColor', nargs = '?', help ='set same color for the bw. or color ini file. \n0,all diff 1,peirod 2,region 3,marker 4,rep', default = 'period' )
parser.add_argument('-sort', '-s', nargs = '*',type = int, help ='sort key beyond samColor', default = [ 0 ] )
parser.add_argument('-ymax', help ='max y axis. for ucsc', default = '10')
parser.add_argument('-depth','-d', nargs = '+', help ='depth for find file', default = [ 0 ], type = int )
parser.add_argument('-ylimit', help ='max y axis limit. for ucsc', nargs = '+', default = [ 0, 0, 10 ])
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse():
    kwargs = vars( args )
    trackType_match = {'bb': 'bigBed', 'bw': 'bigWig', 'hic': 'hic'}
    trackType = trackType_match[kwargs.get('trackType')]
    marker = copy.copy( args.k )
    print ( args.work_dir, args.k, args.f, args.depth )
    fls = list (system.dir( args.work_dir ).detail_fls( args.k, fpattern = args.f, depth = args.depth, sort = 'period') )
    #this marker is lst object not show in short name
    kwargs.update({'fls': fls, 'trackType': trackType })
    #return fls, genome, trackType, sort, args.p, work_dir, group, args.t


def main( colors ):
    kwargs = vars( args )
    hubType = args.t
    if hubType == 'ucsc':
        kwargs = vars( args )
        fls = hubTookit.hub(**kwargs).db( kwargs.get('fls'), inColor = colors )
        print( *fls, sep = '\n')
    elif hubType == 'washu':
        hub = os.path.abspath( os.path.join(work_dir, prefix+'.washu.hub') )
        fh = open(hub,'w')
        fh.write(hubTookit.washu(work_dir, group, fls, genome))
        print(hub)
        huburl = system.fl( hub ).link( )
        print(huburl)
        url = 'http://washu.lab/browser/?genome=%s&datahub=%s' % ('w' + genome, huburl)
        print(url)


if __name__ == '__main__':
    #fls, genome, trackType, sort, prefix, work_dir, group, hubType  = parse( args )
    parse()
    colors = data.data.color()
    print ( colors )
    main( colors )


