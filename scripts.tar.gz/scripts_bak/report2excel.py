#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import importlib
importlib.reload(sys)
import urllib.request, urllib.error, urllib.parse
import ningchao.nBio.index as indexKit
import ningchao.nSys.convert as conKit
from bs4 import BeautifulSoup
import zipfile
import matplotlib#matplotlib.use('Agg')
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
import argparse
from ningchao.nSys.system import un_zip 
import ningchao.nSys.trick as trKit
sys.setdefaultencoding('utf-8')

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'i', nargs='?', help ='input zip file download from novogene' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

file_name = un_zip(args.i)
html = ''
for root,dirs,files in os.walk(file_name):
	for each in files:
		if each.endswith('.html'):
			html = os.path.join(root,each)
			break

fh = open(html)
html = BeautifulSoup( '\n'.join(fh.readlines()), 'html.parser')
tr = html.find_all('tr')
out = []
i = 0
for each in tr:
	child = each.children
	child_list = list(child)
	child_iter = iter(child_list)
	child_len = len(child_list)
	if child_len == 21 :
		tmp  = []
		for i in child_iter:
			tmp.append(i.string)
		out.append(tmp)
for each in out:
	each = [ i.strip() for i in each if i is not None ]
	out = each[:]
	for index in each:
		try :
			tmp_string = conKit.convert(index)
			if tmp_string in list(indexKit.index(num2string = 1).keys()):
				out.insert(8, str(indexKit.index(index = tmp_string, num2string = 1)))
		except :
			pass
	print('\t'.join(out))


















