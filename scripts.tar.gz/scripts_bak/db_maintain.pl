#!/usr/bin/env perl 
use strict;
use warnings;
use DBI;
use Cwd 'abs_path';
use Getopt::Long;
use Pod::Usage;
my ($dbtype,$help,$tname,$flatFile,$sep,$manual,$multiLine,$dbname,$dbpath,$lineSep,$action,$dbargs,$dbh,$in,@line,$db_path,$dns,$seq);
GetOptions(
	"manual",	\$manual,
        'h|?|help',             \$help,
        "dbtype=s",                \$dbtype,
        "tname=s",             \$tname,
	"dbname=s",	\$dbname,
        'yes|no', \$multiLine,
        "sep=s",            \$sep, ## field separator
	"dbpath=s",	\$dbpath,
	"flatFile=s",	\$flatFile,
	"lineSep=s",	\$lineSep,
	"action=s",	\$action,
);
print "$0\n" unless $flatFile;
pod2usage(1) unless $flatFile;
pod2usage(1) if $help; #print SYNOPSIS and OPTIONS
pod2usage(-verbose  => 2) if $manual; # print all head1 and cut

=head1 SYNOPSIS
	
	This is a script can inert data to database sqlite3 mysql auto

=cut
=head1 OPTIONS
 
  usage [options]

  Help Options:
   --help		Show this scripts help information.
   --manual		Read this scripts manual.
   --dbtype	mysql|sqlite3
   --tname		table name
   --dbname		database name
   --flatFile		flat file for insert to db
   --lineSep		line separator. default '\n'
   --sep		filed separator
   --action		insert|shell|all

=cut

$dbargs = {AutoCommit=>0, PrintError =>1};
if($dbtype =~ /^sqlite/i){
	$db_path = abs_path($dbname);
	$dbh = DBI->connect("dbi:SQLite:dbname=$db_path","","",$dbargs);
} elsif ($dbtype =~ /^mysql/i){
	$dbh = DBI->connect("dbi:mysql:$dbname","root","root",$dbargs);
}
open $in,$flatFile;
if (not $lineSep){
	$lineSep = "\n";
}

$/ = $lineSep;
while(<$in>){
	chomp;
	#$sep = quotemeta($sep);
	@line = split /$sep/,$_,-1;
#	print scalar(@line);
	my $sentence = '';
	for(@line){
		if(/^\s+$/){
			$sentence .= 'NUll,';
		} elsif (/^\d+$/){
			$sentence .= "$_,";
		} elsif (/null/i) {
			$sentence .= "$_,";   
        } else {
			$sentence .= $dbh->quote($_).',';
		}
	}
	chop $sentence;
	if ($action =~ /shell/){
		print "insert into $tname values($sentence);\n";
	} elsif ($action =~ /insert/){
		$dbh->do("insert into $tname values($sentence);\n");
	} elsif ($action =~ /all/) {
		print "insert into $tname values($sentence);\n";
		$dbh->do("insert into $tname values($sentence);\n");
	}
}

#if($dbh->err()){
#	die "$DBI->errstr\n";
#}
$dbh->commit();
$dbh->disconnect();
