#!/usr/bin/env python3
import os
import sys
import pickle
import numpy as np
import matplotlib as mpl
import joblib
#from sklearn.externals import joblib
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
plt.tight_layout()
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
import argparse
import loompy
import numpy as np
from collections import defaultdict
from ningchao.nSys import trick
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('loom', nargs='?', help = 'loom file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

ds = loompy.connect(args.loom)
print ( type(ds[:,:]) )
print ( 'attrs: ', ds.attrs.keys() )
print ( 'row keys ds.ra.keys(): ', ds.ra.keys() )
print ( 'column keys ds.ca.keys(): ', ds.ca.keys() )
dit, i = defaultdict( int ), 0
for v in ds.ca['CellID']:
    dit[v] =  i
    i += 1
print (dit['10X41_6_A_1:ATAACAACGGGACAx'])
print ( len(ds.ca['Age']), set(ds.ca['Age']) )
print ( ds.ca['TSNE'][16736,] )
print ( ds.ra['Gene'], len(ds.ra['Gene']), ds.shape )
exit()

model = "/dataC/gaolei/single/modle_training_from_publish"
if os.path.exists(model):
    print ('Err exists: {}'.format( model ) )
    exit()
#print ( dir(ds) )
#print ( ds[:, :].tofile('output.csv', sep = '\t', format = '%f' ) )
predict_test = [ ds[:1, :].T[:,0] ]
#100 gene
#X= ds[:100, :].T
#all gene
X= ds[:, :].T
Y = ds.ca['ClusterName']
print ( 'clusterNameNumber', len(set(Y)), 'cellNumber:', len(Y), X.shape )
#Y = np.array( [ list( ds.ca['ClusterName']) ] ).T
clf = LinearDiscriminantAnalysis()
clf.fit(X, Y)

joblib.dump( clf, model)
loaded_model = joblib.load( model )
p = loaded_model.predict( X )



if 0 :
    UMAP = ds.ca['UMAP']
    TSNE = ds.ca['TSNE']
    fig = plt.figure( figsize=( 18, 24) )
    plt.scatter(TSNE[:,0], TSNE[:,1])
    plt.savefig( "test.pdf", dpi=250, transparent=True, edgecolor='none')


#infor = defaultdict( str )
#for i,e in enumerate(ds.ca['ClusterName']):
#    infor[i] = e
#    print ( e )

exit()
print ( np.unique( ds.ra['MultilevelMarkers'], axis = 0) )
print ( ds.ra['Gamma'].shape )
print ( ds.ra['Selected'] )
print ( [ ds.ca[i] for i in ('TSNE','PCA','UMAP') ])
print ( ds.row_graphs.keys() )
























