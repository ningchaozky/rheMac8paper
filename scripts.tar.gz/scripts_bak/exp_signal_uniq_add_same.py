#!/usr/bin/env python3
import os
import sys
import argparse
import numpy as np
from ningchao.nSys import trick
from collections import defaultdict
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'uniq the colum 0 and add same exp')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



with open( args.tab ) as f:
    header = next(f).strip('\n')
    dit = defaultdict( list )
    for line in f :
        line_arr = line.strip('\n').split('\t')
        name = line_arr[0].split('.')[0]
        dit[name].append([ float(i) for i in line_arr[1:] ])
    print ( header )
    for name in dit:
        print ( name, *np.array( dit[name] ).sum( axis = 0 ), sep = '\t' )





























