#!/usr/bin/perl -w




if(@ARGV){
	open $file,"$ARGV[0]";
	my $q20;
	my $q30;
	my $gc;
	my $bases;
	while(1){
		last if (eof($file));
        my @fq;
				for(0..3){
			    $fq[$_] = <$file>;
				}
				@quantity = split "",$fq[3];
				for(@quantity){
                    $quantity += ord($_);
					$bases++;
					if(ord($_) > 65){
						$q30++;
					}
					if(ord($_) > 55){
						$q20++;
					}
				}
				$count_G += $fq[1] =~ tr/G/G/;
				$count_C += $fq[1] =~ tr/C/C/;
	}
    	
	$gc = sprintf "%2f",($count_G+$count_C)/$bases;
    $q20_per = sprintf "%2f", $q20/$bases;
    $q30_per = sprintf "%2f", $q30/$bases;
    $error = $quantity/$bases;
    $error = sprintf "%2f",10**(int((33-(int $error))/10));
    $base_gb = $bases/(1000**3);
    print "q20\tq30\tbases\tG\tC\tGB\terror\tq20%\tq30%\tgc%\n";
    print "$q20\t$q30\t$bases\t$count_G\t$count_C\t$base_gb\t$error\t$q20_per\t$q30_per\t$gc\n";
}
else{
print "Usage:\t$0 fqfile\n\n";
}
