#!/usr/bin/env python
import os
import sys
import math
import argparse
from itertools import chain
from ningchao.nSys import trick, system
from ningchao.nBio import bed as Bed
from tempfile import NamedTemporaryFile

example = '''enhancer multi promoter'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('pfl', nargs='?', help = 'promoter file')
parser.add_argument('-sdir', nargs='?', help = 'stage specify peirod', default = '/dataB/ftp/pub/rheMac3/prefrontal/enh/wuxi')
parser.add_argument('-merge', nargs='?', help = 'merge with values', default = '/home/ningch/data/chip-seq/rheMac/bw/active/signal/newCombination/active/enhancer/enh.sum.normalByMax.xls')
parser.add_argument('-o', nargs='?', help = 'output')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( ):
    pfl, sdir, pt = args.pfl, args.sdir, '_10_enhancer_gene'
    stage_specify_fls = list( system.dir( sdir ).fls( pt ) )
    return pfl, sdir, dict(zip([ os.path.basename(i).replace(pt, '' ) for i in stage_specify_fls], stage_specify_fls)), args.merge

def promoter_to_dit( promoter ):
    fh, out, order = open( promoter ), {}, []
    header = next( fh ).strip().split('\t')
    for line in fh:
        line_arr = line.strip().split('\t')
        line_arr = [ i.replace('None', '0') for i in line_arr ]
        try :
            trick.dinit( out, line_arr[0], dict(zip(header[1:],[ float(i) for i in line_arr[1:]] )))
        except :
            print ( line_arr )
            exit()
        order.append( line_arr[0] )
    return out, order, header


def bedsIntersect( b1, b2):
    match = {}
    interset = Bed.bed( b1 ).intersect( b2 )
    for line in interset:
        line_arr = line.strip().split('\t')
        p1, p2 = Bed.line( line_arr ).merge_parse()
        trick.dinit( match, p1, [])
        if p2 not in match[p1]:
            match[p1].append( p2 )
    return match 

def multi( ssf, merge, pinfor ):
    #merge match and get the value
    merge, minfor = Bed.bed( merge ).merge_bed_parse( header = True ) 
    for sf in ssf:
        sfbed, sfinfor = Bed.bed( ssf[ sf ] ).merge_bed_parse( )
        sys.stderr.write( sf + '\t' +ssf[ sf ] +'\n' )
        intersect = bedsIntersect( sfbed, merge )
        for sfpos in sfinfor:
            genes, enh_dit = sfinfor[sfpos], []
            if sfpos in intersect:
                merge_pos = intersect[sfpos]
                for mp in merge_pos:
                    enh_dit.append( minfor[mp] )
            else :
                continue
            for gene in genes:
                if gene not in pinfor:
                    continue
                gene_promoter_dit = pinfor[gene]
                enh_stage = [ trick.dit( i ).get( sf, regular = True ) for i in enh_dit ]
                enh_values = [ float(i) for i in list( chain( *enh_stage)) if i != 'None' ]
                stage_promoter = trick.dit( gene_promoter_dit ).get( sf, regular = True, dit = True )
                if len( enh_values ) > 1 :
                    enh_values = [ max( enh_values ) ]
                for enh_val in enh_values:
                    for rep in stage_promoter:
                        #stage_promoter[rep] = stage_promoter[rep] * enh_val
                        stage_promoter[rep] = stage_promoter[rep] +( math.e ** enh_val )
                pinfor[gene].update( stage_promoter )
    return pinfor

def write( header, order, multi_dit, ofh):
    ofh.write( '\t'.join( header) +'\n' )
    header.pop( 0 )
    for gene in order:
        line_arr = [ gene ]
        line_arr.extend( trick.dit(multi_dit[gene]).get(header) )
        ofh.write( '\t'.join( [ str(i) for i in line_arr] ) +'\n' )


def main( ):
    pfl, sdir, ssf, merge = parse( )
    pinfor, order, header = promoter_to_dit( pfl )
    multi_dit = multi( ssf, merge, pinfor )
    ofh = args.o and open( args.o, 'w') or sys.stdout
    write( header, order, multi_dit, ofh )
    ofh.close()
if __name__ == '__main__':
    main()




























