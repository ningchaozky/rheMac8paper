#!/usr/bin/env perl
use strict;
use Getopt::Long;
use Pod::Usage;
use Math::Complex;
my $len;
my $help    = 0;   # Show help overview.
my $manual = 0;
my ($help,$manual,$log,$xls);
GetOptions(
        'manual',               \$manual,
        'h|?|help',             \$help,
        'log|l=s', \$log,
        'xls|e=s',     \$xls,
);
pod2usage(1) if $help; #print SYNOPSIS and OPTIONS
pod2usage(-verbose  => 2) if $manual; # print all head1 and cut

=head1 SYNOPSIS
  
        This is a simple demonstration program for Pod::Usage, this text
        will be displayed if the script is invoked with '--manual'.
=cut
=head1 OPTIONS
 
  pod-usage [options]

  Help Options:
   --help     Show this scripts help information.
   --log   Read this scripts manual.
   --xls  Show the version number and exit.
=cut

$log = $log || 2 ;
open FH,$xls;

while(<FH>){
        chomp;
        my @tmp = split /\t/,$_;
        my $out;
        for(@tmp){
                if(/^\d+.?\d+$/){
                        $_ += 1 ;
                        $out .= sprintf ("%.3f",logn($_,$log))."\t";
                } else {
                        $out .= "$_\t";
                }
        }
        $out =~ s/\t$//;
        print "$out\n";
}



