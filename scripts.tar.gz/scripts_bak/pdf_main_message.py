#!/usr/bin/env python3
import os
import sys
import argparse
import PyPDF2 
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('pdf', nargs = '?', help = 'pdf main message extract')
#parser.add_argument('pdf', nargs = '?', help = 'pdf main message extract')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

pdf = PyPDF2.PdfFileReader( args.pdf )
for i in range( pdf.numPages ):
    text = pdf.getPage(i).extractText()
    if 'Fig. S1' in text:
        print ( text )


























