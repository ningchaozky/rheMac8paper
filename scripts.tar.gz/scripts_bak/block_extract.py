#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from tempfile import NamedTemporaryFile
from ningchao.nSys import trick,line
from ningchao.nSys import line as lk

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'file_in', nargs='?', help ='file in' )
parser.add_argument( '-b', nargs='?', help ='block', default = 'def' )
parser.add_argument( '-to', nargs='+', help = 'if set should be two and put to file and place' )
parser.add_argument( '-back', nargs='?', type = int, help = 'back num indent for the add block', default = 0)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def pinto( *args ):
    to,lst = args
    if not to :
        for line in lst:
            print(line)
        exit()
    fl, place = to 
    fh = open(fl)
    ofh = NamedTemporaryFile('w+t', delete=False, suffix = '.py')
    index = False 
    for line in fh:
        ofh.write(line)
        if place in line:
            index = True
        if index :
            for each in lst:
                ofh.write( each.replace('\t','    ').rstrip() + '\n' )
            index = False 
    ofh.close()
    return ofh.name

def getLst(fl, block):
    lst,findent = [],0
    fh = open(fl)
    for line in fh:
        line = line.replace('\t','    ').replace('\t','    ')
        if block in line:
            nline = fh.next().rstrip()
            lst.append( line.rstrip() )
            lst.append( nline )
            findent = lk.line( nline ).indentation()
            continue
        indent = lk.line( line ).indentation()
        if findent :
            line = line.rstrip()
            if not line:
                continue
            if indent >= findent:
                lst.append( line )
            if indent < findent:
                break 
    return lst

if __name__ == '__main__':
    block, to, fl, back = args.b, args.to, args.file_in, args.back
    lst = getLst(fl, block)
    lst = [ ' ' * back * 4 + i for i in lst]
    fl_name = pinto( to, lst)
    if to :
        os.system('diff %s %s' % (fl_name, to[0]))
        check = input("Please decide write:")
        cmd = 'mv %s %s' % (fl_name, to[0])
        if check in ['Y','y']:
            print(cmd)
            os.system(cmd)
        else :
            print(cmd)
















