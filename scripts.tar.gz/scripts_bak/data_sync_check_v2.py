#!/usr/bin/env    python3
import    os
import    re
import    sys
import    time
import    argparse
import    itertools
import    ningchao
from    datetime    import    datetime
import    subprocess    as    sp
from    ningchao.nData    import    data
from    collections    import    defaultdict
from    ningchao.nSys    import    trick,    system
example    =    '''    '''
parser    =    argparse.ArgumentParser(prog    =    sys.argv[0]    +    os.linesep,description='%s    %s'    %    (os.path.basename(sys.argv[0]),    example),    formatter_class=    argparse.RawTextHelpFormatter)
parser.add_argument(    'dir',    nargs    =    '?',    help    =    'dir    for    find    file')
parser.add_argument(    '-t',    nargs    ='+',    help    =    '''types    for    file    sync    different    disk.    ['txt$','pdf$']''')
parser.add_argument(    '-m',    nargs    ='?',    help    =    '''marker    by    manual    should    ABCD''')
parser.add_argument(    '-r',    action='store_true',    help    =    'uniq    files    and    refresh    the    store    file'    )
parser.add_argument(    '-p',    action='store_true',    help    =    'print    the    records'    )
if    len(sys.argv)    ==    1:
parser.print_help().__str__
sys.exit(2)
args    =    parser.parse_args()



def    run(cmd):
p    =    sp.Popen(cmd,    shell    =    True,    stdout    =    sp.PIPE,    stderr    =    sp.PIPE)
std,    err    =    p.stdout,    p.stderr
return    std

def    get_blk(    path    ):
root    =    '/'.join(    path.split('/')[0:2]    )
for    line    in    run('mount'):
line_arr    =    line.decode().split('    ')
if    line_arr[2]    ==    root    :
return    line_arr[0]
def    show(    data_fl    ):
os.system('cat    {}    |    sort    -k2,2nr'.format(data_fl))
exit()

def    get_uuid(    blk,    **kwargs):
manual_marker    =    kwargs.get('m')
if    not    manual_marker    :
exit(    '#Must    set    args.m    for    refresh    the    locate    file'    )
else    :
old    =    data.data('sequence.data').locate()
already_disks    =    set()
for    fl    in    old:
for    flpos    in    old[fl]:
disk    =    flpos.split('|')[-1]
if    '###'    in    disk:
already_disks.add(disk.split('###')[0])
if    manual_marker    in    already_disks    :
if    not    kwargs['r']:
exit('#Already    set    {},    make    sure    is    #######actuly    {}    disk    and    reset    or    set    -r    for    refresh    {}'.format(    manual_marker,    manual_marker,    manual_marker))
else    :
print    ('#Refresh    {},    for    args.r'.format(manual_marker),    file    =    sys.stderr)
if    not    manual_marker.isupper():
exit('#Must    be    upper    case    format')
for    line    in    run('sudo    blkid    {}'.format(blk)):
line    =    line.decode().strip()
line_arr    =    [    i.strip()    for    i    in    re.split(r':|\"\s+|=\"|\"$',    line    )    if    i    ]
sdd    =    line_arr.pop(0)
dit    =    {    line_arr[i]:line_arr[i+1]    for    i    in    range(0,    len(line_arr),    2    )}
print    (    line,    file    =    sys.stderr)
disk_id    =    ''
if    'PARTUUID'    in    dit    :
disk_id    =    '###'.join(    [manual_marker,    'PARTUUID:'+dit['PARTUUID']]    )
elif    'UUID'    in    dit:
disk_id    =    '###'.join(    [manual_marker,    'UUID:'+dit['UUID']]    )
elif    'LABEL'    in    dit:
disk_id    =    '###'.join(    [    manual_marker,    'LABEL:'+dit['LABEL']]    )
if    disk_id    :
return    disk_id
exit('Check    UUID')

def    get_records(    refresh    =    False    ):
bakinfor    =    data.data('sequence.data').locate()
infor    =    defaultdict(    list    )
with    open(    data_fl_cp    )    as    f    :
for    line    in    f:
line_arr    =    line.strip().split('\t')
flname    =    line_arr[0]
fls    =    [    i    for    i    in    line_arr    if    '/'    in    i    ]
output    =    set()
for    i    in    fls:
if    refresh    :
abspath    =    i.split('/')[0]
if    not    os.path.exists(    abspath    ):
continue
output.add(    i    )
if    list(output):
infor[flname].extend(    list(output)    )
return    infor


def    refresh(    Dir,    pattern,    data_fl    ):
all_refresh_size    =    0
bakinfor    =    data.data('sequence.data').locate()
infor    =    defaultdict(list)
today    =    datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')
data_fl_today    =    '/home/soft/soft/packages/ningchao/nData/sequence.data.{}'.format(today)
fls    =    system.dir(    Dir    ).detail_fls(    pattern,    depth    =    1000000,    abspath    =    True)
for    fl    in    fls:
flname    =    os.path.basename(    fl[0]    )
infor[flname].append(    '|'.join([    str(i)    for    i    in    [    *fl,    uuid    ]])    )
all_refresh_size    +=    fl[2]
print    ('##All    refresh    size    is    {}GB'.format(    round(    all_refresh_size/(    1024*1024*1024    ),    2)),    file    =    sys.stderr)
with    open(    data_fl_today,    'w'    )    as    f:
for    fl    in    bakinfor:
infor[fl].extend(bakinfor[fl])
for    fl    in    infor:
infor[fl]    =    set(    infor[fl]    )
for    flname    in    infor    :
print    (    flname,    len(infor[    flname    ]),    '\t'.join(    infor[    flname    ]    ),    sep    =    '\t',    file    =    f)

os.system('cp    {}    {}'.format(    data_fl_today,    data_fl))
print    ("sort    -k2,2nr    /home/soft/soft/packages/ningchao/nData/sequence.data",    file    =    sys.stderr)


def    check(    ifls    ):
sizes    =    []
for    fl    in    ifls:
fl_details    =    fl.split('|')
sizes.append(    fl_details[2]    )
return    set(    sizes    )

def    gb(    inputstring    ):
return    str(inputstring)    +    ':    '    +    str(round(    float(inputstring)/(1024*1024*1024),    2))    +'GB'

if    __name__    ==    '__main__':
lst    =    ['bam$','fastq$','fq.gz$','bw$','xls$','bed$',    'pdf$','sra$','md5$','MD5$','txt$',    'sh$','py$','R','r','js$']
print    (    '#Use    suffix    find    files.',    *lst,    file    =    sys.stderr    )
if    args.t    :
lst.extend(    args.t    )
pattern    =    '|'.join(lst)
data_fl    =    '/home/soft/soft/packages/ningchao/nData/sequence.data'
args.p    and    show(    data_fl    )
if    os.path.isdir(    args.dir    ):
uuid    =    get_uuid(    get_blk(    args.dir    ),    **vars(args))
print    ('#Dir    model',    file    =    sys.stderr)
refresh(    args.dir,    pattern,    data_fl    )
else    :
'''CREATE    TABLE    IF    NOT    EXISTS    sequenceFiles    (
fileName    TEXT,
fileAbsPath    TEXT,
diskWithID    TEXT,
ctime    NUMERIC,
size    INTEGER,
timeHuamnReadable    TEXT,
sortOrderBySystem    INTEGER,
PRIMARY    KEY    (    fileName,    fileAbsPath,    diskWithID));
'''
print    ('#{}    as    Dir    not    exists,    Goto    file    find    model'.format(args.dir),    file    =    sys.stderr)
con    =    sqlite3.connect(    os.path.join(    ningchao.__path__[0],    'nData/sequence.sqlite3.db')    )
cur    =    con.cursor()
olist    =    cur.execute('select    *    from    sequenceFiles    where    fileName    like    ?',    tuple('%{}%'.format(args.dir)    )
con.commit()
olist    =    list(    olist    )
print    (olist    )
#infor    =    data.data('sequence.data$').locate()
#match    =    {    i:    infor[i]    for    i    in    infor    if    p.search(i)    }
match_size,    match_disks    =    0,    []
if    match    :
print    (    '#num',    '#abspath','ctime','size','time',    'order','uuid',    sep    =    '\t')
for    fl    in    match:
print    (    '#Size    distrubution',    check(    match[fl]    ))
for    each    in    match[fl]:
arr    =    each.split('|')
size    =    int(arr[2])
match_size    +=    size
match_disks.append(    arr[-1]    )
arr[2]    =    gb(    arr[2]    )
print    (    len(match[fl]),    *arr,    sep    =    '\t'    )
for    disk    in    sorted(    set(    match_disks    )):
print    ('#All    size    is    {}GB,    ##include    {}    files,    disk    is    {}\n'.format(    round(    match_size    /    (1024*1024*1024),    2),    len(match[fl]),    disk))
else    :
print    ('#{}    not    in    {}'.format(args.dir,    data_fl),    file    =    sys.stderr)



















