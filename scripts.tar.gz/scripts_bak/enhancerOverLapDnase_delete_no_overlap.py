#!/usr/bin/env python3
import os
import sys
import dill
import argparse
import multiprocessing as mp
from collections import defaultdict
from ningchao.nSys import trick, fix, system
desc = ''' use hic or ctcf to delete no overlaping gene enhancer pair\n/dataB/ftp/pub/rheMac3/prefrontal/hic/whole_genome/symbols.regions.5.pickle'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'peirod', nargs='?', help = 'peirod')
parser.add_argument( 'tab', nargs='?', help = 'enhancerOverLapDnase bed')
parser.add_argument( '-m', nargs='?', help ='interaction infor dit or bedfiles from CTCF', default = '/dataB/ftp/pub/rheMac3/prefrontal/hic/whole_genome/symbols.regions.5.pickle')
parser.add_argument( '-c', nargs='?', help ='CTCF file')
parser.add_argument( '-o', nargs='?', help = 'output prefix')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def check_regions( pos, regions):
    chrom, start, end = pos
    for each in regions:
        interaction_chrom, interaction_start, interaction_end = each.rstrip().split('\t')
        if interaction_chrom != chrom:
            continue
        region_intersection = set.intersection( set( range(int(start), int(end)) ), set( range(int(interaction_start),int(interaction_end))) )
        if region_intersection :
            return 'yes'
    return 'no'

def line_check( line_infor, check_infor = '' ):
    header, interaction, outputfile = second_arg
    index, line = line_infor
    #print ( index, line, header, interaction, outputfile )
    symbol_enhancer_pair = index
    symbol_enhancer_pair_infor = symbol_enhancer_pair.split('.')
    regions = symbol_enhancer_pair_infor[-1].split('|')
    pos = regions[-3:]
    pos_key = '|'.join( pos )
    symbol = symbol_enhancer_pair_infor[0].upper()
    outline = [symbol_enhancer_pair]
    for i,v in enumerate( line ):
        peirod = system.dir.str_map_peirod(header[i])
        if symbol in interaction and peirod in interaction[symbol]:
            regions = interaction[symbol][peirod]
            whether_overlap = check_regions( pos, regions )
            outline.extend([ v, whether_overlap])
    return outline

def ctcf_delete_regions():
    ctcf_overlap_bed = fix.fix(args.tab).append('CTCFoverLap')
    cmd = 'bedtools intersect -a {} -b {} -wa > {}'.format( args.tab, args.c, ctcf_overlap_bed)
    kwargs.update({ 'ctcf_overlap_bed': ctcf_overlap_bed })
    for line in system.run( cmd, shell = True ):
        print ( line )

def main():
    ctcf_delete_regions()
    kwargs.update({'output': open( fix.fix( kwargs.get('ctcf_overlap_bed') ).insert('hicSelect'), 'w')})
    #
    interaction = dill.load( open(args.m, 'rb') )
    interaction_select = defaultdict( lambda : defaultdict (set) )
    for symbol in interaction.keys():
        for peirod in interaction[symbol]:
            if peirod != args.peirod:
                continue
            interaction_select[symbol][peirod] = interaction[symbol][peirod]
    interaction = interaction_select
    #
    kwargs.update({'interaction': interaction, 'peirod': args.peirod})
    arr = []
    with mp.Pool(6) as pool :
        tab = kwargs.get('ctcf_overlap_bed') if args.c else args.tab
        with open( tab ) as f :
            print ( 'Use {}...'.format(tab), file = sys.stderr )
            for i, line in enumerate(f):
                if not i % 600 :
                    print ( line, i, file = sys.stderr )
                    for each in pool.map( line_deal, arr ):
                        print ( *each, sep = '\t', file = kwargs.get('output'))
                    arr = [ line ]
                else :
                    arr.append( line )
        for each in pool.map( line_deal, arr):
            print ( *each, sep = '\t', file = kwargs.get('output'))
def line_deal(line):
    peirod = args.peirod
    interaction = kwargs.get('interaction')
    line_arr = line.rstrip().split('\t')
    symbol = line_arr[-1].split('.')[0]
    pos = line_arr[0:3]
    if symbol in interaction and peirod in interaction[symbol]:
        regions = interaction[symbol][peirod]
        line_arr.append( check_regions( pos, regions ) )
    return line_arr
if __name__ == '__main__':
    kwargs = vars( args )
    main()

























