#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.trick as trickTookit
import ningchao.nSys.parse as pTookit

parser = argparse.ArgumentParser(prog = sys.argv[0],description='get all peaks num in one project')
parser.add_argument('-j', nargs='?', default = 'work.js', help ='project json configuration file')
parser.add_argument('-d', nargs='?', default = '.', help ='work directory for json file')
parser.add_argument('-k', nargs='*', default = ['1e-3_peaks','narrowPeak','xls'], help ='js dir')

exec(trickTookit.usage('parser'))

args = parser.parse_args()

work_dir = os.path.abspath(args.d)
d = pTookit.parse_ini(os.path.join(work_dir,args.j),typ = 'json').to_dict()

marker_order = ['H3K4me3','H3K27me3','H3K27ac','pol2','CTCF']
region_order = ['cerebellum','hippo','prefrontal','striatum','thalamus','V1']
peirod_order = ['E80','E120','4month','4.5Year']
infor = {}

rawdata_dir = os.path.join(d['project_root'],'rawdata')
for period in d['period']:
    for region in d['period'][period]:
        for marker in d['period'][period][region]:
            if marker == 'Input':
                continue
            marker_dir = os.path.join(rawdata_dir,period,region,marker)
            dit = d['period'][period][region][marker]
            for rep in dit:
                if isinstance(dit[rep],list):
                    for each in dit[rep]:
                         for root,dirs,files in os.walk(os.path.join(marker_dir,each)):
                            for subrep in files:
                                names = subrep.split('.')
                                                               if trickTookit.sublist(args.k,names):
                                                                    line_num = 0
                                                                  fh = open(os.path.join(root,subrep))
                                    for line in fh:
                                                                            if line.startswith('#'):
                                                                                    continue
                                                                            else :
                                                                                    line_num = line_num + 1
                                    infor['.'.join([period,region,marker,each])] = line_num
                    for root,dirs,files in os.walk(os.path.join(marker_dir,rep)):
                        for each in files:
                                                        names = each.split('.')
                                                        if trickTookit.sublist(args.k,names):
                                                                line_num = 0
                                                                fh = open(os.path.join(root,each))
                                                                for line in fh:
                                                                        if line.startswith('#'):
                                                                                continue
                                                                        else :
                                                                                line_num = line_num + 1
                                                                infor['.'.join([period,region,marker,rep])] = line_num
                elif isinstance(dit[rep],str):
                    for root,dirs,files in os.walk(os.path.join(marker_dir,dit[rep])):
                        for each in files:
                            names = each.split('.')
                            if trickTookit.sublist(args.k,names):
                                line_num = 0
                                fh = open(os.path.join(root,each))
                                for line in fh:
                                    if line.startswith('#'):
                                        continue
                                    else :
                                        line_num = line_num + 1
                                infor['.'.join([period,region,marker,rep])] = line_num





print('\t'.join(['peirod','region','sample','H3K4me3','H3K27me3','H3K27ac','pol2','CTCF']))
for po in peirod_order:
    for ro in region_order:
        for rep in ['rep1','rep2']:
            out = [po,ro,rep]
            for mo in marker_order:
                key = [po,ro,mo,rep]
                key = '.'.join(key)
                if key in infor:
                    out.append(infor.pop(key))
                else :
                     out.append(0)
            out = [str(i) for i in out]
            print('\t'.join(out))

















