#!/usr/bin/env python3
import os
import sys
#import matplotlib
#matplotlib.use('Agg')
#import matplotlib.pyplot as plt
#plt.savefig( figname, dpi=250)
#plt.style.use('ggplot')
import argparse
from collections import defaultdict
from ningchao.nSys import trick, status
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'mat', nargs = '?', help = 'mat with cluster')
parser.add_argument( '-m', nargs = '?', help = 'peaks mapping', default = '/dataE/rawdata/zhufei/atac/degseq2/ATAC.merge.SAF')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def cluster_rowNames(mat):
    infor = defaultdict( list )
    with open( mat ) as f:
        for line in f:
            line_arr = line.strip().split('\t')
            infor[line_arr[-1]].append(line_arr[0])
    return infor

def mapper_parse( mapdata ):
    infor = defaultdict( list  )
    with open( mapdata, encoding='utf-8', errors='ignore') as f:
        for line in f:
            line_arr = line.strip().split('\t')
            infor[ line_arr[0] ] = line_arr
    return infor


if __name__ == '__main__':
    clustNames = cluster_rowNames( args.mat )
    mapping = mapper_parse( args.m )
    for clust in clustNames:
        names = clustNames[clust]
        ofh = open( clust, 'w' )
        for each in names:
            print ( *[ *mapping[each], clust ][1:4], sep = '\t', file = ofh )
        ofh.close()
        preared_bed = '{}.homer'.format( ofh.name )
        cmd = 'bed_homer_motif_prepare.py {} > {}'.format( ofh.name, preared_bed )
        cmd = status.cmd_accessory( '.', cmd, flag = '{}_homer_prepare'.format( ofh.name ) )
        print ( cmd )
        outdir = '{}.hommerOut.dir'.format( ofh.name  )
        cmd = 'findMotifsGenome.pl {} mm10 {}.motifOut -mask -len 8,10,12,14,16'.format( preared_bed, outdir )
        cmd = status.cmd_accessory( '.', cmd, flag = '{}_homer'.format( ofh.name ) )
        print ( cmd )



















