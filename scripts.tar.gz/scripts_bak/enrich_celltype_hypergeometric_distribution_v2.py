#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import numpy as np
import math
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import dates
from collections import defaultdict
from ningchao.nSys import trick,fix,parse
from ningchao.nBio import neuron,rheMac,geneKit

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tab', nargs = '*', help = 'tab and [ column ] you want to enrich' )
parser.add_argument( '-cat', nargs = '*', help = 'cat key for one' )
parser.add_argument( '-cut', nargs = '?', help = 'pvalue cut off', default = 1.3, type = float )
parser.add_argument( '-diff_num', nargs = '?', help = 'diff gene num you set', type = int )
parser.add_argument( '-bar', choices = ['h','v'], help = 'h|v' )
eval( parse.parse('/home/soft/soft/packages/ningchao/scripts/pick_line_from_maker.py').copy('s') )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def parse( args ):
    dit, tab = neuron.marker( args.s ).enrich( alias = False ), args.tab
    dit_alias = neuron.marker( args.s ).enrich( alias = True )
    return tab, fix.fix(tab[0]), dit, dit_alias, args.cat, args.bar


def soure_only_num( source_cellType_dit ):
    source_cellType_dit_only_num = {}
    for key in list(source_cellType_dit.keys()):
        gene_num = len(source_cellType_dit[key])
        #key = key.replace('xcx.Given.Age.','')
        trick.dinit( source_cellType_dit_only_num, key, gene_num)
    return source_cellType_dit_only_num

def tab_cellType( tab ):
    genes = []
    col = len(tab) > 1 and int(tab[1]) - 1 or 0
    for line in open(tab[0]):
        if 'modProbes' in line:
            continue
        line_arr = line.strip().split('\t')
        name_sps = line_arr[col].split('.')
        if 0 :
            rmIndex = trick.lst( name_sps ).index( ['copy'], regular = True )
            gene = '.'.join([ v for i,v in enumerate(name_sps) if i not in rmIndex ])
        else :
            gene = name_sps[0]
        genes.append( gene )
    return genes

def prepare( genes, soure_dit ):
    soure_only_num_dit, dit = soure_only_num( soure_dit ), {}
    for typ in soure_dit:
        whole_num = len( soure_dit[ typ ] )
        diff_num = args.diff_num and args.diff_num or len( genes )
        intersect_genes = list( set(soure_dit[ typ ]) & set(genes) )
        gene_num = len( intersect_genes )
        pvalue = 1 - stats.hypergeom( 25000,  whole_num, diff_num ).cdf( gene_num )
        pvalue = pvalue and -math.log10( pvalue ) or 0
        #if typ == 'PrimateSpcificGenes':
        #    pvalue = 2
        if intersect_genes:
            if pvalue > args.cut :
                print(typ, soure_dit[ typ ], intersect_genes, diff_num, pvalue) 
                trick.dinit( dit, typ, 'pvalue', pvalue )
    return dit

def goid2desc( lst ):
    fh, dit, out = open('/home/ningch/data/GO/htmls.gos.append'), {}, []
    for line in fh:
        line_arr = line.strip().split('\t')
        goid, desc = line_arr[0], line_arr[-1]
        trick.dinit( dit, goid, desc )
    for each in lst :
        if 'GO:' in each:
            if each in dit:
                out.append(dit[each])
                continue
        out.append( each )
    return out


def plot( plot_dit, prefix, bar = 'v'):
    '''h|v'''
    x, y= [], []
    for typ in plot_dit:
        x.append( typ )
        y.append( plot_dit[ typ ]['pvalue'] )
    pdit = dict(list(zip(x,y)))
    x = rheMac.trick().sort(list(pdit.keys()))
    label = x
    labels = [i.replace('ternal','') for i in label ]
    y = trick.dit(pdit).get(x)
    x = [ i + 1 for i,v in enumerate( x ) ]
    if bar == 'h' :
        fig = plt.figure( )
        ax = fig.add_subplot(111)
        ax.plot( x, y, 'bo')
        ax.vlines( x, 0, y, lw=2)
        ax.set_xlabel( tab[0] )
        ax.set_ylabel('-log10-Pvalue')
        plt.xticks( np.arange(len(x)) + 1, [i.replace('ternal','') for i in label], rotation = 90 )
        plt.axhline(y=1.3, color='r', linestyle='--')
        plt.show( )
        fig.savefig(prefix.append('%s.pdf' % args.s), bbox_inches='tight',pad_inches=+1, width = 12, height = 12 )
    elif bar == 'v':
        pval,typ = y,x
        typ.reverse()
        pval.reverse()
        x = np.arange(len(x))
        #fig = plt.figure(figsize = tuple(args.s))
        #formatter = FuncFormatter(pc)
        fig, ax = plt.subplots(1,2,figsize = tuple( (12, 120 )))
        fig.subplots_adjust(wspace=0, top=1, right=1, left=0, bottom=0.1)
        plt.barh(x, pval,alpha=1)
        ax[0].axis('off')
        #ax[0].xaxis.set_visible(False)
        #ax[0].xaxis.set_major_locator(plt.NullLocator())
        labels = [i.replace('ternal','') for i in label ]
        plt.yticks(np.arange(len(x)), goid2desc( labels) )
        fig.savefig( prefix.append('%s.pdf' % args.s), bbox_inches='tight',pad_inches=+1 )

if __name__ == '__main__':
    tab, prefix, source_dit, source_dit_alias, cat, bar = parse( args )
    print ( source_dit_alias)
    print ( cat)
    print ( bar )
    exit()
    soure_only_num_dit = soure_only_num( source_dit )
    print ( soure_only_num_dit )
    exit()
    genes = list( geneKit.gene( tab_cellType( tab ) ).reAlias() )
    if cat and len(cat) >= 2 :
        source_dit = trick.dit(source_dit).keyCat( cat )
    plot_dit = prepare( genes, source_dit )
    plot( plot_dit, prefix, bar = bar)
    





















