#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import pandas as pd
import matplotlib.pyplot as plt
from ningchao.nSys import trick,system,fix
from ningchao.nBio import chromosome
from ningchao.nBio import bed as BED
from ningchao.nBio import bw as BW
from tempfile import NamedTemporaryFile

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bw', nargs = '?', help = 'bw format for active signal')
parser.add_argument( '-rsmk', nargs = '?', help = 'transposons download from repeat masker', default = '/home/ningch/data/genome/rheMac8/transposons/rheMac_8.rmsk.txt')
parser.add_argument( '-l', nargs = '*', help = 'transposons level you want to show 1 2 3 ', default = [ 1 ], type = int )
parser.add_argument( '-s', nargs = '?', help = 'span for transposons', default = 3000, type = int )
parser.add_argument( '-c', nargs = '?', help = 'cutoff for active signal', default = 5, type = float )
parser.add_argument( '-p', choices = ['E50','E90','E120','0M','4M','45Y','20Y'], help = 'peirod', required = True )
parser.add_argument( '-t', choices = ['gb','promoter'], help = 'gb or promoter', default = 'gb' )

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def parse( args ):
    return os.path.realpath(args.bw), args.rsmk, args.s, args.l, args.c, args.p


def join( lst ):
    return '\t'.join( lst ) + '\n'
def split_rsmk( rsmk, level = [ 1, 2 ], force = True ):
    ofh_dit = {}
    if force :
        fls = list( system.dir('/home/ningch/data/genome/rheMac8/transposons/neuron').fls(fpattern = 'txt|gtf'))
        keys = [ os.path.basename(i).replace('/.','/').replace('.bed','') for i in fls ]
        return dict(list(zip(keys, fls)))
    fh, chroms = open( rsmk ), list( chromosome.chr('rh8').schr() )
    index, ofhs = [ i-1 for i in (6,7,8,10,11,12,13) ], []
    fit_lst = ['acro','centr','telo','RNA','Simple_repeat','Low_complexity','DNA','Unknown','Satellite','5S-Deu-L2','Jockey']
    fit_lst.extend(['Penelope', 'Helitron?','Dong-R4','CR1','RTE-BovB','RTE-X','Gypsy?','Gypsy'])
    for i, line in enumerate(fh):
        if trick.string( line ).fit( fit_lst, typ = 'or' ):
            continue
        line_arr = line.strip().split('\t')
        need = trick.lst(line_arr).get(index)
        if need[0] not in chroms:
            continue
        t1, t2, t3 = need[-1], need[-2], need[-3]
        t1, t2, t3 = [ i.replace('/','ORor') for i in (t1, t2, t3) ]
        t1_name, t2_name, t3_name = [ i.replace('/.','/') for i in ('.'.join(['/tmp/',t1,t2,t3,'bed']), '.'.join(['/tmp/',t1,t2,'bed']), '.'.join([ '/tmp/', t1,'bed'])) ]
        if 3 in level and t1_name not in ofh_dit:
            trick.dinit( ofh_dit, t1_name, open(t1_name, 'w'))
        if 2 in level and t2_name not in ofh_dit:
            trick.dinit( ofh_dit, t2_name, open(t2_name, 'w'))
        if 1 in level and t3_name not in ofh_dit:
            trick.dinit( ofh_dit, t3_name, open(t3_name, 'w'))
        3 in level and ofh_dit[ t1_name ].write( join( need ) )
        2 in level and ofh_dit[ t2_name ].write( join( need ) )
        1 in level and ofh_dit[ t3_name ].write( join( need ) )
    trick.dit( ofh_dit ).close()
    trick.dit( ofh_dit ).name()
    return ofh_dit

def rsmk_beds_span( rsmk_beds, span):
    out = {}
    for typ in rsmk_beds:
        typ_bed = BED.bed( rsmk_beds[typ] ).span(span = span, typ = args.t, simply = True )
        trick.dinit( out, typ, typ_bed )
    return out

def extract( promoter, bw, peirod ):
    cmds = []
    for typ in promoter:
        bed = promoter[typ]
        wd = system.dir('/dataB/ftp/pub/rheMac3/prefrontal/active/signal', peirod).check()
        out = fix.fix(typ).append('gb.out')
        print('echo %s %s' % ( typ, bed ))
        print(BW.bw( bw ).values( wd, bed, out, 'max', typ, typ+'.values.gb.sum' ))

# bw.values( self, wd, bed, out, etyp, label, flag)
if __name__ == '__main__':
    bw, rsmk, span, level, cutoff,  peirod = parse( args )
    genome = chromosome.chr('rh8').size
    rsmk_beds = split_rsmk ( rsmk, level = level )
    promoter = rsmk_beds_span( rsmk_beds, span)
    for typ in promoter:
        sys.stderr.write( '\t'.join([ typ, promoter[typ]]) + '\n' )
    extract( promoter, bw, peirod )
    #intersect_and_plot( rsmk_beds, bed, span = span )




















