#!/usr/bin/perl -w

######################################################
#This script is aimed at extracting gi number from   #
#          outfmt6 result                            #         
######################################################

use Getopt::Long;

my $ncbiresult;
my $out;
my $help;

GetOptions("ncbiresult|n=s" => \$ncbiresult,
		   "out|o=s" => \$out,
		   "help|h" => \$help);

if ( $help ) {
print STDOUT << "EOF";
Usege:
print $0
  			-ncbiresult|n    result of nucbi outfmt contain gi gb ref 
			-out|o           out txt
			-help|o          help
EOF
			exit();
}

			   
open NCBIRESULT, "< $ncbiresult" || die "Can't open this file! $!";
open OUT, "> $out" ||die "Can't open this file! $!";

while (<NCBIRESULT>){
chomp;
if (/^.*gi\|(\d+)\|.*$/ ) {
print OUT "$1\n";
}
}
close OUT;
close NCBIRESULT;
