#!/usr/bin/env python3
import os
import sys
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
import argparse
import pandas as pd
from collections import defaultdict
from ningchao.nSys import trick, system
from ningchao.nBio import chromosome
desc = ''' dir for find merge diff file'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'd', nargs='?', help = 'dir for find diff file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


wholelength = sum(chromosome.chr('rh8').size().values())


fls = system.dir(args.d).fls( '_vs_.*diff$', depth = 10, abspath = False)
infor = defaultdict( lambda : defaultdict ( int ) )
infor_length = defaultdict( lambda : defaultdict ( int ) )
for fl in fls:
    with open( fl ) as f :
        header = next(f).rstrip().split('\t')
        for line in f :
            line_arr = line.rstrip().split('\t')
            typ = line_arr[-2].replace('\"','')
            if 'NA' in typ :
                typ = 'other'
            infor[fl][typ] += 1
            infor_length[fl][typ] += math.log(int(line_arr[2]) - int(line_arr[1]))

lst = []
for fl in infor_length :
    for typ in infor_length[fl]:
        tmp = ( os.path.basename(fl).replace('.diff',''), typ, infor[fl][typ], infor_length[fl][typ] / wholelength, infor_length[fl][typ] )
        lst.append( tmp )

df = pd.DataFrame(lst, columns = [ 'period', 'typ', 'num', 'percent', 'length'] )

ax=sns.barplot( x = 'period', y = 'num', hue='typ',data = df )
ax.tick_params(axis='x', rotation=45)
plt.tight_layout()
plt.savefig( 'test.pdf', dpi=250, transparent=True, edgecolor='none', )

















