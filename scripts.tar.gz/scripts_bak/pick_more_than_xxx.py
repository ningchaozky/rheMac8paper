#!/usr/bin/env python
import sys
import format_fasta as f
if len(sys.argv) < 2:
	print('Usage:','fasta','[length=500]')
	exit()

file = open(sys.argv[1])
list = {}

if len(sys.argv) == 3:
	need_length = int(sys.argv[2])
else:
	need_length = 500

seq = ''
for line in file:
	if line.startswith('>'):
		name = line
		if len(seq) > need_length:
			print(forward,f.format_fa(seq,100),len(seq))
		seq = ''
	elif line is not None:
		forward = name
		seq += line.strip('\n')

if name == forward:
	if len(seq) > need_length:
		print(forward,f.format_fa(seq,100),len(seq))
