#!/usr/bin/env python3
import os
import re
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'fl', nargs = '?', help = 'featureCounts output ')
parser.add_argument( '-mcol', nargs = '*', help = ' merge colomn  ', default = [ 1, 2, 3, 4], type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


fh = open( args.fl )
merge_cols = args.mcol
for line in fh:
    if line.startswith('#'):
        continue
    line_arr, tmp_line = line.strip().split('\t'), []
    if 'Geneid' in line or 'Geneid_Chr_Start_End' in line:
        sub_arr = []
        for each in line_arr:
            if '/' in each:
                each = re.sub(r'\/.*\/','', each ).replace('.bam','').replace('Aligned.sortedByCoord.out','')
            sub_arr.append( each )
        line_arr = sub_arr
    
    key = '_'.join( [ line_arr[ i - 1 ] for i in merge_cols ] )
    tmp_line.append( key )
    tmp_line.extend( line_arr[6:] )
    print ( *tmp_line, sep = '\t')




























