#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick, system
example = '''two same rowname file'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'reps', nargs='+', help ='replicates')
parser.add_argument( '-index', nargs='?', type = int, help = 'index for', required = True )
parser.add_argument( '-valpos', nargs='*', type = int, help = 'values position', required = True )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def nameUpper( name ):
    arr = name.split('.')
    arr[0] = arr[0].upper()
    return '.'.join( arr )

stdout, stderr, returncode = system.run('paste %s' % ( ' '.join(args.reps)))
for line in stdout:
    line_arr = line.strip().split('\t')
    name = trick.lst( line_arr ).get( args.index - 1 )
    val = [ float(i) for i in trick.lst( line_arr ).get( [ i - 1 for i in args.valpos ] ) ]
    mean = sum(val) / len(val)
    print('\t'.join([ nameUpper( name ), str(mean) ] ))































