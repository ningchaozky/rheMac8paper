#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome,geneKit

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='this script already concert the chain\nbed_peaks_mapping.py -bed /home/ningch/data/genome/rheMac8/neuron/neuron.bed  -peak K4.bed.bw.tab', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-bed', nargs='?', help ='bed file you want to extract peaks', required = True )
parser.add_argument('-peak', nargs = '?', help ='peak file for the mapping', required = True )
parser.add_argument('-s', '-span', help = 'span for the mapping', nargs = '?', type = int , default = 2500 )
parser.add_argument('-onlyMapping', '-om', help = 'only output mapping peak', action='store_true')
parser.add_argument('-o', nargs = '?', help =' output file' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()

bed = open(args.bed)
peak = open(args.peak)
out = sys.stdout
span = args.s
if args.o :
    out = open(out,'w')
onlyMapping = args.onlyMapping




bed_infor = {}
chroms = chromosome.chr('rh8').chr
for line in bed:
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    if chrom not in chroms:
        continue
    if len(line_arr) >= 5 :
        chain = line_arr[5]
        gene = line_arr[3]
    else :
        print('should be the bed6')
    if chain == '+':
        start = int(line_arr[1]) - span
        end = int(line_arr[1]) + span
    else :
        start = int(line_arr[2]) - span
        end = int(line_arr[2]) + span
    start_binspan = start/float(span)
    end_binspan = end/float(span)
    if start_binspan == int(start_binspan):
        start_bin = int(start_binspan)
    else :
        start_bin = int(start_binspan) + 1
    trick.set2dict(bed_infor,chrom,str(start_bin),[])
    trick.set2dict(bed_infor,chrom,str(start_bin + 1),[])
    bed_infor[chrom][str(start_bin)].append(','.join([gene,chain]))
    bed_infor[chrom][str(start_bin + 1)].append(','.join([gene,chain]))


for line in peak:
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    if chrom == 'chr' :
        header = line_arr
        header.insert(3,'gene')
        print('\t'.join(header))
    if chrom not in chroms:
        continue
    start_bin = float(int(line_arr[1]))/span
    if start_bin == int(start_bin):
        start_bin = int(start_bin)
    else :
        start_bin = int(start_bin) + 1
    if chrom in bed_infor:
        start_bin = str(start_bin)
        out_line = line_arr[0:3]
        last = line_arr[3:]
        if start_bin in bed_infor[chrom] :
            out_line.append(','.join(geneKit.name(bed_infor[chrom][start_bin])))
            out_line.extend(last)
            out.write('\t'.join(out_line) + '\n')
        else :
            if onlyMapping:
                out_line.append('')
                out_line.extend(last)
                out.write('\t'.join(out_line) + '\n')
























