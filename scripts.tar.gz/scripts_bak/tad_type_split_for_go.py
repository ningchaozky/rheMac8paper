#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick, fix
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help ='excel you want to mini', default = sys.stdin, type = argparse.FileType('r'))
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



files = defaultdict( str )
header = args.tab.readline()
for line in args.tab:
    line_arr = line.rstrip().split('\t')
    typ = line_arr[0].split('|')[-1]
    if 'NA' in typ:
        typ = 'other'
    if typ not in files:
        files[typ] = open( fix.fix( args.tab ).append(typ, 'txt'), 'w')
        print ( header.rstrip(), file = files[typ] )
    print ( line.rstrip(), file = files[typ] )

























