#!/usr/bin/perl 
use strict;

unless(@ARGV){
	die "Usage: $0 fasta\n\tsort fasta by sequence length\n";
}

my($fa,$len,%seq,%len,$name);
open $fa,"$ARGV[0]";

while(<$fa>){
	chomp;
	s///g;
	if(/>/){
		s/>//;
		$name = $_;
	}else{
		$seq{$name} .= $_;
		$len{$name} += length;
	}
}

unless(@ARGV == 2){
	for(sort {$len{$a} <=> $len{$b}} keys %len){
		print ">$_\n$seq{$_}\n";
	}
}else{
	for(sort {$len{$b} <=> $len{$a}} keys %len){
		print ">$_\n$seq{$_}\n";
	}
}
