#!/usr/bin/env sh
if [ $# -lt 1 ]; then
	echo $0 anythingStartInPWDBamTranslate
	exit
fi


dir=$PWD
arr=(${dir//\// })
destDir=${arr[7]}/${arr[8]}

echo bw_view.sh $destDir *bam
bw_view.sh $destDir *bam


