#!/usr/bin/env python
import os
import sys
import string
import argparse
import random
import ningchao.nSys.trick as trKit
import ningchao.nSys.env as envKit
import ningchao.nBio.sge as sgeKit
import ningchao.nBio.pbs as pbsKit
from ningchao.nSys import ip, system

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('-cpu', nargs='?', help ='threads for use. default 1. unit: no unit', default = 2)
parser.add_argument('-m', nargs='?', help ='memory for use. default 3. unit: G', default = 8)
parser.add_argument('-n', nargs='?', default = 0, help ='split times for the bash. default 0 for all split, -1 for split only once')
#parser.add_argument('-s', nargs='?', help ='shell you want to split')
parser.add_argument( 'shell', metavar = 'shell', nargs='?', help ='shell you want to split')
parser.add_argument('-p', nargs='?', help ='prefix for output split files. default: a')
parser.add_argument('-nosub', action ='store_false', help ='submit the split shells. default: a')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def get_prefix( args ):
    s = string.ascii_letters
    prefix = ''.join( random.sample( s, 5) )
    if args.p:
        prefix = args.p
    return prefix


def pbs_get_dirs( fl ):
    wds = []
    with open( fl ) as f :
        for line in f:
            if 'cd ' in line:
                wd = line.strip().split(' ')[1]
                wds.append( wd )
    return wds
def get_now_dirs():
    now_dirs = []
    for line in system.run( 'merge_qstat_infor.py q', shell = True ):
        if line.startswith('/'):
            now_pbs = line.strip()
            wds = pbs_get_dirs( now_pbs )
            now_dirs.extend( wds )
    return now_dirs
def ignore_now_run_pbs( fl, now_dirs):
    wds = pbs_get_dirs( fl )
    return set( wds ) & set( now_dirs )


if __name__ == '__main__':
    prefix, now_dirs = get_prefix( args  ), get_now_dirs()
    if ip.ip().local() != '10.1.1.1':
        obj = pbsKit.pbs( cpu = args.cpu, mem = args.m, sub = args.nosub ).split( prefix, args.shell, num = args.n )
        for each in obj:
            now_run_dirs = ignore_now_run_pbs( each, now_dirs  )
            if now_run_dirs:
                print ('\n\n')
                print ('##Ignore {} for dirs run cmds, check by merge_qstat_infor.py q'.format( now_run_dirs ))
                print ('\n\n')
                continue
            if args.nosub:
                print('dsub %s' % each)
            else :
                print('nohup sh %s > %s.out &' % ( each, '%s.' % args.shell + each))
    else :
        obj = sgeKit.sge(cpu = args.cpu, mem = args.n ).split( prefix, args.shell, num = args.n )
        for each in obj:
            print('qsub %s' % each)
