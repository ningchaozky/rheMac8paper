#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import gzip
import argparse
import mygene
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('-gene2go', nargs = '?', help = 'gene2go file download from https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene2go.gz', default ='gene2go.hg')
parser.add_argument('-tax_id', choices = [ '9606', 'all'], help = 'hg:9606', required = True )

if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    mg = mygene.MyGeneInfo()
    g2go, tax_id = open( args.gene2go ), args.tax_id
    #return print mg.getgene( 1 )
    return mg, g2go, tax_id

def lineParse( line_arr, geneId2symbol_dit, dit ) :
    tid, gid, goid = line_arr[0:3]
    symbol = geneId2symbol_dit.get( gid )
    trick.dinit( dit, goid, [] )
    dit[goid].append( symbol )

def geneId2symbol_line_parse( line_arr, dit ):
    tid,gid,symbol = line_arr[0:3]
    trick.dinit( dit, gid, symbol )
def geneId2symbol( tax_id ):
    dit = {}
    gene_infor = open( '/home/ningch/data/GO/hg.geneId.symbol' )
    for line in gene_infor:
        line_arr = line.strip().split('\t')
        if tax_id == 'all':
            geneId2symbol_line_parse( line_arr, dit )
        elif line_arr[0] == tax_id:
            geneId2symbol_line_parse( line_arr, dit )

    return dit

def GOdit( gfh, geneId2symbol_dit, tax_id ):
    dit = {}
    for line in gfh:
        line_arr = line.strip().split('\t')
        tid = line_arr[ 0 ]
        if tax_id == 'all':
            lineParse( line_arr, geneId2symbol_dit, dit )
        elif tid == tax_id:
            lineParse( line_arr, geneId2symbol_dit, dit ) 
    return dit



if __name__ == '__main__':
    mg, gfh, tax_id = parse( args )
    geneId2symbol_dit = geneId2symbol( tax_id )
    dit = GOdit( gfh, geneId2symbol_dit, tax_id )
    for goid in dit:
        print(goid + '\t' + ','.join( dit[goid] ))
