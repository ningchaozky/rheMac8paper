#!/usr/bin/env Rscript
#first
#https://cran.r-project.org/web/packages/ggalluvial/vignettes/ggalluvial.html
alen <- commandArgs()
suppressMessages(library(argparser))
suppressMessages(library(ggalluvial ))
p <- arg_parser('script description')
p <- add_argument(p, "matrix", help="matrix for plot")
if ( is.null(p$help) || length(alen) < 5) {
    print(p)
    quit(status=1)
}
args <- parse_args(p, argv = commandArgs(trailingOnly = TRUE))
library( ggalluvial )
library( forcats )
library( dplyr )
#data(vaccinations)
#fct_reorder
#levels(vaccinations$response) <- rev(levels(vaccinations$response))
#df = read.table( 'chr1.e6.xls', check.names = FALSE, header = TRUE)
df = read.table( args$matrix, check.names = FALSE, header = TRUE)
plevels = c("E50", "E90", "E120", "0M", "4M", "45Y", "20Y")
slevels = paste('E', seq(12), sep="")
#df$p <- factor( df$period, levels = c("E50", "E90", "E120", "0M", "4M", "45Y", "20Y"))
pdf(paste(args$matrix, "stat.pdf", sep = "") )
df %>%
	mutate( period = factor( period, levels = plevels)) %>%
	mutate( stat = factor( stat, levels = slevels)) %>%
	#ggplot( aes(x = period, stratum = stat, alluvium = pos, y = num, fill = stat, label = stat)) +
	ggplot( aes(x = period, stratum = stat, alluvium = pos, fill = stat, label = stat)) +
 		scale_x_discrete(expand = c(.1, .1)) +
  		geom_flow( stat = "alluvium" ) +
  		geom_stratum(alpha = .5) +
  		geom_text(stat = "stratum", size = 3) +
  		theme(legend.position = "none") +
  		ggtitle("stat dynamic development")
#ggsave( paste(args$matrix, "stat.pdf", sep = "") )


dev.off()
