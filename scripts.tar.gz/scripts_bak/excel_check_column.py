#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick,excel
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('xls', nargs='?', help ='excel check')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
xls = args.xls
cxls = excel.xls(xls)
headers = cxls.header( args.xls )
print( 'header length: ', len(headers))
#sys.stdout.write('\t'.join(headers) + '\n')
summary = defaultdict( int )
summary['headerLength'] = len(headers)
excl, epara = excel.parse( args.xls )
with open( excl ) as f:
    for i,line in enumerate(f) :
        line_arr = line.strip().split('\t')
        arr = [ 'line number: ', i, 'line_length: ', len(line_arr), 'header length: ', summary['headerLength'] ]
        if summary['headerLength'] != len(line_arr):
            arr.append('no')
        else :
            arr.append('yes')
        print ( *arr, sep='\t' )
    #line_arr[3] = line_arr[3].replace(' ','')
    #print '\t'.join(line_arr)






















