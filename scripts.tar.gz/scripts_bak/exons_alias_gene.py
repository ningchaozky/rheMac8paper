#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import entrez

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('exon', nargs = '?', help = 'exon bed')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def parse( args ):
    return open( args.exon )


def pexon( fh, alias ) :
    dit,i,f = {},0,''
    for line in fh:
        line_arr = line.strip().split('\t')
        key = line_arr[3].split('.')
        name = key[0].upper()
        old_name = name
        copy = trick.lst(key).get( 'copy', regular = True )
        name = '.'.join([ name, copy ])
        i += 1
        if f != name:
            i = 1
            f = name
        print(name +'\t' +name+'.exon_%d' % i +'\t' + line, end=' ')
        if old_name in alias:
            name = '.'.join([ alias[old_name], copy ])
            print(name +'\t' +name+'.exon_%d' % i +'\t' + line, end=' ')
if __name__ == '__main__':
    exon = parse( args )
    alias = entrez.hgnc( ).gene2alias( coding = 'all' )
    alias = trick.dit( alias ).rev(valType='list')
    pexon( exon, alias)
































