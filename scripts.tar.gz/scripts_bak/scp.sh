#!/usr/bin/env bash

if [ $# = 0 ]; then
	echo $0 'file'
	exit
fi

for s in $*
do 
	echo  "scp $s ningch@192.168.118.81:/pnas/liujiang_group/ningch/data/chipseq/neuro/"
	scp $s ningch@192.168.118.81:/pnas/liujiang_group/ningch/data/chipseq/neuro/
done
