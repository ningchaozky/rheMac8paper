#!/usr/bin/env python3
import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import seaborn as sns
from ningchao.nSys import OONMFhelpers as OH
from scipy.stats import linregress
import matplotlib.pyplot as plt
from ningchao.nSys import trick, OONMF
from platform import python_version

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('dir', nargs= '?', help = 'directory')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


print(python_version())
def acquire_data(Dim1 = 20, Dim2=40, threshold=0.75):
    # fill in for whatever application
    pass

    data = np.random.rand(Dim1, Dim2)
    data = (data>threshold).astype(int)
    return data

data = acquire_data()
data.shape
plt.imshow(data, cmap='binary')
plt.title('binarized random data')
plt.ylabel('data dimension 1')
plt.xlabel('data dimension 2')
plt.savefig('test.pdf', width = 12, height = 12)

NMFer = OONMF.NMFobject(5)
NMFer.performNMF(data)
NMFer.Basis.shape
NMFer.Mixture.shape

plt.figure(figsize=(5,10))
plt.imshow(NMFer.Basis)
plt.colorbar()
plt.yticks(np.arange(NMFer.Basis.shape[0]))
plt.xticks(np.arange(NMFer.Basis.shape[1]))
plt.xlabel('NMF comp')
plt.ylabel('data dimension 1')
plt.title('Basis')
plt.savefig('test2.pdf', width = 12, height = 12)

NC_ar = [4,8,10,11,12,13,14,15,16,17,18,19,20,24,28,32,36]
NC_ar = np.array(NC_ar)
plt.clf()
plt.figure(figsize=(10,10))
prAUC_ar = []
for comp in NC_ar:
    finname = '../data/TotalPR/2018-06-08NC'+str(comp)+'_NNDSVD_TotalPR.txt'
    print ( finname )
    DF = pd.read_table(finname)
    prec = DF.TP.values / (DF.TP.values + DF.FP.values)
    recall = DF.TP.values / (DF.TP.values + DF.FN.values)
    F1 = 2*prec*recall / (prec+recall)
    prAUC_ar.append(np.trapz([1] + list(recall) + [0], [0] + list(prec) +[1]))
    plt.plot(DF.threshold.values, F1, '-k')

    
plt.plot([0.35, 0.35], [0.2, 0.8], '--r')
plt.plot([0.4, 0.4], [0.2, 0.8], ':r')
plt.plot([0.3, 0.3], [0.2, 0.8], ':r')
OH.increase_axis_fontsize()
plt.xlabel('decision boundary', fontsize=30)
plt.ylabel('F1 score', fontsize=30)
plt.savefig('test3.pdf', width = 12, height = 12)
plt.clf()
plt.figure(figsize=(10,10))
plt.plot(NC_ar, prAUC_ar, 'ok')
OH.increase_axis_fontsize()
plt.xlabel('k', fontsize=30)
plt.ylabel('AUPRC', fontsize=30)
plt.savefig('test4.pdf', width = 12, height = 12)
























