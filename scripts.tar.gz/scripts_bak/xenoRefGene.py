#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick as tr

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='xenoRefGene to bed', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'xenoRefGene', nargs='?', help ='select xenoRefGene from ucsc database' )
parser.add_argument('-o', nargs='?', help ='output of the file')
parser.add_argument('-t', choices = ['geneStartEnd','exon','intron'], help = 'output choices', default = 'geneStartEnd')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def parse( args ):
    ofh = args.o and open(args.o,'w') or sys.stdout 
    xenoRefGene = args.xenoRefGene
    xfh = open(xenoRefGene)
    choices = args.t
    return ofh, xfh, xenoRefGene, choices


def exon(exon_start,exon_end,chrom,after = []):
    exon_start = line_arr[9].split(',')
    exon_end = line_arr[10].split(',')
    out = []
    for i,v in enumerate(exon_start):
        if v.strip() != '':
            each_exon = [chrom,v.strip(),exon_end[i].strip()]
            if after != []:
                each_exon.append(after[0] +'.exon_' + str(i))
                each_exon.extend(after[1:])
            out.append('\t'.join(each_exon))
    return out

if __name__ == '__main__':
    ofh, xfh, xenoRefGene, choices = parse( args )
    for line in xfh:
        line_arr = line.strip().split('\t')
        idname, chrom, strand, txStart, txEnd, cdsStart, cdsEnd, exonCount, exon_start, exon_end = line_arr[1:11]
        print(cdsStart, cdsEnd, file=sys.stderr)
        name = line_arr[12]+'.'+line_arr[1]
        if choices == 'geneStartEnd':
            ofh.write('\t'.join([chrom,txStart,txEnd,name,str(0),strand]) +'\n')
        elif choices == 'exon':
            for each in exon(exon_start,exon_end,chrom, after = [name+'.'+idname, '0', strand]):
                print(each)
