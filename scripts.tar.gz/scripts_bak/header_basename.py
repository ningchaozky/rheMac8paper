#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tab', nargs='?', help ='tab' )
parser.add_argument( '-dstr', nargs='*', help = 'replace to null for the every str', default = ['.PFC.dnase.bw'] )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




with open( args.tab ) as f:
    header_arr = next(f).strip().split('\t')
    for s in args.dstr :
        header_arr = [ os.path.basename(i).replace(s,'') for i in header_arr ]
    new_header = '\t'.join(header_arr)
    print ( new_header, sep = '\t', file = sys.stdout )
    for line in f :
        print ( line.strip(), file = sys.stdout )



























