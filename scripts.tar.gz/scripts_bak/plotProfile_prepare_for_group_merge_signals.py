#!/usr/bin/env python3
import os
import sys
import gzip
import json
import argparse
from ningchao.nSys import trick, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tabs', nargs= '+', help = 'gzs file from plotProfile_prepare_for_group output gz files')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse():
    group_labels,group_boundaries = [], [0]
    data, relabel_num = [],0
    for tab in kwargs.get('tabs'):
        with gzip.open( tab ) as f :
            header = next(f).rstrip().replace(b'@', b'')
            tab_header_infor = json.loads( header )
            group_boundaries_add = group_boundaries[-1] + tab_header_infor.get('group_boundaries')[1]
            group_boundaries.append( group_boundaries_add )
            group_labels.append( *tab_header_infor.get('group_labels') )
            for line in f :
                line = line.decode()
                line_arr = line.rstrip('\n').split('\t')
                line_arr[0:4] = map( str, [ 1, relabel_num, relabel_num+1, '{}:{}-{}'.format(1,relabel_num,relabel_num+1) ] )
                relabel_num += 1
                data.append( '\t'.join( line_arr ) )
    tab_header_infor.update({'group_labels': group_labels, 'group_boundaries': group_boundaries })
    new_header = trick.string.replace( '@' + str(tab_header_infor), [ {'None': 'null', 'False': 'false', 'True': 'true'}, {'\'':'\"'}])
    with gzip.open( fix.fix(kwargs.get('tabs')[0]).append( *kwargs.get('tabs'), 'merge.gz'), 'wb') as f:
        f.write( new_header.encode() + b'\n')
        for line in data:
            f.write( line.encode() + b'\n' )
        #print ( *data, sep = '\n', file = f )




if __name__ == '__main__':
    kwargs = vars( args )
    parse()























