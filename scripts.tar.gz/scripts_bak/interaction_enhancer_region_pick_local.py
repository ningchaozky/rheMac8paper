#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import importlib
importlib.reload(sys)
import argparse
import math
import pandas as pd
sys.setdefaultencoding('utf8')
from ningchao.nSys import trick, system
from ningchao.nBio import rheMac34
from ningchao.nBio import bed as Bed
example = '''\npromoter region tss2K and peak file for enhancer math /dataB/ftp/pub/rheMac3/rheMac.js'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'js', nargs = '?', help = 'js file')
parser.add_argument( '-tss', nargs = '?', help = 'tss file for remove promoter region', default = '/home/ningch/data/genome/rheMac8/exon/merge_exons/gene.tss2k' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def sink( beds, tss ):
    for peirod in beds:
        ac_and_dnase, ac_and_dnase_vpromoter = open( '.'.join([peirod, 'acAndDnase.bed']), 'w' ), open( '.'.join([peirod, 'acAndDnase.vpromoter.bed']), 'w' )
        pbeds = beds[ peirod ]
        for line in Bed.bed( pbeds[1] ).intersect( pbeds[0], par = '-wo' ):
            line_arr = line.strip('\n').split('\t')
            ac_and_dnase.write( '\t'.join( [ line_arr[ i ] for i in [ 0, 1, 2 ] ] ) +'\n' )
        ac_and_dnase.close()
        system.fl( ac_and_dnase.name ).uniq()
        for line in Bed.bed( ac_and_dnase.name ).intersect( tss, par = '-wo -v' ):
            ac_and_dnase_vpromoter.write( line )
        ac_and_dnase_vpromoter.close()
        system.fl( ac_and_dnase_vpromoter.name ).uniq([ 1, 2, 3])
    #system.fl( fh.name ).uniq()
    #system.fl( enhancer_bed ).cut([ 1, 2, 3])
if __name__ == '__main__':
    cwd = os.getcwd()
    infor_obj = rheMac34.infor( args.js )
    beds = infor_obj.enh( )
    sink( beds, args.tss )
    #enhancer_bed = sink( beds, interaction, cwd)
    #pick up gene from region

























