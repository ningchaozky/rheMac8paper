#!/usr/bin/env python
import os
import sys
import argparse
import math
import numpy as np
import ningchao.nSys.fix as fixKit
import ningchao.nSys.trick as trKit
import matplotlib
matplotlib.use('Agg')
from matplotlib.ticker import FuncFormatter
import matplotlib.pyplot as plt


parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('i', nargs='?', help ='kobas output file')
parser.add_argument('-op', nargs='?', help ='output prefix for pdf')
parser.add_argument('-p', nargs='?', type = float, help ='pvalue for enrichment', default = 0.05)
parser.add_argument('-s', nargs='*', type = int, help ='figesize 8 8', default = [8,8] )
parser.add_argument('-f', nargs='*', help ='fiter for the type', default = [])
parser.add_argument('-n', nargs='?',type = int, help ='nums of type plot', default = 50)
parser.add_argument('-k', nargs='+', help ='key words for the term', required = True )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


out = fixKit.change_suff(args.i,'pdf')
if args.op:
    out = fixKit.change_suff(args.op,'pdf')

def pc(x,pos):
    print(x)
    return round(x,3)

fh = open(args.i)
typ = []
pval = []
i = 0
for line in fh:
    if 'GO:' in line:
        line_arr = line.split('\t')
        pvalue = float(line_arr[5])
        if pvalue == 0:
            pvalue = 0.0000000001
        if line_arr[0] not in typ and pvalue <= args.p:
            if trKit.lstInStr(args.f,line_arr[0],typ = 'or'):
                continue
            if not trKit.string.match(  line_arr[0], args.k, typ = 'or', regular = True):
                continue
            if i <= args.n - 1:
                i += 1
                typ.append(line_arr[0])
                if -math.log(pvalue,10) == 10:
                    pval.append(350)
                else :
                    pval.append(-math.log(pvalue,10))

typ.reverse()
pval.reverse()
x = np.arange(len(typ))
#fig = plt.figure(figsize = tuple(args.s))
#formatter = FuncFormatter(pc)
fig, ax = plt.subplots(1,2,figsize = tuple(args.s))
fig.subplots_adjust(wspace=0, top=1, right=1, left=0, bottom=0.1)
plt.barh(x, pval,alpha=1)
plt.axvline( 1.5, ls='--', linewidth= 0.5, color ='grey' )
ax[0].axis('off')
#ax[0].xaxis.set_visible(False)
#ax[0].xaxis.set_major_locator(plt.NullLocator())
plt.yticks(x,typ)
plt.savefig(out,format = 'pdf')




