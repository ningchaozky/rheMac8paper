#!/usr/bin/env python
import os
import sys


def usage():
	if len(sys.argv) <= 1:
		print(sys.argv[0],'file:peak_bed','int:span')
		exit()

if __name__ == '__main__':
	usage()	
span = int(sys.argv[2])
xls = open(sys.argv[1])
for line in xls:
	line_arr = line.rstrip().split('\t')
	a1 = line_arr[1]
	a2 = line_arr[2]
	line_arr[1] = int(line_arr[1])
	line_arr[2] = int(line_arr[2]) + span
	if line_arr[1] < 0 or line_arr[2] < 0:
		continue
	if line_arr[2] < line_arr[1]:
		line_arr[1] = a1
		line_arr[2] = a2
	line_arr = [str(i) for i in line_arr]
	line = '\t'.join(line_arr)
	sys.stdout.write(line+'\n')

