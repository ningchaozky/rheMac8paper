#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import matplotlib
import pandas as pd
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
import numpy as np
import seaborn as sns;sns.set(color_codes=True)
import matplotlib.pyplot as plt
from ningchao.nSys import trick, system, fix
example = '''plot the same transposons in same fig'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'p', nargs = '+', help = '''['E50','E90','E120','0M','4M','45Y','20Y']''')
parser.add_argument( '-dir', nargs='?', help = 'dir for ouput from transposons_active_H3K27me3.py  . /dataB/ftp/pub/rheMac3/prefrontal/bw/20Y.PFC.K27.ppois.bw -p 20Y -y 300', default = '.')
parser.add_argument( '-t', nargs='+', choices = ["MIR","ERV1","ERVL-MaLR","L2","ERV1?","ERVK","L1","LTR","ERVL","LTR?","Alu","L1-Tx1","ERVL?","SVA"], help = 'typ you want to plot')
parser.add_argument( '-y', nargs = '?', help = 'y max', default = 15, type = float )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse( args ):
    fls = system.dir( args.dir ).fls( level = 0, pattern = 'plot.*dat' )
    choices = ["MIR","ERV1","ERVL-MaLR","L2","ERV1?","ERVK","L1","LTR","ERVL","LTR?","Alu","L1-Tx1","ERVL?","SVA"]
    return args.dir, list(zip( args.p,trick.lst( list(fls) ).match( args.p ) ))

def prepare( data ) :
    labels = []
    ofh = open( '/tmp/plot.peirods', 'w' )
    print ( ofh.name, file = sys.stderr )
    ofh.write( '\t'.join( ['type', 'Transposons', 'signal', 'K27me3', 'peirod']) +'\n' )
    i = 0
    for p, fl in data:
        fh = open(fl)
        sys.stderr.write( fl + '\n' )
        next(fh)
        for line in fh:
            line_arr = line.strip().split('\t')
            if line_arr[0] not in ['ERV1','MIR','ERVL-MaLR'] :
            	continue
            if 'nosignal' in line_arr[2] :
                continue
            label = '.'.join( [line_arr[0], line_arr[2], p ])
            if label not in labels:
                i += 1
                sys.stderr.write( label +'\n' )
                labels.append( label )
            line_arr.append( p )
            line_arr[1] = str( i )
            ofh.write( '\t'.join( line_arr ) + '\n' )
    ofh.close()
    return ofh.name, labels

def plot( fname, labels, marker ):
    data = pd.read_csv( fname, sep = '\t', header = 0 )
    print ( data )
    ax=sns.boxplot( x= 'type', y ='K27me3', data = data, hue = 'peirod', showfliers= False )
    #plt.ylim((0, args.y))
    #plt.xticks( np.arange(len(labels)), labels )
    ax.set_xticklabels(ax.get_xticklabels(), rotation=70)
    plt.savefig( fix.fix(fname).append( 'new', 'transposon.pdf'), format='pdf',  bbox_inches='tight', pad_inches=+1 )


if __name__ == '__main__':
    wd, data = parse( args )
    dfl, labels = prepare( data )
    plot( dfl, args.p, 'K27me3' )





















