#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
plt.tight_layout()
import pandas as pd
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from numpy import asarray
from PIL import Image
from scipy import stats
from ningchao.nSys import trick
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'pngs', nargs='+', help = 'pngs for plot')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

infor = defaultdict( list )

lst = []
for png in args.pngs:
    ph = Image.open( png ).convert('RGBA')
    for each in ph.getdata():
        for e in each:
            if 200 < int(e) < 255 :
                infor[png].append( e )
                lst.append( [ png, e ] )
for key in infor:
    print ( key, len(infor[key]))
print ( stats.ttest_ind(*infor.values()) )
df = pd.DataFrame( lst, columns = [ 'png', 'v'] )
ax = sns.boxplot( x='png', y='v', data = df )
plt.savefig(('prefix' + '.pdf'), format='pdf',  bbox_inches='tight', pad_inches=+1 )
    #data = asarray(ph)
    #print ( data[:,:,-3][0] )
    #print ( data.shape, png )
























