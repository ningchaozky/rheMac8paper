#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick
from collections import defaultdict
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'xls', nargs='?', help = 'excel for analysis')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_infor():
    df = pd.read_excel( args.xls, engine = 'openpyxl')
    symbols = defaultdict( list )
    for col_name in df :
        genes = [ i.upper() for i in df[ col_name ].to_list() if isinstance( i, str ) ]
        for gene in genes:
            symbols[gene].append( col_name )
    return symbols 



if __name__ == '__main__':
    symbols = get_infor()
    print ( 'symbol','protein', sep = '\t' )
    for symbol in symbols :
        print ( symbol, '|'.join( symbols[symbol] ), sep = '\t')



























