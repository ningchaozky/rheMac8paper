#!/usr/bin/env python3
import os
import sys
import argparse
from collections import defaultdict
from ningchao.nSys import trick, color

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'bed', nargs = '?', help = 'merge the neighbors chromHMM_multi_bed_split output file')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def com2str( string ):
    return '.'.join( eval( string ) ).replace('H3','').replace('me3','')

def c( string ):
    if 'chr' not in string:
        return 'chr' + string

if __name__ == '__main__':
    color_dit = defaultdict( str )
    print ('''track name={} description={} visibility=2 itemRgb="On" '''.format(args.bed,args.bed))
    with open( args.bed ) as f :
        fchrom, fstart, fend, fstat, fcombinations = next( f ).strip().split('\t')
        lst, num, name = [ fstart, fend ], 0, '{}.{}.{}'
        for line in f:
            chrom, start, end, stat, combinations = line.strip().split('\t')
            if 'MT' in chrom or 'M' in chrom:
                continue
            if stat == fstat and chrom == fchrom:
                lst.append(start)
                lst.append(end)
            else :
                num += 1
                if fstat not in color_dit:
                    color_dit[ fstat ] = ','.join( [ str(i) for i in color.color().random(num = 1)] )
                lst = sorted([ int(i) for i in lst ])
                print ( c(fchrom), lst[0], lst[-1], name.format( num, fstat, com2str(fcombinations)), 0, '+',  lst[0], lst[-1], color_dit[ fstat ], sep = '\t' )
                fchrom, fstat, lst, fcombinations = chrom, stat, [ start, end ], combinations
        print ( c(fchrom), lst[0], lst[-1], name.format( num, fstat, com2str(fcombinations)), 0, '+',  lst[0], lst[-1], color_dit[ fstat ], sep = '\t' )

























