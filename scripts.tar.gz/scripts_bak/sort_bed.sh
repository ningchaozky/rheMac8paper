#!/usr/bin/env sh 
if [ $# == 0 ]; then
	echo -e "$0 bed"
else
	sort -k1,1 -k2,2n $1
fi
