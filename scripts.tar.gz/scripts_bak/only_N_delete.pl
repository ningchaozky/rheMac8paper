#!/usr/bin/perl -w



unless(@ARGV){
	print "\nUsage: $0 list.txt gff3\n\tdelete the transcripts for gff3 file\n\n";
}
else{

	open $del,"$ARGV[0]";
	open $gff3,"$ARGV[1]";

	$list = "\n";
	while(<$del>){
		chomp;
		$list .= "$_\n";
	}


	open OUT, "> del.txt";
	open OUT1, "> out.txt";
	while(<$gff3>){
		chomp;
		@tmp = split /\t/,$_;
		$tmp_length = @tmp;
		if($tmp_length < 5){
			print OUT1 "$_\n";
		}
		else{
			$annotation = (split /[=;]/,$tmp[8])[1];
			if($list =~ /$annotation\n/){
				print OUT "$_\n";
			}
			else{
				print OUT1 "$_\n";
			}
		}
	}	
}


