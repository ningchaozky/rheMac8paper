#!/usr/bin/env python3
import os
import sys
import argparse
import sqlite3
from ningchao.nSys import trick
import ningchao
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('pattern', nargs='?', help = 'patten for search go term')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


datadir = ningchao.__path__[0]
db = os.path.join( datadir, 'nData', 'hsa.db')
print ( db )
con = sqlite3.connect( db )
cur = con.cursor()
sql = 'select goid,name from Gos where name like ?'
print ( sql )
sql_out = list( cur.execute( sql, tuple([ '%{}%'.format( args.pattern ) ]) ) )
con.commit()

all_genes = []
for goid, term in sql_out:
    #sql = 'select gid,goid from GeneGos where goid like ?'
    sql = 'select GeneGos.gid,GeneGos.goid, Genes.name from Genes JOIN GeneGos on Genes.gid = GeneGos.gid where GeneGos.goid like  ?'
    goid_sql_out = list( cur.execute( sql, tuple([ goid ])) )
    con.commit()
    genes = []
    for gid,goid,symbol in goid_sql_out:
        try :
            symbol = [ i.strip() for i in symbol.split(',') if i.strip() ][0]
        except :
            print ( 'Check: ', gid, goid, 'No symbol: ', symbol )
        if symbol not in all_genes:
            all_genes.append( symbol )
        genes.append( symbol )
    print ( goid, term, len(genes) )
    print ( ','.join( genes ) )
print ('all {}: {}'.format( args.pattern, len(  all_genes ) ))
print ( ','.join( all_genes ) )


























