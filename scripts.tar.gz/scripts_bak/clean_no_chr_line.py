#!/usr/bin/env python
import os
import sys
import re
import ningchao.usage as u 
import ningchao.nSys.fix as f
import ningchao.nBio.chromosome as c



if __name__ == '__main__':
    u.usage('file:ascii str:hg19|hg38|mm10|rh3|rh8|dm6')
    input_file = open(sys.argv[1])
    output_file_name = f.insert_suff(sys.argv[1],'chr',-1)
    output_file = open(output_file_name,'w')
    if 'mm10' in sys.argv[2]:
        schr = c.chr('mm10').schr()
    if 'hg19' in sys.argv[2]:
        schr = c.chr('hg19').schr()
    if 'hg38' in sys.argv[2]:
        schr = c.chr('hg38').schr()
    if 'rh8' in sys.argv[2] or 'rh3' in sys.argv[2]:
        schr = c.chr('rh8').schr()
    if 'dm6' in sys.argv[2]:
        schr = c.chr('dm6').schr()
    chroms = list( schr )
    for line in input_file:
        line_arr = line.strip().split('\t')
        if not line_arr[0].startswith('chr'):
            line_arr[0] = 'chr' + line_arr[0]
        if line_arr[0] not in chroms:
            continue
        output_file.write('\t'.join(line_arr) + '\n')
    






