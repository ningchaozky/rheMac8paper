#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import re  ##正则表达式处理工具
import struct  ##二进制数据操作
import importlib
importlib.reload(sys)
import argparse
sys.setdefaultencoding('utf8')
from ningchao.nSys import trick
example = '''swf'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('swf', nargs = '?', help = 'swf')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()
 
def extract_swf(filename, buf, offset):
    try:
        length = struct.unpack_from('<L', buf, offset+4)[0]
        swfname = filename + '_offset_0x%x.swf=' % offset
        open(swfname,'wb').write(buf[offset:offset + length])
        print('[+] Find embeded swf file at offset 0x%x ' % offset)
        print('[+] Save embeded swf file to ' + swfname)
    except:
        pass
        
 
 
if __name__ == '__main__':
  
    filename = args.swf

    print('[+] Searching embeded swf file in ' + sys.argv[1])
 
    
    buf = open(filename, 'rb').read()
    pattern = re.compile('FWS|CWS')
    match_obj = pattern.search(buf, 0)
 
    while match_obj  != None:   ##循环提取（若文件中包含多个SWF文件）
        try:
            extract_swf(filename, buf, match_obj.start())
        except:
            pass
        match_obj = pattern.search(buf, match_obj.end())  ##下一个匹配




























