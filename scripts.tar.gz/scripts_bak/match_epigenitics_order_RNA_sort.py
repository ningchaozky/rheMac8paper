#!/usr/bin/env python3
import os
import sys
import argparse
import pandas as pd
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'sortName', nargs = '?', help = 'sort column name groupby')
parser.add_argument( 'xls', nargs = '?', help = 'mat for groupby sort')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



df = pd.read_csv( args.xls, sep = '\t', header = 0 )
df = df.groupby(['spd']).apply( lambda x: x.sort_values([args.sortName], ascending = False)).reset_index( drop = True )
inSPD = df[ df.spd == 1 ]
outSPD = df[ df.spd == 0 ]
df = pd.concat( [ inSPD, outSPD ])
#df[args.sortName] = df[df[args.sortName] > 100] = 100
df.to_csv(sys.stdout, sep = '\t', index_label = 'id', index = None)


























