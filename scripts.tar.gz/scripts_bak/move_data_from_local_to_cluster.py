#!/usr/bin/env python
import os
import sys

if len(sys.argv) <= 1 :
	print(sys.argv[0],'prefix','suffix','work_dir','for|rev:destination_dir')
	exit()


ips = ['192.168.118.181','192.168.76.34']
if len(sys.argv) > 5 :
	ips.reverse()

dir_path = os.path.abspath(sys.argv[3])
for each in os.walk(dir_path):
	dirpath,dirnames,filenames = each
	if dirnames == []:
		for each_file in filenames:
			if each_file.startswith(sys.argv[1]) and each_file.endswith(sys.argv[2]):
				file_dir = dirpath.replace(dir_path,'')
				file_abs = os.path.join(dirpath,each_file)
				des_file_dir = (sys.argv[4]+file_dir).replace('//','/')
				print("ssh %s mkdir -p %s" % (ips[1],des_file_dir))
				print('scp %s ningch@%s:%s' % (file_abs,ips[1],des_file_dir))
					
