#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import chromosome

description=''' if bed only three column with keep start +- span end end +- span'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='bed pick promoter', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='bed file')
parser.add_argument('-s', nargs='?', type = int, help ='span from tss', default = 3000)
parser.add_argument('-t', choices=['tss','geneBody'], help ='type you want to get', default = 'tss')
parser.add_argument('-o', nargs='?', help = 'output file', type = argparse.FileType('w'), default = sys.stdout)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


def parse ( args ) :
    span, chroms, typ, bfh = args.s, chromosome.chr('rh8', sexX = True ).size(), args.t, open(args.bed)
    return span, chroms, typ, bfh

def line_parse(line):
    line_arr = line.strip().split('\t')
    chrom = line_arr[0]
    start = int(line_arr[1])
    end = int(line_arr[2])
    if len(line_arr) == 3 :
        return list([chrom,start,end])
    else :
        name = line_arr[3]
        chain = line_arr[5]
        return list([chrom,start,end,name,'0',chain])

def deal( bfh, chroms, typ = 'tss'):
    input_position = bfh.tell()
    line_arr = line_parse( next(bfh) )
    if len( line_arr ) == 3 :
        chain = 'bothKeep'
        print ( 'chain choose: ', chain, file = sys.stderr )
    bfh.seek( input_position )
    for line in bfh:
        line_arr = line_parse( line )
        if chain == 'bothKeep':
            chrom,start,end = line_arr
        else :
            chrom,start,end,name,phold,chain = line_arr
        if typ == 'tss':
            if chain == 'bothKeep':
                end2 = end + span
                start2 = end - span
                end = start + span
                start = start - span
            elif chain == '+':
                end = start + span
                start = start - span
            elif chain == '-':
                start = end - span
                end = end + span
        elif typ == 'geneBody':
            start = start - span
            end = end + span
        if start < 0 : start = 0
        if end < 0 : end = 0
        if start > chroms[chrom]: start = chroms[chrom]
        if end > chroms[chrom]: end = chroms[chrom]
        line_arr[1] = start; line_arr[2] = end
        line_arr = [ str(i) for i in line_arr ]
        print ( *line_arr, sep = '\t', file = args.o )
        if chain == 'bothKeep':
            line_arr[1], line_arr[2] = start2, end2
            print( *line_arr, sep = '\t', file = args.o)

if __name__ == '__main__':
    span, chroms, typ, bfh = parse ( args )
    deal( bfh, chroms, typ = typ)



















