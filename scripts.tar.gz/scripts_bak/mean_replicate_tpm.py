#!/usr/bin/env python3
import os
import sys
import argparse
from ningchao.nSys import trick,fix, system
import pandas as pd
from collections import defaultdict

example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'tpm', nargs = '?', help = 'tpm matrix')
parser.add_argument( '-c', choices = ['zhufei','ztz', 'dmel'], help = 'chioces for replicate', required = True)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def get_group( columns, choice ):
    names = list( columns )
    reps_pos = defaultdict( dict )
    for each in choice:
        enum = system.dir.str_map_peirod( each, up = '', down = '', log = True)
        if args.c == 'ztz':
            reps_pos[each] = [ v for i,v in enumerate(names) if system.dir.str_map_peirod(v, up = '/', down = '/', log = True) == enum ]
        else :
            print ( each )
            reps_pos[each] = trick.lst( names ).get( '{}\.'.format(each), regular = True )
    return reps_pos

def spChoices( choice ):
    peirods = []
    if choice == 'rh8':
        peirods = ['E50','E90','E80','E120','0M','4M','45Y','20Y']
    elif choice == 'hg19':
        peirods = ['11w','13w','h14w','16w','h18w','h23w','h24w','h26w']
    elif choice == 'ko':
        peirods = ['WT','APP','DBN1','CRE','CAB1']
    elif choice == 'dmel':
        #peirods = ['kir','KO','plus','high','low','R71G01','G59','R2556','R9329','9328']
        peirods = [ 'EcR', 'EcRA', 'ss2', 'EcRB1', 'G59', 'kir', 'high', 'KO', 'low', 'plus' ]
    elif choice == 'zhufei':
        peirods = ['TCPctr','PL.D6','PL.D11','PH.D6']
    elif choice == 'ztz':
        peirods = ['GV','zygote','2cell_early','2cell_late','4cell','8cell','morula','ICM']
    return peirods

df = pd.read_csv( args.tpm, sep = '\t', header = 0, index_col = 0 )
choice = spChoices( args.c )
reps_pos = get_group( df.columns, choice )
print ( reps_pos, file = sys.stderr )
for sample in reps_pos:
    df[sample] = df[reps_pos[sample]].mean( axis = 1 )
df.round(4).to_csv( fix.fix(args.tpm).append('mean'), sep = '\t', index = True)






























