#!/usr/bin/env python3
import os
import sys
import gzip
import xlrd
import sqlite3
import argparse
from ningchao.nSys import trick
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'geneList', nargs = '?', help = 'gene in the first col')
parser.add_argument( 'allian', nargs = '?', help = 'https://www.alliancegenome.org/downloads gz tsv file')
parser.add_argument( '-col', nargs = '?', help = 'col for gene symbol', default = 3, type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def infor( allian ):
    fh, info = gzip.open(allian, 'rt'), {}
    title = [ 'symbol', 'gene_id', 'desc' ]
    for line in fh:
        if line.startswith('#') or not line.strip():
            continue
        line_arr = line.strip().split('\t')
        symbol, gene_id, desc = line_arr
        info.update({ symbol: desc})
        info.update({ gene_id: desc})
    return info



def select( symbol, cur, dmel = True):
    if dmel :
        sql = '''select description from geneInfoDmel where Symbol like ? '''
    else :
        sql = '''select description from geneInfo where Symbol like ? '''
    sys.stderr.write( sql +'\n' )
    cur.execute( sql, ( symbol, ))
    return cur.fetchall()




if __name__ == '__main__':
    allgene = infor( args.allian )
    con = sqlite3.connect( '/home/soft/data/genome/rheMac8/annot/gene/gene.db' )
    cur = con.cursor()
    xls = xlrd.open_workbook( args.geneList )
    for sheet in xls.sheets():
        for i in range( sheet.nrows ):
            line_arr = sheet.row_values(i)
            if 'st_gene_id' in line_arr:
                continue
            try :
                st_gene_id, gene_id, symbol, log = line_arr[0:4]
            except :
                print ( line_arr )
                exit()
            if symbol in allgene:
                print ( st_gene_id, gene_id, symbol, log, allgene[ symbol ], sep = '\t' )
            elif gene_id in allgene:
                print ( st_gene_id, gene_id, symbol, log, allgene[ gene_id ], sep = '\t' )
            else :
                descriptions = select( symbol, cur )
                if not descriptions :
                    descriptions = select( symbol, cur, dmel = False)
                print ( st_gene_id, gene_id, symbol, log, descriptions, sep = '\t' )

























