#!/usr/bin/env python3
import os
import re
import sys
import argparse
import urllib.request
from ningchao.nSys import trick, system
from bs4 import BeautifulSoup as bs
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'p', nargs = '?', help = 'include pattern', default = '.*')
parser.add_argument( '-mat', nargs = '?', help = 'gse_gsm.py download from internet', default = '/uDiskE/data/early_embryo/GSE_accs.txt.xls')
parser.add_argument( '-f', nargs = '?', help = 'fiter pattern', default = 'teateatateatataete')
parser.add_argument( '-srr', nargs = '?', help = 'srr.sh file for fitter the already download file')
parser.add_argument( '-sraDirs', nargs = '+', help = 'sra data directory', default = [ '/uDiskE/data/early_embryo' ])
parser.add_argument( '-s', help = 'start', action = 'store_true')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def already_download_find_from_dir( args ):
    dit = {}
    for d in args.sraDirs:
        for fl in system.dir(d).fls( 'sra$', depth = 1000000):
            dit.update( { os.path.basename(fl).replace('.sra',''): fl} )
    return dit


def already_download( *args ):
    srr = len(args) and args[0] or 'srr.sh'
    already_download_lst = []
    if not os.path.exists('srr.sh'):
        pass
    else :
        print ('##In pwd find srr.sh, and check whether exists in ./srr.sh', file = sys.stderr)
        with open( srr ) as f:
            for line in f:
                line_arr = re.split(r'\s+', line.replace('#','').strip())
                already_download_lst.extend( line_arr )
    return list( set( already_download_lst ) )



def pick( mat, p, f ):
    p = re.compile(r'{}'.format( p ), re.I)
    f = re.compile(r'{}'.format( f ), re.I)
    with open( mat ) as mat:
        for line in mat:
            if p.search( line ) and not f.search( line ):
                lst = line.strip().split('\t')
                lst.insert(0, line.strip() )
                yield lst



if __name__ == '__main__':
    lst = []
    already_download_lst = already_download( args.srr )
    already_download_srr = already_download_find_from_dir( args )
    for line, gse, gsm, desc in pick( args.mat, args.p, args.f ):
        if gsm not in lst :
            if args.s:
                if gsm in already_download_lst:
                    sys.stderr.write('{} already download, ignore it\n'.format(gsm))
                else :
                    stdout = system.run('esearch -db sra -query {} | efetch -format runinfo'.format( gsm ), shell = True )
                    for each in stdout:
                        if 'Run' in each or not each.strip():
                            continue
                        print ( '#' + line )
                        print ( '#' + line, file = sys.stderr )
                        srr = each.split(',')[0]
                        cmd = 'prefetch {} --max-size 100G  --output-directory .'.format( srr )
                        if srr in already_download_srr:
                            print ( '#{} sra file already donwload igore it'.format( already_download_srr[srr]))
                            cmd = '#' + cmd
                        print ( cmd )
            else :
                print ( line )

        #unique the gsm
        lst.append( gsm )



















