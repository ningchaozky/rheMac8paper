#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import json
import argparse
from ningchao.nSys import trick,nfile,convert


parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('computMatrixOut', nargs='?', help ='computeMatrix output file')
parser.add_argument('-dh', action='store_true', help ='delete the header infor')
parser.add_argument('-o', nargs='?', help ='output file, default sys.stdout')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
ofh = sys.stdout
if args.o:
    ofh = open(out,'w')
computMatrixOut = nfile.file(args.computMatrixOut).open()
header = computMatrixOut.next().strip().strip('@')
header_dit = json.loads(header, object_hook=convert.convert)
for line in computMatrixOut:
    ofh.write(line)

























