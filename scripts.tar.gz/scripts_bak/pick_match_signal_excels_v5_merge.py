#!/usr/bin/env python3
import os
import sys
import matplotlib as mpl
mpl.use('Agg')
from  itertools import chain, combinations
#mpl.rcParams['pdf.fonttype'] = 42
#mpl.rcParams['ps.fonttype'] = 42
#mpl.rcParams['svg.fonttype'] = 'none'
#import matplotlib.pyplot as plt
#plt.tight_layout()
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
#plt.style.use('ggplot')
#plt.subplots_adjust(wspace=0, hspace=0)
#import seaborn as sns;sns.set(color_codes=True)
#sns.set_style("ticks")
#sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system
desc = ''' before_merge_files.match1 RNA.tpm.mini.de80.tmp.match.sum.match1.keep_one'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('match', nargs='?', help = 'match1')
parser.add_argument('keep_one', nargs='?', help = 'keep_one')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


def parse_RNA():
    infor = defaultdict( list )
    with open( args.keep_one ) as f:
        next(f)
        for line in f:
            line_arr = line.rstrip().split('\t')
            infor[line_arr[-1]].append( line_arr[0].split('.')[0].upper() )
    return infor

def set_value( stage_specific ):
    order = [ 'compartment', 'tad', 'K27ac', 'K4me3', 'Pol2', 'dnase', 'K27me3' ]
    order_com = list(chain(*map(lambda x: combinations(order, x), range(0, len(order)+1))))
    order_dit = dict( zip( order_com, range(len(order_com))))
    print ( order_dit )
    infor = defaultdict( lambda : defaultdict( list ) )
    infor_raw = defaultdict( lambda : defaultdict( list ) )
    ofh = defaultdict( str )
    periods = system.dir.periods( prefrontal_raw = True )
    with open( args.match ) as f :
        for line in f :
            line_arr = line.rstrip().split('\t')
            period = line_arr[-1]
            symbol = line_arr[1].split('.')[0].upper()
            dit = dict( zip( periods, line_arr[1:-1] ))
            for o in order :
                if o in line_arr[0]:
                    infor[symbol][period].append(o)
                    infor_raw[symbol][o].append( '\t'.join( line_arr[1:-1] ) )
    for o in order :
        ofh[o] = open(o + '.tab', 'w')
        print ( 'symbol', *periods, sep = '\t', file = ofh[o])
    for s in infor :
        for o in order:
            if o in infor_raw[s]:
                val = trick.lst( infor_raw[s][o] ).pick( pt = 'sum' )[1:]
                print ( s, *val, sep = '\t', file = ofh[o] )
                #print ( *infor_raw[s][o], sep = '\n', file = ofh[o] )
            else :
                print ( s, *[ 0 for i in range(7)], sep = '\t', file = ofh[o] )
    if 0 :
        for s in infor:
            for o in order:
                line_arr = [s]
                for p in periods:
                    if p in infor[s] and o in infor[s][p]:
                        line_arr.append( infor_raw[symbol][period][o] )
                    else :
                        line_arr.append(0)
                print ( *line_arr, sep = '\t', file = ofh[o] )
    cmaps = ['Greys', 'Purples', 'Blues', 'Greens', 'Oranges', 'Reds',
                      'YlOrBr', 'YlOrRd', 'OrRd', 'PuRd', 'RdPu', 'BuPu',
                      'GnBu', 'PuBu', 'YlGnBu', 'PuBuGn', 'BuGn', 'YlGn']
    for o in ofh:
        ofh[o].close()
        cmd = 'heatmap_seaborn.py {} -z_score 0 -cmap {}'.format(ofh[o].name, cmaps.pop(0))
        os.system(cmd)



if __name__ == '__main__':
    stage_specific = parse_RNA()
    set_value( stage_specific )
























