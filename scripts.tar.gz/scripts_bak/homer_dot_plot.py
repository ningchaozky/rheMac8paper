#!/usr/bin/env python3
import os
import sys
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import argparse
import pandas as pd
import numpy as np
from collections import defaultdict
from ningchao.nSys import trick, system
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( 'dir', nargs = '?', help = 'homer run root dir. look /dataE/rawdata/zhufei/atac/degseq2/noPHD6')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

def motif_parse( Dirs, top = 30):
    infor, uniq_motifs = defaultdict( lambda : defaultdict() ), set()
    for Dir in Dirs:
        motifs = system.dir( Dir ).fls('\.motif$', depth = 2, abspath = True)
        for motif in motifs:
            print ( motif, file = sys.stderr )
            cluster = os.path.dirname( motif )
            cluster, typ = os.path.split( cluster )
            cluster = os.path.basename(cluster)
            print ( cluster )
            with open( motif ) as f:
                line_arr = next(f).strip().split('\t')
                bestmatch, pvalue = line_arr[1].replace('/Homer',''), line_arr[-1].split(',')[-1]
                infor[cluster][bestmatch] = float(pvalue.replace('P:',''))
                uniq_motifs.add( bestmatch )
        infor[cluster] = { v[0]:v[1] for i,v in enumerate( sorted ( infor[cluster].items(), key = lambda x: x[1], reverse = False)) }
    df = pd.DataFrame( infor )
    df.to_csv( 'uniq_motifs.xls', sep = '\t', header = True, index = True, index_label = df.index.names )
    for cluster in infor :
        infor[cluster] = { v[0]:v[1] for i,v in enumerate( sorted ( infor[cluster].items(), key = lambda x: x[1], reverse = False)) if i < top }
    return infor

def plot_prepare( dit ):
    lst = []
    fig,ax = plt.subplots(figsize=(10,30))
    ax2 = ax.twinx()
    clusters, motifs = [], []
    for cluster in dit:
        if 'peak' in cluster:
            continue
        clusters.append(cluster)
        for motif in dit[cluster]:
            motifs.append( motif )
            pvalue = dit[cluster][motif] == 0 and 1e-310 or dit[cluster][motif]
            size = -math.log10(pvalue)
            lst.append([ cluster, motif, size])
            s = size
            ax.scatter( cluster, motif, s = s )
            ax2.scatter( cluster, motif, s = 0)
    for cluster in dit:
        for motif in motifs:
            if motif not in dit[cluster]:
                ax.scatter( cluster, motif, s = 1 )
    #ax.set_xticks(list(range(len(clusters))))
    #ax.set_xticklabels(clusters, rotation = 45 )
    #ax.set_yticks(np.arange(len(motifs)))
    #ax.set_yticklabels(motifs)
    #ax2.set_yticks(np.arange(len(motifs)))
    #ax2.set_yticklabels(y2s)
    #fig.tight_layout()
    plt.grid(color='r', linestyle='dotted', linewidth=0)
    plt.savefig('test.pdf', transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
    return pd.DataFrame(lst, columns = ['cluster','motif', 'pvalue'])

if __name__ == '__main__':
    dirs = [ os.path.dirname(i) for i in system.dir(args.dir).fls('homerResults', fdir = True, depth = 10, abspath = True) ]
    infor = motif_parse( dirs )
    df = plot_prepare( infor )
    df.to_csv( 'motif.xls', index_label = 'ID', sep = '\t')


























