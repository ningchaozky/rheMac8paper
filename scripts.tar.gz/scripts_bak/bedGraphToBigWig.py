#!/usr/bin/env python
import os
import sys
import argparse
from ningchao.nSys import trick, system, fix
import ningchao.nBio.chromosome as chrom
example = '''pattern'''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('p', nargs='?', help = 'pattern for bdg file')
parser.add_argument('-gs', nargs='?', help = 'genome size file', required = True)
parser.add_argument('-clean', action = 'store_true', help = 'clean_no_chr_line' )
parser.add_argument('-d', nargs='+', help = 'depth for find file', default = [ 0 ] , type = int)
parser.add_argument('-sort', action = 'store_true', help = 'sort' )
parser.add_argument('-clip', action = 'store_true', help = 'bed clip' )
parser.add_argument('-fp', nargs = '?', help = 'fitter pattern' )
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def convert( bdg, clean, sort, clip, gs):
    sizeFile, cmds, bw = args.gs, [], fix.fix( bdg ).change('bw')
    if clean:
        chrbdg = fix.fix(bdg).insert('chr')
        cmd = 'clean_no_chr_line.py %s %s' % ( bdg, gs)
        cmds.append( cmd )
    else :
        chrbdg = bdg
    if clip:
        bdg_clip = fix.fix(chrbdg).insert('clip')
        cmd = 'bedClip %s %s %s' % ( chrbdg, sizeFile, bdg_clip )
        cmds.append( cmd )
    else :
        bdg_clip = chrbdg
    if sort:
        sort_out = fix.fix( bdg_clip ).insert('sort')
        cmd = 'sort -k1,1 -k2,2n %s > %s' % ( bdg_clip, sort_out )
        cmds.append( cmd )
    else :
        sort_out = bdg_clip
    cmd = 'bedGraphToBigWig %s %s %s' % ( sort_out, sizeFile, bw)
    cmds.append(cmd)
    #cmd = 'rm %s' % ' '.join([bdg, chrbdg, sort_out])
    #cmds.append(cmd)
    return cmds


fls = list (system.dir('.').fls(args.p, fpattern = args.fp, depth = args.d, abspath = False) )
if len( fls ) == 0:
    fls = [ args.p ]
if not len(fls) :
    print ('Find null file for bdg2bw....')
for bdg in fls:
    cmds = convert( bdg, args.clean, args.sort, args.clip, args.gs)
    for cmd in cmds:
        print (cmd)






























