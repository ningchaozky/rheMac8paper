#!/usr/bin/env python3
import os
import sys
import gzip
import json
import math
import numpy as np
import matplotlib as mpl
import pandas as pd
from scipy.stats import zscore
mpl.use('Agg')
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
plt.tight_layout()
#plt.savefig( figname, dpi=250, transparent=True, facecolor=fig.get_facecolor(), edgecolor='none')
#plt.tick_params( axis = 'both', left = True, labelleft = True, which = 'both', bottom = True, top = False, labelbottom = True, direction = 'in' )
#sns.despine( ax = ax[2]  )#remove top and right axis
#subplot define, also polar plot
#with sns.axes_style("whitegrid", {'xtick.top': True, 'ytick.left': True, 'axes.grid': False, 'ytick.color': 'black', 'ytick.direction': 'in' }):
    #fig, ax = plt.subplots( 6, figsize=(10,40), subplot_kw=dict(projection=None))
	#fig,ax = plt.subplots( 3, figsize=(10,30), sharex=True, sharey=True, subplot_kw=dict(projection='polar')); ax[0],ax[1]
plt.style.use('ggplot')
plt.subplots_adjust(wspace=0, hspace=0)
import seaborn as sns;sns.set(color_codes=True)
sns.set_style("ticks")
sns.barplot( palette="Set3" )
#fig = plt.figure( figsize=( 18, 24) )
import argparse
from collections import defaultdict
from ningchao.nSys import trick, system, fix
desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('m', nargs='?', help = 'marker')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()

periods = system.dir.periods( prefrontal_raw = True )
def get_data():
    cmds,gzs = [],[]
    for p in periods:
        gz = fix.fix(args.m).append(p,'gz')
        gzs.append( gz )
        continue
        bw = system.run('''project_beds_bws_bams_andSoOn_pos.py {} {} bw -s ' ' -u 2> /dev/null'''.format(args.m, p), shell = True)[0]
        tad = system.run('''project_beds_bws_bams_andSoOn_pos.py TAD {} bed -s ' ' -u 2> /dev/null'''.format(p), shell = True)[0]
        pdf = fix.fix(gz).append('pdf')
        cmd = 'computeMatrix scale-regions -S {} -R {} -a 1000 -b 1000 -bs 10 --regionBodyLength 2000 -o {}'.format( bw, tad, gz)
        cmds.append( cmd )
        cmd = 'plotHeatmap -m {} -o {}.pdf'.format( gz, pdf)
        cmds.append( cmd )
    return cmds, gzs


def arr_get_cor( arr, num = 10 ):
    arr_length = len(arr)
    arr = map( lambda x : 0 if 'nan' in x else float(x), arr )
    lst = []
    for each in arr:
        lst.append([ each, *[ next(arr) for _ in range( num - 1 ) ] ] )
    cor = np.corrcoef( lst )
    cor[np.isnan(cor)] = 0
    return cor


def plot_data( gzs ):
    infor = defaultdict( lambda : defaultdict( float) )
    #ax = plt.add_subplot(len(gzs))
    figs_num = len(gzs)
    fig = plt.figure(figsize=(10, 10 * figs_num))
    for j,gz in enumerate(gzs) :
        if not os.path.exists(gz) :
            print ('Not exists: {}'.format(gz), file = sys.stderr)
            continue
        with gzip.open(gz) as f:
            header = next(f).decode().replace('@','')
            header_dit = json.loads( header )
            bs = header_dit['bin size'][0]
            cor, i = 0, 0
            for line in f:
                i += 1
                line = line.decode()
                line_arr = line.strip().split('\t')
                cor += arr_get_cor(line_arr[6:])
            df = pd.DataFrame(cor)
            ax = fig.add_subplot( figs_num, 1, j + 1 )
            #df = zscore( df, axis = 0, ddof=1).round(4)
            sns.heatmap( df, cmap = 'magma', robust = True, linewidths = 0, linecolor = None, ax = ax )
            plt.ylabel( gz )
    plt.savefig( 'test.pdf', dpi=250, transparent = True, edgecolor='none')
if __name__ == '__main__':
    cmds, gzs = get_data()
    print ( *cmds, sep = '\n' )
    df = plot_data( gzs )

























