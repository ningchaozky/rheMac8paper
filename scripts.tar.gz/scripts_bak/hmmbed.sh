#!/usr/bin/env sh
if [ $# -lt 1 ]; then
	echo $0 numberOfStat
	exit 1
fi

echo you choose stat number is $1
echo you choose configure file is cellmarkfiletableBed

java -mx50000M -Djava.awt.headless=true -jar /home/soft/soft/ChromHMM/ChromHMM.jar BinarizeBed /home/ningch/data/genome/rheMac8/rheMac8.chrom.sizes . cellmarkfiletableBed BinarizeBed
#java -mx50000M -Djava.awt.headless=true -jar /home/soft/soft/ChromHMM/ChromHMM.jar LearnModel -init random BinarizeBed LearnModelBed $1 rh8 
java -mx50000M -Djava.awt.headless=true -jar /home/soft/soft/ChromHMM/ChromHMM.jar LearnModel BinarizeBed LearnModelBed $1 rh8 
