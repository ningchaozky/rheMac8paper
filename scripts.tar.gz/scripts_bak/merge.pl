#!/usr/bin/perl -w

unless(@ARGV){
	print "\n\tUsage:\t$0 infor.txt [1]\n\n";
}
else{

	open $infor,"$ARGV[0]";
	open $as," > assemblies.txt";
	open $sh,"> merge.sh";
	while(<$infor>){
		chomp;
		unless(/#/){
			@tmp = split /\s+/,$_,2;
			$infor{$tmp[0]} = $tmp[1];
		}	
	}
	@tmp = split /\s+/,$infor{"assemble"};
	for(@tmp){
		chomp;
		if(/^all/i){
			for(keys %infor){
				if(/^sample/i){
					$infor{$_} =~ s/_[12]\..*//;
					$cmd_1 .= `find /$infor{'output_dir'}/$infor{'contract'}/assemble/$infor{$_} -name transcripts.gtf`;
				}
			}
		print $as $cmd_1;
		}
	}
	`mv assemblies.txt /$infor{'output_dir'}/$infor{'contract'}/assemble/assemblies.txt`;
	`mkdir -p /$infor{'output_dir'}/$infor{'contract'}/assemble/cuffmege_out`;
	$cmd_assemble = "cuffmerge -g /$infor{'annotation'} -o /$infor{'output_dir'}/$infor{'contract'}/assemble/cuffmege_out -s /$infor{'genome'} -p 8 /$infor{'output_dir'}/$infor{'contract'}/assemble/assemblies.txt";
	print $sh $cmd_assemble;
		if(@ARGV >=2){
			`sh merge.sh`;
		}
}
