#!/usr/bin/perl -w
#
#
#
#
my $match;
my $blast;
my $out;

use Getopt::Long;
GetOptions ("match|m=s"		=>	\$match,
			"blast|b=s"		=>	\$blast,
			"out|o=s"		=>	\$out,
			"help|h"		=>	\$help);

if($help){
print STDOUT	<<EOF;
Usage:
		match|m			you file you want to translate	Eg:	HarmOR1	gi|879731|
		blast|b			each line contain the information 
		out|o			output file 
		help|h			help message

EOF
		exit(3);
}

open Match, "< $match";
open Blast,	"< $blast";
open OUT,	"> $out";

my %hash;
while(<Match>){
chomp;
my ($key,$value) = split /\s+/,$_;
$hash{$key} = $value;
}


while (my $eachline = <Blast>){
chomp $eachline;
if($eachline =~ /^(.*)\t.*gi(\d+)\|\t(.*)$/){
my $bf = $1;
my $af = $3;
my $name;
my $count=0;
while(my ($key,$gi) = each %hash){
if($eachline =~ /$gi/){
$count++;
print OUT "$bf\t$key\t$af\n";
}
}
if($count==0){
print OUT "$eachline\n";
}
}
}

close Match;
close Blast;
close OUT;
