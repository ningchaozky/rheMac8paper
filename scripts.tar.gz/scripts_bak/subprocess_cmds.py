#!/usr/bin/env python3
import os
import sys
import argparse
import threading
from ningchao.nSys import trick, system
from multiprocessing import Pool
example = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('cmds', nargs='?', help = 'cmds for subprocess exe')
parser.add_argument('-n', nargs='?', help = 'process numbers. 5', default = 5, type = int)
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()


class MyThread(threading.Thread):
    def __init__(self, marker):
        super(MyThread, self).__init__()  # 重构run函数必须要写
        self.n = marker

    def run(self):
        print("task", self.marker)
	
def run( cstr ):
    sys.stderr.write( cstr +'\n' )
    stdout =  os.popen(cstr).readlines()
    for std in stdout:
        print ( std )
cmds = [ i.strip() for i in open(args.cmds).readlines() if i.strip() ]
with Pool( args.n ) as p:
    p.map( run, cmds )
    #p.imap( run, cmds )
    #p.apply_async( run, cmds )































