#!/usr/bin/env python
#-*- coding: utf-8 -*-
import os
import sys
import argparse
import matplotlib
import pandas as pd
matplotlib.use('Agg')
from kneed import KneeLocator
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
from ningchao.nSys import trick,fix,excel
from sklearn.cluster import KMeans

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('matrix', nargs='?', help ='matrix for input')
parser.add_argument('-icol', nargs ='*',type = int, help ='index col for the matrix', default = [ 1 ] )
parser.add_argument('-scol', nargs ='*',type = int, help ='select col for the matrix')
parser.add_argument('-o', nargs='?', help ='prefix for the output file' )
parser.add_argument('-k', nargs='?', type = int, help ='clusters')
parser.add_argument('-sw', action='store_true', help ='print header')
parser.add_argument('-kneed', action='store_true', help ='get the cluster number')

if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()



def parse( args ):
    #使用K-Means算法聚类matrix
    #参数初始化
    iteration, ucols = 1000, [] #聚类最大循环次数
    matrix,icol,scol, output = args.matrix, args.icol, args.scol, args.o
    mheader = excel.xls( matrix).header()
    mcols = [ i for i,v in enumerate( mheader )]
    if args.sw :
        for each in sorted(zip(mheader,mcols)):
            each = list(each)
            each[1] = each[1] + 1
            print(','.join([ str(i) for i in list(each) ]))
        exit()
    if output :
        outputfile = fix.fix(output).append('tab')
    else :
        outputfile = fix.fix( matrix ).append('tab')
    icol = [ i-1 for i in icol ]
    if not scol:
        ucols = mcols
        sys.stderr.write('!!Select %s for kMean analysis\n' % str(trick.lst(mheader).get(ucols)))
    else :
        ucols = []
        if isinstance( icol, int ):
            ucols = [ icol ]
        elif isinstance( icol, list ) :
            ucols = icol[:]
        ucols.extend([i-1 for i in scol ])
        scol = [ i-1 for i in scol if i-1 not in icol ]
        ucols, scol = trick.lst(ucols).uniq(), trick.lst(scol).uniq()
        sys.stderr.write('!!Select %s for kMean analysis\n' % str(trick.lst(mheader).get(ucols)))
    data = pd.read_table(matrix, index_col = icol, usecols = ucols).reindex(columns = trick.lst(mheader).get(scol)) #read data
    if args.k :
        k = args.k
    else :
        k = len(data.dtypes)
    return data, k, iteration, outputfile
    #return matrix,mheader, iteration,icol, ucols, scol, k, outputfile, data
def density_plot(data): #自定义作图函数
#    plt.rcParams['font.sans-serif'] = ['SimHei'] #用来正常显示中文标签
#    plt.rcParams['axes.unicode_minus'] = False #用来正常显示负号
    p = data.plot(kind='kde', linewidth = 2, subplots = True, sharex = False)
    [p[i].set_ylabel('density') for i in range(k)]
    plt.legend()
    return plt

if __name__ == '__main__':
    data, k, iteration, outputfile = parse( args )
    data_zs = 1.0*(data - data.mean())/data.std() #数据标准化
    #model = KMeans(n_clusters = k, n_jobs = 4, max_iter = iteration) #分为k类，并发数4
    # cluster num check 
    sse, silhouette_coefficients  = [], []
    kmeans_kwargs = {
        "init": "random",
        "n_init": 10,
        "max_iter": 10000,
        "random_state": 42,
    }
    test_region = int( 1.5 * k )
    print ( 'test region is %d\n' % test_region )
    if args.kneed :
        for k in range(2, test_region):
            sys.stderr.write('Test cluster num is %d\n' % k )
            kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
            kmeans.fit( data_zs )
            score = silhouette_score( data_zs, kmeans.labels_)
            sse.append(kmeans.inertia_)
            silhouette_coefficients.append(score)
    
        kl = KneeLocator(
            range(2, test_region), sse, curve="convex", direction="decreasing"
        )

    #plot
        plt.style.use("fivethirtyeight")
        plt.plot(range(2, test_region), silhouette_coefficients)
        plt.xticks(range(2, test_region))
        plt.xlabel("Number of Clusters")
        plt.ylabel("Silhouette Coefficient")
        plt.savefig('cluster_num_check.png')
        exit('kneed is %s. U can not use kneed paremeter to cluster\n' % str( kl.elbow ))

    model = KMeans(n_clusters = k, **kmeans_kwargs ) #分为k类，并发数4
    model.fit(data_zs) #开始聚类
    #简单打印结果
    r1 = pd.Series(model.labels_).value_counts() #统计各个类别的数目
    r2 = pd.DataFrame(model.cluster_centers_) #找出聚类中心
    r = pd.concat([r2, r1], axis = 1) #横向连接（0是纵向），得到聚类中心对应的类别下的数目
    r.columns = list(data.columns) + ['clust_num'] #重命名表头
    print(r)

    #详细输出原始数据及其类别
    r = pd.concat([data, pd.Series(model.labels_, index = data.index)], axis = 1)  #详细输出每个样本对应的类别
    r.columns = list(data.columns) + ['cluster'] #重命名表头
    
    r.to_csv(outputfile,sep = '\t') #保存结果
    pic_output = fix.fix(outputfile).change('') #概率密度图文件名前缀
    
#    for i in range(k):
#        density_plot(data[r['cluster']==i]).savefig('%s%s.png' %(pic_output, i))
    if 0 :
        sort_cols = trick.lst(excel.xls(matrix).header()).get(ucols)
        print(sort_cols)
        sort_cols.insert(0,'cluster')
        ascending = [ False ] * len(sort_cols)
        sort_cols = ['cluster']
        ascending = [ True ]
        r2 = r.sort(sort_cols, ascending= ascending )
        r2.to_csv(outputfile+'.sort',sep = '\t')













