#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='print useage for script', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('bed', nargs='?', help ='3 column bed file for motif find')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
bed = args.bed
bed_tmp = bed + '.tmp'
bfh = open(bed)
btfh = open(bed_tmp, 'w')

for i,line in enumerate(bfh):
    btfh.write(line.strip() + '\t' + 'peak_' + str(i) +'\n')

btfh.close()
bfh.close()
work_dir = os.path.dirname(bed)
print('cd %s' % work_dir)
print('findMotifsGenome.pl %s rheMac8 ER_MotifOutput -size 200 -mask\n' % os.path.basename(bed_tmp))




























