#!/usr/bin/env perl 
use strict;
use warnings;
use Statistics::R;

my $a=1;  
my $R = Statistics::R->new();
   $R->startR;  $R->send(qq`library(GO.db)\nGOBPANCESTOR\$\'GO:0001868\'`) ;   
   my $ret = $R->read;  
   print $ret,"\n";  
#输出R的处理结果  
$R->stopR();
