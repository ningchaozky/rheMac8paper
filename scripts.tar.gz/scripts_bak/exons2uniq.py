#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,fix

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='exons get gene infor', formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument( '-beds', nargs='*', help ='beds to merge gene' )
parser.add_argument( '-op', nargs='?', help ='output prefix' )
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
ofh = sys.stdout
beds = args.beds
prefix = fix.fix(args.op)
efh = open(prefix.append('uniqExon'),'w')
#gfh = open(prefix.append('uniqGene'),'w')

def parse(line):
    infor = {}
    line_arr = line.strip().split('\t')
    names = line_arr[3].split('.')
    name = names[0]
    gname = '.'.join(names[0:2])
    key = '\t'.join([ line_arr[0], line_arr[1], line_arr[2], name, line_arr[5] ])
    trick.set2dict(infor,key,'raw','\t'.join(line_arr[0:7]))
    return line_arr[0], line_arr[1], line_arr[2], key, infor, gname


uniq = {}
name_uniq = {}
for bed in beds:
    bfh = open(bed)
    fchrom,fstart,fend,fkey,finfor,flname = parse(next(bfh))
    exons = [fstart,fend]
    trick.set1dict( name_uniq, flname, 0 )
    efh.write(finfor[fkey]['raw'] + '\n')   
#   gfh.write(finfor[fkey]['raw'].replace('.exon_0','') + '\n')
    for line in bfh:
        chrom,start,end,key,infor,lname = parse(line)
#exon deal with
        if key not in uniq:
            trick.set1dict(uniq,key, 0 )
            efh.write(infor[key]['raw'] + '\n')
        else :
            uniq[key] += 1
#gene get from the exons
        























