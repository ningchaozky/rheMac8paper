#!/usr/bin/env python
import os
import sys
import argparse
import ningchao.nSys.env as envTookit
import ningchao.nSys.trick as trickTookit
from tempfile import NamedTemporaryFile

parser = argparse.ArgumentParser(prog = sys.argv[0],description='')
parser.add_argument('xls', nargs='+', help ='excel and cols you want to add num and uniq')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()




def parse( args ):
    xls = args.xls
    col = len(xls) == 2 and int(xls[1]) - 1 or 0 
    return xls[0], col


if __name__ == '__main__':
    xls,col = parse( args )
    xfh, lst = open( xls ), []
    f = NamedTemporaryFile(prefix='mytemp', suffix='.txt', dir='.', delete = False )
    for i,line in enumerate(xfh):
        line_arr = line.strip().split('\t')
        if line_arr[col] not in lst:
            #line_arr[col] = line_arr[col] + '.' + str( i )
            f.write( '\t'.join(line_arr) + '\n' )
            lst.append( line_arr[col] )
    f.close()
    cmd = 'mv %s %s' % (f.name, xls)
    os.system( cmd )
