#!/usr/bin/env python
import ningch as nc
import os
import sys
import re


nc.usage('str:jobs_id, ...')

jobs = sys.argv[1:]
p = re.compile(r'\n\t',re.M)
harr = {}
for each in jobs:
	stdout,stderr = nc.run_sys('qstat -f %s' % each)
	info = ''
	next(stdout)
	for line in stdout:
		info += line
	infors = iter(p.sub('',info).split('\n'))
	for e in infors:
		e_arr = e.split('=')
		e_arr = [i.strip() for i in e_arr]
		e = e.strip()
		if e == '':
			continue
		harr[e_arr[0]] = e_arr[1]
	print('job id:\t\t\t\t'+each)
	print('job name:\t\t\t'+harr['Job_Name'])
	print('init_work_dir:\t\t\t'+harr['init_work_dir'])
	print('submit_args:\t\t\t'+harr['submit_args'].replace('-h','').strip())
	print('server:\t\t\t\t'+harr['server'])
	print('submit_host:\t\t\t'+harr['submit_host'])
	print('init_time:\t\t\t'+harr['etime'])
	print('Output_Path:\t\t\t'+harr['Output_Path'])
	print('Error_Path\t\t\t'+harr['Error_Path'])
	print('resources_used.walltime:\t'+harr['resources_used.walltime'])
	print('resources_used.cput:\t\t'+harr['resources_used.cput'])
	print('resources_used.mem\t\t'+str(int(harr['resources_used.mem'].replace('kb',''))/1024.0/1024)+'GB')
	print('resources_used.vmem\t\t'+str(int(harr['resources_used.vmem'].replace('kb',''))/1024.0/1024)+'GB')


