#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick
from ningchao.nBio import bw
example = ''' fixWig '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s %s' % (os.path.basename(sys.argv[0]), example), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('fixWig', nargs='?', help ='reference')
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()


fixWig = args.fixWig
fh = bw.fixBigWig(fixWig).open()
for line in fh:
    if line.startswith('fixedStep'):
        line_arr = line.strip().split(' ')
        chrom = line_arr[1].split('=')[1]
        start = int(line_arr[2].split('=')[1]) - 2
        step = int(line_arr[3].split('=')[1])
        continue
    start += step
    end = start + 1
    print('\t'.join([ str(i) for i in (chrom,start,end,line.strip()) ]))


























