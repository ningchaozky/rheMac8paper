#!/usr/bin/env python3
import os
import sys
import argparse
import random
import multiprocessing as mp
from collections import defaultdict
from ningchao.nSys import trick, fix, system

desc = ''' '''
parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description=desc, formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('tab', nargs='?', help = 'file for sort')
parser.add_argument('-i', nargs='?', help = 'header how many lines', default = 1, type = int)
parser.add_argument('-s', nargs=2, help = 'pos for split', default = 3, type = int)
parser.add_argument('-c', nargs='?', help = 'sort commmand for sort')
parser.add_argument('-o', nargs='?', help = 'output for sort')
if len(sys.argv) == 1:
    parser.print_help().__str__
    sys.exit(2)
args = parser.parse_args()



def sort_file( files ):
    with mp.Pool(6) as p:
        p.map( sort_fun, [ *list(files.values()) ] )
        #os.spawnlp( os.P_NOWAIT, *cmds  )
        #files[chrom] = fix.fix( files[chrom].name ).append('sorted')
    p.close()
    p.join()
    for key in files:
        files[key] = fix.fix(files[key]).append('sorted')
    return files
def sort_fun( infile ):
    sorted_file = fix.fix( infile ).append('sorted')
    cmds = [ 'sort', '-k4,4n', infile, '-o', sorted_file  ]
    stdout_arr, stderr_arr, returncode = system.run( ' '.join(cmds) )
    #system.run( ' '.join(cmds), shell = True )

def split_to_chrom():
    files = defaultdict( str )
    with open( args.tab ) as f :
        [ next(f) for i in range(args.i) ]
        i = 0
        for line in f :
            line_arr = line.strip().split('\t')
            chrom = line_arr[args.s -1]
            random_str = ''.join(random.sample( [ chr(i) for i in range(97,123)  ], k = 4))
            chrom_tmp_file = fix.fix( chrom ).append('{}.{}.tmp'.format( random_str, os.path.basename(args.tab)))
            if chrom not in files :
                files[chrom] = open(chrom_tmp_file,'w')
            print ( line.strip(), file = files[chrom] )
    for key in files:
        files[key].close()
        files[key] = files[key].name
    kwargs.update({'files': files})
    return files
if __name__ == '__main__':
    kwargs = vars( args )
    samtools_path = '/home/soft/soft/samtools/v1.10/bin/samtools'
    files = split_to_chrom()
    sort_file( files )
    #chroms = [ i for i in sorted(list(files.keys())) if 'lambda' not in i ]
    chroms = [ i for i in sorted(list(files.keys())) ]
    cat_files = [ files[i] for i in chroms ]
    if args.o :
        cmd = 'cat {} > {}'.format(' '.join(cat_files), args.o )
    else :
        cmd = 'cat {} > {}'.format(' '.join(cat_files), fix.fix(args.tab).insert('sorted') )
    system.run( cmd, shell = True )



























