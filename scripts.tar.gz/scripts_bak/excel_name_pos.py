#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
import argparse
from ningchao.nSys import trick,excel

parser = argparse.ArgumentParser(prog = sys.argv[0] + os.linesep,description='%s ' % os.path.basename(sys.argv[0]), formatter_class= argparse.RawTextHelpFormatter)
parser.add_argument('xls', nargs='?', help ='excel input')
parser.add_argument('-col', nargs='?', help ='excel input' )
parser.add_argument('-namePattern', nargs='*', help ='length 4, pick the pos 2', default = [ 4, 2 ], type = int)
if len(sys.argv) == 1:
	parser.print_help().__str__
	sys.exit(2)
args = parser.parse_args()
xls = excel.xls(args.xls)
col = args.col
namePattern = args.namePattern
if not col:
    print(xls.lstinfor( sort = False ))
else :
    col = int(col) - 1
    xfh = open(args.xls)
    for line in xfh:
        line_arr = line.strip().split('\t')
        names = line_arr[col].split(',')
        for i in range(len(names)/namePattern[0]):
            line_arr[col] = names[(i + 1) * (namePattern[1] - 1)]
        print('\t'.join(line_arr))



























